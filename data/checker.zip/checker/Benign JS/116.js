SuperSuperSuperSuperSuperSuperSuperSuperSuperSuperSuperSuperLongCall((err, result) => {
  // comment
});

func(one, two, three, four, five, six, seven, eig, is, this, too, long, no, []);
func(one, two, three, four, five, six, seven, eig, is, this, too, long, yes, []);
func(one, two, three, four, five, six, seven, eig, is, this, too, long, yes, [
  // Comments
]);
func(five, six, seven, eig, is, this, too, long, yes, [
  // Comments
]);

func(one, two, three, four, five, six, seven, eig, is, this, too, long, no, {});
func(one, two, three, four, five, six, seven, eig, is, this, too, long, yes, {});
func(one, two, three, four, five, six, seven, eig, is, this, too, long, yes, {
  // Comments
});

foo(
  (
    one,
    two,
    three,
    four,
    five,
    six,
    seven,
    eight,
    nine,
    ten,
    eleven,
    twelve,
    thirteen,
    fourteen,
  ) => {},
);

const contentTypes = function(tile, singleSelection) {
  return compute(
    function contentTypesContentTypes(
      tile,
      searchString = '',
      filteredContentTypes = [],
      contentTypesArray = [],
      selectedGroup,
      singleSelection) {
      selectedGroup = (tile.state && tile.state.group) || selectedGroup;
    }
  );
};