require('object.assign').shim();
require('es6-map/implement');