(function() {}).length
typeof (function() {});
export default (function() {})();
(function() {})()``;
(function() {})``;
new (function() {});
(function() {});
a = function f() {} || b;
(function() {} && a);
a + function() {};
new function() {};