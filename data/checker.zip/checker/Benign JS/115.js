const els = items.map(item => (
  <div className="whatever">
    <span>{children}</span>
  </div>
));