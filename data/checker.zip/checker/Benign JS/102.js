const dog = {
  @readonly
  @nonenumerable
  @doubledValue
  legs: 4
};