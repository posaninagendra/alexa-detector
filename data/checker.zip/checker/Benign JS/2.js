setTimeout(() => {
  module.exports = { a: 'hello' };
}, 0);