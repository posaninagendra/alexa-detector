export const langTagRegex = /^[a-z]{2}(?:-[a-zA-Z]{2,3})?$/;
export default {
  en: 'English',
  es: 'Spanish'
};