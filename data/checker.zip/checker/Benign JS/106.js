import("module.js");
import("module.js").then((a) => a);