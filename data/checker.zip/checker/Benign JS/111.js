
declare module X {
  declare interface Y { x: number; }
}