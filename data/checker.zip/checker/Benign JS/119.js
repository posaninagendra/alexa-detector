Object.keys(
  availableLocales({
    test: true
  })
)
.forEach(locale => {
  // ...
});