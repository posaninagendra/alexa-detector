/* @flow */

"use strict";

import a from "a";

a();