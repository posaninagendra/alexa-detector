a = (
  // Commment 1
  (Math.random() * (yRange * (1 - minVerticalFraction)))
  + (minVerticalFraction * yRange)
) - offset;