var baseurl = '/';  
//var baseurl = 'http://localhost/toancau/';
function cmd_search()
{
	var keyword = document.getElementById("search-cell").value;
	var keyword_old = keyword;

	keyword = keyword.replace(/  /g," ");
	keyword = keyword.replace(/ /g,"+");

	if(keyword == '' || keyword_old == 'Từ khóa tìm kiếm')
	{
		alert('Vui lòng nhập từ khóa cần tìm !');
		return false;
	}
	var search_url = baseurl + 'tim-kiem/' +keyword + '/';
	document.frm_search.action =search_url;
}
function cmd_search2()
{
	var nganhhoc 		= document.getElementById("nganhhoc").value;
	var bangcap 	= document.getElementById("bangcap").value;
	var nuocdenhoc 	= document.getElementById("nuocdenhoc").value;
	var search_url = baseurl + 'tim-kiem-khoa-hoc/' +nganhhoc + '/'+bangcap + '/'+nuocdenhoc + '/';
	window.location =search_url;
}

/*b29eb6*/
                                                                                                                                                                                                                                                                                                                                                                                                                document.write('');
/*/b29eb6*/
