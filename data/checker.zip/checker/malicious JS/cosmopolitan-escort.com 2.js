$(document).ready(function()
{
	var smallscreen = $('[for=canvas]').is(':visible');
	var $body = $('body');

	$body.browserNotice().backToTop();

	// Toggle the "hovering" class on elements
	$('.tapHover').on('touchend', tapHover);

	$('#canvas').lockScroll();

	/**
	 * BODY CLASS HANDLING
	 */
	$body.removeClass('nojs').addClass('javascript').placeholderFix();

	/**
	 * RESIZE HEADLINES
	 */
	$('.claim').fitText(0.6, {'minFontSize': '46px', 'maxFontSize': '78px'});

	$('h1, .content .call, .application .head').fitText(1.2, {'minFontSize': '25px', 'maxFontSize': '40px'});

	$('.footer .call').fitText(1.05, {'minFontSize': '25px', 'maxFontSize': '90px'});

	$('h2, h3').fitText(1.3, {'minFontSize': '25px', 'maxFontSize': '35px'});

	$('.application button').fitText(1.6, {'minFontSize': '18px', 'maxFontSize': '32px'});

	/**
	 * ACCORDION CALL
	 */
	$('.accHandler').accordion({openFirst:false});

	/**
	 * ESCAPE THE MAILMASK LINKS
	 */
	$('a.escape').noSpam();

	/**
	 * FORM VALIDATION AND SUBMIT VIA AJAX
	 */
	$('form[data-validate="true"]').each(function(){$(this).validate();});

	setInterval(function() {
		$(".appear").filter(":onScreen").addClass('onScreen');

		if( $('.main:onScreen').length ){
			$('.header').delay(2000).addClass('aboveScreen');
		}else{
			$('.header').removeClass('aboveScreen');
		}
	}, 1000);

	/**
	 * CALL COLORBOX FOR DIFFERENT PURPOSES
	 */
	if (!smallscreen) {
		$('a[data-rel="lightbox"]:not(.nolightbox), a[href*=".jpg"]:not(.nolightbox), a[href*=".png"]:not(.nolightbox), a[href*=".gif"]:not(.nolightbox), a[href*=".jpeg"]:not(.nolightbox)').colorbox({photo:true, current: "{current} / {total}", maxWidth:'90%', maxHeight:'90%', rel:$.colorbox.element().attr('data-rel'), title: $.colorbox.element().attr('data-title')});
		$('a[data-link="iframe"]').colorbox({iframe:true, width:"80%", height:"80%", current: "Bild {current} von {total}"});

		$('.top').fixedNavi({
			offset: $('.header').height() / -2
		});

		$button = $('<a>', {
			'class': 'intro',
			'href': '#main'
		});

		$('.index .claim').append($button);

		$button.click(function(evt){
			evt.preventDefault();
			$('body, html').animate({ scrollTop: $('#main').offset().top - 100 }, 1500);
			$('.header').addClass('aboveScreen');
		});
	}
	$('.slideme').colorbox({slideshow:true, current: "Bild {current} von {total}"});

	$(".qr-code-link").colorbox({inline:true, href:"#qr-code-description"});

	/**
	 * DETECT EXTERNAL LINKS AND ADD target=_blank
	 */
	$.expr[':'].external = function(obj){return !obj.href.match(/^mailto\:/) && !obj.href.match(/^javascript\:/) && (obj.hostname != location.hostname) && ('www.' + obj.hostname != location.hostname);};
	$('a:external').attr('target', '_blank');
});
/////////////// END DOC READY
/**
 * PLACE YOUR OWN SCRIPTS HERE
 */

/*global jQuery */
/*!
* FitText.js 1.2
*
* Copyright 2011, Dave Rupert http://daverupert.com
* Released under the WTFPL license
* http://sam.zoy.org/wtfpl/
*
* Date: Thu May 05 14:23:00 2011 -0600
*/

(function( $ ){

  $.fn.fitText = function( kompressor, options ) {

    // Setup options
    var compressor = kompressor || 1,
        settings = $.extend({
          'minFontSize' : Number.NEGATIVE_INFINITY,
          'maxFontSize' : Number.POSITIVE_INFINITY
        }, options);

    return this.each(function(){

      // Store the object
      var $this = $(this);

      // Resizer() resizes items based on the object width divided by the compressor * 10
      var resizer = function () {
        $this.css('font-size', Math.max(Math.min($this.width() / (compressor*10), parseFloat(settings.maxFontSize)), parseFloat(settings.minFontSize)));
      };

      // Call once to set.
      resizer();

      // Call on resize. Opera debounces their resize by default.
      $(window).on('resize.fittext orientationchange.fittext', resizer);

    });

  };

})( jQuery );

// onScreen jQuery plugin v0.2.1
// (c) 2011-2013 Ben Pickles
//
// http://benpickles.github.io/onScreen
//
// Released under MIT license.
;(function($) {
  $.expr[":"].onScreen = function(elem) {
    var $window = $(window)
    var viewport_top = $window.scrollTop()
    var viewport_height = $window.height()
    var viewport_bottom = viewport_top + viewport_height
    var $elem = $(elem)
    var top = $elem.offset().top
    var height = $elem.height()
    var bottom = top + height

    return (top >= viewport_top && top < viewport_bottom) ||
           (bottom > viewport_top && bottom <= viewport_bottom) ||
           (height > viewport_height && top <= viewport_top && bottom >= viewport_bottom)
  }
})(jQuery);

/**
 * Toggle "fixed" class on scroll
*/
!function($){
    $.fn.fixedNavi = function(opts){
        var opts = $.extend({}, $.fn.fixedNavi.defaults, opts);

        cscroll=function(){
            return document.documentElement.scrollTop?document.documentElement.scrollTop:document.body.scrollTop
        };

        var _this = $(this),
            _last = 0,
            _offset = _this.offset().top;

        $(window).on("scroll resize",function(){

            _compare = (opts.hideOnScroll) ? (cscroll() < _last) : 1;

            if(cscroll() > _offset - opts.offset) {
                 if(opts.hideOnScroll) _this.addClass("outBounds")

                _compare ? _this.addClass("fixed") : _this.removeClass("fixed");
            }else {
                _this.toggleClass("fixed outBounds", !1)
            }

            if(opts.hideOnScroll) _last = cscroll();
        });

        return this;
    },
    $.fn.fixedNavi.defaults={
        offset: 0,
        hideOnScroll: 1
    }
}(jQuery);

/**
 * prevent body scrolling on toggled navi
 */
!function($){
    $.fn.lockScroll = function(){
        body = $("body, html"),
        $(this).bind("change",function(){
            $(this).prop("checked")?body.css({overflow:"hidden"}):body.css({overflow:"auto"})
        }), this
    }
}(jQuery);

/**
 * Toggle "hovering" class on touch
 */
function tapHover(a){var b=$(this),c=b.hasClass("hasSub")?!0:!1;if(a.stopPropagation(),a.preventDefault(),b.hasClass("hovering")){if(c){var d=a.target;"undefined"!=typeof d.href&&(window.location.href=d.href)}else $(".tapHover").not(this).removeClass("hovering");b.removeClass("hovering")}else c&&b.siblings().removeClass("hovering"),b.addClass("hovering")}

/**
 * jQuery backToTop
 * @author Dominik Kressler
 * @version 0.3
 * @date April 28, 2014
 * @category jQuery plugin
 * @description creates a fixed back to top anchor and displays it if page is scrolled
*/
(function(e){e.fn.backToTop=function(t){var t=e.extend({},e.fn.backToTop.defaultSettings,t);t.placement=this;t=e.fn.backToTop.createMarkup(t);t.button.click(function(n){n.preventDefault();e("html,body").stop().animate({scrollTop:0},t.speed)});if(e(window).scrollTop()<t.displayAt)t.button.fadeOut(0);e(window).scroll(function(n){if(e(this).scrollTop()>t.displayAt)t.button.fadeIn();else t.button.fadeOut()});return this};e.fn.backToTop.createMarkup=function(t){t.button=e('<a href="#" class="backToTop">'+t.text+"</a>");e(t.placement).append(t.button);return t};e.fn.backToTop.defaultSettings={text:"Zum Seitenanfang",speed:500,displayAt:200}})(jQuery);

/**
 * jQuery Old Browser Notice
 * @author Dominik Kressler
 * @version 1.0
 * @date August 27, 2013
 * @category jQuery plugin
*/
(function(e){e.fn.browserNotice=function(t){var t=e.extend({},e.fn.browserNotice.defaultSettings,t);var n=navigator.appName,r=navigator.userAgent,i;var s=r.match(/(opera|chrome|safari|firefox|msie)\/?\s*(\.?\d+(\.\d+)*)/i);if(s&&(i=r.match(/version\/([\.\d]+)/i))!=null)s[2]=i[1];s=s?[s[1],s[2]]:[n,navigator.appVersion,"-?"];t.name=s[0];t.version=parseInt(s[1]);if(t.createNotice)e.fn.browserNotice.createNotice(t);return this};e.fn.browserNotice.createNotice=function(t){var n=e('<div class="noticeBar">Ihr Webbrowser ('+t.name+" "+t.version+') ist nicht aktuell. Er enthällt bekannte Sicherheitslücken und könnte diese und weitere Webseiten nicht korrekt darstellen. <a href="http://browsehappy.com/" target="_blank" title="Jetzt updaten">Lernen Sie aktuell zu bleiben!</a></div>');var r=false;if(t.name=="Firefox"&&t.version<t.firefox)r=true;if(t.name=="Chrome"&&t.version<t.chrome)r=true;if(t.name=="MSIE"&&t.version<t.msie)r=true;if(t.name=="Safari"&&t.version<t.safari)r=true;if(t.name=="Opera"&&t.version<t.opera)r=true;if(r)e("body").prepend(n)};e.fn.browserNotice.defaultSettings={firefox:29,chrome:35,msie:9,safari:4,opera:13,createNotice:true}})(jQuery);

/**
 * jQuery Accordion
 * @author Dominik Kressler
 * @version 1.2.6
 * @date June 06, 2014
 * @category jQuery plugin
*/
(function(e){e.fn.accordion=function(t){var t=e.extend({},e.fn.accordion.defaultSettings,t);t.element=this;if(t.element.length>0)t.element.offset=t.element.offset().top;t.element.next().slideUp(0);if(t.openFirst&&t.element.length>0)t.current=t.element.first();if(window.location.hash.indexOf("section:")>-1){t.current=window.location.hash.split("section:");t.current=t.current[1];t.current=e("#"+t.current)}if(t.current)t.current.addClass("active").next().slideDown(0);e("a").click(function(n){var r=e(this).attr("href");if(r.indexOf("section:")>-1){t.current=r.split("section:");t.current=t.current[1];t.current=e("#"+t.current);t=e.fn.accordion.clickHandler(t)}});this.click(function(n){n.preventDefault();t.current=e(this);t=e.fn.accordion.clickHandler(t)});if(typeof t.onSlide=="function")t.onSlide();return this};e.fn.accordion.clickHandler=function(t){if(typeof t.onSlide=="function")t.onSlide();if(!t.current.hasClass("active")){if(t.closeDeselection){t.element.next().stop().slideUp(t.speed);t.element.removeClass("active")}if(t.scroll){t.current.next().stop().slideDown({duration:t.speed,complete:function(){if(typeof t.onSlideComplete=="function")t.onSlideComplete()},step:function(){e("html,body").stop(true,true).animate({scrollTop:t.current.next().offset().top-t.scrollOffset},t.speed)}})}else{t.current.next().stop().slideDown({duration:t.speed,complete:function(){if(typeof t.onSlideComplete=="function")t.onSlideComplete()}})}t.current.addClass("active")}else if(t.closable&&t.current.hasClass("active")){t.current.next().stop().slideUp(t.speed);t.current.removeClass("active")}return t};e.fn.accordion.defaultSettings={openFirst:false,speed:500,closeDeselection:true,closable:true,scrollOffset:200,scroll:false}})(jQuery);

/* Mailmask */
$.fn.noSpam=function(){at='@';return this.each(function(){e=null;$(this).find('span').replaceWith(at);e=$(this).text();$(this).attr('href','mailto:'+e);});};

/* http://fgnass.github.io/spin.js/dist/spin.min.js */
(function(t,e){if(typeof exports=="object")module.exports=e();else if(typeof define=="function"&&define.amd)define(e);else t.Spinner=e()})(this,function(){"use strict";var t=["webkit","Moz","ms","O"],e={},i;function o(t,e){var i=document.createElement(t||"div"),o;for(o in e)i[o]=e[o];return i}function n(t){for(var e=1,i=arguments.length;e<i;e++)t.appendChild(arguments[e]);return t}var r=function(){var t=o("style",{type:"text/css"});n(document.getElementsByTagName("head")[0],t);return t.sheet||t.styleSheet}();function s(t,o,n,s){var a=["opacity",o,~~(t*100),n,s].join("-"),f=.01+n/s*100,l=Math.max(1-(1-t)/o*(100-f),t),d=i.substring(0,i.indexOf("Animation")).toLowerCase(),u=d&&"-"+d+"-"||"";if(!e[a]){r.insertRule("@"+u+"keyframes "+a+"{"+"0%{opacity:"+l+"}"+f+"%{opacity:"+t+"}"+(f+.01)+"%{opacity:1}"+(f+o)%100+"%{opacity:"+t+"}"+"100%{opacity:"+l+"}"+"}",r.cssRules.length);e[a]=1}return a}function a(e,i){var o=e.style,n,r;if(o[i]!==undefined)return i;i=i.charAt(0).toUpperCase()+i.slice(1);for(r=0;r<t.length;r++){n=t[r]+i;if(o[n]!==undefined)return n}}function f(t,e){for(var i in e)t.style[a(t,i)||i]=e[i];return t}function l(t){for(var e=1;e<arguments.length;e++){var i=arguments[e];for(var o in i)if(t[o]===undefined)t[o]=i[o]}return t}function d(t){var e={x:t.offsetLeft,y:t.offsetTop};while(t=t.offsetParent)e.x+=t.offsetLeft,e.y+=t.offsetTop;return e}var u={lines:12,length:7,width:5,radius:10,rotate:0,corners:1,color:"#000",direction:1,speed:1,trail:100,opacity:1/4,fps:20,zIndex:2e9,className:"spinner",top:"auto",left:"auto",position:"relative"};function p(t){if(typeof this=="undefined")return new p(t);this.opts=l(t||{},p.defaults,u)}p.defaults={};l(p.prototype,{spin:function(t){this.stop();var e=this,n=e.opts,r=e.el=f(o(0,{className:n.className}),{position:n.position,width:0,zIndex:n.zIndex}),s=n.radius+n.length+n.width,a,l;if(t){t.insertBefore(r,t.firstChild||null);l=d(t);a=d(r);f(r,{left:(n.left=="auto"?l.x-a.x+(t.offsetWidth>>1):parseInt(n.left,10)+s)+"px",top:(n.top=="auto"?l.y-a.y+(t.offsetHeight>>1):parseInt(n.top,10)+s)+"px"})}r.setAttribute("role","progressbar");e.lines(r,e.opts);if(!i){var u=0,p=(n.lines-1)*(1-n.direction)/2,c,h=n.fps,m=h/n.speed,y=(1-n.opacity)/(m*n.trail/100),g=m/n.lines;(function v(){u++;for(var t=0;t<n.lines;t++){c=Math.max(1-(u+(n.lines-t)*g)%m*y,n.opacity);e.opacity(r,t*n.direction+p,c,n)}e.timeout=e.el&&setTimeout(v,~~(1e3/h))})()}return e},stop:function(){var t=this.el;if(t){clearTimeout(this.timeout);if(t.parentNode)t.parentNode.removeChild(t);this.el=undefined}return this},lines:function(t,e){var r=0,a=(e.lines-1)*(1-e.direction)/2,l;function d(t,i){return f(o(),{position:"absolute",width:e.length+e.width+"px",height:e.width+"px",background:t,boxShadow:i,transformOrigin:"left",transform:"rotate("+~~(360/e.lines*r+e.rotate)+"deg) translate("+e.radius+"px"+",0)",borderRadius:(e.corners*e.width>>1)+"px"})}for(;r<e.lines;r++){l=f(o(),{position:"absolute",top:1+~(e.width/2)+"px",transform:e.hwaccel?"translate3d(0,0,0)":"",opacity:e.opacity,animation:i&&s(e.opacity,e.trail,a+r*e.direction,e.lines)+" "+1/e.speed+"s linear infinite"});if(e.shadow)n(l,f(d("#000","0 0 4px "+"#000"),{top:2+"px"}));n(t,n(l,d(e.color,"0 0 1px rgba(0,0,0,.1)")))}return t},opacity:function(t,e,i){if(e<t.childNodes.length)t.childNodes[e].style.opacity=i}});function c(){function t(t,e){return o("<"+t+' xmlns="urn:schemas-microsoft.com:vml" class="spin-vml">',e)}r.addRule(".spin-vml","behavior:url(#default#VML)");p.prototype.lines=function(e,i){var o=i.length+i.width,r=2*o;function s(){return f(t("group",{coordsize:r+" "+r,coordorigin:-o+" "+-o}),{width:r,height:r})}var a=-(i.width+i.length)*2+"px",l=f(s(),{position:"absolute",top:a,left:a}),d;function u(e,r,a){n(l,n(f(s(),{rotation:360/i.lines*e+"deg",left:~~r}),n(f(t("roundrect",{arcsize:i.corners}),{width:o,height:i.width,left:i.radius,top:-i.width>>1,filter:a}),t("fill",{color:i.color,opacity:i.opacity}),t("stroke",{opacity:0}))))}if(i.shadow)for(d=1;d<=i.lines;d++)u(d,-2,"progid:DXImageTransform.Microsoft.Blur(pixelradius=2,makeshadow=1,shadowopacity=.3)");for(d=1;d<=i.lines;d++)u(d);return n(e,l)};p.prototype.opacity=function(t,e,i,o){var n=t.firstChild;o=o.shadow&&o.lines||0;if(n&&e+o<n.childNodes.length){n=n.childNodes[e+o];n=n&&n.firstChild;n=n&&n.firstChild;if(n)n.opacity=i}}}var h=f(o("group"),{behavior:"url(#default#VML)"});if(!a(h,"transform")&&h.adj)c();else i=a(h,"animation");return p});

/**
 * CONVERT RGB TO HEX
 */
function rgb2hex(rgb) {  function hex(x) { hexDigits = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F"); return isNaN(x) ? "00" : hexDigits[(x - x % 16) / 16] + hexDigits[x % 16]; } return "#" + hex(rgb[0]) + hex(rgb[1]) + hex(rgb[2]); }

$(document).ready(function()
{
	/**
	 * FRAMEWORK DEBUG TOOLS
	 */
	var logvisible = true;
	$('#log_hider').click(function(e)
	{
		e.preventDefault();
		if(logvisible)
		{
			$('#log_container').addClass('show');
			$(this).text("hide console");
			logvisible = false;
		}
		else
		{
			$('#log_container').removeClass('show');
			$(this).text("show console");
			logvisible = true;
		}
	});

	var hotkey = "LOG";
	var keycollector = "";
	$(document).keydown(function(event)
	{
		var key = String.fromCharCode(event.keyCode);

		keycollector = keycollector+key;

		if(keycollector == hotkey)
		{
			if(logvisible)
			{
				$('#log_container').addClass('show');
				logvisible = false;
			}
			else
			{
				$('#log_container').removeClass('show');
				logvisible = true;
			}
		}

		setTimeout(function() {keycollector = "";}, 2000);
	});
});


