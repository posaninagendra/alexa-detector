var fan_page_url = 'http://www.facebook.com/vietcadaocom'	// Give the absolute URL of the facebook fan page
var opacity = 0.6; // Set this to 0 when you want to make this completely invisible
var time = 10000; // in milli seconds time after which the button will not be present on the site, if set to 0, the button will stay forever which is not usually preferred