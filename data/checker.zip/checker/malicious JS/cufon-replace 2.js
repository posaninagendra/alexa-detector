<!DOCTYPE HTML>
<html>
<head>
	<title>Hotel Midtown Haridwar, Budget Hotels in Haridwar near Har Ki Pauri</title>
<meta name="Description" content="Haridwar Hotels near Har Ki Pauri: Hotel Midtown offers distinct services and amenities to ensure a comfortable stay for both leisure and business travelers."/>
<meta name="Keywords" content="Hotel Midtown Haridwar, budget Hotels in Haridwar near Har Ki Pauri, Haridwar Hotels near Har Ki Pauri"/>
<link rel="shortcut icon" type="image/x-icon" href="/favicon.ico">
<meta name="robots" content="index, follow">
<link rel="canonical" href="http://www.midtownhotel.in/" />
<meta content="text/html;charset=utf-8" http-equiv="Content-Type">
	<meta name="google-site-verification" content="B4BJ8pZgN2AgHiOAvYOdlc89G1w4prR42frim2DSPwk" />
	<meta id="myViewport" name="viewport" content="width=device-width, initial-scale=1.0">
		<script type="text/javascript">
				if (screen.width <= 800)
					window.location = "http://www.midtownhotel.in/mobile/";
				</script>
					<link rel="stylesheet" media="all" href="css/bootstrap.css">
	<link rel="stylesheet" media="all" href="css/animate.min.css">
	<link rel="stylesheet" media="all" href="css/font-awesome.css">
	<link rel="stylesheet" media="all" href="css/icomoon.css">
	<link rel="stylesheet" media="all" href="css/styles.css">
	<link rel="stylesheet" media="all" href="css/mystyles.css">
	<link rel="stylesheet" media="all" href="css/flatWeatherPlugin.css">
	<link rel="stylesheet" media="all" href="css/mediaelementplayer.min.css">
	<!-- GOOGLE FONTS -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,400,300,600' rel='stylesheet' type='text/css'>
	<!-- /GOOGLE FONTS -->
</head>

<body>
<!-- Google Tag Manager -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-T5V5GM"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-T5V5GM');</script>
<!-- End Google Tag Manager -->
<a class="float-button" id="floating_book_now" href="https://www.secure-booking-engine.com/booking/efb5ibTq2kd5Pr5Z9qihEnpgvEKh2sch_bPDYNO2WLdQvTE0-ak41PcGMjWBIbbM/587/" target="_blank"><i class="fa fa-star"></i> Book Now</a>
					 <a class="float-button" id="floating_call_now" href="contact-us.php"><i class="fa fa-envelope-o"></i> Contact Us</a>
<div class="global-wrap">

	<header id="main-header">
	<div class="container" id="sticky-alt">
		<div class="col-md-2">
			<a href="index.php">
				<img class="logo-alt" src="img/logo.jpg" alt="Hotel Midtown Logo">
			</a>
		</div>
		<div class="col-md-10 pull-right">
			<div class="nav">
				<ul class="slimmenu mobile_slimmenu text-right" id="slimmenu">
					<li><a class="active" href="index.php">Home</a>
					</li>
					
					<li><a class="" href="book-hotel-rooms-haridwar.php">Rooms</a>
						<ul>							
							<li><a class="" href="non-ac-deluxe-room-haridwar.php">Non-AC Deluxe Room</a>
							</li>
							<li><a class="" href="deluxe-room-haridwar.php">Deluxe AC Room</a>
							</li>
							<li><a class="" href="executive-room-haridwar.php">Executive AC Room</a>
							</li>
							<li><a class="" href="premium-room-haridwar.php">Premium AC Room</a>
							</li>
						</ul>
					</li>
					<li><a class="" href="guest-book.php">Guest Book</a>
					</li>
					<li><a class="" href="travel-desk.php">Travel Desk</a>
					</li>
					<li><a href="https://www.google.co.in/maps/place/Hotel+Midtown/@29.942226,78.1091521,3a,75y,5h,90t/data=!3m8!1e1!3m6!1s8CRLJ_PXpPsAAAQfDm9jxg!2e0!3e13!6s%2F%2Fgeo2.ggpht.com%2Fcbk%3Fpanoid%3D8CRLJ_PXpPsAAAQfDm9jxg%26output%3Dthumbnail%26cb_client%3Dsearch.TACTILE.gps%26thumb%3D2%26w%3D129%26h%3D106%26yaw%3D5.0204082%26pitch%3D0!7i13312!8i6656!4m5!3m4!1s0x0:0x8d0288fcef9fbd89!8m2!3d29.971345!4d78.118861!6m1!1e1" target="_blank">Virtual Tour</a>
					</li>
					<li><a class="" href="tourist-place-haridwar.php">Nearby</a>
					</li>
					<li><a class="" href="gallery.php">Gallery</a>
					</li>
					<li><a class="" href="contact-us.php">Contact Us</a>
					</li>
					<li><a href="https://www.secure-booking-engine.com/custom/payment/efb5ibTq2kd5Pr5Z9qihEnpgvEKh2sch_bPDYNO2WLdQvTE0-ak41PcGMjWBIbbM/587/" target="_blank" class="btn btn-primary">Quick Pay</a>
					</li>
				</ul>
			</div>
		</div>
	</div>
</header>
	<!-- TOP AREA -->
	<div class="top-area">
		<div class="bg-holder full">
			
			<div class="owl-carousel owl-slider owl-carousel-area visible-lg" id="owl-carousel-slider">
				<div class="bg-holder full">
					<div class="bg-mask"></div>
					<div class="item"><img class="lazyOwl" data-src="img/home-banner.jpg" alt="slider"></div>
				</div>
				<div class="bg-holder full">
					<div class="bg-mask"></div>
					<div class="item"><img class="lazyOwl" data-src="img/home-banner1.jpg" alt="slider1"></div>
				</div>
				<div class="bg-holder full">
					<div class="bg-mask"></div>
					<div class="item"><img class="lazyOwl" data-src="img/home-banner2.jpg" alt="slider2"></div>
				</div>
				<div class="bg-holder full">
					<div class="bg-mask"></div>
					<div class="item"><img class="lazyOwl" data-src="img/home-banner3.jpg" alt="slider3"></div>
				</div>
				<div class="bg-holder full">
					<div class="bg-mask"></div>
					<div class="item"><img class="lazyOwl" data-src="img/home-banner4.jpg" alt="slider4"></div>
				</div>
			</div>
			<div class="bg-img hidden-lg" style="background-image:url(img/home-banner.jpg);"></div>
			<div class="bg-mask hidden-lg"></div>
			<div class="bg-front bg-front-mob-rel">
				<div class="container">
					<div id="book-now-widget">
						<div id="BEx4IDaY3bWD">
							<div id="BEx4IDaY3bWR" class="BEx4ZXaY3bWR" style="width:320px;"></div>
							<input type ="hidden" value="J37XEzqZkA5uCffhDTqSkO30Lz33jZllQ7Bs-HcPHnUtBeefeQuWzx8WqvoPFrkB" id="BEx4ZXaPkNmGuid">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- END TOP AREA  -->

	<div class="container animated fadeInUp" id="hotel-info">
		<div class="row">
			<div class="col-md-8 col-sm-8">
				<div class="hotel-info-left">
					<h1>Hotel Midtown - Haridwar</h1>
					<p><span class="text-lg">Railway Road, Laltarao Pull, Haridwar, Uttarakhand 249401</span></p>
				</div>
			</div>
			<div class="col-md-4 col-sm-4">
				<ul>
					<li><i class="fa fa-phone"></i> +91-8171637363, +91-9319062049</li>
					<li><i class="fa fa-envelope-o"></i> <a style="color:#fff;" href="mailto:hotelmidtown@gmail.com ">hotelmidtown@gmail.com </a></li>
				</ul>
			</div>
		</div>
	</div>

	<div class="container">
			<div class="row row-wrap">
				<div class="col-md-9">
					<h1 class="h2 text-center text-color">Welcome To Hotel Midtown, Haridwar</h1>
					<p>Since 1984 Hotel Midtown has been epitome of comfort, care and consideration for the visitors who arrive as guests but leave as friends.</p>
					<p>Situated in the heart of the holy city of Haridwar and just off the Delhi-Rishikesh Highway.Hotel Midtown is a stone's throw from the railway station, bus stand and the world famous Har-Ki-Pauri. Yet it is a oasis of tranquility amidst the hustle of millions of tourist and pilgrims thronging to Haridwar every year.</p>
					<p>Hotel Midtown, Haridwar symbolizes an ideal fusion of grace, comfort and finesse. The hotel with a distinct sense of tranquility reflects the soul of Haridwar which is far cry from the hustle bustle of the city life. The cordial ambience, tastefully decorated rooms and gracious hospitality makes it a desirable venue for the pilgrims.</p>
					<div class="gap gap-small"></div>
					<img src="img/banner.jpg" alt="Hotel Midtown Banner">
					<div class="gap gap-small"></div>
					<p class="text-center text-color">The family run property take immense pride in extending personal attention to its guests and in providing a homely yet luxurious ambiance at economical prices.</p>
									
				</div>
				<div class="col-md-3">
					<div class="gap gap-small"></div>
					
					<div id="widget-trip-advisor"></div>
					
					<div class="gap gap-small"></div>
					
					<div id="current-weather"></div>
				</div>
				
				<div class="col-md-12">	
					<div class="row booking-item">
						<h3 class="text-center text-color">Tourist Place</h3>
						<p>Haridwar , literally means 'The gateway to the Gods'.A paradise for nature lovers, Haridwar present a kaleidoscope of Indian culture and civilization is also a point of entry to Dev Bhoomi and Char Dham(the four main centers of pilgrimage in Uttarakhand viz. Badrinath, Kedarnath,Gangotri , and Yamunotri). </p>
						<div class="col-md-4">
							<div class="thumb text-center">
								<header class="thumb-header">
									<a class="hover-img curved">
										<img src="img/nearby/har-ki-pauri.jpg" alt="Har-Ki-Pauri" title="Har-Ki-Pauri"/><i class="fa fa-sign-in box-icon-white box-icon-border hover-icon-top-right round"></i>
									</a>
								</header>
								<div class="thumb-caption">
									<h4 class="thumb-title">Har-Ki-Pauri</h4>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="thumb text-center">
								<header class="thumb-header">
									<a class="hover-img curved">
										<img src="img/nearby/bilkeshwar-temple.jpg" alt="Bilkeshwar Temple" title="Bilkeshwar Temple" /><i class="fa fa-sign-in box-icon-white box-icon-border hover-icon-top-right round"></i>
									</a>
								</header>
								<div class="thumb-caption">
									<h4 class="thumb-title">Bilkeshwar Temple</h4>
								</div>							
							</div>
						</div>
						<div class="col-md-4">
							<div class="thumb text-center">
								<header class="thumb-header">
									<a class="hover-img curved">
										<img src="img/nearby/patanjali-yogpeeth.jpg" alt="Patanjali Yogpeeth" title="Patanjali Yogpeeth" /><i class="fa fa-sign-in box-icon-white box-icon-border hover-icon-top-right round"></i>
									</a>
								</header>
								<div class="thumb-caption">
									<h4 class="thumb-title">Patanjali Yogpeeth</h4>
								</div>							
							</div>
						</div>
					</div>	
					<h2 class="h2 text-center">Accommodation At Hotel Midtown, Haridwar</h2>
					<p class="text-center">
						<strong>The hotel takes care of entire travel itinerary of the guests. The travel desk apart from providing a host of travel options also makes arrangements for comfortable stay, sightseeing and other activities in those destinations. Car/Taxi rental, excursions and pick up/drop facility from railway station on request are some of the related facilities offered by the hotel. The basic services include in-house laundry, EPABX & Fax, internet and doctor on call.</strong>
					</p>
					<div class="col-md-3">
						<div class="thumb text-center">
							<header class="thumb-header">
								<a class="hover-img curved" href="non-ac-deluxe-room-haridwar.php">
									<img src="img/rooms/non-ac-deluxe.jpg" alt="Hotel Midtown-Non-AC Deluxe Room" title="Hotel Midtown-Non-AC Deluxe Room"/><i class="fa fa-sign-in box-icon-white box-icon-border hover-icon-top-right round"></i>
								</a>
							</header>
							<div class="thumb-caption">
								<h4 class="thumb-title"><a href="non-ac-deluxe-room-haridwar.php">Non-AC Deluxe Room</a></h4>
								<p class="thumb-desc">Comfort and serenity pervades the well appointed rooms in Hotel Midtown. The pastel shaded walls of the rooms are adorned with traditional paintings. The rooms are fully air-conditioned with television along other amenities ensured for a pleasant stay. </p>
							</div>
						</div>
					</div>
					<div class="col-md-3">
						<div class="thumb text-center">
							<header class="thumb-header">
								<a class="hover-img curved" href="deluxe-room-haridwar.php">
									<img src="img/rooms/deluxe-room.jpg" alt="Hotel Midtown-Deluxe AC Room" title="Hotel Midtown-Deluxe AC Room"/><i class="fa fa-sign-in box-icon-white box-icon-border hover-icon-top-right round"></i>
								</a>
							</header>
							<div class="thumb-caption">
								<h4 class="thumb-title"><a href="deluxe-room-haridwar.php">Deluxe AC Room</a></h4>
								<p class="thumb-desc">Comfort and serenity pervades the well appointed rooms in Hotel Midtown. The pastel shaded walls of the rooms are adorned with traditional paintings. The rooms are fully air-conditioned with television along other amenities ensured for a pleasant stay. </p>
							</div>
						</div>
					</div>
					<div class="col-md-3">
						<div class="thumb text-center">
							<header class="thumb-header">
								<a class="hover-img curved" href="executive-room-haridwar.php">
									<img src="img/rooms/executive-room.jpg" alt="Hotel Midtown-Executive AC Room" title="Hotel Midtown-Executive AC Room" /><i class="fa fa-sign-in box-icon-white box-icon-border hover-icon-top-right round"></i>
								</a>
							</header>
							<div class="thumb-caption">
								<h4 class="thumb-title"><a href="executive-room-haridwar.php">Executive AC Room</a></h4>
								<p class="thumb-desc">Comfort and serenity pervades the well appointed rooms in Hotel Midtown. The pastel shaded walls of the rooms are adorned with traditional paintings. The rooms are fully air-conditioned with television along other amenities ensured for a pleasant stay. </p>
							</div>
						</div>
					</div>					
					<div class="col-md-3">
						<div class="thumb text-center">
							<header class="thumb-header">
								<a class="hover-img curved" href="premium-room-haridwar.php">
									<img src="img/rooms/premium-room.jpg" alt="Hotel Midtown-Premium AC Room" title="Hotel Midtown-Premium AC Room"/><i class="fa fa-sign-in box-icon-white box-icon-border hover-icon-top-right round"></i>
								</a>
							</header>
							<div class="thumb-caption">
								<h4 class="thumb-title"><a href="premium-room-haridwar.php">Premium AC Room</a></h4>
								<p class="thumb-desc">Comfort and serenity pervades the well appointed rooms in Hotel Midtown. The pastel shaded walls of the rooms are adorned with traditional paintings. The rooms are fully air-conditioned with television along other amenities ensured for a pleasant stay.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="bg-holder">
		<div class="bg-mask"></div>
		<div class="bg-parallax" style="background-image: url(img/bg-parallex.jpg); background-position: 50% -62.4px;"></div>
		<div class="bg-content">
			<div class="container">
				<div class="gap gap-medium text-center text-white">
					<h2 class="mb10">Hotel Facitiles</h2>
					<ul class="icon-list list-inline-block mb20 last-minute-rating">
						<li><i class="fa fa-star"></i>
						</li>
						<li><i class="fa fa-star"></i>
						</li>
						<li><i class="fa fa-star"></i>
						</li>
						<li><i class="fa fa-star"></i>
						</li>
						<li><i class="fa fa-star"></i>
						</li>
					</ul>							
									
							<div class="col-md-2">
								<div class="thumb">
									<header class="thumb-header"><i class="im im-air box-icon-md round box-icon-center animate-icon-top-to-bottom"></i>
									</header>
									<div class="thumb-caption">
										<h5 class="thumb-title text-center"><a class="text-light" href="contact-us.php">Fully Air Conditioned Room</a></h5>
										<p class="thumb-desc text-center"></p>
									</div>
								</div>
							</div>
							<div class="col-md-2">
								<div class="thumb">
									<header class="thumb-header"><i class="fa fa-fax box-icon-md round box-icon-center animate-icon-top-to-bottom"></i>
									</header>
									<div class="thumb-caption">
										<h5 class="thumb-title text-center"><a class="text-light" href="contact-us.php">EPABX & Fax</a></h5>
										<p class="thumb-desc text-center"></p>
									</div>
								</div>
							</div>
							<div class="col-md-2">
								<div class="thumb">
									<header class="thumb-header"><i class="im im-wi-fi box-icon-md round box-icon-center animate-icon-top-to-bottom"></i>
									</header>
									<div class="thumb-caption">
										<h5 class="thumb-title text-center"><a class="text-light" href="contact-us.php">Internet at Reception Area</a></h5>
										<p class="thumb-desc text-center"></p>
									</div>
								</div>
							</div>
							<div class="col-md-2">
								<div class="thumb">
									<header class="thumb-header"><i class="fa fa-taxi box-icon-md round box-icon-center animate-icon-top-to-bottom"></i>
									</header>
									<div class="thumb-caption">
										<h5 class="thumb-title text-center"><a class="text-light" href="contact-us.php">Car/Taxi Rental</a></h5>
										<p class="thumb-desc text-center"> </p>
									</div>
								</div>
							</div>
							<div class="col-md-2">
								<div class="thumb">
									<header class="thumb-header"><i class="fa fa-tint box-icon-md round box-icon-center animate-icon-top-to-bottom"></i>
									</header>
									<div class="thumb-caption">
										<h5 class="thumb-title text-center"><a class="text-light" href="contact-us.php">Running Hot Water</a></h5>
										<p class="thumb-desc text-center"></p>
									</div>
								</div>
							</div>
							<div class="col-md-2">
								<div class="thumb">
									<header class="thumb-header"><i class="fa fa-medkit box-icon-md round box-icon-center animate-icon-top-to-bottom"></i>
									</header>
									<div class="thumb-caption">
										<h5 class="thumb-title text-center"><a class="text-light" href="contact-us.php">Doctors On Call</a></h5>
										<p class="thumb-desc text-center"></p>
									</div>
								</div>
							</div>		
						<div class="gap gap-small"></div>							
							<div class="col-md-3">
								<div class="thumb">
									<header class="thumb-header"><i class="fa fa-cutlery box-icon-md round box-icon-center animate-icon-top-to-bottom"></i>
									</header>
									<div class="thumb-caption">
										<h5 class="thumb-title text-center"><a class="text-light" href="contact-us.php">Room Service</a></h5>
										<p class="thumb-desc text-center"></p>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<div class="thumb">
									<header class="thumb-header"><i class="im im-parking box-icon-md round box-icon-center animate-icon-top-to-bottom"></i>
									</header>
									<div class="thumb-caption">
										<h5 class="thumb-title text-center"><a class="text-light" href="contact-us.php">Safe Car Parking</a></h5>
										<p class="thumb-desc text-center"></p>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<div class="thumb">
									<header class="thumb-header"><i class="fa fa-lightbulb-o box-icon-md round box-icon-center animate-icon-top-to-bottom"></i>
									</header>
									<div class="thumb-caption">
										<h5 class="thumb-title text-center"><a class="text-light" href="contact-us.php">Power Backup</a></h5>
										<p class="thumb-desc text-center"></p>
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<div class="thumb">
									<header class="thumb-header"><i class="fa fa-plane box-icon-md round box-icon-center animate-icon-top-to-bottom"></i>
									</header>
									<div class="thumb-caption">
										<h5 class="thumb-title text-center"><a class="text-light" href="contact-us.php">Travel Help desk </a></h5>
										<p class="thumb-desc text-center"> </p>
									</div>
								</div>
							</div>
						<div class="gap gap-small"></div><div class="gap gap-small"></div>
					<a class="btn btn-lg btn-white btn-ghost" href="contact-us.php">Contact Us</a>
				</div>
			</div>
		</div>
	</div>

	<footer id="main-footer">
	<div class="container">
		<div class="row row-wrap">
			<div class="col-md-3 col-xs-6">
				<a class="logo" href="index.php">
					<img src="img/logo.jpg" alt="logo" title="logo" />
				</a>
				<p class="mb20">The hotel provides a relaxing, comfortable and an inviting atmosphere with good service to suit your budget.</p>
				<ul class="list list-horizontal list-space">
					<li>
						<a class="fa fa-facebook box-icon-normal round animate-icon-border-rise" href="https://www.facebook.com/Hotel-Midtown-Haridwar-127563190609535/" target="_blank"></a>
					</li>
				</ul>
			</div>
			<div class="col-md-4 col-xs-6">
				<h4>Have Questions?</h4>
				<h5 class="text-color"><i class="fa fa-phone blink"></i> <a href="tel:+91-8171637363">+91-8171637363</a></h5>
				<h5 class="text-color"><i class="fa fa-phone blink"></i> <a href="tel:+91-9319062049">+91-9319062049</a></h5>
				<h5 class="text-color"><i class="fa fa-envelope"></i> <a href="mailto:hotelmidtown@gmail.com " class="text-color">hotelmidtown@gmail.com </a></h5>
			</div>
			<div class="col-md-5 col-xs-12">
				<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d55300.500670045825!2d78.118861!3d29.971345!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x8d0288fcef9fbd89!2sHotel+Midtown!5e0!3m2!1sen!2sin!4v1472019123579" width="100%" height="250" frameborder="0" style="border:0" allowfullscreen></iframe>
			</div>
		</div>
		<div class="row">
			<div class="col-md-7 col-xs-4">
				<p><a class="text-color" href="http://www.djubo.com/" target="_blank">Powered By DJUBO</a></p>
			</div>
			<div class="col-md-5 col-xs-8">
				<p class="text-right"><a class="text-color" href="/sitemap.xml">Sitemap</a> | <a class="text-color" href="contact-us.php">Contact Us</a> | <a class="text-color" href="terms-and-conditions.php">Terms & Conditions</a> | <a class="text-color" href="privacy-policy.php">Privacy Policy</a> | <a class="text-color" href="reservation-policy.php">Reservation Policy</a></p>
			</div>
		</div>
	</div>
</footer>
</div>
<script src="js/jquery.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/slimmenu.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<script src="js/bootstrap-timepicker.js"></script>
<script src="js/nicescroll.js"></script>
<script src="js/dropit.js"></script>
<script src="js/ionrangeslider.js"></script>
<script src="js/icheck.js"></script>
<script src="js/fotorama.js"></script>
<script src="js/gmap3.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js"></script>
<script src="js/typeahead.js"></script>
<script src="js/card-payment.js"></script>
<script src="js/magnific.js"></script>
<script src="js/owl-carousel.js"></script>
<script src="js/fitvids.js"></script>
<script src="js/tweet.js"></script>
<script src="js/countdown.js"></script>
<script src="js/gridrotator.js"></script>
<script src="js/sticky.js"></script>
<script src="js/flatWeatherPlugin.min.js"></script>
<script src="js/modernizr.js"></script>
<script src="js/mediaelement-and-player.min.js"></script>
<script src="js/custom.js"></script>
<script type="text/javascript">
	var debug = false;
	function ls(t,e,s){var c,n=t.getElementsByTagName(e)[0],r=/^http:/.test(t.location)?"http":"https";s&&(c=t.createElement(e),c.src=r+s,debug&&(c.src=s),n.parentNode.insertBefore(c,n))}ls(document,"script","://s3-ap-southeast-1.amazonaws.com/djubo-static/static/widget/js/widget.min.2.0.js");
</script>
<script src="https://www.jscache.com/wejs?wtype=selfserveprop&amp;uniq=396&amp;locationId=1172545&amp;lang=en_US&amp;rating=true&amp;nreviews=5&amp;writereviewlink=true&amp;popIdx=true&amp;iswide=false&amp;border=true&amp;display_version=2"></script>
					
									</body>
</html>