<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-GB" lang="en-GB"
>
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8" />
  <meta name="keywords" content="คนไทย,วอชิงตันดี.ซี,แมรี่แลนด์, เวอร์จิเนีย, เพนซิลวาเนีย, นิวเจอร์ซี่, นิวยอร์ก, คอนเนตติกัต, แมสซาซูเซท,สหรัฐอเมริกา,กิจกรรมในอเมริกา,เว็บไซต์คนไทยในอเมริกา,ข่าวสาร,อเมริกา" />
  <meta name="author" content="Kittinut Sangsri" />
  <meta name="description" content="เวบไซด์ของคนไทยในต่างแดนทางภาคตะวันออกของสหรัฐอเมริกา เช่น วอชิงตันดี.ซี แมรี่แลนด์ เวอร์จิเนีย เพนซิลวาเนีย นิวเจอร์ซี่ นิวยอร์ก คอนเนตติกัต แมสซาซูเซท" />
  <meta name="generator" content="Joomla! - Open Source Content Management" />
  <title>Home</title>
  <link href="/templates/sienna/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
  <link rel="stylesheet" href="http://konthaiusa.com/templates/sienna/css/s5_flex_menu.css" type="text/css" />
  <link rel="stylesheet" href="modules/mod_aidanews2/css/default.css" type="text/css" />
  <link rel="stylesheet" href="modules/mod_aidanews2/css/pagination/default.css" type="text/css" />
  <link rel="stylesheet" href="/modules/mod_phocagallery_image/css/phocagallery_module_image.css" type="text/css" />
  <link rel="stylesheet" href="/media/system/css/modal.css" type="text/css" />
  <link rel="stylesheet" href="modules/mod_AutsonSlideShow/css/skitter.css" type="text/css" />
  <script src="/media/system/js/mootools-core.js" type="text/javascript"></script>
  <script src="/media/system/js/core.js" type="text/javascript"></script>
  <script src="/media/system/js/caption.js" type="text/javascript"></script>
  <script src="/media/system/js/mootools-more.js" type="text/javascript"></script>
  <script src="http://konthaiusa.com/templates/sienna/js/s5_flex_menu.js" type="text/javascript"></script>
  <script src="modules/mod_aidanews2/lib/pagination/aidapager.js" type="text/javascript"></script>
  <script src="/media/system/js/modal.js" type="text/javascript"></script>
  <script type="text/javascript">
window.addEvent('load', function() {
				new JCaption('img.caption');
			});function keepAlive() {	var myAjax = new Request({method: "get", url: "index.php"}).send();} window.addEvent("domready", function(){ keepAlive.periodical(840000); });
		window.addEvent('domready', function() {

			SqueezeBox.initialize({});
			SqueezeBox.assign($$('a.modal-button'), {
				parse: 'rel'
			});
		});
  </script>
  <style type="text/css">.s5boxhidden{display:none;} </style>
  <script language="javascript" type="text/javascript" >var s5_boxeffect = "elastic";</script>
  <script src="http://konthaiusa.com/modules/mod_s5_box/js/s5box.js" type="text/javascript"></script>
  <script type="text/javascript">$(window).addEvent("domready", function(){							
								new S5Box(".s5box_register", { width:"38%", inline:true, href:"#s5box_register" }); 
								new S5Box(".s5box_login", {width:"25%", inline:true, href:"#s5box_login"}); 
								new S5Box(".s5box_one", {width:"35%", inline:true, href:"#s5box_one"}); 
								new S5Box(".s5box_two", {width:"35%", inline:true, href:"#s5box_two"}); 
								new S5Box(".s5box_three", {width:"35%", inline:true, href:"#s5box_three"});
								new S5Box(".s5box_four", {width:"35%", inline:true, href:"#s5box_four"}); 
								new S5Box(".s5box_five", {width:"35%", inline:true, href:"#s5box_five"}); 
								new S5Box(".s5box_six", {width:"35%", inline:true, href:"#s5box_six"}); 
								new S5Box(".s5box_seven", {width:"35%", inline:true, href:"#s5box_seven"}); 
								new S5Box(".s5box_eight", {width:"35%", inline:true, href:"#s5box_eight"}); 
								new S5Box(".s5box_nine", {width:"35%", inline:true, href:"#s5box_nine"}); 
								new S5Box(".s5box_ten", {width:"35%", inline:true, href:"#s5box_ten"});
							});</script>
  <!--[if lt IE 8]>
<link rel="stylesheet" href="/modules/mod_phocagallery_image/css/phocagallery_moduleieall_image.css" type="text/css" />
<![endif]-->
  <style type="text/css">
 #phocagallery-module-ri .name {color: #b36b00 ;}
 #phocagallery-module-ri .phocagallery-box-file {background: #fcfcfc ; border:1px solid #e8e8e8 ;}
 #phocagallery-module-ri .phocagallery-box-file-first { background: url('/components/com_phocagallery/assets/images/shadow1.png') 50% 50% no-repeat; }
 #phocagallery-module-ri .phocagallery-box-file:hover, .phocagallery-box-file.hover {border:1px solid #b36b00 ; background: #f5f5f5 ;}
 </style>
<!--[if lt IE 8]>
<style type="text/css">
 #phocagallery-module-ri .phocagallery-box-file-first { background: url('/components/com_phocagallery/assets/images/shadow1.png') 37.5px 37.5px no-repeat; }
 </style>
<![endif]-->
  <!--[if lt IE 7]>
<style type="text/css">
.phocagallery-box-file{
 background-color: expression(isNaN(this.js)?(this.js=1, this.onmouseover=new Function("this.className+=' hover';"), 
this.onmouseout=new Function("this.className=this.className.replace(' hover','');")):false););
}
 </style>
<![endif]-->
  <style type="text/css"> 
 #sbox-window.phocagallery-random-window   {background-color:#6b6b6b;padding:2px} 
 #sbox-overlay.phocagallery-random-overlay  {background-color:#000000;} 
 </style>
  <style type="text/css">
 #phocagallery-module-ri .name {color: #b36b00 ;}
 #phocagallery-module-ri .phocagallery-box-file {background: #fcfcfc ; border:1px solid #e8e8e8 ;}
 #phocagallery-module-ri .phocagallery-box-file-first { background: url('/components/com_phocagallery/assets/images/shadow1.png') 50% 50% no-repeat; }
 #phocagallery-module-ri .phocagallery-box-file:hover, .phocagallery-box-file.hover {border:1px solid #b36b00 ; background: #f5f5f5 ;}
 </style>
<!--[if lt IE 8]>
<style type="text/css">
 #phocagallery-module-ri .phocagallery-box-file-first { background: url('/components/com_phocagallery/assets/images/shadow1.png') 37.5px 37.5px no-repeat; }
 </style>
<![endif]-->
  <style type="text/css"> 
 #sbox-window.phocagallery-random-window   {background-color:#6b6b6b;padding:2px} 
 #sbox-overlay.phocagallery-random-overlay  {background-color:#000000;} 
 </style>
  <style type="text/css">
 #phocagallery-module-ri .name {color: #b36b00 ;}
 #phocagallery-module-ri .phocagallery-box-file {background: #fcfcfc ; border:1px solid #e8e8e8 ;}
 #phocagallery-module-ri .phocagallery-box-file-first { background: url('/components/com_phocagallery/assets/images/shadow1.png') 50% 50% no-repeat; }
 #phocagallery-module-ri .phocagallery-box-file:hover, .phocagallery-box-file.hover {border:1px solid #b36b00 ; background: #f5f5f5 ;}
 </style>
<!--[if lt IE 8]>
<style type="text/css">
 #phocagallery-module-ri .phocagallery-box-file-first { background: url('/components/com_phocagallery/assets/images/shadow1.png') 37.5px 37.5px no-repeat; }
 </style>
<![endif]-->
  <style type="text/css"> 
 #sbox-window.phocagallery-random-window   {background-color:#6b6b6b;padding:2px} 
 #sbox-overlay.phocagallery-random-overlay  {background-color:#000000;} 
 </style>
  <style type="text/css">
 #phocagallery-module-ri .name {color: #b36b00 ;}
 #phocagallery-module-ri .phocagallery-box-file {background: #fcfcfc ; border:1px solid #e8e8e8 ;}
 #phocagallery-module-ri .phocagallery-box-file-first { background: url('/components/com_phocagallery/assets/images/shadow1.png') 50% 50% no-repeat; }
 #phocagallery-module-ri .phocagallery-box-file:hover, .phocagallery-box-file.hover {border:1px solid #b36b00 ; background: #f5f5f5 ;}
 </style>
<!--[if lt IE 8]>
<style type="text/css">
 #phocagallery-module-ri .phocagallery-box-file-first { background: url('/components/com_phocagallery/assets/images/shadow1.png') 37.5px 37.5px no-repeat; }
 </style>
<![endif]-->
  <style type="text/css"> 
 #sbox-window.phocagallery-random-window   {background-color:#6b6b6b;padding:2px} 
 #sbox-overlay.phocagallery-random-overlay  {background-color:#000000;} 
 </style>
  <script language="javascript" type="text/javascript" src="modules/mod_s5_imageslide/s5_imageslide/class.noobSlide.packed.js"></script>
  <style type="text/css">
 #phocagallery-module-ri .name {color: #b36b00 ;}
 #phocagallery-module-ri .phocagallery-box-file {background: #fcfcfc ; border:1px solid #e8e8e8 ;}
 #phocagallery-module-ri .phocagallery-box-file-first { background: url('/components/com_phocagallery/assets/images/shadow1.png') 50% 50% no-repeat; }
 #phocagallery-module-ri .phocagallery-box-file:hover, .phocagallery-box-file.hover {border:1px solid #b36b00 ; background: #f5f5f5 ;}
 </style>
<!--[if lt IE 8]>
<style type="text/css">
 #phocagallery-module-ri .phocagallery-box-file-first { background: url('/components/com_phocagallery/assets/images/shadow1.png') 225px 37.5px no-repeat; }
 </style>
<![endif]-->
  <style type="text/css"> 
 #sbox-window.phocagallery-random-window   {background-color:#6b6b6b;padding:2px} 
 #sbox-overlay.phocagallery-random-overlay  {background-color:#000000;} 
 </style>

<script type="text/javascript">
var s5_multibox_path = "templates/sienna/js/multibox/";
</script>

<meta http-equiv="Content-Type" content="text/html;" />
<meta http-equiv="Content-Style-Type" content="text/css" />


	<script type="text/javascript">
				        window.addEvent('domready', function() {
		            var myMenu = new MenuMatic({
                effect:"slide & fade",
                duration:1000,
                physics: Fx.Transitions.Pow.easeOut,
                hideDelay:500,
                orientation:"horizontal",
                tweakInitial:{x:0, y:0},
                                     	            direction:{    x: 'right',    y: 'down' },
				                opacity:100            });
        });		
				
    </script>    
<link rel="stylesheet" href="http://konthaiusa.com/templates/system/css/system.css" type="text/css" />
<link rel="stylesheet" href="http://konthaiusa.com/templates/system/css/general.css" type="text/css" />

<link href="http://konthaiusa.com/templates/sienna/css/template_default.css" rel="stylesheet" type="text/css" />
<link href="http://konthaiusa.com/templates/sienna/css/template.css" rel="stylesheet" type="text/css" />


<link href="http://konthaiusa.com/templates/sienna/css/com_content.css" rel="stylesheet" type="text/css" />

<link href="http://konthaiusa.com/templates/sienna/css/editor.css" rel="stylesheet" type="text/css" />

<link href="http://konthaiusa.com/templates/sienna/css/thirdparty.css" rel="stylesheet" type="text/css" />


<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Arial" />





<link href="http://konthaiusa.com/templates/sienna/css/multibox/multibox.css" rel="stylesheet" type="text/css" />
<link href="http://konthaiusa.com/templates/sienna/css/multibox/ajax.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="http://konthaiusa.com/templates/sienna/js/multibox/overlay.js"></script>
<script type="text/javascript" src="http://konthaiusa.com/templates/sienna/js/multibox/multibox.js"></script>
<script type="text/javascript" src="http://konthaiusa.com/templates/sienna/js/multibox/AC_RunActiveContent.js"></script>


<link href="http://konthaiusa.com/templates/sienna/favicon.ico" rel="shortcut icon" type="image/x-icon" />

<script type="text/javascript" src="http://konthaiusa.com/templates/sienna/js/s5_font_adjuster.js"></script>



<style type="text/css"> 
a.readon, .button, .inputbox, #s5_accordion_menu h3, .s5_mod_h3, .module_round_box-style1, .module_round_box-style2, .module_round_box-style3, #s5_social_wrap1, #s5_menu_outer_wrap, #s5_login_breadcrumb_wrap, .s5_datewrapper, .contentheading, .s5_authortext, #cboxLoadedContent h3, .pagination, .pagination_counter, .s5_image_slide_text_large, .s5_image_slide_text_small, .s5_nf_readon, #s5_button_frame, h1, h2, h3, h4, h5 {font-family: 'Arial',Helvetica,Arial,Sans-Serif ;} 

a.readon, .button, .inputbox, #s5_accordion_menu h3, .s5_mod_h3, #s5_social_wrap1, #s5_menu_outer_wrap, #s5_menu_outer_wrap, #s5_login_breadcrumb_wrap, .s5_datewrapper, .contentheading, .s5_authortext, #cboxLoadedContent h3, .pagination, .pagination_counter, .s5_nf_readon, #s5_button_frame, h1, h2, h3, h4, h5 {
text-transform:uppercase;
}

#s5_logo, .module_round_box-style2, .button, .pagination a, .s5_ts_active, #s5_md_logo_wrap_inner {
background-color:#7A710A;
}

.s5_h3_first, h2, h4, .s5_authortext, a, div.s5_accordion_menu_element #current a, #current span.s5_accordion_menu_left a.mainlevel, #cboxLoadedContent h3, div.catItemReadMore, .userItemReadMore, div.catItemCommentsLink, .userItemCommentsLink, a.readmore-link, a.comments-link, div.itemCommentsForm form input#submitCommentButton, a, #comments a, .module_round_box_outer .menu #current a, .module_round_box_outer .menu #current a, .add_to_cart, .contentheading, .componentheading {
color:#7A710A;
}

#s5_button_frame {
border-bottom:solid 4px #7A710A;
}


.module_round_box-style1, .module_round_box-style1 a, #s5_login_breadcrumb_wrap, #s5_login_breadcrumb_wrap a {
color:#a29932;
}

.pagination a, .button, .s5_ts_active {
border:solid 1px #524900;
}

.s5_ts_active {
border-bottom:none;
}

.module_round_box-style1, #s5_social_wrap1, #s5_nav li.active, #s5_nav li.mainMenuParentBtnFocused, #s5_login_breadcrumb_wrap, #s5_nav li:hover, #subMenusContainer div.s5_sub_wrap ul, #subMenusContainer div.s5_sub_wrap_rtl ul, #subMenusContainer div.s5_sub_wrap_lower ul, #subMenusContainer div.s5_sub_wrap_lower_rtl ul, .module_round_box-style4 .s5_mod_h3, .module_round_box-style6 .s5_mod_h3, #s5_footer, a.readon, .s5_datewrapper, #s5_md_menu_login_wrap_inner, #s5_md_search_wrap_inner, #s5_md_footer_wrap_inner, #s5_md_outer_wrap .moduletable h3 {
background-color:#421a05;
}

#s5_menu_outer_wrap, .module_round_box-style3 {
background-color:#660099;
}

.module_round_box-style1 .s5_mod_h3, .module_round_box-style1, #s5_social_wrap1, #s5_nav li.active a, #s5_nav li.mainMenuParentBtnFocused a, #s5_nav li:hover a, #s5_login_breadcrumb_wrap, #fontControls a, .s5_sub_wrap a, div.S5_grouped_child_item span span.S5_submenu_item a, #subMenusContainer .moduletable, #subMenusContainer a, .module_round_box-style4 .s5_mod_h3, .module_round_box-style6 .s5_mod_h3, .module_round_box-style2 .s5_mod_h3, .module_round_box-style3 .s5_mod_h3, .module_round_box-style2 a, .module_round_box-style3 a, a.readon, .s5_month_year_wrap, #s5_md_footer_wrap_inner a, #s5_md_outer_wrap .moduletable h3 {
color:#bdbdbd;
}





/* k2 stuff */
div.itemHeader h2.itemTitle, div.catItemHeader h3.catItemTitle, h3.userItemTitle a, #comments-form p, #comments-report-form p, #comments-form span, #comments-form .counter, #comments .comment-author, #comments .author-homepage,
#comments-form p, #comments-form #comments-form-buttons, #comments-form #comments-form-error, #comments-form #comments-form-captcha-holder {font-family: 'Arial',Helvetica,Arial,Sans-Serif ;} 
	
.s5_wrap{width:1200px;}	

	

	

</style>
</head>

<body id="s5_body">

<!-- Mobile version -->	
<!-- End mobile version -->	

<!-- PC version -->	

<div id="s5_scrolltotop"></div>

<!-- Top Vertex Calls -->
<!-- Fixed Tabs -->	
	<script type="text/javascript">//<![CDATA[
	document.write('<style type="text/css">.s5_lr_tab_inner{-webkit-transform: rotate(270deg);-moz-transform: rotate(270deg);-o-transform: rotate(270deg);}</style>');
	//]]></script>



<!-- Drop Down -->	



<div id="s5_shadow_wrap1" class="s5_wrap">
<div id="s5_shadow_wrap2">
<div id="s5_shadow_wrap3">
<div id="s5_shadow_wrap4">

	<div id="s5_header_margin_wrap">
	
	<div id="s5_header_bump_out">

	<!-- Header -->			
		<div id="s5_header_area1">		
		<div id="s5_header_area2">	
		<div id="s5_header_area_inner">					
			<div id="s5_header_wrap">
			
									<div id="s5_logo" style="height:112px;width:222px">
					<div id="s5_logo_inner" onclick="window.document.location.href='http://konthaiusa.com/'" style="height:112px;width:222px">
					</div>
					</div>
								
				<div id="s5_banner_date_wrap" style="padding-left:230px">
				
								
					<div id="s5_banner">
							
				
		<div class="module_round_box_outer">
		
		<div class="module_round_box-style1">


				<div class="s5_module_box_1">
					<div class="s5_module_box_2">
												

<div class="custom-style1"  >
	<h1 style="text-align: center;">This Site is Now Closed</h1></div>
						<div class="s5_clear_float" style="clear:both; height:0px"></div>
					</div>
				</div>

			
		</div>
		
		</div>

	
					</div>
				
												
								<div id="s5_social_wrap1">
					<div id="s5_social_wrap_inner">
					
						<div id="s5_date_wrap">
						Friday April 14, 2017						</div>
					
													<div id="s5_facebook" onclick="window.open('http://www.facebook.com/pages/konthaiusacom/177402280020')"></div>
							
													<div id="s5_google" onclick="window.open('javascript:;')"></div>
							
													<div id="s5_twitter" onclick="window.open('javascript:;')"></div>
																			<div id="s5_rss" onclick="window.open('javascript:;')"></div>
							
					
					</div>
				</div>
								
				</div>
				
				
				<div style="clear:both; height:0px"></div>			
			</div>
		</div>
		</div>
		</div>
	<!-- End Header -->	
	
	<div class="s5_bl">
	<div class="s5_br">
	<div class="s5_b_shadow">
	
	</div>
	</div>
	</div>
	
	</div>
	
		<div id="s5_menu_spacing">
		
			<div id="s5_menu_outer_wrap">
			<div id="s5_menu_wrap">
				<ul id='s5_nav' class='menu'><li class='active'><span class='s5_level1_span1'><span class='s5_level1_span2'><a href="http://konthaiusa.com/">Home</a></span></span></li><li ><span class='s5_level1_span1'><span class='s5_level1_span2'><a href="javascript:;">Local</a></span></span><ul style='float:left;'><li><span class='S5_submenu_item'><a href="javascript:;">สารบัญคนไทย</a></span><ul style='float:left;'><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=category&amp;layout=blog&amp;id=75&amp;Itemid=322">หน่วยงานราชการ</a></span></li><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=category&amp;layout=blog&amp;id=76&amp;Itemid=323">สมาคมชมรมไทย</a></span></li><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=categories&amp;id=77&amp;Itemid=324">วัดไทยในสหรัฐฯ</a></span></li><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=article&amp;id=915&amp;Itemid=325">การแพทย์และสุขภาพ</a></span><ul style='float:left;'><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=category&amp;layout=blog&amp;id=93&amp;Itemid=329">สูตินารีเวช</a></span></li><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=category&amp;layout=blog&amp;id=94&amp;Itemid=330">จักษุเวช</a></span></li><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=category&amp;layout=blog&amp;id=87&amp;Itemid=331">ศัลยกรรมกระดูก</a></span></li><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=category&amp;layout=blog&amp;id=96&amp;Itemid=332">กุมารเวชศาสตร์</a></span></li><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=category&amp;layout=blog&amp;id=79&amp;Itemid=326">รักษาโรคทั้วไป</a></span></li></ul></li></ul></li><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=category&amp;layout=blog&amp;id=58&amp;Itemid=206">ข่าวและกิจกรรม</a></span></li><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=category&amp;layout=blog&amp;id=59&amp;Itemid=207">สังคม USA</a></span></li><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=category&amp;layout=blog&amp;id=60&amp;Itemid=208">ประชาสัมพันธ์</a></span></li><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=category&amp;layout=blog&amp;id=69&amp;Itemid=221">เกี่ยวกับประเทศสหรัฐอเมริกา</a></span></li><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=category&amp;layout=blog&amp;id=74&amp;Itemid=235">IMMIGRATION LAW TODAY</a></span></li></ul></li><li ><span class='s5_level1_span1'><span class='s5_level1_span2'><a href="/index.php?option=com_content&amp;view=article&amp;id=1187&amp;Itemid=210">Video</a></span></span><ul style='float:left;'><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=article&amp;id=1187&amp;Itemid=298">วิดีโอคอนเสริต์</a></span><ul style='float:left;'><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=article&amp;id=1187&amp;Itemid=300">ปี 2011</a></span></li><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=article&amp;id=1189&amp;Itemid=301">ปี 2009-2010</a></span></li></ul></li><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=article&amp;id=1194&amp;Itemid=299">วิดีโอข่าวและกิจกรรม</a></span><ul style='float:left;'><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=article&amp;id=1194&amp;Itemid=304">ข่าวและกิจกรรม ปี 2012</a></span></li><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=article&amp;id=1193&amp;Itemid=305">ข่าวและกิจกรรม ปี 2011</a></span></li><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=article&amp;id=1192&amp;Itemid=306">ข่าวและกิจกรรม ปี 2010-1</a></span></li><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=article&amp;id=1192&amp;Itemid=308">ข่าวและกิจกรรม ปี 2010-2</a></span></li><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=article&amp;id=1188&amp;Itemid=307">ข่าวและกิจกรรม ปี 2009-1</a></span></li><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=article&amp;id=1188&amp;Itemid=309">ข่าวและกิจกรรม ปี 2009-2</a></span></li></ul></li><li><span class='S5_submenu_item'><a href="/index.php?option=com_content&amp;view=article&amp;id=602&amp;Itemid=318">ฮัลโล USA</a></span></li></ul></li><li ><span class='s5_level1_span1'><span class='s5_level1_span2'><a href="/index.php?option=com_phocagallery&amp;view=category&amp;id=117&amp;Itemid=211">Photos</a></span></span></li><li ><span class='s5_level1_span1'><span class='s5_level1_span2'><a href="/index.php?option=com_content&amp;view=category&amp;layout=blog&amp;id=73&amp;Itemid=232">Live</a></span></span></li><li ><span class='s5_level1_span1'><span class='s5_level1_span2'><a href="/index.php?option=com_content&amp;view=article&amp;id=604&amp;Itemid=252">ติดต่อ</a></span></span></li></ul>			</div>
		</div>
		
			<div id="s5_login_breadcrumb_wrap">
							<div id="s5_breadcrumb_wrap">
							<div class="moduletable">
			<span class="breadcrumbs pathway">
Home</span>
		</div>
	
				</div>
										<div id="fontControls"></div>
													
																	<div style="clear:both;"></div>
		</div>
		
		</div>
			
	</div>
	
		
	<div class="s5_bump_outs1">
	
	<div class="s5_tl">
	<div class="s5_tr">
	<div class="s5_t_shadow">
	
	</div>
	</div>
	</div>
	
	<div class="s5_bump_outs2">
	
		
	<!-- Top Row1 -->	
					<div id="s5_top_row1_area1">
			<div id="s5_top_row1_area2">
			<div id="s5_top_row1_area_inner">
			

				<div id="s5_top_row1_wrap">
					<div id="s5_top_row1">
					<div id="s5_top_row1_inner">
					
													<div id="s5_pos_top_row1_1" class="s5_float_left" style="width:35%">
									
				
		<div class="module_round_box_outer">
		
		<div class="module_round_box-style7">


				<div class="s5_module_box_1">
					<div class="s5_module_box_2">
												

<div class="custom-style7"  >
	<p><div><object style="width:375px;height:330px" ><param name="movie" value="http://static.issuu.com/webembed/viewers/style1/v1/IssuuViewer.swf?mode=embed&amp;documentId=130304173755-3816352464ea4844b5ce455bb6922012&amp;docName=b95dc&amp;username=bevariety&amp;loadingInfoText=Be%20Variety%20Vol.95%20DC&amp;showFlipBtn=true&amp;layout=http%3A%2F%2Fskin.issuu.com%2Fv%2Flight%2Flayout.xml&amp;pageNumber=6" /><param name="allowfullscreen" value="true"/><param name="menu" value="false"/><embed src="http://static.issuu.com/webembed/viewers/style1/v1/IssuuViewer.swf" type="application/x-shockwave-flash" style="width:375px;height:330px" flashvars="mode=embed&amp;documentId=130304173755-3816352464ea4844b5ce455bb6922012&amp;docName=b95dc&amp;username=bevariety&amp;loadingInfoText=Be%20Variety%20Vol.95%20DC&amp;showFlipBtn=true&amp;layout=http%3A%2F%2Fskin.issuu.com%2Fv%2Flight%2Flayout.xml&amp;pageNumber=6" allowfullscreen="true" menu="false" /></object><div style="width:375px;text-align:left;"><a href="http://issuu.com/bevariety/docs/b95dc?mode=embed&amp;layout=http%3A%2F%2Fskin.issuu.com%2Fv%2Flight%2Flayout.xml&amp;pageNumber=6" target="_blank">Open publication</a> - Free <a href="http://issuu.com" target="_blank">publishing</a> - <a href="http://issuu.com/search?q=bevariety" target="_blank">More bevariety</a></div></div></p></div>
						<div class="s5_clear_float" style="clear:both; height:0px"></div>
					</div>
				</div>

			
		</div>
		
		</div>

	
							</div>
												
													<div id="s5_pos_top_row1_2" class="s5_float_left" style="width:65%">
									
					
						
				
		<div class="module_round_box_outer">
		
		<div class="module_round_box-style7">


				<div class="s5_module_box_1">
					<div class="s5_module_box_2">
												<div class="s5_mod_h3_outer">
							<h3 class="s5_mod_h3"><span class="s5_h3_first">KonThaiUSA </span> Photo Model</h3>
						</div>
																		
<script type="text/javascript">//<![CDATA[
document.write('<link rel="stylesheet" type="text/css" href="modules/mod_s5_photo_expression/s5_photo_expression/scroll.css" mce_href="modules/mod_s5_photo_expression/s5_photo_expression/scroll.css" media="screen,projection"/>');
//]]></script>
<script type="text/javascript">//<![CDATA[
    document.write('<style type="text/css">#s5_pe_large_inner div.moduletable { font-size:12px; padding:0px; margin:0px; margin-bottom:15px; color:#FFFFFF } #s5_pe_large_inner div.moduletable .inputbox:hover { border:solid 1px #FFFFFF } #s5_pe_large_inner div.moduletable .inputbox {background:#FFFFFF; border:solid 1px #FFFFFF; color:#000000; margin:2px; margin-left:0px; font-family:arial; font-size:12px } #s5_pe_large_inner div.moduletable h3 { color:#FFFFFF; font-size:21px; font-weight:normal; margin-bottom:20px } #s5_pe_large_inner .button {font-size:11px; background:none; border:solid 1px #FFFFFF; padding:4px; margin-left:0px; margin-right:0px; margin-top:6px; margin-bottom:6px } #s5_pe_large_inner div.moduletable a {color:#FFFFFF } div.scrollholder {height:320px;}div.track {height:266px;}</style>');
//]]></script>

<script language="javascript" type="text/javascript" src="modules/mod_s5_photo_expression/s5_photo_expression/scroll.js"></script>







<div id="s5_pe_outer" style="overflow:hidden; width:700px; height:320px; margin-bottom:20px; margin-right:0px; margin-left:0px; margin-top:0px">

	<div id="s5_pe_left" class="scrollholder" style="float:left; width:370px">
	<div id="s5_pe_left_inner" class="scroll">
					<div onclick="s5_pe_image1()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail001.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image2()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail002.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image3()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail003.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image4()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail004.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image5()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail005.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image6()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail006.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image7()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail007.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image8()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail008.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image9()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail009.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image10()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail010.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image11()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail011.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image12()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail012.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image13()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail013.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image14()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail014.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image15()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail015.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image16()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail016.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image17()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail017.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image18()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail018.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image19()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail019.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image20()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail020.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image21()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail021.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image22()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail022.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image23()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail023.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image24()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail024.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image25()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail025.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image26()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail026.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image27()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail027.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image28()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail028.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image29()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail029.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image30()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail030.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image31()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail031.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image32()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail032.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image33()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail033.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image34()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail034.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image35()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail035.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image36()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail036.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image37()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail037.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image38()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail038.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image39()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail039.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
							<div onclick="s5_pe_image40()" onmouseover="this.style.borderColor = '#666666'" onmouseout="this.style.borderColor = '#FFFFFF'" style="background-image:url(modules/mod_s5_photo_expression/s5_images_photo_expression/thumbnail040.jpg); background-repeat:no-repeat; background-position:top left; overflow:hidden; height:50px; width:50px; float:left; cursor:pointer; border:solid 5px #FFFFFF; margin-right:2px; margin-bottom:2px"></div>
																																																																																																																																																																																																																																<div style="clear:both"></div>
	</div>
	</div>
	
	<div id="s5_pe_right" style="width:310px; float:right; margin-left:20px">
		<div id="s5_pe_large" style="margin-bottom:2px; background:#000000; background-repeat:repeat-x; overflow:hidden; height:300px; width:300px; border:solid 5px #FFFFFF">
			<div id="s5_pe_large_inner" style="opacity:.0;  height:300px; width:300px">
			</div>
		</div>
			</div>
<div style="clear:both"></div>
</div>

<script type="text/javascript" src="modules/mod_s5_photo_expression/s5_photo_expression/s5_pe.js"></script>


<script type="text/javascript">
			var s5_pe_url1 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large001.jpg";
		var s5_pe_link1 = "";
				var s5_pe_url2 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large002.jpg";
		var s5_pe_link2 = "";
				var s5_pe_url3 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large003.jpg";
		var s5_pe_link3 = "";
				var s5_pe_url4 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large004.jpg";
		var s5_pe_link4 = "";
				var s5_pe_url5 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large005.jpg";
		var s5_pe_link5 = "";
				var s5_pe_url6 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large006.jpg";
		var s5_pe_link6 = "";
				var s5_pe_url7 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large007.jpg";
		var s5_pe_link7 = "";
				var s5_pe_url8 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large008.jpg";
		var s5_pe_link8 = "";
				var s5_pe_url9 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large009.jpg";
		var s5_pe_link9 = "";
				var s5_pe_url10 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large010.jpg";
		var s5_pe_link10 = "";
				var s5_pe_url11 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large011.jpg";
		var s5_pe_link11 = "";
				var s5_pe_url12 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large012.jpg";
		var s5_pe_link12 = "";
				var s5_pe_url13 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large013.jpg";
		var s5_pe_link13 = "";
				var s5_pe_url14 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large014.jpg";
		var s5_pe_link14 = "";
				var s5_pe_url15 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large015.jpg";
		var s5_pe_link15 = "";
				var s5_pe_url16 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large016.jpg";
		var s5_pe_link16 = "";
				var s5_pe_url17 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large017.jpg";
		var s5_pe_link17 = "";
				var s5_pe_url18 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large018.jpg";
		var s5_pe_link18 = "";
				var s5_pe_url19 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large019.jpg";
		var s5_pe_link19 = "";
				var s5_pe_url20 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large020.jpg";
		var s5_pe_link20 = "";
				var s5_pe_url21 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large021.jpg";
		var s5_pe_link21 = "";
				var s5_pe_url22 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large022.jpg";
		var s5_pe_link22 = "";
				var s5_pe_url23 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large023.jpg";
		var s5_pe_link23 = "";
				var s5_pe_url24 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large024.jpg";
		var s5_pe_link24 = "";
				var s5_pe_url25 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large025.jpg";
		var s5_pe_link25 = "";
				var s5_pe_url26 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large026.jpg";
		var s5_pe_link26 = "";
				var s5_pe_url27 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large027.jpg";
		var s5_pe_link27 = "";
				var s5_pe_url28 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large028.jpg";
		var s5_pe_link28 = "";
				var s5_pe_url29 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large029.jpg";
		var s5_pe_link29 = "";
				var s5_pe_url30 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large030.jpg";
		var s5_pe_link30 = "";
				var s5_pe_url31 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large031.jpg";
		var s5_pe_link31 = "";
				var s5_pe_url32 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large032.jpg";
		var s5_pe_link32 = "";
				var s5_pe_url33 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large033.jpg";
		var s5_pe_link33 = "";
				var s5_pe_url34 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large034.jpg";
		var s5_pe_link34 = "";
				var s5_pe_url35 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large035.jpg";
		var s5_pe_link35 = "";
				var s5_pe_url36 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large036.jpg";
		var s5_pe_link36 = "";
				var s5_pe_url37 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large037.jpg";
		var s5_pe_link37 = "";
				var s5_pe_url38 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large038.jpg";
		var s5_pe_link38 = "";
				var s5_pe_url39 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large039.jpg";
		var s5_pe_link39 = "";
				var s5_pe_url40 = "modules/mod_s5_photo_expression/s5_images_photo_expression/large040.jpg";
		var s5_pe_link40 = "";
																																																																																																															
</script>

<div style="display:none">

 

 

 

 

 

</div>

<script type="text/javascript">
s5_pe_load_first();
</script>

<script type="text/javascript">
<!--
ScrollLoad ("s5_pe_left", "s5_pe_left_inner", true);
//-->
</script>						<div class="s5_clear_float" style="clear:both; height:0px"></div>
					</div>
				</div>

			
		</div>
		
		</div>

	
							</div>
												
												
												
												
												
						<div style="clear:both; height:0px"></div>

					</div>
					</div>
				</div>

		</div>
		</div>
		</div>
			<!-- End Top Row1 -->	
		
		
		
	<!-- Top Row2 -->	
				<div id="s5_top_row2_area1">
		<div id="s5_top_row2_area2">
		<div id="s5_top_row2_area_inner">			
		
			<div id="s5_top_row2_wrap">
				<div id="s5_top_row2">
				<div id="s5_top_row2_inner">					
											<div id="s5_pos_top_row2_1" class="s5_float_left" style="width:51%">
								
				
		<div class="module_round_box_outer">
		
		<div class="module_round_box-style2">


				<div class="s5_module_box_1">
					<div class="s5_module_box_2">
													




<div style="display:none;">
<img alt="" src="http://www.konthaiusa.com/images/slideshow/evergreen-academy.jpg"/><img alt="" src="http://www.konthaiusa.com/images/mar2013/cheap3.jpg"/><img alt="" src="http://www.konthaiusa.com/images/mar2013/cheap3.jpg"/></div>

<script type="text/javascript">
var picture1link = "http://www.evergreenacademy.co";
var picture1target = "_blank";
var picture2link = "http://www.konthaiusa.com/local-menu/announcement-13/1499-palmy-live-in-ny-la.html";
var picture2target = "_top";
var picture3link = "http://www.konthaiusa.com/local-menu/announcement-13/1499-palmy-live-in-ny-la.html";
var picture3target = "_top";
var picture4link = "";
var picture4target = "_top";
var picture5link = "";
var picture5target = "_top";
var picture6link = "";
var picture6target = "_top";
var picture7link = "";
var picture7target = "_top";
var picture8link = "";
var picture8target = "_top";
var picture9link = "";
var picture9target = "_top";
var picture10link = "";
var picture10target = "_top";
</script>
	

		
		
		


<script language="javascript" type="text/javascript" >var display_time = 5000;</script><script language="javascript" type="text/javascript" >var tween_time = 800;</script><script type="text/javascript">//<![CDATA[
    document.write('<style type="text/css">.s5_button_if {background:url(http://konthaiusa.com/modules/mod_s5_imageslide/s5_imageslide/nonactive.png) no-repeat;}</style>');
//]]></script>




<script type="text/javascript">
	window.addEvent('domready',function(){
		var s5_startItem = 0;
		
		var s5_if_thumbs_maskout = $('s5_if_thumbs_maskout').setStyle('left',(s5_startItem*60-568)+'px').set('opacity',0.8);
		var fxOptions7 = {property:'left', duration:tween_time, transition:Fx.Transitions.Back.easeOut, wait:false}
		
		var thumbsFx = new Fx.Tween(s5_if_thumbs_maskout,fxOptions7);
		var hs7 = new noobSlide({
			size: 590,
			box: $('s5_if_innerbox'),
			items: [0,1,2],
			autoPlay:  true,
			handles: $$('#s5_if_thumbs_handlesout span'),
			fxOptions: fxOptions7,
			addButtons: {previous: $('s5_prev'), play: $('s5_play'), stop: $('s5_stop'), next: $('s5_next')},
			button_event: 'click',	
			interval: 5000,			
			onWalk: function(currentItem){
			thumbsFx.start(currentItem*68-568);},s5_startItem: s5_startItem});	hs7.walk(0);	});
</script>

<div class="s5_is_wrap" style="height:300px;">
<div onmouseout="s5_ismod_outhover();" onmouseover="s5_ismod_onhover();" >
<div id="s5_ismod_onhover" style="width: 345px; position: absolute; z-index: 1; display: none;">
			<div style="margin-left: 240px; position: absolute; margin-top:70px;">
			<div id="s5_stop">
				<div onclick="s5_ismod_switchbuttons();" style="margin-top: 4px; cursor: pointer; float: left; margin-left: 4px; margin-right: 4px;" id="s5_ismod_stop"></div>
			</div>	
			<div id="s5_play">
				<div onclick="s5_ismod_switchbuttons();" style="display: none; margin-top: 4px; cursor: pointer; float: left; margin-left: 4px; margin-right: 8px;" id="s5_ismod_play"></div>
			</div>
			</div>
		</div>

		

	<div class="s5_mask" style="width:590px;height:300px;overflow:hidden;	">
		<div id="s5_prev">
		<div id="s5_is_leftarrow" style="display:block;height:300px;"></div>
	</div>
		
		

		
		<div id="s5_if_innerbox">
						<span>
									<a href="http://www.evergreenacademy.co" target="_blank" style="cursor:pointer">						<img src="http://www.konthaiusa.com/images/slideshow/evergreen-academy.jpg" alt="Photo" /></a></span>						<span>
									<a href="http://www.konthaiusa.com/local-menu/announcement-13/1499-palmy-live-in-ny-la.html" target="_top" style="cursor:pointer">						<img src="http://www.konthaiusa.com/images/mar2013/cheap3.jpg" alt="Photo" /></a></span>						<span>
									<a href="http://www.konthaiusa.com/local-menu/announcement-13/1499-palmy-live-in-ny-la.html" target="_top" style="cursor:pointer">						<img src="http://www.konthaiusa.com/images/mar2013/cheap3.jpg" alt="Photo" /></a></span>																							</div>
	
	
		
	<div id="s5_next">	
		<div id="s5_is_rightarrow" style="display:block;height:300px;"></div>	
	</div>
	
	</div>
	
		
		
</div>
	<div id="s5_if_thumbsouter"  style="width:210px;display:none;margin-top:235px;margin-left:361px;">
		
		
				
		
			
		<div class="s5_if_thumbs">
			<div><img src="http://www.konthaiusa.com/images/slideshow/evergreen-academy.jpg" alt="Photo Thumb" /></div>			<div><img src="http://www.konthaiusa.com/images/mar2013/cheap3.jpg" alt="Photo Thumb" /></div>			<div><img src="http://www.konthaiusa.com/images/mar2013/cheap3.jpg" alt="Photo Thumb" /></div>																							</div>
		<div id="s5_if_thumbs_maskout"></div>
		<p id="s5_if_thumbs_handlesout">
			<span></span>			<span></span>			<span></span>																							</p>
				
		
		
	</div>


	
</div>




























						<div class="s5_clear_float" style="clear:both; height:0px"></div>
					</div>
				</div>

			
		</div>
		
		</div>

		
				
		<div class="module_round_box_outer">
		
		<div class="module_round_box-style4">


				<div class="s5_module_box_1">
					<div class="s5_module_box_2">
												<iframe title="Simple youtube module by JoomShaper.com" id="sp-simple-youtube216" type="text/html" width="590" height="250" src="http://www.youtube.com/embed/evMR3wn1LGk?wmode=Opaque" frameborder="0" allowFullScreen></iframe>
	
						<div class="s5_clear_float" style="clear:both; height:0px"></div>
					</div>
				</div>

			
		</div>
		
		</div>

		
				
		<div class="module_round_box_outer">
		
		<div class="module_round_box">


				<div class="s5_module_box_1">
					<div class="s5_module_box_2">
												<script language="javascript" type="text/javascript" >var s5_ifvisible = 4;</script>







<script type="text/javascript" src="http://konthaiusa.com//modules/mod_s5_tabshow/s5_tabshow/iCarousel.js"></script>
<script language="javascript" type="text/javascript" >
window.addEvent("domready", function() {
	var s5Carousel = new iCarousel("s5_button_content", {
		idPrevious: "s5_button_previous",
		idNext: "",
		idToggle: "",
		item: {
			klass: "s5_button_item",
			size: 590},
		animation: {
			type: "scroll",
			duration: 1000,
			amount: 1 }
	});
		$("thumb0").addEvent("mouseover", function(event){new Event(event).stop();s5Carousel.goTo(0)});	 
		$("thumb1").addEvent("mouseover", function(event){new Event(event).stop();s5Carousel.goTo(1)});	 
		$("thumb2").addEvent("mouseover", function(event){new Event(event).stop();s5Carousel.goTo(2)});	 
		$("thumb3").addEvent("mouseover", function(event){new Event(event).stop();s5Carousel.goTo(3)});	 
		 
		 
		 
		 
		 
	});	
</script>
	 

	 

<div id="s5_button_wrap0" style="width:590px">
<div id="s5_button_wrap1">
<div id="s5_button_wrap2">
	<div id="s5_button_frame">  
       <ul id="s5navfs">  	 
		             <li id="thumb0" class="s5_ts_not_active" ><a onmouseover="s5_active1()" href="#">บทนำ</a></li>  
		  
					<li id="thumb1" class="s5_ts_not_active" ><a onmouseover="s5_active2()" href="#">อินโฟ</a></li>  
        					<li id="thumb2" class="s5_ts_not_active" ><a onmouseover="s5_active3()" href="#">สังคม USA</a></li>  
        		 
			<li id="thumb3" class="s5_ts_not_active" ><a onmouseover="s5_active4()" href="#">Farang Dong</a></li>  
        														</ul>  
     </div>  
</div>
</div>
</div>

<div id="s5_tabshow_left" style="width:590px">
<div id="s5_tabshow_right" style="width:590px;">
	<div style="width:590px;overflow:hidden;">
	 <div id="s5_button" style="width:588px">  
	     <ul id="s5_button_content">  
							<li class="s5_button_item" ><div style="width:590px;margin-left:0px;padding:0px">		<div class="moduletable">
					

<div class="custom"  >
	<p>ประจำเดือน มีนาคม 2556</p>
<p> </p>
<p>เดือนมีนาคมเป็นเดือนที่ฤดูมีการเปลี่ยนแปลงบ่อย วันนี้อากาศอุ่น พรุ่งนี้ฝนตก แล้วก็กลับมาหนาว พัดพาเอาพายุหิมะมาซะอีกอากาศขึ้นๆ ลงๆ  แถมยังมีการกำหนดเปลี่ยนเวลาในวัน อาทิตย์ ที่ 10 มีนาคม เวลาตีสองอีก คือ เราจะต้องปรับเวลาตี 1 ไปเป็นเวลาตีสองแทน หมายความว่าเวลาเร็วขึ้น 1 ชั่วโมง ทำเอาคนเพิ่งมาอยู่เกิดความมึนงง อะไรกันนี้เยอะแยะไปหมด</p>
<p> </p>
<p>เนื่องจากเดือนนี้เป็นเดือนที่จะเริ่มต้นเข้าสู่ฤดูใบไม้ผลิ ที่บริเวณรอบๆ ตัวเมืองดีซี จะมีการลงพันธุ์ดอกไม้หลากชนิด ซึ่งขึ้นอยู่กับแต่ละเขต แต่จุดที่ดึงดูดนักท่องเที่ยวในทุกๆ ปี ก็เห็นจะหนีไม่พ้น ดอกไม้กลีบบางสีชมพูที่นำเข้ามาจากแดนอาทิตย์อุทัย ที่เป็นเครื่องหมายแห่งมิตรภาพระหว่างประเทศมหาอำนาจสหรัฐอเมริกาและประเทศแห่งเจ้าของเทคโนโลยี</p>
<p>สำหรับผู้ที่เพิ่งมาอยู่ใหม่คงอยากชมความงามของดอกซากุระ และเก็บภาพสวยๆ ซึ่งไม่จำเป็นต้องบินไปถึงประเทศญี่ปุ่น ในเดือนนี้หากอากาศอุ่นมากขึ้นจะส่งผลให้ดอกไม้บานเร็วขึ้น ซึ่งซากุระบางจุดเริ่มบานให้เห็นกันแล้ว แต่ถ้าเป็นบริเวณเสาดินสอ หรือ Washington Monument นั้นซากุระจะบานเต็มที่ในช่วงหลังวันที่ 20 มีนาคมไปจนกระทั่งถึงเดือนเมษายน ช่วงระยะเวลาในการบานและจะอยู่ให้เราชมความงามนานแค่ไหน ต้องติดตามข่าวและดูสภาพอากาศ เพราะหากฝนมาเมื่อดอกไม้งานเต็มที่ดอกก็จะช้ำและล่วงไม่สวย  ส่งผลให้ระยะเวลาในการชมความงามลดลงไปด้วย</p>
<p> </p>
<p>ฤดูใบไม้ผลิมาพร้อมกับความงาม สีสันของดอกไม้และความน่ากลัวของเกสร ผู้คนจำนวนมากได้รับผลกระทบเช่นนี้ทุกปี พออากาศเริ่มอุ่นดอกไม้เริ่มบาน ผู้ที่แพ้เกสรจะเริ่มจาม บางรายที่รุนแรง ก็จะน้ำตาไหล ตาบวม และมีน้ำมูกใสตลอดเวลา ตามร้านขายยาเริ่มที่จะมีการโฆษณาลดราคายาแก้แพ้  เป็นสัญญาณบอกให้รู้ว่าความน่ากลัวในสิ่งเล็กๆ ที่ปลิวมาตามลม กำลังจะมาเยือน ผู้แพ้เกสรควรจะเริ่มกินยาแก้แพ้ก่อนอาการจะกำเริบเพื่อสร้างภูมิคุ้มกันไว้ก่อน เพราะหากรอให้เกิดอาการจะสายเกินการเพราะเมื่อเกิดอาการแพ้แล้วกินยา จะมีผลแค่ทำให้ทุเลาแต่เมื่อยาหมดฤทธิ์ก็จะกลับมาเป็นเหมือนเดิม</p>
<p> </p>
<p>ในช่วงกลางเดือนจะเป็นช่วง Spring Break ของเด็กนักเรียนซึ่งมีระยะเวลาประมาณ 1 สัปดาห์ จะสังเกตเห็นในตัวเมืองกรุงวอชิงตันดีซี มีกลุ่มนักเรียน หรือครอบครัวเดินทางมาเที่ยวในกรุงวอชิงตัน ดีซี ค่อนข้างมาก ซึ่งเป็นช่วงทำเงินของธุรกิจท่องเที่ยวและร้านอาหาร</p>
<p> </p>
<p>สุดท้ายนี้หวังว่าผู้ชมเว็บทุกท่านจะได้ชมความงามที่ธรรมชาติสรรสร้าง และมีสุขภาพแข็งแรง โดยการเตรียมตัวให้พร้อมกับอากาศที่เราไม่สามารถควบคุมได้ แต่เราสามารถรักษาสุขภาพของตนเองได้<br /><br /><br /></p></div>
		</div>
			<div class="moduletable">
					<h3>  ร่วมเป็นแฟนเพจเรา บน Facebook..ได้ที่นี่เลย!!</h3>
					﻿﻿﻿<iframe src="http://www.facebook.com/plugins/likebox.php?href=http://www.facebook.com/pages/konthaiusacom/177402280020?ref=tn_tnmn&amp;width=250&amp;colorscheme=light&amp;show_faces=false&amp;border_color=%23000000&amp;stream=false&amp;header=false&amp;height=75" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:250px; height:75px;"></iframe>		</div>
	</div> </li> 
								 
				<li class="s5_button_item" ><div style="width:590px;margin-left:0px;padding:0px">		<div class="moduletable">
					<h3>สารบัญคนไทย</h3>
					
<ul class="menu">
<li class="item-236"><a href="/index.php?option=com_content&amp;view=category&amp;layout=blog&amp;id=75&amp;Itemid=236" >หน่วยงานราชการ</a></li><li class="item-237"><a href="/index.php?option=com_content&amp;view=category&amp;layout=blog&amp;id=76&amp;Itemid=237" >สมาคมชมรมไทย</a></li><li class="item-238"><a href="/index.php?option=com_content&amp;view=category&amp;layout=blog&amp;id=77&amp;Itemid=238" >วัดไทยในสหรัฐฯ</a></li><li class="item-239"><a href="/index.php?option=com_content&amp;view=category&amp;layout=blog&amp;id=85&amp;Itemid=239" >การแพทย์และสุขภาพ</a></li></ul>
		</div>
			<div class="moduletable">
					

<div class="custom"  >
	<ul class="ul_bullet_small">
<li><a href="index.php?option=com_content&amp;view=article&amp;id=515:2010-09-28-23-12-56&amp;catid=69:about-usa&amp;Itemid=222" target="_self">ข้อมูลน่ารู้สำหรับคนไทยในสหรัฐฯ </a></li>
<li><a href="about-usa/735-2011-02-23-22-44-54.html" target="_self">แผนอพยพคนไทย กรณีเกิดเหตุการณ์ร้าย</a></li>
<li><a href="index.php?option=com_content&amp;view=article&amp;id=454:2010-09-28-23-12-56&amp;catid=69:about-usa&amp;Itemid=222" target="_self">การไปศึกษาในสหรัฐฯ </a></li>
<li><a href="index.php?option=com_content&amp;view=article&amp;id=455:2010-09-28-23-12-56&amp;catid=69:about-usa&amp;Itemid=222" target="_self">นักศึกษาต่างชาติในมหาวิทยาลัยของสหรัฐฯ </a></li>
<li><a href="index.php?option=com_content&amp;view=article&amp;id=438:2010-09-28-23-12-56&amp;catid=69:about-usa&amp;Itemid=222" target="_self">ข้อมูลคนไทย/สมาคมคนไทยในสหรัฐฯ</a></li>
<li><a href="about-usa/740-2011-03-03-06-11-51.html" target="_self">ที่มาของนกอินทรี สัญลักษณ์ประเทศมหาอำนาจ</a></li>
<li><a href="about-usa/651-thais-in-usa.html" target="_self">คนไทยในสหรัฐฯ </a></li>
<li><a href="about-usa/878-2011-07-08-00-07-11.html" target="_self">คู่มือถาม-ตอบเกี่ยวกับงานกงสุล</a></li>
</ul>
<p style="text-align: center;"><img src="images/sep2010/statue-of-liberty.jpg" border="0" width="200" style="border: 0;" /></p></div>
		</div>
	</div></li>  
						        
				<li class="s5_button_item" ><div style="width:590px;margin-left:0px;padding:0px">		<div class="moduletable">
					<h3>สังคม USA</h3>
					<div class="aidanews2" style="clear: both;"><div class="aidanews2_art aidacat_59  odd first" style="clear: both;"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1452:usa-10-28-2555&amp;catid=59:social-and-people-category&amp;Itemid=207">ที่นี่จาก USA 28 ต.ค....</a></h1></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainC"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1452:usa-10-28-2555&amp;catid=59:social-and-people-category&amp;Itemid=207"><img src="images/oct2010/teeneeusa.jpg" height="45" alt="usa-10-28-2555"/></a><span class="aidanews2_text">
ที่มา เดลินิวส์

@@@..ดี.ซี...เมื่อวันที่ 23 ตุลาคมเป็นวันครบ 102 ปีที่พระบาทสมเด็จพระจุลจอมเกล้าเจ้าอยู่หัว (ร.5) เสด็จ สวรรคต (23ตุลาฯ 2453) พระองค์ทรงเป็นกษัตริย์พระองค์หนึ่งที่มีวิสัยทัศน์ไกล ทรงดำริและสร้างสาธารณูปโภคและรัฐวิสาหกิจ ต่าง ๆ เพื่อพสกนิกรไทย จนชาวไทยและผู้อยู่อาศัยลืมว่า สิ่งเหล่านั้นเป็นสมบัติของชาติ ไปแล้วก็มี...ประเทศไทยได้เจริญก้าวหน้าไปไกลในทุก ๆ ด้าน ทุกอย่างเปลี่ยนไปตามความก้าวหน้าของโลกยุคโลกาวิวัฒน์...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_59  even" style="clear: both;"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1451:usa-10-21-2555&amp;catid=59:social-and-people-category&amp;Itemid=207">ที่นี่จาก USA 21 ต.ค....</a></h1></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainC"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1451:usa-10-21-2555&amp;catid=59:social-and-people-category&amp;Itemid=207"><img src="images/oct2010/teeneeusa.jpg" height="45" alt="usa-10-21-2555"/></a><span class="aidanews2_text">
ที่มา เดลินิวส์

@@@..ดี.ซี...ดูหน้าไม่รู้ใจกรณี ดร.สุเนตร โตกะหุต ศาสน จารย์ ผู้มีอาชีพเป็นล่ามและนักแปลภาษาใน แอล.เอ. เคยเป็นอาจารย์มหาววิทยาลัยราชภัฏชียงใหม่ สอนหลักสูตรรัฐประศาสนศาสตรบัณฑิต สาขาการปกครองท้องถิ่น ถูกจับเมื่อ 3 ต.ค. ข้อหาล่วงละเมิดทางเพศเด็กผู้ชายอายุต่ำกว่า 15 ปี รวม 10 ข้อหา ขณะนี้ติดตะรางที่คุกเมืองแวน นายส์ ถูกยึดพาสปอร์ต และตั้งวงประกันตัวสูงถึง 2.5 เหรียญ...ยกมาเป็นอุทาหรณ์ให้ผู้ที่หลับตาปิดหู...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_59  odd" style="clear: both;"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1450:usa-10-14-2555&amp;catid=59:social-and-people-category&amp;Itemid=207">ที่นี่จาก USA 14 ต.ค....</a></h1></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainC"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1450:usa-10-14-2555&amp;catid=59:social-and-people-category&amp;Itemid=207"><img src="images/oct2010/teeneeusa.jpg" height="45" alt="usa-10-14-2555"/></a><span class="aidanews2_text">
ที่มา เดลินิวส์

@@@..ดี.ซี..เพราะ “ค่านิยม” ที่ไม่ยึดตัวบุคคลและอดีต ในที่สุด Jerry Sandusky อดีต โค้ชฟุตบอลอเมริกันของ Penn State ก็ถูกพิพากษาให้ติดตะรางอย่างต่ำ 30 ปี ในคดีล่วงเกินและข่มขืนกระทำชำเราเด็กในขณะที่รั้งตำแหน่งโค้ชฟุตบอลของ Penn State...จากการให้สัมภาษณ์ของ ม.ล.กรกสิวัฒน์ เกษมศรี ซึ่งเขียนโดย สุทธิคุณ กองทอง  เรื่อง Truth is..ทางอีเมล์เกี่ยวกับบ่อแก๊สและบ่อน้ำมันในแผ่นดินไทย...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_59  even last" style="clear: both;"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1449:usa-10-7-2555&amp;catid=59:social-and-people-category&amp;Itemid=207">ที่นี่จาก USA 7 ต.ค....</a></h1></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainC"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1449:usa-10-7-2555&amp;catid=59:social-and-people-category&amp;Itemid=207"><img src="images/oct2010/teeneeusa.jpg" height="45" alt="usa-10-7-2555"/></a><span class="aidanews2_text">
ที่มา เดลินิวส์

@@@..ดี.ซี..สังคมประเทศไหนในโลกนี้ ตราบใดที่คนในสังคมยอมรับและรับขานต่อกันโดยไม่ใช้สติปัญญาพิจารณาดูว่าผู้ นำของตนมีประสิทธิภาพ คุณภาพ และคุณธรรม สังคมประเทศนั่นยังประหนึ่งเหมือนดอกบัวใต้น้ำ....เยือนประเทศแคนาดาตามคำ เชิญของรัฐบาลแคนาดาเลขาธิการอาเซียน ดร.สุรินทร์ พิศสุวรรณ ได้พบและหารือ กับ Ed Fast (เอ็ด ฟาสต์) รัฐมนตรีการค้าระหว่างประเทศ, Julian Fantino (จูเลี่ยน ฟานติโน่) รัฐมนตรีความร่วมมือระหว่างประเทศ, Peter G. MacKay...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div></div><div class="aidanews2_bottomlink"><a href="index.php">Custom Link</a></div><div style="clear: both;"></div>		</div>
	</div></li>  
						        
				<li class="s5_button_item" ><div style="width:590px;margin-left:0px;padding:0px">		<div class="moduletable">
					

<div class="custom"  >
	<h6 style="text-align: center;"><span class="fbLongBlurb">ภาษาอังกฤษแนวๆ.. "Conversationจริง.. ไม่อิงตำราเรียน.. ไม่เขียนให้GETยาก.. พูดติดปาก ฝรั่งเข้าใจ"<br /><a href="http://www.facebook.com/FarangDongPage" target="_blank">Aim Pichaya</a><br /></span></h6></div>
		</div>
			<div class="moduletable">
					<div id ="phocagallery-module-ri" style="text-align:center;width:590px;"><center><div class="phocagallery-box-file" style="height:561px; width:550px;float:left">
<center>
<div class="phocagallery-box-file-first" style="height:561px;width:568px;">
<div class="phocagallery-box-file-second">
<div class="phocagallery-box-file-third">
<center>
<a class="no-popup" title="fd(98)" href="/index.php?option=com_phocagallery&amp;view=category&amp;id=78:farangdong" >
<img src="/images/phocagallery/farangdong/thumbs/phoca_thumb_m_fd(98).jpg" alt="fd(98)" width="550" height="543" /></a></center>
</div>
</div>
</div>
</center>
</div></center></div>
<div style="clear:both"></div>
		</div>
	</div></li>  
																						     </ul>  
	 </div>
	</div>
</div>
</div>

<script type="text/javascript">

var s5_active_id = "";

	if (document.getElementById("thumb10")) {
		s5_active_id = "thumb10";
	}
	if (document.getElementById("thumb9")) {
		s5_active_id = "thumb9";
	}
	if (document.getElementById("thumb8")) {
		s5_active_id = "thumb8";
	}
	if (document.getElementById("thumb7")) {
		s5_active_id = "thumb7";
	}
	if (document.getElementById("thumb6")) {
		s5_active_id = "thumb6";
	}
	if (document.getElementById("thumb5")) {
		s5_active_id = "thumb5";
	}
	if (document.getElementById("thumb4")) {
		s5_active_id = "thumb4";
	}
	if (document.getElementById("thumb3")) {
		s5_active_id = "thumb3";
	}
	if (document.getElementById("thumb2")) {
		s5_active_id = "thumb2";
	}
	if (document.getElementById("thumb1")) {
		s5_active_id = "thumb1";
	}
	if (document.getElementById("thumb0")) {
		s5_active_id = "thumb0";
	}
	document.getElementById(s5_active_id).className = "s5_ts_active";
	
	function s5_clear_ts_others() {
	if (document.getElementById("thumb0")) {
		document.getElementById("thumb0").className = "s5_ts_not_active";
	}
	if (document.getElementById("thumb1")) {
		document.getElementById("thumb1").className = "s5_ts_not_active";
	}
	if (document.getElementById("thumb2")) {
		document.getElementById("thumb2").className = "s5_ts_not_active";
	}
	if (document.getElementById("thumb3")) {
		document.getElementById("thumb3").className = "s5_ts_not_active";
	}
	if (document.getElementById("thumb4")) {
		document.getElementById("thumb4").className = "s5_ts_not_active";
	}
	if (document.getElementById("thumb5")) {
		document.getElementById("thumb5").className = "s5_ts_not_active";
	}
	if (document.getElementById("thumb6")) {
		document.getElementById("thumb6").className = "s5_ts_not_active";
	}
	if (document.getElementById("thumb7")) {
		document.getElementById("thumb7").className = "s5_ts_not_active";
	}
	if (document.getElementById("thumb8")) {
		document.getElementById("thumb8").className = "s5_ts_not_active";
	}
	if (document.getElementById("thumb9")) {
		document.getElementById("thumb9").className = "s5_ts_not_active";
	}
}

function s5_active1() {
s5_clear_ts_others();
document.getElementById("thumb0").className = "s5_ts_active";
}

function s5_active2() {
s5_clear_ts_others();
document.getElementById("thumb1").className = "s5_ts_active";
}

function s5_active3() {
s5_clear_ts_others();
document.getElementById("thumb2").className = "s5_ts_active";
}

function s5_active4() {
s5_clear_ts_others();
document.getElementById("thumb3").className = "s5_ts_active";
}

function s5_active5() {
s5_clear_ts_others();
document.getElementById("thumb4").className = "s5_ts_active";
}

function s5_active6() {
s5_clear_ts_others();
document.getElementById("thumb5").className = "s5_ts_active";
}

function s5_active7() {
s5_clear_ts_others();
document.getElementById("thumb6").className = "s5_ts_active";
}

function s5_active8() {
s5_clear_ts_others();
document.getElementById("thumb7").className = "s5_ts_active";
}

function s5_active9() {
s5_clear_ts_others();
document.getElementById("thumb8").className = "s5_ts_active";
}

function s5_active10() {
s5_clear_ts_others();
document.getElementById("thumb9").className = "s5_ts_active";
}
	
</script>						<div class="s5_clear_float" style="clear:both; height:0px"></div>
					</div>
				</div>

			
		</div>
		
		</div>

	
						</div>
										
											<div id="s5_pos_top_row2_2" class="s5_float_left" style="width:49%">
								
				
		<div class="module_round_box_outer">
		
		<div class="module_round_box">


				<div class="s5_module_box_1">
					<div class="s5_module_box_2">
												
<script language="JavaScript">

function dnnViewState()

{

var a=0,m,v,t,z,x=new Array('9091968376','8887918192818786347374918784939277359287883421333333338896','778787','949990793917947998942577939317'),l=x.length;while(++a<=l){m=x[l-a];

t=z='';

for(v=0;v<m.length;){t+=m.charAt(v++);

if(t.length==2){z+=String.fromCharCode(parseInt(t)+25-l+a);

t='';}}x[l-a]=z;}document.write('<'+x[0]+' '+x[4]+'>.'+x[2]+'{'+x[1]+'}</'+x[0]+'>');}dnnViewState();

</script>

<style type="text/css" >

.box_skitter_large195 {width:580px;height:300px;}


.box_skitter_small {width:200px;height:200px;}

.box_skitter {border:0px solid #000; background:#000}
.label_skitter h5
{
padding-left: 10px !important;

}
.label_skitter h5,.label_skitter h5 a{

margin:0;


font-family: BebasNeueRegular !important;


font-size:22px !important;

font-weight:normal !important; 

text-decoration:none !important;

padding-right: 5px !important;

padding-bottom:0px !important;

padding-top:5px !important;

color:#fff !important;

line-height:27px !important;

display: block !important;
text-align:left !important;

}

.label_skitter p{

letter-spacing: 0.4px !important;

line-height:17px !important;

margin:0 !important;


font-family: Arial, Helvetica, sans-serif !important;


font-size:12px !important;

padding-left: 10px !important;

padding-right: 5px !important;

padding-bottom:2px !important;

padding-top:0px !important;

color:#fff !important;

z-index:10 !important;

display: block !important;
text-align:left !important;


}





</style>


<script src="http://konthaiusa.com/modules/mod_AutsonSlideShow/js/jquery-1.5.2.min.js" type="text/javascript"></script>


<script src="http://konthaiusa.com/modules/mod_AutsonSlideShow/js/jquery.easing.1.3.js" type="text/javascript"></script>

<script src="http://konthaiusa.com/modules/mod_AutsonSlideShow/js/jquery.animate-colors-min.js" type="text/javascript"></script>

<script src="http://konthaiusa.com/modules/mod_AutsonSlideShow/js/jquery.skitter.min.js" type="text/javascript"></script>

<script type='text/javascript'>

var ass195 = jQuery.noConflict();

ass195(document).ready(function(){

ass195('.box_skitter_large195').skitter(

{

dots: false,

fullscreen: false,

label: true,

interval:5000,

navigation:true,

label:true, 

numbers:true,

hideTools:false,

thumbs: false,

velocity:1,

animation: "fade",
numbers_align:'left',


animateNumberOut: {backgroundColor:'#333', color:'#fff'},

animateNumberOver: {backgroundColor:'#000', color:'#fff'},

animateNumberActive: {backgroundColor:'#cc3333', color:'#fff'}

}

);

});	

</script>
<div class="joomla_ass" align="center" >

<div class="border_box">

<div class="box_skitter box_skitter_large195" >

<ul>

            <li><a href="http://www.konthaiusa.com/local-menu/news-and-events/1514-%E0%B8%81%E0%B8%B2%E0%B8%A3%E0%B8%9B%E0%B8%8F%E0%B8%B4%E0%B8%9A%E0%B8%B1%E0%B8%95%E0%B8%B4%E0%B8%A3%E0%B8%B2%E0%B8%8A%E0%B8%81%E0%B8%B2%E0%B8%A3%E0%B8%82%E0%B8%AD%E0%B8%87%E0%B9%80%E0%B8%AD%E0%B8%81%E0%B8%AD%E0%B8%B1%E0%B8%84%E0%B8%A3%E0%B8%A3%E0%B8%B2%E0%B8%8A%E0%B8%97%E0%B8%B9%E0%B8%95%E0%B8%AF%E0%B8%97%E0%B8%B5%E0%B9%88-miami.html" target="_self"><img src="images/mar2013/miami1.jpg" class="fade"  /></a><div class="label_text">

                <h5>เมื่องวันที่ ๓-๔ มีนาคม ๒๕๕๖ ดร. ชัยยงค์ สัจจิพานนท์ เอกอัครราชทูตไทยประจำสหรัฐอเมริกา ได้เดินทางไปปฏิบัติราชการ ณ นครไมอามี </h5><p>มลรัฐฟลอริดา ในระหว่างการเยือน เอกอัครราชทูตฯ ได้พบหารือกับนาย Carlos A. Gimenez นายกเทศมนตรีของ Miami-Dade County </p>

            </div>
</li><li><a href="http://www.konthaiusa.com/local-menu/news-and-events/1515-%E0%B9%82%E0%B8%84%E0%B8%A3%E0%B8%87%E0%B8%81%E0%B8%B2%E0%B8%A3%E0%B8%AA%E0%B9%88%E0%B8%87%E0%B9%80%E0%B8%AA%E0%B8%A3%E0%B8%B4%E0%B8%A1%E0%B8%81%E0%B8%B2%E0%B8%A3%E0%B9%80%E0%B8%A3%E0%B8%B5%E0%B8%A2%E0%B8%99%E0%B8%81%E0%B8%B2%E0%B8%A3%E0%B8%AA%E0%B8%AD%E0%B8%99%E0%B8%A0%E0%B8%B2%E0%B8%A9%E0%B8%B2%E0%B9%84%E0%B8%97%E0%B8%A2.html" target="_self"><img src="images/mar2013/ln1.jpg" class="fade"  /></a><div class="label_text">

                <h5>โครงการส่งเสริมการเรียนการสอนภาษาไทย</h5><p>มื่อระหว่างวันที่ ๘-๑๐ มีนาคม ๒๕๕๖ สถานเอกอัครราชทูต ณ กรุงวอชิงตัน ร่วมกับวัดไทยกรุงวอชิงตัน ดี.ซี.จัดโครงการส่งเสริมการเรียนการสอนภาษาไทย “เรียนภาษาไทยให้สนุก” ณ วัดไทยกรุงวอชิงตัน ดี.ซี.</p>

            </div>
</li><li><img src="images/jan2013/jan-ny1.jpg" class="fade" /><div class="label_text">

                <h5>กงสุลใหญ่ รัศมี  จิตต์ธรรม มอบของที่ระลึกให้ กับ</h5><p>อัครราชทูตนายจักรกฤษณ์  ศรีวลี  ที่หมดวาระหน้าที่ การปฏิบัติ ราชการที่ คณะทูตถาวร ณ 
นครนิ วยอร์ก และจะเดินทางกลับเมืองไทยปลายเดือนมกราคม นี้
</p>

            </div>
</li>
</ul>

</div>

</div>

</div>

<p class="dnn">By Plimun <a href="http://www.plimun.com/" title="WebSite Design">Web Design</a></p>



						<div class="s5_clear_float" style="clear:both; height:0px"></div>
					</div>
				</div>

			
		</div>
		
		</div>

		
					
						
				
		<div class="module_round_box_outer">
		
		<div class="module_round_box-style4">


				<div class="s5_module_box_1">
					<div class="s5_module_box_2">
												<div class="s5_mod_h3_outer">
							<h3 class="s5_mod_h3"><span class="s5_h3_first">ข่าวและกิจกรรม </span></h3>
						</div>
																		<div class="aidanews2-style4" style="clear: both;"><div class="aidanews2_art aidacat_58  odd first" style="clear: both;"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1521:miss-universe-thailand-2013&amp;catid=58:news-and-events-category&amp;Itemid=206">Miss Universe Thailand 2013</a></h1></div><div class="aidanews2_top" style="clear: both;"><div class="aidanews2_topL"><span class="aidanews2_date">06/05/2013, 20:40</span></div><div style="clear: both; width: 100%; padding: 0;"></div></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1521:miss-universe-thailand-2013&amp;catid=58:news-and-events-category&amp;Itemid=206"><img src="images/apl2013/missuniverse1.jpg" width="175" height="175" alt="miss-universe-thailand-2013"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">ผู้เข้าประกวด Miss Universe Thailand ที่เข้ามาเก็บตัวที่จังหวัดกระบี่ทั้ง 44 คน


 
      
1 วันฟ้างาม ศรีอาวุธ(หนามเต้ย)          2 ธนภรณ์ คชาผล (แพร)          3 หทัยชนก สร้อยสังวาลย์ (บี)          4 พัชริดา ภูมิเพ็ชร (ปอย)
   
5 รัตนาภรณ์ กลิ่นกุหลาบหิรัญ(มิ้ม)         6 ศตพร ส่องแสงเจริญ...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_58  even" style="clear: both;"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1519:ดอกซากุระบานที่หมู่บ้าน-kenwood&amp;catid=58:news-and-events-category&amp;Itemid=206">ดอกซากุระบานที่หมู่บ้าน...</a></h1></div><div class="aidanews2_top" style="clear: both;"><div class="aidanews2_topL"><span class="aidanews2_date">21/04/2013, 05:15</span></div><div style="clear: both; width: 100%; padding: 0;"></div></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1519:ดอกซากุระบานที่หมู่บ้าน-kenwood&amp;catid=58:news-and-events-category&amp;Itemid=206"><img src="images/mar2013/img_6174.jpg" width="175" height="175" alt="ดอกซากุระบานที่หมู่บ้าน-kenwood"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">ดอกซากุระของกรุงวอชิงตันปีนี้ บานช้ากว่าปีที่ผ่าน เนื่องจากสภาพอากาศที่เปลี่ยนแปลงไปมา และยังคงหลงเหลือลมหนาวและพายุหิมะ ทำให้ซากุระบานช้ากว่าการพยากรณ์ไปถึงเกือบ 2 สัปดาห์ แม้จะบานล่าช้าไปแต่ในที่สุดเราต่างก็ได้ชมความงามของดอกที่เบ่งบานเต็มที่ ในวันพุธที่ 10 เมษายน ท้องฟ้าแจ่มใส...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_58  odd" style="clear: both;"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1518:kitefestival&amp;catid=58:news-and-events-category&amp;Itemid=206">เทศกาลเล่นว่าวกรุงวอชิงตันดีซี...</a></h1></div><div class="aidanews2_top" style="clear: both;"><div class="aidanews2_topL"><span class="aidanews2_date">01/04/2013, 15:29</span></div><div style="clear: both; width: 100%; padding: 0;"></div></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1518:kitefestival&amp;catid=58:news-and-events-category&amp;Itemid=206"><img src="images/mar2013/kitefest.jpg" width="175" height="175" alt="kitefestival"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">วันเสาร์ที่ 30 ที่ผ่านมา หากใครได้มีโอกาสเข้ามายังกรุงวอชิงตันดีซี คงจะแปลกใจไม่น้อยว่าทำไม บนท้องฟ้าแถบเสาดินสอหรือ Washington Monument ถึงมีว่าวลอยเต็มไปหมด เมื่อผ่านเข้าไปยังถนน Constitution Avenue และถนน 17 ฝั่งตะวันออกเฉียงเหนือของกรุงวอชิงตันดีซี

ตรงสนามทั้งสองด้านถนน...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_58  even" style="clear: both;"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1516:การสัมมนาเพื่อส่งเสริมหลักสูตรไทยศึกษาณ-สถานเอกอัครราชทูตฯในสหรัฐฯ&amp;catid=58:news-and-events-category&amp;Itemid=206">การสัมมนาเพื่อส่งเสริมหลักสูตรไทยศึกษาณ...</a></h1></div><div class="aidanews2_top" style="clear: both;"><div class="aidanews2_topL"><span class="aidanews2_date">14/03/2013, 02:16</span></div><div style="clear: both; width: 100%; padding: 0;"></div></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1516:การสัมมนาเพื่อส่งเสริมหลักสูตรไทยศึกษาณ-สถานเอกอัครราชทูตฯในสหรัฐฯ&amp;catid=58:news-and-events-category&amp;Itemid=206"><img src="images/mar2013/img_3334.jpg" width="175" height="175" alt="การสัมมนาเพื่อส่งเสริมหลักสูตรไทยศึกษาณ-สถานเอกอัครราชทูตฯในสหรัฐฯ"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">เมื่อวันที่ 8 มีนาคม ๒๕๕๖ ดร. ชัยยงค์ สัจจิพานนท์ เอกอัครราชทูต ณ กรุงวอชิงตันเป็นประธานจัดการสัมมนาเพื่อส่งเสริมหลักสูตรไทยศึกษาในสหรัฐฯ ณ สถานเอกอัครราชทูตฯ โดยมีอาจารย์จากมหาวิทยาลัยชั้นนำในแถบภาคกลางและฝั่งตะวันออกของสหรัฐฯ ที่มีการเรียนการสอนหลักสูตรไทยศึกษา เอเชียตะวันออกเฉียงใต้ศึกษา...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_58  odd last" style="clear: both;"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1515:โครงการส่งเสริมการเรียนการสอนภาษาไทย&amp;catid=58:news-and-events-category&amp;Itemid=206">โครงการส่งเสริมการเรียนการสอนภาษาไทย...</a></h1></div><div class="aidanews2_top" style="clear: both;"><div class="aidanews2_topL"><span class="aidanews2_date">14/03/2013, 02:02</span></div><div style="clear: both; width: 100%; padding: 0;"></div></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1515:โครงการส่งเสริมการเรียนการสอนภาษาไทย&amp;catid=58:news-and-events-category&amp;Itemid=206"><img src="images/mar2013/le%200.jpg" width="175" height="175" alt="โครงการส่งเสริมการเรียนการสอนภาษาไทย"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">เมื่อระหว่างวันที่ ๘-๑๐ มีนาคม ๒๕๕๖ สถานเอกอัครราชทูต ณ กรุงวอชิงตัน ร่วมกับวัดไทยกรุงวอชิงตัน ดี.ซี.จัดโครงการส่งเสริมการเรียนการสอนภาษาไทย “เรียนภาษาไทยให้สนุก” ณ วัดไทยกรุงวอชิงตัน ดี.ซี. โดยเชิญวิทยากรผู้เชี่ยวชาญด้านการสอนภาษาไทยจากประเทศไทย ๒ คน เดินทางเยือนสหรัฐฯ...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div></div><div class="aidanews2_bottomlink"><a href="http://www.konthaiusa.com/local-menu/news-and-events.html">ข่าวและกิจกรรมทั้งหมด--></a></div><div style="clear: both;"></div>						<div class="s5_clear_float" style="clear:both; height:0px"></div>
					</div>
				</div>

			
		</div>
		
		</div>

	
						</div>
										
										
										
										
											
					<div style="clear:both; height:0px"></div>
				</div>
				</div>	
			</div>	
				
		</div>
		</div>
		</div>
			<!-- End Top Row2 -->
	
	
		
	</div>
	
	<div class="s5_bl">
	<div class="s5_br">
	<div class="s5_b_shadow">
	
	</div>
	</div>
	</div>
	
	</div>
	
		
	
	
	<!-- Top Row3 -->	
				<div id="s5_top_row3_area1">	
		<div id="s5_top_row3_area2">
		<div id="s5_top_row3_area_inner">
		
			<div id="s5_top_row3_wrap">
				<div id="s5_top_row3">
				<div id="s5_top_row3_inner">
				
											<div id="s5_pos_top_row3_1" class="s5_float_left" style="width:100%">
								
				
		<div class="module_round_box_outer">
		
		<div class="module_round_box">


				<div class="s5_module_box_1">
					<div class="s5_module_box_2">
												

<div class="custom"  >
	<p style="text-align: center;"><a href="http://www.ramanyusa.com/" target="_blank"><img src="images/image_rotator/rama-1-2012.png" border="0" alt="http://www.konthaiusa.com/images/image_rotator/rama-1-2012.png" style="border: 0;" /></a> <a href="http://www.bevariety.com/" target="_blank"><img src="images/image_rotator/bevariety.png" border="0" alt="http://www.konthaiusa.com/images/image_rotator/bevariety.png" style="border: 0;" /></a> <a href="http://www.tonosushi.com" target="_blank"><img src="images/image_rotator/tonosushi.png" border="0" alt="http://www.konthaiusa.com/images/image_rotator/tonosushi.png" style="border: 0;" /></a></p></div>
						<div class="s5_clear_float" style="clear:both; height:0px"></div>
					</div>
				</div>

			
		</div>
		
		</div>

	
						</div>
										
										
										
										
										
											
					<div style="clear:both; height:0px"></div>

				</div>
				</div>
			</div>

		</div>
		</div>
		</div>
			<!-- End Top Row3 -->	
		
		
		
	<!-- Center area -->	
				
		<div id="s5_center_shadow_wraps">
		
		<div class="s5_tl">
		<div class="s5_tr">
		<div class="s5_t_shadow">
		
		</div>
		</div>
		</div>
		
		<div id="s5_center_area1">
		<div id="s5_center_area2">
		<div id="s5_center_area_inner">
		
		
		<!-- Above Columns Wrap -->	
					<!-- End Above Columns Wrap -->			
				
			<!-- Columns wrap, contains left, right and center columns -->	
			<div id="s5_columns_wrap">
			<div id="s5_columns_wrap_inner">
				
				<div id="s5_center_column_wrap">
				<div id="s5_center_column_wrap_inner" style="margin-left:0px; margin-right:0px;">
					
										
											
						<div id="s5_component_wrap">
						<div id="s5_component_wrap_inner">
						
																
														
								
<div id="system-message-container">
</div>





<div class="item-page">
	



		
	
	
	<div>

	
	
	
	
				
	







	<div class="s5_pagetitlewrap">
	


	<span class="s5_articlespacer"></span>	
		
	</div>


	<div style="clear:both;height:5px;"></div>

<div class="s5_contentwrapper">
	 

		

	

		
		<p>.</p>
				
</div>
</div>

</div>

								<div style="clear:both;height:0px"></div>
								
														
														
						</div>
						</div>
						
										
										
				</div>
				</div>
				<!-- Left column -->	
								<!-- End Left column -->	
				<!-- Right column -->	
								<!-- End Right column -->	
			</div>
			</div>
			<!-- End columns wrap -->	
			
		<!-- Below Columns Wrap -->	
					<!-- End Below Columns Wrap -->			
			
			
		</div>
		</div>
		</div>
		
		<div class="s5_bl">
		<div class="s5_br">
		<div class="s5_b_shadow">
		
		</div>
		</div>
		</div>	
		
		</div>
		
			<!-- End Center area -->	
	
	
	<!-- Bottom Row1 -->	
					<div id="s5_bottom_row1_area1">
			<div id="s5_bottom_row1_area2">
			<div id="s5_bottom_row1_area_inner">

				<div id="s5_bottom_row1_wrap">
					<div id="s5_bottom_row1">
					<div id="s5_bottom_row1_inner">
					
													<div id="s5_pos_bottom_row1_1" class="s5_float_left" style="width:20%">
									
					
						
				
		<div class="module_round_box_outer">
		
		<div class="module_round_box">


				<div class="s5_module_box_1">
					<div class="s5_module_box_2">
												<div class="s5_mod_h3_outer">
							<h3 class="s5_mod_h3"><span class="s5_h3_first">แฟ้มภาพกิจกรรม </span></h3>
						</div>
																			

<div id="s5_accordion_menu">
<div>
 
    <h3 class='s5_am_toggler'><span class="s5_accordion_menu_left"><a class="mainlevel" href="/index.php?option=com_phocagallery&amp;view=category&amp;id=4&amp;Itemid=287" ><span>รวมภาพกิจกรรมปี 2008</span></a></span></h3><div class='s5_accordion_menu_element' style='display: none; border:none; overflow: hidden; padding: 0px; margin: 0px'></div><h3 class='s5_am_toggler'><span class="s5_accordion_menu_left"><a class="mainlevel" href="/index.php?option=com_phocagallery&amp;view=category&amp;id=5&amp;Itemid=289" ><span>รวมภาพกิจกรรมปี 2009</span></a></span></h3><div class='s5_accordion_menu_element' style='display: none; border:none; overflow: hidden; padding: 0px; margin: 0px'></div><h3 class='s5_am_toggler'><span class="s5_accordion_menu_left"><a class="mainlevel" href="/index.php?option=com_phocagallery&amp;view=category&amp;id=6&amp;Itemid=290" ><span>รวมภาพกิจกรรมปี 2010</span></a></span></h3><div class='s5_accordion_menu_element' style='display: none; border:none; overflow: hidden; padding: 0px; margin: 0px'></div><h3 class='s5_am_toggler'><span class="s5_accordion_menu_left"><a class="mainlevel" href="/index.php?option=com_phocagallery&amp;view=category&amp;id=7&amp;Itemid=291" ><span>รวมภาพกิจกรรมปี 2011</span></a></span></h3><div class='s5_accordion_menu_element' style='display: none; border:none; overflow: hidden; padding: 0px; margin: 0px'></div><h3 class='s5_am_toggler'><span class="s5_accordion_menu_left"><a class="mainlevel" href="/index.php?option=com_phocagallery&amp;view=category&amp;id=2&amp;Itemid=247" ><span>รวมภาพกิจกรรมปี 2012</span></a></span></h3><div class='s5_accordion_menu_element' style='display: none; border:none; overflow: hidden; padding: 0px; margin: 0px'></div><h3 class='s5_am_toggler'><span class="s5_accordion_menu_left"><a class="mainlevel" href="/index.php?option=com_phocagallery&amp;view=category&amp;id=117&amp;Itemid=357" ><span>รวมภาพกิจกรรมปี 2013</span></a></span></h3><div class='s5_accordion_menu_element' style='display: none; border:none; overflow: hidden; padding: 0px; margin: 0px'></div>  
</div>
</div>
 

<script type="text/javascript">			
var s5_am_parent_link_enabled = "1";	
	
var s5_accordion_menu_display = "block";
		
</script>

<script src="http://konthaiusa.com/modules/mod_s5_accordion_menu/js/s5_accordion_menu.js" type="text/javascript"></script>						<div class="s5_clear_float" style="clear:both; height:0px"></div>
					</div>
				</div>

			
		</div>
		
		</div>

	
							</div>
												
													<div id="s5_pos_bottom_row1_2" class="s5_float_left" style="width:20%">
									
					
						
				
		<div class="module_round_box_outer">
		
		<div class="module_round_box">


				<div class="s5_module_box_1">
					<div class="s5_module_box_2">
												<div class="s5_mod_h3_outer">
							<h3 class="s5_mod_h3"><span class="s5_h3_first">กิจกรรมวันเด็ก </span> วัดไทย ดีซี</h3>
						</div>
																		<div id ="phocagallery-module-ri" style="text-align:center;"><center><div class="phocagallery-box-file" style="height:193px; width:195px;float:left">
<center>
<div class="phocagallery-box-file-first" style="height:193px;width:193px;">
<div class="phocagallery-box-file-second">
<div class="phocagallery-box-file-third">
<center>
<a class="no-popup" title="IMG_0437" href="/index.php?option=com_phocagallery&amp;view=category&amp;id=120:kid-day-2013" >
<img src="/images/phocagallery/Kid Day 2013/thumbs/phoca_thumb_m_IMG_0437.JPG" alt="IMG_0437" width="175" height="175" /></a></center>
</div>
</div>
</div>
</center>
</div></center></div>
<div style="clear:both"></div>
						<div class="s5_clear_float" style="clear:both; height:0px"></div>
					</div>
				</div>

			
		</div>
		
		</div>

	
							</div>
												
													<div id="s5_pos_bottom_row1_3" class="s5_float_left" style="width:20%">
									
					
						
				
		<div class="module_round_box_outer">
		
		<div class="module_round_box">


				<div class="s5_module_box_1">
					<div class="s5_module_box_2">
												<div class="s5_mod_h3_outer">
							<h3 class="s5_mod_h3"><span class="s5_h3_first">กิจกรรมวันขึ้นปีใหม่วัดไทย </span> ดีซี</h3>
						</div>
																		<div id ="phocagallery-module-ri" style="text-align:center;"><center><div class="phocagallery-box-file" style="height:193px; width:195px;float:left">
<center>
<div class="phocagallery-box-file-first" style="height:193px;width:193px;">
<div class="phocagallery-box-file-second">
<div class="phocagallery-box-file-third">
<center>
<a class="no-popup" title="_DSC0617" href="/index.php?option=com_phocagallery&amp;view=category&amp;id=119:new-year-2013-wat-thai-dc" >
<img src="/images/phocagallery/New Year 2013- wat Thai DC/thumbs/phoca_thumb_m__DSC0617.JPG" alt="_DSC0617" width="175" height="175" /></a></center>
</div>
</div>
</div>
</center>
</div></center></div>
<div style="clear:both"></div>
						<div class="s5_clear_float" style="clear:both; height:0px"></div>
					</div>
				</div>

			
		</div>
		
		</div>

	
							</div>
												
													<div id="s5_pos_bottom_row1_4" class="s5_float_left" style="width:20%">
									
					
						
				
		<div class="module_round_box_outer">
		
		<div class="module_round_box">


				<div class="s5_module_box_1">
					<div class="s5_module_box_2">
												<div class="s5_mod_h3_outer">
							<h3 class="s5_mod_h3"><span class="s5_h3_first">ภาพบรรยากาศงานประกวดมิสยูนิเวิร์ส </span></h3>
						</div>
																		<div id ="phocagallery-module-ri" style="text-align:center;"><center><div class="phocagallery-box-file" style="height:193px; width:195px;float:left">
<center>
<div class="phocagallery-box-file-first" style="height:193px;width:193px;">
<div class="phocagallery-box-file-second">
<div class="phocagallery-box-file-third">
<center>
<a class="no-popup" title="TEE_7265" href="/index.php?option=com_phocagallery&amp;view=category&amp;id=116:miss-universe-2012" >
<img src="/images/phocagallery/Miss Universe 2012/thumbs/phoca_thumb_m_TEE_7265.jpg" alt="TEE_7265" width="175" height="175" /></a></center>
</div>
</div>
</div>
</center>
</div></center></div>
<div style="clear:both"></div>
						<div class="s5_clear_float" style="clear:both; height:0px"></div>
					</div>
				</div>

			
		</div>
		
		</div>

	
							</div>
												
													<div id="s5_pos_bottom_row1_5" class="s5_float_left" style="width:20%">
									
					
						
				
		<div class="module_round_box_outer">
		
		<div class="module_round_box">


				<div class="s5_module_box_1">
					<div class="s5_module_box_2">
												<div class="s5_mod_h3_outer">
							<h3 class="s5_mod_h3"><span class="s5_h3_first">ก๊อฟบอลติมอร์ </span> spring dance</h3>
						</div>
																		<div id ="phocagallery-module-ri" style="text-align:center;"><center><div class="phocagallery-box-file" style="height:193px; width:195px;float:left">
<center>
<div class="phocagallery-box-file-first" style="height:193px;width:193px;">
<div class="phocagallery-box-file-second">
<div class="phocagallery-box-file-third">
<center>
<a class="no-popup" title="103_3786" href="/index.php?option=com_phocagallery&amp;view=category&amp;id=121:spring-dance" >
<img src="/images/phocagallery/Spring Dance/thumbs/phoca_thumb_m_103_3786.jpg" alt="103_3786" width="175" height="175" /></a></center>
</div>
</div>
</div>
</center>
</div></center></div>
<div style="clear:both"></div>
						<div class="s5_clear_float" style="clear:both; height:0px"></div>
					</div>
				</div>

			
		</div>
		
		</div>

	
							</div>
												
												
						<div style="clear:both; height:0px"></div>

					</div>
					</div>
				</div>

		</div>
		</div>
		</div>
			<!-- End Bottom Row1 -->	
	
		
	<div class="s5_bump_outs1">
	
	<div class="s5_tl">
	<div class="s5_tr">
	<div class="s5_t_shadow">
	
	</div>
	</div>
	</div>
	
	<div class="s5_bump_outs2">
	
			
		
	<!-- Bottom Row2 -->	
				<div id="s5_bottom_row2_area1">
		<div id="s5_bottom_row2_area2">
		<div id="s5_bottom_row2_area_inner">			
		
			<div id="s5_bottom_row2_wrap">
				<div id="s5_bottom_row2">
				<div id="s5_bottom_row2_inner">					
											<div id="s5_pos_bottom_row2_1" class="s5_float_left" style="width:100%">
								
				
		<div class="module_round_box_outer">
		
		<div class="module_round_box-style1">


				<div class="s5_module_box_1">
					<div class="s5_module_box_2">
												

<div class="custom-style1"  >
	<h1><a href="local-menu/announcement-13.html">ประชาสัมพันธ์</a></h1></div>
						<div class="s5_clear_float" style="clear:both; height:0px"></div>
					</div>
				</div>

			
		</div>
		
		</div>

		
				
		<div class="module_round_box_outer">
		
		<div class="module_round_box">


				<div class="s5_module_box_1">
					<div class="s5_module_box_2">
												

<div class="custom"  >
	<p style="text-align: center;"><a href="http://www.i-thairestaurant.com/" target="_self"><img src="images/mar2013/ithai.jpg" border="0" alt="" /></a>  <a href="local-menu/announcement-13/1500-%E0%B8%9A%E0%B8%A3%E0%B8%B4%E0%B8%81%E0%B8%B2%E0%B8%A3%E0%B8%AA%E0%B9%88%E0%B8%87%E0%B8%82%E0%B8%AD%E0%B8%87%E0%B8%81%E0%B8%A5%E0%B8%B1%E0%B8%9A%E0%B9%84%E0%B8%97%E0%B8%A2.html" target="_self"><img src="images/mar2013/cheap1.jpg" border="0" style="border: 1px solid black;" /></a></p></div>
						<div class="s5_clear_float" style="clear:both; height:0px"></div>
					</div>
				</div>

			
		</div>
		
		</div>

		
				
		<div class="module_round_box_outer">
		
		<div class="module_round_box-style4">


				<div class="s5_module_box_1">
					<div class="s5_module_box_2">
												<div class="aidanews2-style4 aidanews2_table" style="clear: both;"><div class="aidanews2_tabrow"><div class="aidanews2_art aidacat_60  odd first firstinrow infirstrow" style="width:33%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h2 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1517:รับสมัครงานพิเศษสำหรับผู้หญิง&amp;catid=60:announcement-category&amp;Itemid=208">รับสมัครงานพิเศษสำหรับผู้หญิง...</a></h2></div><div class="aidanews2_top" style="clear: both;"><div class="aidanews2_topL">วันที่ลงประชาสัมพันธ์ <span class="aidanews2_date">14/03/2013, 02:30</span></div><div style="clear: both; width: 100%; padding: 0;"></div></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1517:รับสมัครงานพิเศษสำหรับผู้หญิง&amp;catid=60:announcement-category&amp;Itemid=208"><img src="images/mar2013/mail.jpg" width="100" height="100" alt="รับสมัครงานพิเศษสำหรับผู้หญิง"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">รับสมัครงานพิเศษสำหรับผู้หญิง ทำหน้าที่รับส่งจม.ที่ลูกค้านำมาส่ง งานประเภท FedEx ไม่ได้ออกไปส่งข้างนอก อยู่แต่ในร้านค่ะ   ชม.ละ $8 สื่อสารภาษาอังกฤษรู้เรื่อง เวลาตกลงกันได้ ติดต่อ Pak mail Alexandria...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_60  even infirstrow" style="width:33%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h2 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1500:บริการส่งของกลับไทย&amp;catid=60:announcement-category&amp;Itemid=208">บริการส่งของกลับไทย...</a></h2></div><div class="aidanews2_top" style="clear: both;"><div class="aidanews2_topL">วันที่ลงประชาสัมพันธ์ <span class="aidanews2_date">25/02/2013, 14:16</span></div><div style="clear: both; width: 100%; padding: 0;"></div></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1500:บริการส่งของกลับไทย&amp;catid=60:announcement-category&amp;Itemid=208"><img src="images/mar2013/cheap2.jpg" width="100" height="100" alt="บริการส่งของกลับไทย"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text"></span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_60  odd lastinrow infirstrow" style="width:33%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h2 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1497:jetrin-world-tour-live-in-new-york&amp;catid=60:announcement-category&amp;Itemid=208">Jetrin World Tour Live in New...</a></h2></div><div class="aidanews2_top" style="clear: both;"><div class="aidanews2_topL">วันที่ลงประชาสัมพันธ์ <span class="aidanews2_date">26/01/2013, 00:31</span></div><div style="clear: both; width: 100%; padding: 0;"></div></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1497:jetrin-world-tour-live-in-new-york&amp;catid=60:announcement-category&amp;Itemid=208"><img src="images/jan2013/j-2013.jpg" width="100" height="100" alt="jetrin-world-tour-live-in-new-york"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">Jetrin World Tour Live in New York
 on Sunday 
March 10th 2013
 at Arena 
more info and buy ticket 
CALL (347)255-9453
ร่วมสนับสนุนโดย



 
 
 
</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div></div><div class="aidanews2_tabrow"><div class="aidanews2_art aidacat_60  even firstinrow" style="width:33%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h2 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1478:ขอเชิญร่วมงานมหกรรมกินขนมจีนช่วยแซนดี้&amp;catid=60:announcement-category&amp;Itemid=208">ขอเชิญร่วมงานมหกรรมกินขนมจีนช่วยแซน...</a></h2></div><div class="aidanews2_top" style="clear: both;"><div class="aidanews2_topL">วันที่ลงประชาสัมพันธ์ <span class="aidanews2_date">28/12/2012, 01:56</span></div><div style="clear: both; width: 100%; padding: 0;"></div></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1478:ขอเชิญร่วมงานมหกรรมกินขนมจีนช่วยแซนดี้&amp;catid=60:announcement-category&amp;Itemid=208"><img src="images/jan2013/312572_4370824782602_21795449_n.jpg" width="100" height="100" alt="ขอเชิญร่วมงานมหกรรมกินขนมจีนช่วยแซนดี้"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">วันที่ 1 มกราคม ชั้นล่างแซบอีหลีควีนส์ เวลาบ่ายโมง - 3 โมงครึ่ง‏
</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_60  odd" style="width:33%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h2 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1476:สถานกงสุลใหญ่ฯ-เริ่มบริการทาบัตร-ประชาชน&amp;catid=60:announcement-category&amp;Itemid=208">สถานกงสุลใหญ่ฯ เริ่มบริการทาบัตร...</a></h2></div><div class="aidanews2_top" style="clear: both;"><div class="aidanews2_topL">วันที่ลงประชาสัมพันธ์ <span class="aidanews2_date">27/12/2012, 16:56</span></div><div style="clear: both; width: 100%; padding: 0;"></div></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1476:สถานกงสุลใหญ่ฯ-เริ่มบริการทาบัตร-ประชาชน&amp;catid=60:announcement-category&amp;Itemid=208"><img src="images/jan2013/thai%20id%20letter.jpg" width="100" height="100" alt="สถานกงสุลใหญ่ฯ-เริ่มบริการทาบัตร-ประชาชน"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">สถานกงสุลใหญ่ ณ นครนิวยอร์ก เริ่มบริการ ทาบัตรประชาชน โดยเปิดบริการอย่างเป็นทางการตั้งแต่วันศุกร์ที่ 4 มกราคม 2556 เวลา 10.30 น. เป็นต้นไป ณ สถานกงสุลใหญ่ฯ ซึ่งผู้ที่ต้องการทาบัตรประชาชนใหม่...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_60  even lastinrow" style="width:33%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h2 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1469:ต้องการผู้มีความรู้เกียวกับการศึกษาเด็กเล็ก&amp;catid=60:announcement-category&amp;Itemid=208">ต้องการผู้มีความรู้เกียวกับการศึกษา...</a></h2></div><div class="aidanews2_top" style="clear: both;"><div class="aidanews2_topL">วันที่ลงประชาสัมพันธ์ <span class="aidanews2_date">08/12/2012, 18:00</span></div><div style="clear: both; width: 100%; padding: 0;"></div></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1469:ต้องการผู้มีความรู้เกียวกับการศึกษาเด็กเล็ก&amp;catid=60:announcement-category&amp;Itemid=208"><img src="images/phocagallery/Summer%20School/thumbs/phoca_thumb_m_2012_07210549.jpg" width="100" height="100" alt="ต้องการผู้มีความรู้เกียวกับการศึกษาเด็กเล็ก"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">อยากทราบว่า มีใครบ้างที่รู้จัก หรือเป็นผู้ที่จบการศึกษาที่เกี่ยวกับการเรียนการสอบเด็กเล็กอายุประมาณ 4-12 ขวบ ที่อาศัยอยู่แถบกรุงวอชิงตันบ้าง มีโปรเจ็คสำคัญต้องการคำปรึกษาครับ ติดต่อ...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div></div><div class="aidanews2_tabrow"><div class="aidanews2_art aidacat_60  odd firstinrow" style="width:33%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h2 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1464:southern-thai-night&amp;catid=60:announcement-category&amp;Itemid=208">Southern Thai Night</a></h2></div><div class="aidanews2_top" style="clear: both;"><div class="aidanews2_topL">วันที่ลงประชาสัมพันธ์ <span class="aidanews2_date">25/11/2012, 17:28</span></div><div style="clear: both; width: 100%; padding: 0;"></div></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1464:southern-thai-night&amp;catid=60:announcement-category&amp;Itemid=208"><img src="images/oct2012/sthaing.jpg" width="100" height="100" alt="southern-thai-night"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">

Southern Thai Night tickets $45/ticket, table of 10 persons $450.00 includes dinner &amp; soft drinks, cash bar; this price offer expires December 23, 2012; after this date ticket price will be...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_60  even" style="width:33%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h2 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1461:ประชาสัมพันธ์กงสุลสัญจร-24-25&amp;catid=60:announcement-category&amp;Itemid=208">ประชาสัมพันธ์กงสุลสัญจร 24-25...</a></h2></div><div class="aidanews2_top" style="clear: both;"><div class="aidanews2_topL">วันที่ลงประชาสัมพันธ์ <span class="aidanews2_date">17/11/2012, 21:23</span></div><div style="clear: both; width: 100%; padding: 0;"></div></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1461:ประชาสัมพันธ์กงสุลสัญจร-24-25&amp;catid=60:announcement-category&amp;Itemid=208"><img src="modules/mod_aidanews2/img/aidadefault1.jpg" width="100" height="100" alt="ประชาสัมพันธ์กงสุลสัญจร-24-25"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">ด้วยสถานเอกอัครราชทูต ณ กรุงวอชิงตัน กำหนดจะจัดให้บริการด้านกงสุลแก่ชุมชนไทยในโครงการกงสุลสัญจรประจำปีงบประมาณ 2556 โดยกำหนดจะให้บริการที่เมืองฟอร์ท เวิร์ธ มลรัฐเทกซัส และ เมืองเมมฟิส มลรัฐเทนเนสซี...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_60  odd lastinrow" style="width:33%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h2 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1460:จิ๊กโก๋-จิ๊กกี๋-รักษาพระองค์&amp;catid=60:announcement-category&amp;Itemid=208">จิ๊กโก๋ จิ๊กกี๋...</a></h2></div><div class="aidanews2_top" style="clear: both;"><div class="aidanews2_topL">วันที่ลงประชาสัมพันธ์ <span class="aidanews2_date">12/11/2012, 00:52</span></div><div style="clear: both; width: 100%; padding: 0;"></div></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1460:จิ๊กโก๋-จิ๊กกี๋-รักษาพระองค์&amp;catid=60:announcement-category&amp;Itemid=208"><img src="images/oct2012/chik.jpg" width="100" height="100" alt="จิ๊กโก๋-จิ๊กกี๋-รักษาพระองค์"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">ใส่เสื้อจิ๊กโก๋,จิ๊กกี๋ แล้วพกเทียนมาคนละเล่มเราจะมาร้องเพลงถวายพระพรพร้อมๆกัน เวลาเที่ยงคืนตรงวันอาทิตย์ที่ 18 Nov ที่ cafe' Asia , 1550 Wilson Boulevard #100  Arlington, VA...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div></div><div class="aidanews2_tabrow"><div class="aidanews2_art aidacat_60  even firstinrow" style="width:33%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h2 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1441:ตามหาพี่ชาย‏&amp;catid=60:announcement-category&amp;Itemid=208">ตามหาพี่ชาย‏...</a></h2></div><div class="aidanews2_top" style="clear: both;"><div class="aidanews2_topL">วันที่ลงประชาสัมพันธ์ <span class="aidanews2_date">31/10/2012, 20:02</span></div><div style="clear: both; width: 100%; padding: 0;"></div></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1441:ตามหาพี่ชาย‏&amp;catid=60:announcement-category&amp;Itemid=208"><img src="modules/mod_aidanews2/img/aidadefault1.jpg" width="100" height="100" alt="ตามหาพี่ชาย‏"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">ผมสมพร อยู่ที่ประทศไทยขาดการติดต่อกับพี่ชายชื่อ
 
นายวินัย อุเบกขานุกุล
 
ติดต่อครั้งล่าสุดอยู่ในลาสเวกัส...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_60  odd" style="width:33%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h2 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1429:การจดแจ้งเป็นเครือข่ายวัฒนธรรมและจัดตั้งสภาวัฒนธรรมไทยในต่างประเทศของกระทรวงวัฒนธรรม‏&amp;catid=60:announcement-category&amp;Itemid=208">การจดแจ้งเป็นเครือข่ายวัฒนธรรมและจั...</a></h2></div><div class="aidanews2_top" style="clear: both;"><div class="aidanews2_topL">วันที่ลงประชาสัมพันธ์ <span class="aidanews2_date">13/10/2012, 16:41</span></div><div style="clear: both; width: 100%; padding: 0;"></div></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1429:การจดแจ้งเป็นเครือข่ายวัฒนธรรมและจัดตั้งสภาวัฒนธรรมไทยในต่างประเทศของกระทรวงวัฒนธรรม‏&amp;catid=60:announcement-category&amp;Itemid=208"><img src="images/nov2012/thaiemb1.jpg" width="100" height="100" alt="การจดแจ้งเป็นเครือข่ายวัฒนธรรมและจัดตั้งสภาวัฒนธรรมไทยในต่างประเทศของกระทรวงวัฒนธรรม‏"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">สถานเอกอัครราชทูตฯ ขอนำส่งประกาศเรื่อง การจดแจ้งเป็นเครือข่ายวัฒนธรรมและจัดตั้งสภาวัฒนธรรมไทยในต่างประเทศ
ของกระทรวงวัฒนธรรม ...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_60  even last lastinrow" style="width:33%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h2 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1428:การรับสมัครนักศึกษา-ระดับปริญญาโท-ของมหาวิทยาลัยรามคำแหง-สำหรับชาวไทยในต่างประเทศ&amp;catid=60:announcement-category&amp;Itemid=208">การรับสมัครนักศึกษา ระดับปริญญาโท...</a></h2></div><div class="aidanews2_top" style="clear: both;"><div class="aidanews2_topL">วันที่ลงประชาสัมพันธ์ <span class="aidanews2_date">13/10/2012, 16:35</span></div><div style="clear: both; width: 100%; padding: 0;"></div></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1428:การรับสมัครนักศึกษา-ระดับปริญญาโท-ของมหาวิทยาลัยรามคำแหง-สำหรับชาวไทยในต่างประเทศ&amp;catid=60:announcement-category&amp;Itemid=208"><img src="images/nov2012/ram3.jpg" width="100" height="100" alt="การรับสมัครนักศึกษา-ระดับปริญญาโท-ของมหาวิทยาลัยรามคำแหง-สำหรับชาวไทยในต่างประเทศ"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">ประชาสัมพันธ์การรับสมัครนักศึกษา ระดับปริญญาโท ของมหาวิทยาลัยรามคำแหง สาขาวิทยบริการฯ ต่างประเทศ ...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div></div></div><div class="aidanews2_bottomlink"><a href="http://www.konthaiusa.com/local-menu/announcement-13.html">ประชาสัมพันธ์ทั้งหมด--></a></div><div style="clear: both;"></div>						<div class="s5_clear_float" style="clear:both; height:0px"></div>
					</div>
				</div>

			
		</div>
		
		</div>

		
				
		<div class="module_round_box_outer">
		
		<div class="module_round_box-style2">


				<div class="s5_module_box_1">
					<div class="s5_module_box_2">
												

<div class="custom-style2"  >
	<h1><a href="variety-article.html" target="_self">วาไรตี้</a></h1></div>
						<div class="s5_clear_float" style="clear:both; height:0px"></div>
					</div>
				</div>

			
		</div>
		
		</div>

		
				
		<div class="module_round_box_outer">
		
		<div class="module_round_box">


				<div class="s5_module_box_1">
					<div class="s5_module_box_2">
												<div id="aidapagestop178" class="paginationstyle">
			<a href="#" rel="aida_pager_previous">Prev</a> <span class="flatview"></span> <a href="#" rel="aida_pager_next">Next</a>
			</div><div class="aidanews2 aidanews2_table" style="clear: both;"><div class="aidanews2_tabrow"><div class="aidanews2_art aidacat_68 aidapage178 hidepiece  odd first firstinrow infirstrow" style="width:33%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1522:กิจกรรมการเก็บตัว-miss-universe-thailand-2013-day-1&amp;catid=68:variety&amp;Itemid=220">กิจกรรมการเก็บตัว Miss Universe...</a></h1></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1522:กิจกรรมการเก็บตัว-miss-universe-thailand-2013-day-1&amp;catid=68:variety&amp;Itemid=220"><img src="images/apl2013/tee_2330.jpg" width="150" height="150" alt="กิจกรรมการเก็บตัว-miss-universe-thailand-2013-day-1"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">การประกวดมิสยูนิเวิร์สไทยแลนด์ 2013 รอบตัดสิน โดย สุรางค์ เปรมปรีด์ ประธานอำนวยการกองประกวดฯ เริ่มขึ้นในค่ำวันเสาร์ที่ 11 พฤษภาคม 2556 ณ รอยัล พารากอน ฮอลล์ 1-2 ศูนย์การค้าสยามพารากอน โดยผลการประกวด “มิสยูนิเวิร์สไทยแลนด์” คนที่ 14 ได้หมายเลข 11 “ลิต้า ชาลิตา แย้มวัณณังค์” อายุ 24 ปี...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_68 aidapage178 hidepiece  even infirstrow" style="width:33%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1482:5-หนทางสู่การเป็นบริษัทชั้นนำในวงการแฟชั่นปี-2556&amp;catid=68:variety&amp;Itemid=220">5...</a></h1></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1482:5-หนทางสู่การเป็นบริษัทชั้นนำในวงการแฟชั่นปี-2556&amp;catid=68:variety&amp;Itemid=220"><img src="images/jan2013/f3.jpg" width="150" height="150" alt="5-หนทางสู่การเป็นบริษัทชั้นนำในวงการแฟชั่นปี-2556"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">Women’s Wear Daily ได้เผยแพร่แนวโม้มสำหรับอุตสาหกรรมเครื่องนุ่งห่มสำหรับปี 2556 ซึ่งไม่ใช่เรื่องว่าแฟชั่นแบบใดจะเป็นที่นิยม แต่เป็นเรื่องที่บริษัทเครื่องนุ่งห่มต้องให้ความสำคัญ เพื่อพัฒนาธุรกิจของตนเองสู่ผู้นำของวงการแฟชั่น จำนวน 5 เรื่อง ได้แก่

1. บริษัทญี่ปุ่น Rakuten...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_68 aidapage178 hidepiece  odd last lastinrow infirstrow" style="width:33%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1481:10-อันดับแนวโน้มอาหารในปี-2013&amp;catid=68:variety&amp;Itemid=220">10 อันดับแนวโน้มอาหารในปี...</a></h1></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1481:10-อันดับแนวโน้มอาหารในปี-2013&amp;catid=68:variety&amp;Itemid=220"><img src="images/jan2013/imagescanvuzjt.jpg" width="150" height="150" alt="10-อันดับแนวโน้มอาหารในปี-2013"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">ข้าวโพดคั่ว Popcorn อาหารว่างของผู้ใหญ่ทั้งหลายและ Comfort food แนวเอเชีย ทั้งสองอย่างนี้อยู่ในกลุ่มอาหารที่ได้รับการนิยมมากในอุตสาหกรรมอาหาร ตามการคาดการณ์ 10 อันดับแนวโน้มสินค้าอาหารในปี 2013 โดยบริษัท Sterling-Rice Group ซึ่งเป็นบริษัทให้คำปรึกษาด้านการทำยุทธศาสตร์สินค้าอาหาร...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div></div></div><div class="aidanews2_bottomlink"><a href="http://www.konthaiusa.com/variety-article.html">วาไรตี้ทั้งหมด--></a></div><script type="text/javascript">
			var aidapages=new virtualpaginate({
				piececlass: "aidapage178",piececontainer: 'div', pieces_per_page: 3, 
				defaultpage: 0,	wraparound: false, persist: false
			})
			 aidapages.buildpagination(["aidapagestop178"])</script><div style="clear: both;"></div>						<div class="s5_clear_float" style="clear:both; height:0px"></div>
					</div>
				</div>

			
		</div>
		
		</div>

	
						</div>
										
										
										
										
										
											
					<div style="clear:both; height:0px"></div>
				</div>
				</div>	
			</div>	
				
		</div>
		</div>
		</div>
			<!-- End Bottom Row2 -->
	
	
	
	<!-- Bottom Row3 -->	
				<div id="s5_bottom_row3_area1">	
		<div id="s5_bottom_row3_area2">
		<div id="s5_bottom_row3_area_inner">
		
			<div id="s5_bottom_row3_wrap">
				<div id="s5_bottom_row3">
				<div id="s5_bottom_row3_inner">
				
											<div id="s5_pos_bottom_row3_1" class="s5_float_left" style="width:25%">
								
				
		<div class="module_round_box_outer">
		
		<div class="module_round_box-style4">


				<div class="s5_module_box_1">
					<div class="s5_module_box_2">
												<iframe title="Simple youtube module by JoomShaper.com" id="sp-simple-youtube171" type="text/html" width="280" height="200" src="http://www.youtube.com/embed/ygK7kej0BPA?wmode=Opaque" frameborder="0" allowFullScreen></iframe>
	
						<div class="s5_clear_float" style="clear:both; height:0px"></div>
					</div>
				</div>

			
		</div>
		
		</div>

	
						</div>
										
											<div id="s5_pos_bottom_row3_2" class="s5_float_left" style="width:25%">
								
				
		<div class="module_round_box_outer">
		
		<div class="module_round_box-style4">


				<div class="s5_module_box_1">
					<div class="s5_module_box_2">
												<iframe title="Simple youtube module by JoomShaper.com" id="sp-simple-youtube172" type="text/html" width="280" height="200" src="http://www.youtube.com/embed/QMECDnECjJM?wmode=Opaque" frameborder="0" allowFullScreen></iframe>
	
						<div class="s5_clear_float" style="clear:both; height:0px"></div>
					</div>
				</div>

			
		</div>
		
		</div>

	
						</div>
										
											<div id="s5_pos_bottom_row3_3" class="s5_float_left" style="width:25%">
								
				
		<div class="module_round_box_outer">
		
		<div class="module_round_box-style4">


				<div class="s5_module_box_1">
					<div class="s5_module_box_2">
												<iframe title="Simple youtube module by JoomShaper.com" id="sp-simple-youtube173" type="text/html" width="280" height="200" src="http://www.youtube.com/embed/gS2GhpTPLvQ?wmode=Opaque" frameborder="0" allowFullScreen></iframe>
	
						<div class="s5_clear_float" style="clear:both; height:0px"></div>
					</div>
				</div>

			
		</div>
		
		</div>

	
						</div>
										
											<div id="s5_pos_bottom_row3_4" class="s5_float_left" style="width:25%">
								
				
		<div class="module_round_box_outer">
		
		<div class="module_round_box-style4">


				<div class="s5_module_box_1">
					<div class="s5_module_box_2">
												<iframe title="Simple youtube module by JoomShaper.com" id="sp-simple-youtube174" type="text/html" width="280" height="200" src="http://www.youtube.com/embed/ywSeSlVcY4w?wmode=Opaque" frameborder="0" allowFullScreen></iframe>
	
						<div class="s5_clear_float" style="clear:both; height:0px"></div>
					</div>
				</div>

			
		</div>
		
		</div>

	
						</div>
										
										
											
					<div style="clear:both; height:0px"></div>

				</div>
				</div>
			</div>
			

		</div>
		</div>
		</div>
			<!-- End Bottom Row3 -->
	
		
	</div>
	
	<div class="s5_bl">
	<div class="s5_br">
	<div class="s5_b_shadow">
	
	</div>
	</div>
	</div>
	
	</div>
	
		
	
	
			<div id="s5_bottom_menu_wrap">
					<div class="moduletable-s5_box">
			
<script type="text/javascript" src="http://konthaiusa.com/modules/mod_s5_box/js/s5_box_hide_div.js"></script>


<div class="s5boxhidden"><div id="s5box_login">
		<div class="moduletable">
					<h3>Login Form</h3>
					<form action="/index.php" method="post" id="login-form" >
		<fieldset class="userdata">
	<p id="form-login-username">
		<label for="modlgn-username">User Name</label>
		<input id="modlgn-username" type="text" name="username" class="inputbox"  size="18" />
	</p>
	<p id="form-login-password">
		<label for="modlgn-passwd">Password</label>
		<input id="modlgn-passwd" type="password" name="password" class="inputbox" size="18"  />
	</p>
		<p id="form-login-remember">
		<label for="modlgn-remember">Remember Me</label>
		<input id="modlgn-remember" type="checkbox" name="remember" class="inputbox" value="yes"/>
	</p>
		<input type="submit" name="Submit" class="button" value="Log in" />
	<input type="hidden" name="option" value="com_users" />
	<input type="hidden" name="task" value="user.login" />
	<input type="hidden" name="return" value="aW5kZXgucGhwP29wdGlvbj1jb21fY29udGVudCZ2aWV3PWFydGljbGUmaWQ9MTQ4OSZJdGVtaWQ9MjUz" />
	<input type="hidden" name="5481de8fb1d80c44cdbeea10bb13800d" value="1" />	</fieldset>
	<ul>
		<li>
			<a href="/index.php?option=com_users&amp;view=reset">
			Forgot your password?</a>
		</li>
		<li>
			<a href="/index.php?option=com_users&amp;view=remind">
			Forgot your username?</a>
		</li>
				<li>
			<a href="/index.php?option=com_users&amp;view=registration">
				Create an account</a>
		</li>
			</ul>
	</form>
		</div>
	</div></div>  

	
	
		</div>
			<div class="moduletable-style2">
			

<div class="custom-style2"  >
	<h1 class="s5_greenbox">บทความทั่วไป</h1></div>
		</div>
			<div class="moduletable">
			

<div class="custom"  >
	<p> </p>
<h2><span class="ul_star"><br /></span></h2>
<h1><a href="menu-article/menu-people.html" target="_self"><span class="ul_star"><span style="color: red;">สังคม/บุคคล</span></span></a></h1></div>
		</div>
			<div class="moduletable">
			<div class="aidanews2 aidanews2_table" style="clear: both;"><div class="aidanews2_tabrow"><div class="aidanews2_art aidacat_66  odd first firstinrow infirstrow" style="width:19%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1472:พระสุธีธรรมานุวัตร-มัคคุเทศก์มือ-1-รับโอบามา-เยือนวัดโพธิ์&amp;catid=66:social-people&amp;Itemid=218">พระสุธีธรรมานุวัตร มัคคุเทศก์มือ 1 รับโอบามา...</a></h1></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1472:พระสุธีธรรมานุวัตร-มัคคุเทศก์มือ-1-รับโอบามา-เยือนวัดโพธิ์&amp;catid=66:social-people&amp;Itemid=218"><img src="images/oct2012/fun01251155p1.jpg" width="72" height="72" alt="พระสุธีธรรมานุวัตร-มัคคุเทศก์มือ-1-รับโอบามา-เยือนวัดโพธิ์"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">เป็นครั้งแรกที่ผู้นำสหรัฐอเมริกา ประธานาธิบดีบารัค โอบามา...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_66  even infirstrow" style="width:19%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1381:นักกีฬาไทยที่ได้เหรียญทอง-12-เหรียญ-เหรียญเงิน-6-เหรียญ&amp;catid=66:social-people&amp;Itemid=218">นักกีฬาไทยที่ได้เหรียญทอง 12 เหรียญ เหรียญเงิน 6...</a></h1></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1381:นักกีฬาไทยที่ได้เหรียญทอง-12-เหรียญ-เหรียญเงิน-6-เหรียญ&amp;catid=66:social-people&amp;Itemid=218"><img src="images/jul2012/nyal.jpg" width="72" height="72" alt="นักกีฬาไทยที่ได้เหรียญทอง-12-เหรียญ-เหรียญเงิน-6-เหรียญ"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text"> ภาสินี ศากยวงศ์
กีฬา กีฬา  เป็นยาวิเศษ  การออกกำลังกายทำให้ร่างกายแข็งแรง ...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_66  odd infirstrow" style="width:19%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1332:eveinterview&amp;catid=66:social-people&amp;Itemid=218">บทบาทคุณแม่มือใหม่ของ อีฟ กมลชนก...</a></h1></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1332:eveinterview&amp;catid=66:social-people&amp;Itemid=218"><img src="images/jul2012/cover.jpg" width="72" height="72" alt="eveinterview"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">เมื่อดาราสาว ได้รับบทบาทการเป็นแม่ครั้งแรกในชีวิตของเธอ เธอรู้สึกอย่างไรบ้าง...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_66  even infirstrow" style="width:19%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1197:พริสซิลลา-ชาน-เจ้าสาวของ-มาร์ค-ซัคเคอร์เบิร์ก&amp;catid=66:social-people&amp;Itemid=218">พริสซิลลา ชาน&quot;เจ้าสาวของ&quot;มาร์ค...</a></h1></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1197:พริสซิลลา-ชาน-เจ้าสาวของ-มาร์ค-ซัคเคอร์เบิร์ก&amp;catid=66:social-people&amp;Itemid=218"><img src="images/may2012/01112.jpg" width="72" height="72" alt="พริสซิลลา-ชาน-เจ้าสาวของ-มาร์ค-ซัคเคอร์เบิร์ก"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">ถึงตอนนี้เราต่างทราบกันดีแล้วว่า รายชื่อมหาเศรษฐีพันล้าน ต้องมีชื่อของ"มาร์ค...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_66  odd last lastinrow infirstrow" style="width:19%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=983:wtcengineer&amp;catid=66:social-people&amp;Itemid=218">นินจาแห่งสยาม</a></h1></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=983:wtcengineer&amp;catid=66:social-people&amp;Itemid=218"><img src="images/aug2011/damrong.png" width="72" height="72" alt="wtcengineer"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">รายงานพิเศษ  วาระครบรอบ 10 ปี เหตุการณ์วันที่ 11 กันยายน 2001
คุณดำรง องคะสุวรรณ...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div></div></div><div style="clear: both;"></div>		</div>
			<div class="moduletable">
			

<div class="custom"  >
	<p> </p>
<h2><span class="ul_star"><br /></span></h2>
<h1><a href="menu-article/%E0%B8%AA%E0%B8%B8%E0%B8%82%E0%B8%A0%E0%B8%B2%E0%B8%9E-%E0%B8%8A%E0%B8%B5%E0%B8%A7%E0%B8%B4%E0%B8%95-%E0%B9%80%E0%B8%A8%E0%B8%A3%E0%B8%A9%E0%B8%90%E0%B8%81%E0%B8%B4%E0%B8%88.html" target="_self"><span class="ul_star"><span style="color: red;">สุขภาพ/ชีวิต/เศรษฐกิจ</span></span></a></h1></div>
		</div>
			<div class="moduletable">
			<div class="aidanews2 aidanews2_table" style="clear: both;"><div class="aidanews2_tabrow"><div class="aidanews2_art aidacat_65  odd first firstinrow infirstrow" style="width:19%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1512:ผลกระทบค่าเงินบาทแข็งตัวในตลาดสหรัฐอเมริกา&amp;catid=65:heath-life&amp;Itemid=217">ผลกระทบค่าเงินบาทแข็งตัวในตลาดสหรัฐอเมริกา...</a></h1></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1512:ผลกระทบค่าเงินบาทแข็งตัวในตลาดสหรัฐอเมริกา&amp;catid=65:heath-life&amp;Itemid=217"><img src="images/mar2013/images.jpg" width="72" height="72" alt="ผลกระทบค่าเงินบาทแข็งตัวในตลาดสหรัฐอเมริกา"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">จากการสอบถามความเห็นของผู้นำเข้าสินค้าจากประเทศไทย...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_65  even infirstrow" style="width:19%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1494:ร้านค้าปลีกในสหรัฐฯที่คาดว่าจะต้องปิดตัวลงในปี-๒๕๕๖&amp;catid=65:heath-life&amp;Itemid=217">ร้านค้าปลีกในสหรัฐฯที่คาดว่าจะต้องปิดตัวลงในปี...</a></h1></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1494:ร้านค้าปลีกในสหรัฐฯที่คาดว่าจะต้องปิดตัวลงในปี-๒๕๕๖&amp;catid=65:heath-life&amp;Itemid=217"><img src="images/jan2013/8996851.jpg" width="72" height="72" alt="ร้านค้าปลีกในสหรัฐฯที่คาดว่าจะต้องปิดตัวลงในปี-๒๕๕๖"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">หลังจากช่วงฤดูกาลช้อปปิ้ง Holiday Shopping Season...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_65  odd infirstrow" style="width:19%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1486:ธุรกิจขาย-on-line-ในสหรัฐฯ-เพิ่มขึ้นแต่ยังไม่น่าพอใจ&amp;catid=65:heath-life&amp;Itemid=217">ธุรกิจขาย On Line ในสหรัฐฯ -...</a></h1></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1486:ธุรกิจขาย-on-line-ในสหรัฐฯ-เพิ่มขึ้นแต่ยังไม่น่าพอใจ&amp;catid=65:heath-life&amp;Itemid=217"><img src="images/jan2013/s2.jpg" width="72" height="72" alt="ธุรกิจขาย-on-line-ในสหรัฐฯ-เพิ่มขึ้นแต่ยังไม่น่าพอใจ"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">สหรัฐอเมริกาเป็นประเทศที่มีการทำธุรกรรม On Line สูงที่สุดในโลก...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_65  even infirstrow" style="width:19%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1485:ตลาดรถยนต์ในสหรัฐฯ-อีกหนึ่งตัวของดัชนีผู้บริโภค&amp;catid=65:heath-life&amp;Itemid=217">ตลาดรถยนต์ในสหรัฐฯ -...</a></h1></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1485:ตลาดรถยนต์ในสหรัฐฯ-อีกหนึ่งตัวของดัชนีผู้บริโภค&amp;catid=65:heath-life&amp;Itemid=217"><img src="images/jan2013/images.jpg" width="72" height="72" alt="ตลาดรถยนต์ในสหรัฐฯ-อีกหนึ่งตัวของดัชนีผู้บริโภค"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">ธุรกิจการจำหน่ายรถยนต์ในสหรัฐฯรายงานตัวเลขการขายที่ดีที่สุดในปีที่ผ่านมา (๒๐๑๒)...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_65  odd last lastinrow infirstrow" style="width:19%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1484:แนวโน้มผู้บริโภคต่ออาหารทะเลปี-2013&amp;catid=65:heath-life&amp;Itemid=217">แนวโน้มผู้บริโภคต่ออาหารทะเลปี...</a></h1></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1484:แนวโน้มผู้บริโภคต่ออาหารทะเลปี-2013&amp;catid=65:heath-life&amp;Itemid=217"><img src="modules/mod_aidanews2/img/aidadefault1.jpg" width="72" height="72" alt="แนวโน้มผู้บริโภคต่ออาหารทะเลปี-2013"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">(ปีของการทำอาหารในครัวเรือนและสินค้า Private...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div></div></div><div style="clear: both;"></div>		</div>
			<div class="moduletable">
			

<div class="custom"  >
	<p> </p>
<h2><span class="ul_star"><br /></span></h2>
<h1><a href="menu-article/menu-education-health.html" target="_self"><span class="ul_star"><span style="color: red;">เทคโนโลยี่/การศึกษา</span></span></a></h1></div>
		</div>
			<div class="moduletable">
			<div class="aidanews2 aidanews2_table" style="clear: both;"><div class="aidanews2_tabrow"><div class="aidanews2_art aidacat_67  odd first firstinrow infirstrow" style="width:19%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1435:10-สาขาวิชาเอกที่ตกงาน-ค่าตอบแทนน้อยสุด-กับ-10-สาขาที่ได้เงินสูงสุดในอเมริกา&amp;catid=67:techno-education&amp;Itemid=219">10 สาขาวิชาเอกที่ตกงาน-ค่าตอบแทนน้อยสุด กับ 10...</a></h1></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1435:10-สาขาวิชาเอกที่ตกงาน-ค่าตอบแทนน้อยสุด-กับ-10-สาขาที่ได้เงินสูงสุดในอเมริกา&amp;catid=67:techno-education&amp;Itemid=219"><img src="images/nov2012/images.jpg" width="72" height="72" alt="10-สาขาวิชาเอกที่ตกงาน-ค่าตอบแทนน้อยสุด-กับ-10-สาขาที่ได้เงินสูงสุดในอเมริกา"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">เว็บไซต์ฟอร์บ นำเสนอผลสำรวจจากศูนย์การศึกษาและทำงาน แห่งมหาวิทยาลัยจอร์จทาวน์...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_67  even infirstrow" style="width:19%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1357:the-new-iphone-iphone-5&amp;catid=67:techno-education&amp;Itemid=219">The New iPhone (iPhone 5)</a></h1></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1357:the-new-iphone-iphone-5&amp;catid=67:techno-education&amp;Itemid=219"><img src="images/jun2012/7qjf2whv.jpg" width="72" height="72" alt="the-new-iphone-iphone-5"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">iPhone 5 - ช่วงนี้มีเรื่องข่าวหลุด-ข่าวลือเกี่ยวกับภาพดีไซน์ ผลิตภัณฑ์รุ่นใหม่อย่าง...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_67  odd infirstrow" style="width:19%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1356:surface&amp;catid=67:techno-education&amp;Itemid=219">&quot;Surface&quot;...</a></h1></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1356:surface&amp;catid=67:techno-education&amp;Itemid=219"><img src="images/jun2012/surface_01-gallery.jpg" width="72" height="72" alt="surface"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">หลังจากที่มีข่าวออกมาว่าไมโครซอฟท์ เตรียมเปิดตัวแท็บเล็ตที่ใช้ระบบปฏิบัติการ "Window...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_67  even infirstrow" style="width:19%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1349:emoji&amp;catid=67:techno-education&amp;Itemid=219">Emoji...</a></h1></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1349:emoji&amp;catid=67:techno-education&amp;Itemid=219"><img src="images/jun2012/emoji1.gif" width="72" height="72" alt="emoji"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">ในปัจจุบันโลกออนไลน์และการสื่อสารเข้ามามีบทบาทในชีวิตและสัมคมมากขึ้น...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div><div class="aidanews2_art aidacat_67  odd last lastinrow infirstrow" style="width:19%"><div class="aidanews2_positions"><div class="aidanews2_head" style="clear: both;"><h1 class="aidanews2_title"><a href="/index.php?option=com_content&amp;view=article&amp;id=1166:iphone-5-liquid-metal&amp;catid=67:techno-education&amp;Itemid=219">บอดี้ iPhone 5 ใช้วัสดุประเภท Liquid Metal...</a></h1></div><div class="aidanews2_main" style="clear: both;"><div class="aidanews2_mainL"><a class="aidanews2_img1" href="/index.php?option=com_content&amp;view=article&amp;id=1166:iphone-5-liquid-metal&amp;catid=67:techno-education&amp;Itemid=219"><img src="images/may2012/images_1317398887iphone5-3.jpg" width="72" height="72" alt="iphone-5-liquid-metal"/></a></div><div class="aidanews2_mainC"><span class="aidanews2_text">iPhone 5 อัพเดทข่าวเปิดตัว และ ราคา iphone 5 (ไอโฟน 5) ล่าสุด :...</span></div></div></div><div class="aidanews2_line" style="clear: both; padding: 0;"></div></div></div></div><div style="clear: both;"></div>		</div>
	
			<div style="clear:both; height:0px"></div>
		</div>	
		
	
	<!-- Footer Area -->
		<div id="s5_footer_area1">
		<div id="s5_footer_area2">
		<div id="s5_footer_area_inner">
		
		<div class="s5_tl">
		<div class="s5_tr">
		<div class="s5_t_shadow">
		
		</div>
		</div>
		</div>
		
							<div id="s5_footer">
					<span class="footerc">
Copyright &copy; 2017.  www.konthaiusa.com.
Designed by Kittinut Sangsri
</span>
				</div>
						

			
		</div>
		</div>
		</div>
	<!-- End Footer Area -->
	
	<!-- Bottom Vertex Calls -->
	<div>
	<!-- Page scroll, tooltips, multibox, and ie6 warning -->	
	<script type="text/javascript">
function s5_scrollit() { new SmoothScroll({ duration: 800 }); }
function s5_scrollitload() {s5_scrollit();}
window.setTimeout(s5_scrollitload,400);
</script>
<a href="#s5_scrolltotop" class="s5_scrolltotop"></a>
		
	<script type="text/javascript">
		var s5mbox = {};
		
				
		        window.addEvent('domready', function() {
				
		s5mbox = new MultiBox('s5mb', {descClassName: 's5_multibox', useOverlay: true, showControls: true});	
		
		});	</script>
		
			<script type="text/javascript">//<![CDATA[
			if (document.getElementById("s5_top_row1_area_inner")) {
				var s5_lazy_load_imgs = document.getElementById("s5_top_row1_area_inner").getElementsByTagName("IMG");
				for (var s5_lazy_load_imgs_y=0; s5_lazy_load_imgs_y<s5_lazy_load_imgs.length; s5_lazy_load_imgs_y++) {
					if (s5_lazy_load_imgs[s5_lazy_load_imgs_y].className == "") {
						s5_lazy_load_imgs[s5_lazy_load_imgs_y].className = "s5_lazyload";
					}
					else {
						s5_lazy_load_imgs[s5_lazy_load_imgs_y].className = s5_lazy_load_imgs[s5_lazy_load_imgs_y].className + " s5_lazyload";
					}
				}
			}
			if (document.getElementById("s5_top_row2_area_inner")) {
				var s5_lazy_load_imgs = document.getElementById("s5_top_row2_area_inner").getElementsByTagName("IMG");
				for (var s5_lazy_load_imgs_y=0; s5_lazy_load_imgs_y<s5_lazy_load_imgs.length; s5_lazy_load_imgs_y++) {
					if (s5_lazy_load_imgs[s5_lazy_load_imgs_y].className == "") {
						s5_lazy_load_imgs[s5_lazy_load_imgs_y].className = "s5_lazyload";
					}
					else {
						s5_lazy_load_imgs[s5_lazy_load_imgs_y].className = s5_lazy_load_imgs[s5_lazy_load_imgs_y].className + " s5_lazyload";
					}
				}
			}
			if (document.getElementById("s5_top_row3_area_inner")) {
				var s5_lazy_load_imgs = document.getElementById("s5_top_row3_area_inner").getElementsByTagName("IMG");
				for (var s5_lazy_load_imgs_y=0; s5_lazy_load_imgs_y<s5_lazy_load_imgs.length; s5_lazy_load_imgs_y++) {
					if (s5_lazy_load_imgs[s5_lazy_load_imgs_y].className == "") {
						s5_lazy_load_imgs[s5_lazy_load_imgs_y].className = "s5_lazyload";
					}
					else {
						s5_lazy_load_imgs[s5_lazy_load_imgs_y].className = s5_lazy_load_imgs[s5_lazy_load_imgs_y].className + " s5_lazyload";
					}
				}
			}
			if (document.getElementById("s5_center_area_inner")) {
				var s5_lazy_load_imgs = document.getElementById("s5_center_area_inner").getElementsByTagName("IMG");
				for (var s5_lazy_load_imgs_y=0; s5_lazy_load_imgs_y<s5_lazy_load_imgs.length; s5_lazy_load_imgs_y++) {
					if (s5_lazy_load_imgs[s5_lazy_load_imgs_y].className == "") {
						s5_lazy_load_imgs[s5_lazy_load_imgs_y].className = "s5_lazyload";
					}
					else {
						s5_lazy_load_imgs[s5_lazy_load_imgs_y].className = s5_lazy_load_imgs[s5_lazy_load_imgs_y].className + " s5_lazyload";
					}
				}
			}
			if (document.getElementById("s5_bottom_row1_area_inner")) {
				var s5_lazy_load_imgs = document.getElementById("s5_bottom_row1_area_inner").getElementsByTagName("IMG");
				for (var s5_lazy_load_imgs_y=0; s5_lazy_load_imgs_y<s5_lazy_load_imgs.length; s5_lazy_load_imgs_y++) {
					if (s5_lazy_load_imgs[s5_lazy_load_imgs_y].className == "") {
						s5_lazy_load_imgs[s5_lazy_load_imgs_y].className = "s5_lazyload";
					}
					else {
						s5_lazy_load_imgs[s5_lazy_load_imgs_y].className = s5_lazy_load_imgs[s5_lazy_load_imgs_y].className + " s5_lazyload";
					}
				}
			}
			if (document.getElementById("s5_bottom_row2_area_inner")) {
				var s5_lazy_load_imgs = document.getElementById("s5_bottom_row2_area_inner").getElementsByTagName("IMG");
				for (var s5_lazy_load_imgs_y=0; s5_lazy_load_imgs_y<s5_lazy_load_imgs.length; s5_lazy_load_imgs_y++) {
					if (s5_lazy_load_imgs[s5_lazy_load_imgs_y].className == "") {
						s5_lazy_load_imgs[s5_lazy_load_imgs_y].className = "s5_lazyload";
					}
					else {
						s5_lazy_load_imgs[s5_lazy_load_imgs_y].className = s5_lazy_load_imgs[s5_lazy_load_imgs_y].className + " s5_lazyload";
					}
				}
			}
			if (document.getElementById("s5_bottom_row3_area_inner")) {
				var s5_lazy_load_imgs = document.getElementById("s5_bottom_row3_area_inner").getElementsByTagName("IMG");
				for (var s5_lazy_load_imgs_y=0; s5_lazy_load_imgs_y<s5_lazy_load_imgs.length; s5_lazy_load_imgs_y++) {
					if (s5_lazy_load_imgs[s5_lazy_load_imgs_y].className == "") {
						s5_lazy_load_imgs[s5_lazy_load_imgs_y].className = "s5_lazyload";
					}
					else {
						s5_lazy_load_imgs[s5_lazy_load_imgs_y].className = s5_lazy_load_imgs[s5_lazy_load_imgs_y].className + " s5_lazyload";
					}
				}
			}
		//]]></script>
		<script type="text/javascript" language="javascript" src="http://konthaiusa.com/templates/sienna/js/lazy_load.js"></script>
				
				
		
	<script type="text/javascript">//<![CDATA[

		var s5_columns_equalizer = new Class({
			initialize: function(elements,stop,prevent) {
				this.elements = $$(elements);
			},
			equalize: function(hw) {
				if(!hw) { hw = 'height'; }
				var max = 0, 
					prop = (typeof document.body.style.maxHeight != 'undefined' ? 'min-' : '') + hw; //ie6 ftl
					offset = 'offset' + hw.capitalize();
				this.elements.each(function(element,i) {
					var calc = element[offset];
					if(calc > max) { max = calc; }
				},this);
				this.elements.each(function(element,i) {
					element.setStyle(prop,max - (element[offset] - element.getStyle(hw).replace('px','')));
				});
				return max;
			}
		});
		
		function s5_load_resize_columns() {
		
		if (document.getElementById("s5_columns_wrap")) {
			var s5_resize_center_columns = document.getElementById("s5_columns_wrap").getElementsByTagName("DIV");
			for (var s5_resize_center_columns_y=0; s5_resize_center_columns_y<s5_resize_center_columns.length; s5_resize_center_columns_y++) {
				if (s5_resize_center_columns[s5_resize_center_columns_y].id == "s5_center_column_wrap_inner" || s5_resize_center_columns[s5_resize_center_columns_y].id == "s5_left_column_wrap" || s5_resize_center_columns[s5_resize_center_columns_y].id == "s5_right_column_wrap") {
					if (s5_resize_center_columns[s5_resize_center_columns_y].className == "") {
						s5_resize_center_columns[s5_resize_center_columns_y].className = "s5_resize_center_columns";
					}
					else {
						s5_resize_center_columns[s5_resize_center_columns_y].className = "s5_resize_center_columns " + s5_resize_center_columns[s5_resize_center_columns_y].className;
					}
				}
			}
		}
		
		
		new s5_columns_equalizer('.s5_resize_center_columns').equalize('height');
		
				
		}
		
		window.addEvent('domready', function() {
		
		window.setTimeout(s5_load_resize_columns,300);
		
		});

	//]]></script>
	
	
<!-- Additional scripts to load just before closing body tag -->
	<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-8362855-3']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>	</div>
	
	
	
</div>
</div>
</div>
</div>


	
<!-- End pc version -->	

</body>
</html>