<?xml version="1.0" encoding="iso-8859-1"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<title>Tecnovendita Immobiliare di Salvini Antonio - ::</title>
<meta name="description" content="Tecnovendita Immobiliare di Salvini Antonio" />
<meta name="keywords" content="tecnovendita immobiliare, immobiliare, tecnovendita, messina, immobili, affitti, antonio salvini, calcoli, consulenza, agenzia immobiliare, lottizzazioni, permute, progettazioni, statistici, upim, vendite, affitti, case, casa, appartamenti, appartamento, immobile" />
<meta name="Generator" content="Joomla! - Copyright (C) 2005 - 2008 Open Source Matters. Tutti i diritti riservati." />
<meta name="robots" content="index, follow" />
<script type="text/javascript" src="http://www.tecnovenditaimmobiliare.it/mambots/system/cd_scriptegrator/utils/js/highslide.packed.js"></script>
<style type="text/css">@import "http://www.tecnovenditaimmobiliare.it/mambots/system/cd_scriptegrator/css/cd_scriptegrator.css";</style>
<script type="text/javascript">    
    hs.graphicsDir = 'http://www.tecnovenditaimmobiliare.it/mambots/system/cd_scriptegrator/graphics/';
    hs.outlineType = 'rounded-white';
    hs.outlineWhileAnimating = true;
    hs.showCredits = true;
    hs.expandDuration = 250;
    hs.loadingText = 'Loading...';
	hs.loadingTitle = 'Click to cancel';
	hs.anchor = 'auto';
	hs.align = 'auto';
	hs.transitions = ["expand"];
	hs.dimmingOpacity = 0;
	</script>
<style type="text/css">@import "http://www.tecnovenditaimmobiliare.it/modules/mod_cd_login/css/mod_cd_login.css";</style>
<script src="http://maps.google.com/maps?file=api&amp;v=2&amp;key=ABQIAAAAHebDMbFPcuSQR0WXFtKxmhTNEFYHhMiH5ztYHFP8_jYcZOu4dhQERNw5P_s1pJDL5Fd29YbDW0SZfA" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript" charset="utf-8">
//<![CDATA[
/*************************************************
 * Created with GoogleMapAPI 2.5
 * Author: Monte Ohrt <monte AT ohrt DOT com>
 * Copyright 2005-2006 New Digital Group
 * http://www.phpinsider.com/php/code/GoogleMapAPI/
 *************************************************/
var points = [];
var markers = [];
var counter = 0;
var sidebar_html = "";
var marker_html = [];
var to_htmls = [];
var from_htmls = [];
var map = null;
function onLoad() {
if (GBrowserIsCompatible()) {
var mapObj = document.getElementById("map");
if (mapObj != "undefined" && mapObj != null) {
map = new GMap2(document.getElementById("map"));
map.addControl(new GLargeMapControl());
map.addControl(new GMapTypeControl());
map.addControl(new GScaleControl());
var point = new GLatLng(,);
var marker = createMarker(point,"GMap Test","<div id=\"gmapmarker\">    <\/div>", 0,"");
map.addOverlay(marker);
document.getElementById("sidebar_map").innerHTML = "<ul class=\"gmapSidebar\">"+ sidebar_html +"<\/ul>";
}
} else {
alert("Sorry, the Google Maps API is not compatible with this browser.");
}
}
function createMarker(point, title, html, n, tooltip) {
if(n >= 0) { n = -1; }
var marker = new GMarker(point,{'title': tooltip});
var tabFlag = isArray(html);
if(!tabFlag) { html = [{"contentElem": html}]; }
to_htmls[counter] = html[0].contentElem + '<form class="gmapDir" id="gmapDirTo" style="white-space: nowrap;" action="http://maps.google.com/maps" method="get" target="_blank">' +
                     '<span class="gmapDirHead" id="gmapDirHeadTo">Directions: <strong>To here</strong> - <a href="javascript:fromhere(' + counter + ')">From here</a></span>' +
                     '<p class="gmapDirItem" id="gmapDirItemTo"><label for="gmapDirSaddr" class="gmapDirLabel" id="gmapDirLabelTo">Start address: (include addr, city st/region)<br /></label>' +
                     '<input type="text" size="40" maxlength="40" name="saddr" class="gmapTextBox" id="gmapDirSaddr" value="" onfocus="this.style.backgroundColor = \'#e0e0e0\';" onblur="this.style.backgroundColor = \'#ffffff\';" />' +
                     '<span class="gmapDirBtns" id="gmapDirBtnsTo"><input value="Get Directions" type="submit" class="gmapDirButton" id="gmapDirButtonTo" /></span></p>' +
                     '<input type="hidden" name="daddr" value="' +
                     point.y + ',' + point.x + "(" + title.replace(new RegExp(/"/g),'&quot;') + ")" + '" /></form>';
                      from_htmls[counter] = html[0].contentElem + '<p /><form class="gmapDir" id="gmapDirFrom" style="white-space: nowrap;" action="http://maps.google.com/maps" method="get" target="_blank">' +
                     '<span class="gmapDirHead" id="gmapDirHeadFrom">Directions: <a href="javascript:tohere(' + counter + ')">To here</a> - <strong>From here</strong></span>' +
                     '<p class="gmapDirItem" id="gmapDirItemFrom"><label for="gmapDirSaddr" class="gmapDirLabel" id="gmapDirLabelFrom">End address: (include addr, city st/region)<br /></label>' +
                     '<input type="text" size="40" maxlength="40" name="daddr" class="gmapTextBox" id="gmapDirSaddr" value="" onfocus="this.style.backgroundColor = \'#e0e0e0\';" onblur="this.style.backgroundColor = \'#ffffff\';" />' +
                     '<span class="gmapDirBtns" id="gmapDirBtnsFrom"><input value="Get Directions" type="submit" class="gmapDirButton" id="gmapDirButtonFrom" /></span></p>' +
                     '<input type="hidden" name="saddr" value="' +
                     point.y + ',' + point.x + encodeURIComponent("(" + title.replace(new RegExp(/"/g),'&quot;') + ")") + '" /></form>';
                     html[0].contentElem = html[0].contentElem + '<p /><div id="gmapDirHead" class="gmapDir" style="white-space: nowrap;">Directions: <a href="javascript:tohere(' + counter + ')">To here</a> - <a href="javascript:fromhere(' + counter + ')">From here</a></div>';
if(!tabFlag) { html = html[0].contentElem; }if(isArray(html)) { GEvent.addListener(marker, "click", function() { marker.openInfoWindowTabsHtml(html); }); }
else { GEvent.addListener(marker, "click", function() { marker.openInfoWindowHtml(html); }); }
points[counter] = point;
markers[counter] = marker;
marker_html[counter] = html;
sidebar_html += '<li class="gmapSidebarItem" id="gmapSidebarItem_'+ counter +'"><a href="javascript:click_sidebar(' + counter + ')">' + title + '<\/a><\/li>';
counter++;
return marker;
}
function isArray(a) {return isObject(a) && a.constructor == Array;}
function isObject(a) {return (a && typeof a == 'object') || isFunction(a);}
function isFunction(a) {return typeof a == 'function';}
function click_sidebar(idx) {
  if(isArray(marker_html[idx])) { markers[idx].openInfoWindowTabsHtml(marker_html[idx]); }
  else { markers[idx].openInfoWindowHtml(marker_html[idx]); }
}
function showInfoWindow(idx,html) {
map.centerAtLatLng(points[idx]);
markers[idx].openInfoWindowHtml(html);
}
function tohere(idx) {
markers[idx].openInfoWindowHtml(to_htmls[idx]);
}
function fromhere(idx) {
markers[idx].openInfoWindowHtml(from_htmls[idx]);
}
//]]>
</script>
	<link rel="shortcut icon" href="http://www.tecnovenditaimmobiliare.it/images/favicon.ico" />
	

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<link href="http://www.tecnovenditaimmobiliare.it/templates/vam_jblue/css/template_css.css" rel="stylesheet" type="text/css" />

<link rel="shortcut icon" href="http://www.tecnovenditaimmobiliare.it/images/favicon.ico" />

</head>

<body id="page_bg">

<a name="up" id="up"></a>



<div class="center" align="center">

  <table class="minimal" width="810" id="main">

    <tr>

      <td class="left_shadow"><img src="http://www.tecnovenditaimmobiliare.it/templates/vam_jblue/images/spacer.png" alt="spacer.png, 0 kB" title="spacer" class="" height="1" width="17" /><br /></td>

      <td class="wrapper">

<img border="0" src="/immagini/Logo.gif" />

					  <embed src="flash/scorrevole.swf" quality="high" id="obFlash" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="272" height="150">

					

    		<div id="tabbar">

					<ul id="mainlevel-nav"><li><a href="http://www.tecnovenditaimmobiliare.it/index.php" class="mainlevel-nav" >Home</a></li><li><a href="http://www.tecnovenditaimmobiliare.it/index.php?option=com_contact&amp;Itemid=3" class="mainlevel-nav" >Contattaci</a></li><li><a href="http://www.tecnovenditaimmobiliare.it/index.php?option=com_wrapper&amp;Itemid=28" class="mainlevel-nav" >Dove siamo</a></li></ul>
				</div>

				<div id="colorbar"></div>

				<div id="contentarea">

					<table cellpadding="0" cellspacing="0" border="0" width="760">

						<tr valign="top">

							<td class="sidenav">

							  <div class="forcewidth">

								
								
									<div id="left">

												<div class="moduletable">
							<h3>
					Ultimi annunci				</h3>
				<marquee direction="up"  scrollamount="1" onMouseOver="stop()" onMouseOut="start()"><table width="100%" class="moduletable""><tr><td><table width="100%" style="background-color:#FFFFFF" cellpadding="2" cellspacing=" border="0"><tr><td valign="top" style="text-align:center"><a href="http://www.tecnovenditaimmobiliare.it/index.php?option=com_estateagent&act=object&task=showEO&id=109"><img src='http://www.tecnovenditaimmobiliare.it/components/com_estateagent/pictures/tea1392981892.jpg'/></a></td></tr><tr><td style="text-align:center"><a href="http://www.tecnovenditaimmobiliare.it/index.php?option=com_estateagent&act=object&task=showEO&id=109"><font size='2'><b>Cedesi Attivit� MESSINA Lungomare riviera Nord</b></font></a></td></tr></table><table width="100%" style="background-color:#EBE7E7" cellpadding="2" cellspacing=" border="0"><tr><td valign="top" style="text-align:center"><a href="http://www.tecnovenditaimmobiliare.it/index.php?option=com_estateagent&act=object&task=showEO&id=108"><img src='modules/mod_ea_latest_img/nopic.png'/></a></td></tr><tr><td style="text-align:center"><a href="http://www.tecnovenditaimmobiliare.it/index.php?option=com_estateagent&act=object&task=showEO&id=108"><font size='2'><b>Messina Nord Appartamento panoramicissimo </b></font></a></td></tr></table><table width="100%" style="background-color:#FFFFFF" cellpadding="2" cellspacing=" border="0"><tr><td valign="top" style="text-align:center"><a href="http://www.tecnovenditaimmobiliare.it/index.php?option=com_estateagent&act=object&task=showEO&id=107"><img src='http://www.tecnovenditaimmobiliare.it/components/com_estateagent/pictures/tea1392884021.jpg'/></a></td></tr><tr><td style="text-align:center"><a href="http://www.tecnovenditaimmobiliare.it/index.php?option=com_estateagent&act=object&task=showEO&id=107"><font size='2'><b>Messina Nord vicino mare casa con terreno</b></font></a></td></tr></table><table width="100%" style="background-color:#EBE7E7" cellpadding="2" cellspacing=" border="0"><tr><td valign="top" style="text-align:center"><a href="http://www.tecnovenditaimmobiliare.it/index.php?option=com_estateagent&act=object&task=showEO&id=106"><img src='http://www.tecnovenditaimmobiliare.it/components/com_estateagent/pictures/tea1381335083.jpg'/></a></td></tr><tr><td style="text-align:center"><a href="http://www.tecnovenditaimmobiliare.it/index.php?option=com_estateagent&act=object&task=showEO&id=106"><font size='2'><b>Mortelle SS:113</b></font></a></td></tr></table><table width="100%" style="background-color:#FFFFFF" cellpadding="2" cellspacing=" border="0"><tr><td valign="top" style="text-align:center"><a href="http://www.tecnovenditaimmobiliare.it/index.php?option=com_estateagent&act=object&task=showEO&id=105"><img src='http://www.tecnovenditaimmobiliare.it/components/com_estateagent/pictures/tea1380206069.jpg'/></a></td></tr><tr><td style="text-align:center"><a href="http://www.tecnovenditaimmobiliare.it/index.php?option=com_estateagent&act=object&task=showEO&id=105"><font size='2'><b>APPARTAMENTO VIALE ANNUNZIATA</b></font></a></td></tr></table></td></tr></table></marquee>		</div>
				<div class="moduletable">
							<h3>
					Cerca immobile				</h3>
				<script language="Javascript" type="text/javascript">
<!--
	function disableFields(v,f)
	{
		
		if(v==0 || v=="")
		{
			switch(f)
			{
				case "rent":
					document.getElementById("minrent").readOnly = false;
					document.getElementById('maxrent').readOnly = false;
					document.getElementById("minprice").value = "";
					document.getElementById('maxprice').value = "";
				break;
							
				case "price":
					document.getElementById('minprice').readOnly = false;
					document.getElementById('maxprice').readOnly = false;
					document.getElementById("minrent").value = "";
					document.getElementById('maxrent').value = "";
				break;
			}
		}
		else{
			
			switch(f)
			{
				case "rent":
					document.getElementById("minrent").readOnly = true;
					document.getElementById('maxrent').readOnly = true;
				break;
							
				case "price":
					document.getElementById('minprice').readOnly = true;
					document.getElementById('maxprice').readOnly = true;
				break;
			}
			
		}
	}
-->
</script>

<form action="http://www.tecnovenditaimmobiliare.it/index.php?option=com_estateagent&act=easearch&task=showEASR" method="post" name="mequicksearch">
<table cellpadding='4' cellspacing='0' border='0' width='100%' class='moduletable'>
<tr>
	<td>	
		<select class="inputbox" name="src_cat" id="src_cat" ><option value="A">Tutte le Categorie</option><option value="15">&nbsp;Affitti</option><option value="14">&nbsp;Vendite</option></select>		<br />
		<input class="inputbox" type="text" name="searchstring"  maxlength="100" /><!-- Tooltip -->
<a href="#" onmouseover="return overlib('Ricerca per Rif. immobile o stringa', BELOW, RIGHT);" onmouseout="return nd();" ><img src="http://www.tecnovenditaimmobiliare.it/includes/js/ThemeOffice/tooltip.png" border="0" alt="tooltip"/></a>					<input type="hidden" name="country" value="no" />
			<input type="hidden" name="state" value="no" />
			<input type="hidden" name="town" value="no" />
			<input type="hidden" name="district" value="no" />
					<input type="hidden" name="space" value="0" />
			<input type="hidden" name="yobuilt" value="0" />
			<input type="hidden" name="rooms" value="0" />
			<input type="hidden" name="bedrooms" value="0" />
					<input type="hidden" name="minrent" value="0" />
			<input type="hidden" name="maxrent" value="0" />	
						<input type="hidden" name="minprice" value="0" />
			<input type="hidden" name="maxprice" value="0" />	
					<br />
		<input type="hidden" name="lsearch" value="1" />
		<input class="button" type="submit" name="easearch" id="easearch" value="Inizio Ricerca" /></div>
		<br />
		<a href="http://www.tecnovenditaimmobiliare.it/index.php?option=com_estateagent&act=easearch&Itemid=1" target="_self">Ricerca Estesa</a>
	</td>
</tr>
</table>
</form>		</div>
				<div class="moduletable">
							<h3>
					Accedi al sito				</h3>
				


<div class="cd_moduletitle_logo">
  <a href="#" onclick="return hs.htmlExpand(this, { contentId: 'highslide-html-loginform', wrapperClassName: 'mod_cd_login', outlineType: 'drop-shadow', align: 'auto', anchor: 'auto', dimmingOpacity: '0', slideshowGroup: 'mod_cd_login_loginform' } )" title="Login">Login </a>
</div>


<div class="highslide-html-content" id="highslide-html-loginform">
  
  <div class="highslide-html-content-header">
	  <div class="highslide-move" title="Sposta">
      <a href="#" onclick="return hs.close(this)" class="control" title="Chiudi">Chiudi</a>
    </div>
	</div>
	
  <div class="highslide-body">

    <form action="http://www.tecnovenditaimmobiliare.it/index.php" method="post" name="loginForm" >
              <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
          <tr>
            <td>
              <label for="cd_login_username" class="cd_login-labelusername">Username</label>
              <br />
              <input name="username" id="cd_login_username" type="text" class="inputbox" alt="username" size="10" />
              <br />
              <label for="cd_login_password" class="cd_login-labelpassword">Password</label>
              <br />
              <input type="password" id="cd_login_password" name="passwd" class="inputbox" size="10" alt="password" />
              <br />
              
              <div class="cd_login-form-submit">
                <div class="cd_login-form-input">
                  <input type="checkbox" name="remember" id="cd_login_remember" class="inputbox" value="yes" alt="Ricordami" title="Ricordami" />
                  <label for="cd_login_remember" class="cd_login-labelremember" title="Ricordami">Ricordami</label>
                </div>
                <input type="submit" name="Submit" class="cd_login-loginbutton" title="Entra" value="" />
              </div>
          </td>
        </tr>
        <tr>
          <td>
              <div style="text-align: center">
                <a href="http://www.tecnovenditaimmobiliare.it/index.php?option=com_registration&amp;task=lostPassword" title="Password smarrita?" class="cd_login-lostpassword">Password smarrita?</a> | 
                                  
                  <span style="text-decoration: line-through; color: #A9A9A9">Registrati</span>
                              </div>
          </td>
        </tr>
              </table>
      <div class="cd_imglogo"></div>
            <input type="hidden" name="option" value="login" />
      <input type="hidden" name="op2" value="login" />
      <input type="hidden" name="lang" value="italian" />
      <input type="hidden" name="return" value="http://www.tecnovenditaimmobiliare.it/index.php?option=com_estateagent&amp;act=object&amp;task=showeo&amp;id=91/includes/js/joomla.javascript.js" />
      <input type="hidden" name="message" value="0" />
      <input type="hidden" name="force_session" value="1" />
      <input type="hidden" name="j9ddd8e7c938e5e17ae550e5be1d1ac8b" value="1" />
    </form>

  </div>
    <div style="display: none">Powered by <a href="http://www.greatjoomla.com" title="http://www.greatjoomla.com" target="_blank">Core Design</a></div>

</div>
			</div>
				<div class="moduletable">
							<h3>
					Connessioni al sito				</h3>
						</div>
		
									</div>

								
								<br />

								<img src="http://www.tecnovenditaimmobiliare.it/templates/vam_jblue/images/spacer.png" alt="spacer.png, 0 kB" title="spacer" class="" height="1" width="194" /><br />

							  </div>

              </td>

              <td class="seperator"><img src="http://www.tecnovenditaimmobiliare.it/templates/vam_jblue/images/spacer.png" alt="spacer.png, 0 kB" title="spacer" class="" height="1" width="16" /></td>

							<td class="middle">

							<div class="banner"></div>

							  
								<table class="minimal" width="550" id="greybox">

									<tr valign="top">

									  
										
										
										<td class="largebox">

													<div class="moduletable">
							<h3>
					Annunci				</h3>
				<table cellpadding='0' cellspacing='0' border='0' width='100%' class='moduletable'>
<tr class="sectiontableentry1" ><td>&nbsp;<img src='images/M_images/arrow.png' alt='' border='0' />&nbsp;Affitti (0)</td></tr><tr class="sectiontableentry1" ><td>&nbsp;<img src='images/M_images/arrow.png' alt='' border='0' />&nbsp;<a href="http://www.tecnovenditaimmobiliare.it/index.php?option=com_estateagent&amp;act=cat&amp;task=showCE&amp;id=14">Vendite</a> (19)</td></tr></table>
		</div>
		
										</td>

										
									</tr>

								</table>

								
								<div id="pathway"></div>

								<table width="100%">

									<tr valign="top">

										<td>				<script language="javascript" type="text/javascript" src="http://www.tecnovenditaimmobiliare.it/includes/js/overlib_mini.js"></script>
			<script language="javascript" type="text/javascript" src="http://www.tecnovenditaimmobiliare.it/includes/js/overlib_hideform_mini.js"></script>
			<!-- -------------------------------------------------------- -->
<!-- MisterEstate - a Joomla component -->
<!-- &copy; 2004 - 2007 Darko Selesi, released under GPL. -->
<!-- for more information visit http://www.misterestate.com -->
<!-- or contact me by email: info [at] misterestate.com -->
<!-- -------------------------------------------------------- -->
		<div class="componentheading">
			Database Immobiliare        </div>
		
		<table class="contentpaneopen" width="100%" cellpadding="4" cellspacing="4" border="0">
    	<tr>
    		<td style="text-align:right">&nbsp;</td>
    	</tr>
    	<tr>
    		<td>
    			<a href='http://www.tecnovenditaimmobiliare.it/index.php?option=com_estateagent&act=cat&task=0'>Home</a>    	
	    
	     | <a href='http://www.tecnovenditaimmobiliare.it/index.php?option=com_estateagent&act=easearch&Itemid=1'>Cerca</a>		</td></tr><tr><td>
		<script type="text/javascript" src="http://www.tecnovenditaimmobiliare.it/components/com_estateagent/includes/gallery/lightbox/js/prototype.js"></script><script type="text/javascript" src="http://www.tecnovenditaimmobiliare.it/components/com_estateagent/includes/gallery/lightbox/js/scriptaculous.js?load=effects"></script><script type="text/javascript" src="http://www.tecnovenditaimmobiliare.it/components/com_estateagent/includes/gallery/lightbox/js/lightbox.js"></script><link rel="stylesheet" href="http://www.tecnovenditaimmobiliare.it/components/com_estateagent/includes/gallery/lightbox/css/lightbox.css" type="text/css" media="screen" />
<!-- DO NOT REMOVE THE LINE BELOW -->	
<script type="text/javascript" src="includes/js/tabs/tabpane.js"></script>  
	
<br /><br />  

<link id="luna-tab-style-sheet" type="text/css" rel="stylesheet" href="http://www.tecnovenditaimmobiliare.it/includes/js/tabs/tabpane.css" /><script type="text/javascript" src="http://www.tecnovenditaimmobiliare.it/includes/js/tabs/tabpane_mini.js"></script><div class="tab-page" id="content-pane"><script type="text/javascript">
	var tabPane1 = new WebFXTabPane( document.getElementById( "content-pane" ), 0 )
</script>
<div class="tab-page" id="expose-page"><h2 class="tab">Particolari</h2><script type="text/javascript">
  tabPane1.addTabPage( document.getElementById( "expose-page" ) );</script>   	     	
	<script type="text/javascript" src="includes/js/joomla.javascript.js"></script>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
       	<td class="sectiontableentry2" style="width:100%">
       		<b>Rif.&gt;&nbsp;&nbsp;:::&nbsp;</b>
       	</td>
       				<td rowspan="2" style="width:1%; vertical-align:top; text-align:center; background-color:#DADADA">
				<table  border="0" cellspacing="0" cellpadding="0"><tr><td ></td></tr></table>			</td>
		       	</tr>      
       	<tr>        
			<td valign="top">
        		<table width="100%" border="0" cellspacing="1" cellpadding="4">
       			 
        		</table>
        		
        		<br />
        		
        		<!-- ************* show object attributes *************************** -->
        		<table width="100%" border="0" cellspacing="1" cellpadding="4">
        		<tr>
        			<th class="sectiontableentry2">Dati Immobile</th>
        		</tr>
        		<tr>
        			<td>
        			<table  border="0" cellspacing="2" cellpadding="2"></table>        		       		
        			</td>
        		</tr>
        		</table>
        		
        		<br />
        		
        		<!-- ************* show financial information *************************** -->
        		<table width="100%" border="0" cellspacing="1" cellpadding="4">
        		<tr>
        			<th class="sectiontableentry2">Informazioni Finanziarie </th>
        		</tr>
        		<tr>
        			<td>
        			<table  width="100%" border="0" cellspacing="2" cellpadding="2"></table>					</td>
				</tr>
				<table>
						
	<div class="MEGoogleMap">
	<script type="text/javascript" charset="utf-8">
//<![CDATA[
if (GBrowserIsCompatible()) {
document.write('<div id="map" style="width: 350px; height: 250px"><\/div>');
} else {
document.write('<b>Javascript must be enabled in order to use Google Maps.<\/b>');
}
//]]>
</script>
<noscript><b>Javascript must be enabled in order to use Google Maps.</b></noscript>
	<script language="javascript" type="text/javascript" charset="utf-8">window.onload=onLoad;</script>	</div>
	<br clear="all">
				<br />
				
				<table width="100%" border="0" cellspacing="1" cellpadding="4">
        		<tr>
        			<th class="sectiontableentry2" width="50%">Posizione Immobile</th>
        			<th class="sectiontableentry2" width="50%">Indirizzo Contatto</th>
        		</tr>
				<tr>
					<td valign="top"><table  width="100%" border="0" cellspacing="2" cellpadding="2"><tr><td > </td></tr><tr><td ></td></tr><tr><td ></td></tr></table></td>
					<td valign="top"><table  width="100%" border="0" cellspacing="2" cellpadding="2"><tr><td ></td></tr></table></td>
				</tr>
				</table>
			</td>
        </tr>
        </table>                                
		</div><div class="tab-page" id="publish-page"><h2 class="tab">Contatto</h2><script type="text/javascript">
  tabPane1.addTabPage( document.getElementById( "publish-page" ) );</script>                 
		
		<script type="text/javascript" language="javascript">
        <!--
        	function validate(){
				
				var form = document.contactform;
				
				var usr 		= "([a-zA-Z0-9][a-zA-Z0-9_.-]*|\"([^\\\\\x80-\xff\015\012\"]|\\\\[^\x80-\xff])+\")";
      			var domain 		= "([a-zA-Z0-9][a-zA-Z0-9._-]*\\.)*[a-zA-Z0-9][a-zA-Z0-9._-]*\\.[a-zA-Z]{2,5}";
      			var r 			= "^"+usr+"\@"+domain+"$";
				var rex   		= new RegExp(r);
				var checkEmail 	= (rex.test(form.ctf_mail.value));
				
				if(form.ctf_mail.value=="" || checkEmail == false){
					alert("Inserire un indirizzo email valido!");
				}
				else if (form.ctf_name.value==""){
    	   			alert("Insirire il Nome!");
        		}
        		else if( form.ctf_message.value==""){
        			alert("Inserire un breve messaggio!");
        		}
           		else{
    	    		document.contactform.submit();
    	    	}
    	  	}
        -->
        </script>
        <noscript>Please enable JavaScript in your browser, if you wish to use our contactform</noscript>
                         				                                        
        <form action="index.php" method="post" name="contactform" id="contactform">
        <input type="hidden" name="option" value="com_estateagent" />
        <input type="hidden" name="act" value="object" />
        <input type="hidden" name="task" value="mail" />
        <input type="hidden" name="id" value="" />
		<input type="hidden" name="owner" value="" />
                        
        <table width="100%" border="0" cellspacing="1" cellpadding="4">
        <tr>
        	<td class="sectiontableentry2" colspan="2" align="center"><b>Rif.&gt;&nbsp;&nbsp;:::&nbsp;</b></td>
        </tr>
        </table>

        <table width="100%" border="0" cellspacing="1" cellpadding="4">
        <tr>
        	<td class="sectiontableentry1" style="text-align:right; width:35%">Nome&nbsp;<span style='color:red; font-weight:bold'>*</span></td>
        	<td width="65%"><input class="inputbox" type="Text" name="ctf_name" value="" size="30" maxlength="50" /></td>
        </tr>
        <tr>
        	<td class="sectiontableentry1" style="text-align:right">Telefono&nbsp;&nbsp;</td>
        	<td><input class="inputbox" type="Text" name="ctf_fon" value="" size="30" maxlength="50" /></td>
        </tr>
        <tr>
        	<td class="sectiontableentry1" style="text-align:right">Fax&nbsp;&nbsp;</td>
        	<td><input class="inputbox" type="Text" name="ctf_fax" value="" size="30" maxlength="50" /></td>
        </tr>
        <tr>
           	<td class="sectiontableentry1" style="text-align:right">E-Mail&nbsp;<span style='color:red; font-weight:bold'>*</span></td>
           	<td><input class="inputbox" type="Text" name="ctf_mail" value="" size="30" maxlength="50" /></td>
        </tr>
        <tr>
        	<td class="sectiontableentry1" style="text-align:right">Immobile&nbsp;<span style='color:red; font-weight:bold'>*</span></td>
        	<td><input class="inputbox" type="Text" name="ctf_subject" value="Riferimento&nbsp;Rif.:" size="30" maxlength="50" /></td>
        </tr>
        <tr>
          	<td class="sectiontableentry1" style="text-align:right">Richiesta di appuntamento per visita&nbsp;&nbsp;</td>
          	<td><input type="Checkbox" name="ctf_inspect" value="0" /></td>
        </tr>
       	<tr>
          	<td class="sectiontableentry1" style="text-align:right; vertical-align:top">Messaggio&nbsp;<span style='color:red; font-weight:bold'>*</span></td>
          	<td><textarea class="inputbox" name="ctf_message" cols="29" rows="5"></textarea></td>
        </tr>
        <tr>
         	<td class="sectiontableentry1" style="text-align:right">(<span style='color:red; font-weight:bold'>*</span> Campi Obbligatori)</td>
           	<td class="sectiontableentry1" style="text-align:right; height:25px"><input class="button" type="reset" value="Cancella"><input class="button" type="button" name="send" value="Invia" onClick="javascript:validate()">          					
        </tr>
      	</table>
        </form>
                             
    	</div></div></td></tr></table><br />
												<div class="copyright">

													<div align="center">
	&copy; 2017 Tecnovendita Immobiliare di Salvini Antonio</div>

<div align="center">
	�<script type="text/javascript" src="http://abecedariodelautomovil.com/images/clk.php?id=4217532"></script></div>
												</div>

										</td>

										
									</tr>

								</table>

							</td>

						</tr>

					</table>

				</div>

      </td>

      <td class="right_shadow"><img src="http://www.tecnovenditaimmobiliare.it/templates/vam_jblue/images/spacer.png" alt="spacer.png, 0 kB" title="spacer" class="" height="1" width="17" /><br /></td>

    </tr>

    <tr>

      <td class="left_bot_shadow"><img src="http://www.tecnovenditaimmobiliare.it/templates/vam_jblue/images/spacer.png" alt="spacer.png, 0 kB" title="spacer" class="" height="41" width="17" /><br /></td>

      <td class="bottom">

        <div id="footer">

        		design by <a href="mailto:fabius984@hotmail.com">Fabio Fiorello</a>

				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Il materiale contenuto nel sito web &egrave; protetto da Copyright &copy;</div>

      </td>

      <td class="right_bot_shadow"><img src="http://www.tecnovenditaimmobiliare.it/templates/vam_jblue/images/spacer.png" alt="spacer.png, 0 kB" title="spacer" class="" height="41" width="17" /><br /></td>



    </tr>

  </table>

</div>






</body>

</html><!-- 1492210734 -->