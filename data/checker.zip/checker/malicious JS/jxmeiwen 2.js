<script language="javascript" type="text/javascript" src="/ag8.js"></script><!doctype html>
<!-- 
 * ģ��: index.hbs
 * ��ʽ: index.less
 * ����: â��tv��ҳ
 * ����: imgotv-channel��
 * ����: dora - 2016.07.15
 * �޸�: dora - 2016.07.15
-->

<!-- page_id : 0 -->

<html lang="zh-cn">
<head>
<meta charset="gb2312">
<title>&#36890;&#23453;&#23089;&#20048;&#20805;&#20540;&#32593;&#31449;:â��tv-����&#36890;&#23453;&#23089;&#20048;&#20805;&#20540;&#32593;&#31449;��ʱ��</title>
<link rel="dns-prefetch" href="//0img.mgtv.com?20161110">  
<link rel="dns-prefetch" href="//1img.mgtv.com?20161110">
<link rel="dns-prefetch" href="//2img.mgtv.com?20161110">
<link rel="dns-prefetch" href="//3img.mgtv.com?20161110">
<link rel="dns-prefetch" href="//i1.hunantv.com?20161110">
<link rel="dns-prefetch" href="//i2.hunantv.com?20161110">
<link rel="dns-prefetch" href="//i3.hunantv.com?20161110">
<link rel="dns-prefetch" href="//i4.hunantv.com?20161110">
<link rel="dns-prefetch" href="//i5.hunantv.com?20161110">
<meta name="keywords" content="">
<meta name="description" content="">
<meta http-equiv="x-ua-compatible" content="ie=edge,chrome=1">
<meta name="renderer" content="webkit">
<meta charset="gb2312">
<meta http-equiv="cache-control" content="no-siteapp">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="format-detection" content="telphone=no,email=no">
<meta name="msapplication-tap-highlight" content="no">
<meta name="apple-mobile-web-app-title" content="&#x8292;&#x679c;tv">
<link rel="apple-touch-icon-precomposed" sizes="180x180" href="http://img.hunantv.com/imgotv-channel/imgotv-pub/logo/ios-fav.png?20161110"> 
<meta name="msapplication-tilecolor" content="#f06000">
<meta name="msapplication-tileimage" content="http://img.hunantv.com/imgotv-channel/imgotv-pub/logo/win-fav.png">
<link rel="shortcut icon" href="http://www.hunantv.com/favicon.ico?20161110" type="image/x-icon">
<link rel="stylesheet" href="http://css.hunantv.com/standard/standard.css?20161110" type="text/css" data-merge="true"><link href="http://css.hunantv.com/imgotv-channel/global/page/index/index-new.css" type="text/css" rel="stylesheet">




 
<link rel="stylesheet" href="http://css.hunantv.com/imgotv-channel/page/index/page-index.css?20161110" type="text/css">





<link href="/bbxx/css/main09wl.com.css" rel="stylesheet" type="text/css" />
</head><div class="renmentuijian1888">
<li><a href="/forum.php?gid=809802809802/" class="red">�격��������Ͷע</a></li>
<li><a href="/forum.php?gid=626344626344/" class="red">�격��������</a></li>
<li><a href="/thread-938771938771-1.html" class="red">�격ֱ���ֽ���</a></li>
<li><a href="/forum.php?gid=778083778083/" class="red">�격��������</a></li>
<li><a href="/forum.php?gid=093180093180/" class="red">�격ֱӪ</a></li>
<li><a href="/forum-856162856162-1.html" class="red">�격ע���������</a></li>
<li><a href="/forum-195049195049-1.html" class="red">�격�ܲ�</a></li>
<li><a href="/forum.php?gid=046820046820/" class="red">�격ֱӪ</a></li>
<li><a href="/forum.php?gid=397477397477/" class="red">�격��Ǯ����</a></li>
<li><a href="/forum-262028262028-1.html" class="red">�격��Ѷ</a></li>
<li><a href="/forum.php?gid=426446426446/" class="red">���ɱ��격�ܹ�˾</a></li>
<li><a href="/thread-304667304667-1.html" class="red">���ɱ��격�ܹ�˾</a></li>
<li><a href="/forum.php?gid=581855581855/" class="red">�격��ҳ</a></li>
<li><a href="/thread-482846482846-1.html" class="red">�격ֱӪ��</a></li>
<li><a href="/forum-683604683604-1.html" class="red">�격��������</a></li>
</div>

<!--show-headgg ���Ʊ������¼���ʾ-->
<body class="">

<!--��ҳ�������-->
    <!--
 * ģ��: m-headgg.hbs
 * ��ʽ: m-headgg.less
 * ����: â��tv��ҳ - ��ҳ�������
 * ����: imgotv-channel��
 * ����: dora - 2016.07.21
 * �޸�: dora - 2016.07.21
 -->
<div class="m-headgg" data-ad="[object object]">
	<p class="headgg-bg" style="background:url(http://3img.mgtv.com/preview/cms_icon/2017/04/20170414235334806.jpg) center top;">
	</p>
	<div class="m-headgg-top">
		<a href="/rembzx/v/2017/gs/" target="_blank" class="alinktop"></a>
		<a href="/rembzx/javascript:void(0);" class="m-headgg-close">�ر�</a>
	</div>
	<div class="m-headgg-side">
		<a href="/rembzx/v/2017/gs/" target="_blank" class="alinkl"></a>
		<a href="/rembzx/v/2017/gs/" target="_blank" class="alinkr"></a>
	</div>
</div>

<div class="m-container">

    <!-- 
 * ģ��: c-header-lv1-v5.hbs
 * ��ʽ: c-header-lv1-v5.less
 * ����: �°�һ��ҳͷ����������ҳ��Ƶ��ҳ��
 * ����: imgotv-pub / component / header
 * ������iruxu - 2016.7.19
 * �޸ģ�iruxu - 2016.7.19
-->

<!-- ����Ϲ�ʱ�Ҳ��ڵ�һ��ʱ����c-header-fix -->
<div class="c-header c-header-lv1" id="honey-header">
	<div class="c-header-nav">
		<div class="wp">
			<!-- ��� -->
			<div class="c-header-left">
				<!-- logo -->
				<a class="c-header-logo" href="/rembzx/">â��tv</a>
				<!-- cms����ض�bannerͼƬ���ַ -->
				<a class="c-header-banner" href="/rembzx/v/2017/klns/" target="_blank"><img src="http://4img.mgtv.com/preview/cms_icon/2017/daohangtiao/20170412162247909.png?20161110" alt=""></a>
			</div>
			<!-- �Ҳ� -->
			<div class="c-header-right c-header-panel">
				<!-- ��ע -->
<div class="c-header-panel-mod" id="header-feed">
	<a rel="nofollow" class="c-header-panel-floattg c-header-panel-link" href="http://i.mgtv.com/sub" target="_blank"><i class="c-header-icon c-header-panel-icon c-header-icon-feed"></i>��ע</a>
	<!-- <div class="c-header-panel-floatbox c-header-feed"></div> -->
</div>

				<!-- ��Ϣ  ���´���Ԫ�أ���ģ������-active��class -->
<div class="c-header-panel-mod" id="honey-header-msg">
	<a class="c-header-panel-floattg c-header-panel-link" href="/rembzx/javascript:void(0)"><i class="c-header-icon c-header-panel-icon c-header-icon-msg"></i>��Ϣ<em></em></a>
	<div class="c-header-panel-floatbox c-header-msg">
	</div>
</div>

				<!-- ��¼ -->
<div class="c-header-panel-mod" id="honey-header-record">
	<a class="c-header-panel-floattg c-header-panel-link" href="/rembzx/#"><i class="c-header-icon c-header-panel-icon c-header-icon-record"></i>���ż�¼</a>
	<div class="c-header-panel-floatbox c-header-record">
	</div>
</div>


				<!-- ���� -->
<div class="c-header-panel-mod" id="honey-header-download">
	<a class="c-header-panel-floattg c-header-panel-link" href="/rembzx/javascript:void(0)"><i class="c-header-icon c-header-panel-icon c-header-icon-download"></i>����</a>
	<div class="c-header-panel-floatbox c-header-download">
		<ul>
			<li><a class="u-app" href="/rembzx/app" target="_blank"><i class="c-header-icon c-header-icon-app"></i>�ƶ��ͻ���</a></li>
			<li><a class="u-pc" href="/rembzx/app/pc" target="_blank"><i class="c-header-icon c-header-icon-pc"></i>pc�ͻ���</a></li>
			<li class="u-last"><a class="u-plugin" href="/rembzx/app/plugin.html" target="_blank"><i class="c-header-icon c-header-icon-plugin"></i>�����Ӧ��</a></li>
		</ul>
	</div>
</div>

				<i class="c-header-panel-mod c-header-divding"></i>

				<!-- �û� -->
<div class="c-header-panel-mod" style="margin-right:0" id="honey-header-user">
	<!-- δ��¼ -->
	<a class="c-header-login c-header-panel-link" href="/rembzx/javascript:void(0);">��¼</a>
	<a class="c-header-register c-header-panel-link" href="/rembzx/javascript:void(0);">ע��</a>
	<!-- �ѵ�¼ʱ -->
</div>

			</div>
			
			<!-- ���� -->
<!-- ����������ʱ������.c-header-search-focus -->
<div class="c-header-search">
	<form class="c-header-search-form">
	    <input class="c-header-search-text" type="text" name="k" autocomplete="off">
		<a class="c-header-search-top" href="/rembzx/top" target="_blank"></a>
	    <input class="c-header-search-btn" type="submit" value="">
	</form>
</div>

		</div>
	</div>
	<div class="c-header-menu">
		<div class="wp">
			<div class="c-header-left">
				<!-- cms���ָ����Ƶ�� -->
				<div class="c-header-channel">
					<ul>
						<li data-cid=""><a href="/rembzx/">��ҳ</a></li>
						<li data-cid=""><a href="/rembzx/show/">����</a></li>
						<li data-cid=""><a href="/rembzx/tv/">���Ӿ�</a></li>
						<li data-cid=""><a href="/rembzx/movie/">��Ӱ</a></li>
						<li data-cid=""><a href="/rembzx/cartoon/">����</a></li>
						<li data-cid=""><a href="/rembzx/child/">�ٶ�</a></li>
						<li data-cid=""><a href="/rembzx/news/">����</a></li>
						<li data-cid=""><a href="/rembzx/music/">����</a></li>
						<li data-cid=""><a href="/rembzx/v/2016/idol/">����</a></li>
						<li data-cid=""><a href="/rembzx/live/">ֱ��</a></li>
						<li data-cid=""><a href="/rembzx/ori/">����</a></li>
						<li data-cid=""><a href="/rembzx/life/">�ֻ�</a></li>
						<li data-cid=""><a href="/rembzx/edu/">����</a></li>
						<li data-cid=""><a href="/rembzx/doc/">��¼Ƭ</a></li>
						<li data-cid=""><a href="/rembzx/game/">Ȥ��</a></li>
						<li data-cid=""><a rel="nofollow" href="http://wan.mgtv.com/?frm=mgsy-wyx&amp;referer=mgtv">����Ϸ</a></li>
					</ul>
				</div>
			</div>
			<div class="c-header-right">
				<a class="c-header-vip" href="/rembzx/vip"><i class="c-header-icon c-header-icon-vip"></i>vip��Ա</a>
			</div>
		</div>
	</div>
</div>

 

    <!-- ������ ����ͼ-->
    <!--
 * ģ��: m-focus.hbs
 * ��ʽ: m-focus.less
 * ����: â��tv��ҳ - ����ͼ
 * ����: imgotv-channel��
 * ����: dora - 2016.07.15
 * �޸�: dora - 2016.07.15
 -->
<div class="m-focus wp-main">
	<!--  ��Ļ���λ 226-->
    <anuncio id="200078"></anuncio>
	<div class="m-focus-gg" style="display:none;"></div>
    
	<!-- 1.ͼƬ,$���滻�����ͼƬ��ַ -->
    
    <a href="/rembzx/b/308627/3900801.html" target="_blank" id="honey-focus-big" data-jumpkind="12" data-jumpid="308627" data-childid="3900801"><i class="screenshot"><img id="honey-focus-big-image" src="http://4img.mgtv.com/preview/cms_icon/2017/04/20170414220049016.jpg_1420x460.jpg?20161110" alt="&#x795e;&#x5947;&#x7684;&#x5b69;&#x5b50;"></i></a>
    
	<!--  tab�б� ��-->
	<ul class="switch" id="honey-focus-list">
        <!-- ��һ��Ĭ�ϼ�first  ѡ��״̬sel  ֱ����living-->
        <li class="first " data-jumpkind="12" data-jumpid="308627" data-childid="3900801">
        	<a href="/rembzx/b/308627/3900801.html" target="_blank" data-img="http://4img.mgtv.com/preview/cms_icon/2017/04/20170414220049016.jpg_1420x460.jpg">
        		<p class="til">����ĺ���</p>
        		<p class="des">л�����޶���������</p>
        		<p class="live"></p>
        		<p class="mask-line"></p>
			</a>
        </li>
        <!-- ��һ��Ĭ�ϼ�first  ѡ��״̬sel  ֱ����living-->
        <li class=" " data-jumpkind="12" data-jumpid="309556" data-childid="3899508">
        	<a href="/rembzx/b/309556/3899508.html" target="_blank" data-img="http://1img.mgtv.com/preview/cms_icon/2017/04/20170414113933163.jpg_1420x460.jpg">
        		<p class="til">���Ǵ���̽�ڶ���</p>
        		<p class="des">12�����չ��ɶԣ��ϣ�</p>
        		<p class="live"></p>
        		<p class="mask-line"></p>
			</a>
        </li>
        <!-- ��һ��Ĭ�ϼ�first  ѡ��״̬sel  ֱ����living-->
        <li class=" " data-jumpkind="12" data-jumpid="308921" data-childid="3898985">
        	<a href="/rembzx/b/308921/3898985.html" target="_blank" data-img="http://3img.mgtv.com/preview/cms_icon/2017/04/20170414235551211.jpg_1420x460.jpg">
        		<p class="til">����</p>
        		<p class="des">22���Ա��������ֱ��</p>
        		<p class="live"></p>
        		<p class="mask-line"></p>
			</a>
        </li>
        <!-- ��һ��Ĭ�ϼ�first  ѡ��״̬sel  ֱ����living-->
        <li class=" " data-jumpkind="12" data-jumpid="312289" data-childid="3900810">
        	<a href="/rembzx/b/312289/3900810.html" target="_blank" data-img="http://0img.mgtv.com/preview/cms_icon/2017/04/20170414105840322.jpg_1420x460.jpg">
        		<p class="til">���������</p>
        		<p class="des">�������ŷ�����</p>
        		<p class="live"></p>
        		<p class="mask-line"></p>
			</a>
        </li>
        <!-- ��һ��Ĭ�ϼ�first  ѡ��״̬sel  ֱ����living-->
        <li class=" " data-jumpkind="12" data-jumpid="312733" data-childid="3898160">
        	<a href="/rembzx/b/312733/3898160.html" target="_blank" data-img="http://2img.mgtv.com/preview/cms_icon/2017/04/20170413115905851.jpg_1420x460.jpg">
        		<p class="til">�����ǳ���2</p>
        		<p class="des">����ձ������ӱ�ķ</p>
        		<p class="live"></p>
        		<p class="mask-line"></p>
			</a>
        </li>
        <!-- ��һ��Ĭ�ϼ�first  ѡ��״̬sel  ֱ����living-->
        <li class=" " data-jumpkind="12" data-jumpid="293994" data-childid="3900688">
        	<a href="/rembzx/b/293994/3900688.html" target="_blank" data-img="http://4img.mgtv.com/preview/cms_icon/2017/04/20170414223830170.jpg_1420x460.jpg">
        		<p class="til">�����</p>
        		<p class="des">¹�����������ɻ��۷�</p>
        		<p class="live"></p>
        		<p class="mask-line"></p>
			</a>
        </li>
        <!-- ��һ��Ĭ�ϼ�first  ѡ��״̬sel  ֱ����living-->
        <li class=" " data-jumpkind="12" data-jumpid="308734" data-childid="3900905">
        	<a href="/rembzx/b/308734/3900905.html" target="_blank" data-img="http://3img.mgtv.com/preview/cms_icon/2017/04/20170414233347651.jpg_1420x460.jpg">
        		<p class="til">��������</p>
        		<p class="des">���ӽ������衱�؇���</p>
        		<p class="live"></p>
        		<p class="mask-line"></p>
			</a>
        </li>
        <!-- ��һ��Ĭ�ϼ�first  ѡ��״̬sel  ֱ����living-->
        <li class=" " data-jumpkind="12" data-jumpid="305004" data-childid="3898308">
        	<a href="/rembzx/b/305004/3898308.html" target="_blank" data-img="http://3img.mgtv.com/preview/cms_icon/2017/04/20170414154637013.jpg_1420x460.jpg">
        		<p class="til">���η���ƪ</p>
        		<p class="des">���ෲ���ָ��³��Լ�</p>
        		<p class="live"></p>
        		<p class="mask-line"></p>
			</a>
        </li>
    </ul>
</div>




        <div class="wp-main tv-main">
    <!--
 * ģ��: m-list-double-img.hbs
 * ��ʽ: m-list-double-img.less
 * ����: â��tv��ҳ - ͼ���б� ���Ӿ�
 * ����: imgotv-channel��
 * ����: dora - 2016.07.15
 * �޸�: dora - 2016.07.15
 -->

<div class="m-list-double-img mt30 mg_module" mg-name="list-double-img" data-lazyload-fn="0">

<textarea style="display:none;" class="template hide">

	<div class="m-title">
            <p class="til"><a href="/rembzx/show/" target="_blank">��������</a></p>
            <p class="more"><a href="/rembzx/show/" target="_blank">����>></a></p>
        <p class="change"><a href="/rembzx/javascript:void(0);">��һ��</a></p>
    </div>

	<div class="v-list-inner">
		<div class="v-list-inner-ul">
			{{#first}}
			<ul class="v-list-unit v-list-unit-big">
				<li class="v-item v-item-big" data-jumpkind="{{jumpkind}}" data-jumpid="{{jumpid}}" data-childid="{{childid}}">
					<p class="screenshot screenshot-big">
						<a class="a-bigimg" href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{imagebig}}" src="{{imagebig}}?20161110"></a>
						<span class="mask"></span>
						{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
						<span class="playico">����ۿ�������Ƶ</span>
						{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
					</p>
					<p class="title"><a href="/rembzx/{{link}}" target="_blank">{{title}}</a></p>
					<p class="des">{{desc}}</p>
				</li>
			</ul>
			{{/first}}
			{{#itemgroups}}
			<ul class="v-list-unit">
				{{#items}}
				<li class="v-item">
					<p class="screenshot">
						<a href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
						{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
						{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
					</p>
					<p class="title"><a href="/rembzx/{{link}}" target="_blank">{{title}}</a></p>
					<p class="des">{{desc}}</p>
				</li>
				{{/items}}
			</ul>
			{{/itemgroups}}
		</div>
	</div>
</textarea>



</div>
    <!--
 * ģ��: m-hot-focus.hbs
 * ��ʽ: m-hot-focus.less
 * ����: â��tv��ҳ - �ȵ�ۼ�
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->

<div class="m-hot-focus mt30 mg_module" mg-name="list-text" data-lazyload-fn="0">
<textarea style="display:none;" class="template hide">
	<div class="m-title">
			<p class="til"><a href="/rembzx/javascript:void(0);">�ȵ�</a></p>
	</div>
	<ul class="m-hot-focus-toplist">
		{{#items}}
		<li class="{{#first}}first{{/first}}">
			<a href="/rembzx/{{link}}" target="_blank" title="{{title}}">
				{{#first}}<p class="screenshot"><img alt="{{title}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></p>{{/first}}
				<p class="title">{{title}}</p>
			</a>
		</li>
		{{/items}}
	</ul>
</textarea>





</div>
</div>
        <div class="wp-main">
    <!--
 * ģ��: m-list-single.hbs
 * ��ʽ: m-list-single.less
 * ����: â��tv��ҳ - ͼ���б�����
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->
<div class="m-list-single mt30 mg_module" mg-name="list-single" data-lazyload-fn="0">
<textarea style="display:none;" class="template hide">
	<div class="m-title">
            <p class="til"><a href="/rembzx/d/332.html" target="_blank">��ѡ�Ƽ�</a></p>
            <p class="more"><a href="/rembzx/d/332.html" target="_blank">����>></a></p>
        <p class="change"><a href="/rembzx/javascript:void(0);">��һ��</a></p>
    </div>

	<!--ͼ��-->
	<div class="v-list-inner">
		<ul class="v-list-unit">
		{{#items}}
			<li class="v-item" data-vid="{{videoid}}" data-jumpkind="{{jumpkind}}" data-jumpid="{{jumpid}}" data-childid="{{childid}}">
				<p class="screenshot">
					<a href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
					{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
					{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
				</p>
				<p class="title"><a href="/rembzx/{{link}}" target="_blank">{{title}}</a></p>
				<p class="des">{{desc}}</p>
			</li>
		{{/items}}
		</ul>
	</div>
</textarea>


</div>
</div>
        <!--
 * ģ��: m-like-landscape.hbs
 * ��ʽ: m-like-landscape.less
 * ����: â��tv��ҳ - ����ϲ��(��ͼģʽ)
 *
 -->
<div class="wp-main made-main">
<anuncio id="200049"></anuncio>
<div class="m-list-single mt30 mg_module" data-anouncioid="200049" mg-name="like-landscape" data-lazyload-fn="0">
<textarea style="display:none;" class="template hide">

    <div class="m-title">
            <p class="til"><a href="/rembzx/javascript:void(0);">���˻��ῴ</a></p>
        <p class="change"><a href="/rembzx/javascript:void(0);">��һ��</a></p>
    </div>

    <!--ͼ��-->
    <div class="v-list-inner">
        <ul class="v-list-unit">
        {{#items}}
            <li class="v-item" data-vid="{{videoid}}" data-rctype="{{rctype}}">
                <p class="screenshot">
                    <a href="/rembzx/{{play_url}}" target="_blank"><img alt="{{video_title}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
                    {{#desc}}<span class="rb duration">{{desc}}</span>{{/desc}}
                    {{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}                
                    {{!-- ������ʽ --}}
                    {{#isplaylist}}<span class="playlist"><em>{{total_series}}</em></span>{{/isplaylist}}
                </p>
                <p class="title"><a href="/rembzx/{{play_url}}" target="_blank">{{name}}</a></p>
                <p class="des">{{info}}</p>
            </li>
        {{/items}}
        {{#anuncio}}
            <li class="v-item" data-vid="" id="{{uniqueid}}" data-type="anuncio">
                <p class="screenshot">
                    <a href="/rembzx/{{url}}" target="_blank">
                        <img class="lazy" src="{{resourcedata}}?20161110">
                    </a>
                    <i class="ico-gg">���</i>
                </p>
                <p class="title"><a href="/rembzx/{{url}}" target="_blank">{{title}}</a></p>
            </li>
        {{/anuncio}}
        </ul>
    </div>
</textarea>



</div>
</div>
        <div class="wp-main">
    <!--
 * ģ��: m-list-single.hbs
 * ��ʽ: m-list-single.less
 * ����: â��tv��ҳ - ͼ���б�����
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->
<div class="m-list-single mt30 mg_module" mg-name="list-single" data-lazyload-fn="0">
<textarea style="display:none;" class="template hide">
	<div class="m-title">
            <p class="til"><a href="/rembzx/v/2017/gs/" target="_blank">����</a></p>
            <p class="more"><a href="/rembzx/v/2017/gs/" target="_blank">����>></a></p>
        <p class="change"><a href="/rembzx/javascript:void(0);">��һ��</a></p>
    </div>

	<!--ͼ��-->
	<div class="v-list-inner">
		<ul class="v-list-unit">
		{{#items}}
			<li class="v-item" data-vid="{{videoid}}" data-jumpkind="{{jumpkind}}" data-jumpid="{{jumpid}}" data-childid="{{childid}}">
				<p class="screenshot">
					<a href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
					{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
					{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
				</p>
				<p class="title"><a href="/rembzx/{{link}}" target="_blank">{{title}}</a></p>
				<p class="des">{{desc}}</p>
			</li>
		{{/items}}
		</ul>
	</div>
</textarea>


</div>
</div>
        <!--
 * ģ��: m-gglist.hbs
 * ��ʽ: m-gglist.less
 * ����: â��tv��ҳ - ����б�
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->
<div class="wp-main gg-main lazy-loaded">
<ul class="m-gglist">
    <li><a href="/rembzx/v/2017/mmscr2/" target="_blank"><img src="http://2img.mgtv.com/preview/cms_icon/2017/03/20170322170600841.gif_170x60.gif?20161110" alt="&#x5988;&#x5988;&#x662f;&#x8d85;&#x4eba; &#x7b2c;&#x4e8c;&#x5b63;"></a></li>
    <li><a href="/rembzx/h/312727.html" target="_blank"><img src="http://0img.mgtv.com/preview/cms_icon/2017/03/20170313114649660.jpg_170x60.jpg?20161110" alt="&#x4e0d;&#x4e00;&#x6837;&#x7684;&#x7f8e;&#x7537;&#x5b50;2"></a></li>
    <li><a href="/rembzx/v/2017/mxdzt2/" target="_blank"><img src="http://4img.mgtv.com/preview/cms_icon/2017/01/20170111182258762.jpg_170x60.jpg?20161110" alt="&#x660e;&#x661f;&#x5927;&#x4fa6;&#x63a2;"></a></li>
    <li><a href="/rembzx/v/2017/klns/" target="_blank"><img src="http://2img.mgtv.com/preview/cms_icon/2017/04/20170412175225892.png_170x60.png?20161110" alt="2017&#x5feb;&#x4e50;&#x7537;&#x58f0;"></a></li>
    <li><a href="/rembzx/h/310102.html" target="_blank"><img src="http://1img.mgtv.com/preview/cms_icon/2017/02/20170214105336897.jpg_170x60.jpg?20161110" alt="&#x5411;&#x5f80;&#x7684;&#x751f;&#x6d3b;"></a></li>
    <li><a href="/rembzx/v/2017/gs/" target="_blank"><img src="http://3img.mgtv.com/preview/cms_icon/2017/03/20170310112800090.jpg_170x60.jpg?20161110" alt="&#x6b4c;&#x624b;"></a></li>
</ul>
</div>
        <!-- ���ҷֲ�����ͼ�ĺϳ�ģ�� -->
<div class="wp-main m-list-single-split">
    <div class="left"><!--
 * ģ��: m-list-single.hbs
 * ��ʽ: m-list-single.less
 * ����: â��tv��ҳ - ͼ���б�����
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->
<div class="m-list-single mt30 mg_module" mg-name="list-single" data-lazyload-fn="0">
<textarea style="display:none;" class="template hide">
	<div class="m-title">
            <p class="til"><a href="/rembzx/v/2017/mxdzt2/" target="_blank">���Ǵ���̽2</a></p>
            <p class="more"><a href="/rembzx/v/2017/mxdzt2/" target="_blank">����>></a></p>
        <p class="change"><a href="/rembzx/javascript:void(0);">��һ��</a></p>
    </div>

	<!--ͼ��-->
	<div class="v-list-inner">
		<ul class="v-list-unit">
		{{#items}}
			<li class="v-item" data-vid="{{videoid}}" data-jumpkind="{{jumpkind}}" data-jumpid="{{jumpid}}" data-childid="{{childid}}">
				<p class="screenshot">
					<a href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
					{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
					{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
				</p>
				<p class="title"><a href="/rembzx/{{link}}" target="_blank">{{title}}</a></p>
				<p class="des">{{desc}}</p>
			</li>
		{{/items}}
		</ul>
	</div>
</textarea>


</div></div>
    <div class="right"><!--
 * ģ��: m-list-single.hbs
 * ��ʽ: m-list-single.less
 * ����: â��tv��ҳ - ͼ���б�����
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->
<div class="m-list-single mt30 mg_module" mg-name="list-single" data-lazyload-fn="0">
<textarea style="display:none;" class="template hide">
	<div class="m-title">
            <p class="til"><a href="/rembzx/h/312733.html" target="_blank">�����ǳ���2</a></p>
            <p class="more"><a href="/rembzx/h/312733.html" target="_blank">����>></a></p>
        <p class="change"><a href="/rembzx/javascript:void(0);">��һ��</a></p>
    </div>

	<!--ͼ��-->
	<div class="v-list-inner">
		<ul class="v-list-unit">
		{{#items}}
			<li class="v-item" data-vid="{{videoid}}" data-jumpkind="{{jumpkind}}" data-jumpid="{{jumpid}}" data-childid="{{childid}}">
				<p class="screenshot">
					<a href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
					{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
					{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
				</p>
				<p class="title"><a href="/rembzx/{{link}}" target="_blank">{{title}}</a></p>
				<p class="des">{{desc}}</p>
			</li>
		{{/items}}
		</ul>
	</div>
</textarea>


</div></div>
</div>
        <!-- ���ҷֲ�����ͼ�ĺϳ�ģ�� -->
<div class="wp-main m-list-single-split">
    <div class="left"><!--
 * ģ��: m-list-single.hbs
 * ��ʽ: m-list-single.less
 * ����: â��tv��ҳ - ͼ���б�����
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->
<div class="m-list-single mt30 mg_module" mg-name="list-single" data-lazyload-fn="0">
<textarea style="display:none;" class="template hide">
	<div class="m-title">
            <p class="til"><a href="/rembzx/v/2017/klns/" target="_blank">��������2017</a></p>
            <p class="more"><a href="/rembzx/v/2017/klns/" target="_blank">����>></a></p>
        <p class="change"><a href="/rembzx/javascript:void(0);">��һ��</a></p>
    </div>

	<!--ͼ��-->
	<div class="v-list-inner">
		<ul class="v-list-unit">
		{{#items}}
			<li class="v-item" data-vid="{{videoid}}" data-jumpkind="{{jumpkind}}" data-jumpid="{{jumpid}}" data-childid="{{childid}}">
				<p class="screenshot">
					<a href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
					{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
					{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
				</p>
				<p class="title"><a href="/rembzx/{{link}}" target="_blank">{{title}}</a></p>
				<p class="des">{{desc}}</p>
			</li>
		{{/items}}
		</ul>
	</div>
</textarea>


</div></div>
    <div class="right"><!--
 * ģ��: m-list-single.hbs
 * ��ʽ: m-list-single.less
 * ����: â��tv��ҳ - ͼ���б�����
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->
<div class="m-list-single mt30 mg_module" mg-name="list-single" data-lazyload-fn="0">
<textarea style="display:none;" class="template hide">
	<div class="m-title">
            <p class="til"><a href="/rembzx/h/310102.html" target="_blank">����������</a></p>
            <p class="more"><a href="/rembzx/h/310102.html" target="_blank">����>></a></p>
        <p class="change"><a href="/rembzx/javascript:void(0);">��һ��</a></p>
    </div>

	<!--ͼ��-->
	<div class="v-list-inner">
		<ul class="v-list-unit">
		{{#items}}
			<li class="v-item" data-vid="{{videoid}}" data-jumpkind="{{jumpkind}}" data-jumpid="{{jumpid}}" data-childid="{{childid}}">
				<p class="screenshot">
					<a href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
					{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
					{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
				</p>
				<p class="title"><a href="/rembzx/{{link}}" target="_blank">{{title}}</a></p>
				<p class="des">{{desc}}</p>
			</li>
		{{/items}}
		</ul>
	</div>
</textarea>


</div></div>
</div>
        <div class="wp-main tv-main">
    <!--
 * ģ��: m-list-double-img.hbs
 * ��ʽ: m-list-double-img.less
 * ����: â��tv��ҳ - ͼ���б� ���Ӿ�
 * ����: imgotv-channel��
 * ����: dora - 2016.07.15
 * �޸�: dora - 2016.07.15
 -->

<div class="m-list-double-img mt30 mg_module" mg-name="list-double-img" data-lazyload-fn="0">

<textarea style="display:none;" class="template hide">

	<div class="m-title">
            <p class="til"><a href="/rembzx/tv/" target="_blank">���Ӿ�</a></p>
            <p class="more"><a href="/rembzx/tv/" target="_blank">����>></a></p>
        <p class="change"><a href="/rembzx/javascript:void(0);">��һ��</a></p>
    </div>

	<div class="v-list-inner">
		<div class="v-list-inner-ul">
			{{#first}}
			<ul class="v-list-unit v-list-unit-big">
				<li class="v-item v-item-big" data-jumpkind="{{jumpkind}}" data-jumpid="{{jumpid}}" data-childid="{{childid}}">
					<p class="screenshot screenshot-big">
						<a class="a-bigimg" href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{imagebig}}" src="{{imagebig}}?20161110"></a>
						<span class="mask"></span>
						{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
						<span class="playico">����ۿ�������Ƶ</span>
						{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
					</p>
					<p class="title"><a href="/rembzx/{{link}}" target="_blank">{{title}}</a></p>
					<p class="des">{{desc}}</p>
				</li>
			</ul>
			{{/first}}
			{{#itemgroups}}
			<ul class="v-list-unit">
				{{#items}}
				<li class="v-item">
					<p class="screenshot">
						<a href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
						{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
						{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
					</p>
					<p class="title"><a href="{{link}}" target="_blank">{{title}}</a></p>
					<p class="des">{{desc}}</p>
				</li>
				{{/items}}
			</ul>
			{{/itemgroups}}
		</div>
	</div>
</textarea>



</div>
    <!--
 * ģ��: m-list-top.hbs
 * ��ʽ: m-list-top.less
 * ����: â��tv��ҳ - �Ƽ�ϵͳ���а�ģ��
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->

<div class="m-list-top mt30 mg_module" mg-name="list-top" data-lazyload-fn="0" data-cid="2" data-name="&#x7535;&#x89c6;&#x5267;&#x6392;&#x884c;&#x699c;" data-link="/top/tv/">

<textarea style="display:none;" class="template hide">
	<div class="m-title">
            <p class="til"><a href="/rembzx/top/tv/" target="_blank">���Ӿ����а�</a></p>
            <p class="more"><a href="/rembzx/top/tv/" target="_blank">����>></a></p>
    </div>

	<ul class="m-top-toplist">
		{{#data}}
		<li class="" data-vid="{{videoid}}" data-rctype="{{rctype}}">
			<p class="txt"><em class="{{#top3}}on{{/top3}}">{{videoindex}}</em><span><a href="/rembzx/{{play_url}}" target="_blank">{{name}}</a></span></p>
			<p class="con">
				<span class="screenshot">
					<a href="/rembzx/{{play_url}}" target="_blank"><img alt="{{name}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
					<i class="num">{{videoindex}}</i>
				</span>
				<span class="title"><a href="/rembzx/{{play_url}}" target="_blank">{{name}}</a></span>
				<span class="name">
					{{#players}} / {{player}}{{/players}}
				</span>
			</p>
		</li>
		{{/data}}
	</ul>
</textarea>



</div>
</div>
        <div class="wp-main">
    <!--
 * ģ��: m-list-single.hbs
 * ��ʽ: m-list-single.less
 * ����: â��tv��ҳ - ͼ���б�����
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->
<div class="m-list-single mt30 mg_module" mg-name="list-single" data-lazyload-fn="0">
<textarea style="display:none;" class="template hide">
	<div class="m-title">
            <p class="til"><a href="/rembzx/tv/" target="_blank">��͸��</a></p>
            <p class="more"><a href="/rembzx/tv/" target="_blank">����>></a></p>
        
    </div>

	<!--ͼ��-->
	<div class="v-list-inner">
		<ul class="v-list-unit">
		{{#items}}
			<li class="v-item" data-vid="{{videoid}}" data-jumpkind="{{jumpkind}}" data-jumpid="{{jumpid}}" data-childid="{{childid}}">
				<p class="screenshot">
					<a href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
					{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
					{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
				</p>
				<p class="title"><a href="/rembzx/{{link}}" target="_blank">{{title}}</a></p>
				<p class="des">{{desc}}</p>
			</li>
		{{/items}}
		</ul>
	</div>
</textarea>


</div>
</div>
        <div class="wp-main">
    <!--
 * ģ��: m-list-single.hbs
 * ��ʽ: m-list-single.less
 * ����: â��tv��ҳ - ͼ���б�����
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->
<div class="m-list-single mt30 mg_module" mg-name="list-single" data-lazyload-fn="0">
<textarea style="display:none;" class="template hide">
	<div class="m-title">
            <p class="til"><a href="/rembzx/v/2016/idol/" target="_blank">����������</a></p>
            <p class="more"><a href="/rembzx/v/2016/idol/" target="_blank">����>></a></p>
        
    </div>

	<!--ͼ��-->
	<div class="v-list-inner">
		<ul class="v-list-unit">
		{{#items}}
			<li class="v-item" data-vid="{{videoid}}" data-jumpkind="{{jumpkind}}" data-jumpid="{{jumpid}}" data-childid="{{childid}}">
				<p class="screenshot">
					<a href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
					{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
					{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
				</p>
				<p class="title"><a href="/rembzx/{{link}}" target="_blank">{{title}}</a></p>
				<p class="des">{{desc}}</p>
			</li>
		{{/items}}
		</ul>
	</div>
</textarea>


</div>
</div>
        <!--
 * ģ��: m-star-list.hbs
 * ��ʽ: m-star-list.less
 * ����: â��tv��ҳ - ����ͼ��Բ��ģ��
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->
<div class="wp-main star-main">
<div class="m-list-single-circle mt30 mg_module" mg-name="list-star" data-lazyload-fn="0">

<textarea style="display:none;" class="template hide">
    <div class="m-title">
            <p class="til"><a href="/rembzx/javascript:void(0);">����</a></p>
        
    </div>

    <ul class="starul">
        {{#items}}
        {{!-- ֱ���������� sel --}}
        <li class="{{#isonline}}sel{{/isonline}}" data-uid="{{uid}}">  
            <p class="screenshot">
                <a href="/rembzx/{{link}}" target="_blank">
                    <img class="lazy" data-original="{{photo}}" src="{{photo}}?20161110" alt="{{nickname}}" width="90" height="90">
                </a>
                <i class="mask"></i>
                <i class="num">{{hotvalue}}</i>
            </p>
            <p class="name"><a href="/rembzx/{{link}}" target="_blank">{{nickname}}</a></p>
            <p class="living">ֱ����</p>
            <p class="playnum"><span>{{hotvalue}}</span></p>
        </li>
        {{/items}}
    </ul>
</textarea>


</div>
</div>
        <div class="wp-main">
    <!--
 * ģ��: m-list-portrait.hbs
 * ��ʽ: m-list-portrait.less
 * ����: â��tv��ҳ - �����б�ģ��
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->
<div class="m-list-portrait mt30 mg_module" mg-name="list-portrait" data-lazyload-fn="0">
<textarea style="display:none;" class="template hide">
	<div class="m-title">
            <p class="til"><a href="/rembzx/movie/" target="_blank">��Ӱ</a></p>
            <p class="more"><a href="/rembzx/movie/" target="_blank">����>></a></p>
        <p class="change"><a href="/rembzx/javascript:void(0);">��һ��</a></p>
    </div>

	<div class="v-list-inner">
		<ul class="v-list-unit">
		{{#items}}
			<li class="v-item" data-vid="{{videoid}}">
				<p class="screenshot">
					<a href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
					{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
					{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
				</p>
				<p class="title"><a href="{{link}}" target="_blank">{{title}}</a></p>
				<p class="des">{{desc}}</p>
			</li>
		{{/items}}
		</ul>
	</div>
</textarea>


</div>
    <!--
 * ģ��: m-list-top.hbs
 * ��ʽ: m-list-top.less
 * ����: â��tv��ҳ - �Ƽ�ϵͳ���а�ģ��
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->

<div class="m-list-top mt30 mg_module" mg-name="list-top" data-lazyload-fn="0" data-cid="3" data-name="&#x7535;&#x5f71;&#x6392;&#x884c;&#x699c;" data-link="/top/movie/">

<textarea style="display:none;" class="template hide">
	<div class="m-title">
            <p class="til"><a href="/rembzx/top/movie/" target="_blank">��Ӱ���а�</a></p>
            <p class="more"><a href="/rembzx/top/movie/" target="_blank">����>></a></p>
    </div>

	<ul class="m-top-toplist">
		{{#data}}
		<li class="" data-vid="{{videoid}}" data-rctype="{{rctype}}">
			<p class="txt"><em class="{{#top3}}on{{/top3}}">{{videoindex}}</em><span><a href="/rembzx/{{play_url}}" target="_blank">{{name}}</a></span></p>
			<p class="con">
				<span class="screenshot">
					<a href="/rembzx/{{play_url}}" target="_blank"><img alt="{{name}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
					<i class="num">{{videoindex}}</i>
				</span>
				<span class="title"><a href="/rembzx/{{play_url}}" target="_blank">{{name}}</a></span>
				<span class="name">
					{{#players}} / {{player}}{{/players}}
				</span>
			</p>
		</li>
		{{/data}}
	</ul>
</textarea>



</div>
</div>
        <div class="wp-main tv-main">
    <!--
 * ģ��: m-list-double-img.hbs
 * ��ʽ: m-list-double-img.less
 * ����: â��tv��ҳ - ͼ���б� ���Ӿ�
 * ����: imgotv-channel��
 * ����: dora - 2016.07.15
 * �޸�: dora - 2016.07.15
 -->

<div class="m-list-double-img mt30 mg_module" mg-name="list-double-img" data-lazyload-fn="0">

<textarea style="display:none;" class="template hide">

	<div class="m-title">
            <p class="til"><a href="/rembzx/child/" target="_blank">�ٶ�Ƶ��</a></p>
            <p class="more"><a href="/rembzx/child/" target="_blank">����>></a></p>
        <p class="change"><a href="/rembzx/javascript:void(0);">��һ��</a></p>
    </div>

	<div class="v-list-inner">
		<div class="v-list-inner-ul">
			{{#first}}
			<ul class="v-list-unit v-list-unit-big">
				<li class="v-item v-item-big" data-jumpkind="{{jumpkind}}" data-jumpid="{{jumpid}}" data-childid="{{childid}}">
					<p class="screenshot screenshot-big">
						<a class="a-bigimg" href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{imagebig}}" src="{{imagebig}}?20161110"></a>
						<span class="mask"></span>
						{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
						<span class="playico">����ۿ�������Ƶ</span>
						{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
					</p>
					<p class="title"><a href="/rembzx/{{link}}" target="_blank">{{title}}</a></p>
					<p class="des">{{desc}}</p>
				</li>
			</ul>
			{{/first}}
			{{#itemgroups}}
			<ul class="v-list-unit">
				{{#items}}
				<li class="v-item">
					<p class="screenshot">
						<a href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
						{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
						{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
					</p>
					<p class="title"><a href="{{link}}" target="_blank">{{title}}</a></p>
					<p class="des">{{desc}}</p>
				</li>
				{{/items}}
			</ul>
			{{/itemgroups}}
		</div>
	</div>
</textarea>



</div>
    <!--
 * ģ��: m-list-top.hbs
 * ��ʽ: m-list-top.less
 * ����: â��tv��ҳ - �Ƽ�ϵͳ���а�ģ��
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->

<div class="m-list-top mt30 mg_module" mg-name="list-top" data-lazyload-fn="0" data-cid="50" data-name="&#x5c11;&#x513f;&#x6392;&#x884c;&#x699c;" data-link="/top/cartoon/">

<textarea style="display:none;" class="template hide">
	<div class="m-title">
            <p class="til"><a href="/rembzx/top/cartoon/" target="_blank">�ٶ����а�</a></p>
            <p class="more"><a href="/rembzx/top/cartoon/" target="_blank">����>></a></p>
    </div>

	<ul class="m-top-toplist">
		{{#data}}
		<li class="" data-vid="{{videoid}}" data-rctype="{{rctype}}">
			<p class="txt"><em class="{{#top3}}on{{/top3}}">{{videoindex}}</em><span><a href="/rembzx/{{play_url}}" target="_blank">{{name}}</a></span></p>
			<p class="con">
				<span class="screenshot">
					<a href="/rembzx/{{play_url}}" target="_blank"><img alt="{{name}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
					<i class="num">{{videoindex}}</i>
				</span>
				<span class="title"><a href="/rembzx/{{play_url}}" target="_blank">{{name}}</a></span>
				<span class="name">
					{{#players}} / {{player}}{{/players}}
				</span>
			</p>
		</li>
		{{/data}}
	</ul>
</textarea>



</div>
</div>
        <div class="wp-main">
    <!--
 * ģ��: m-list-single.hbs
 * ��ʽ: m-list-single.less
 * ����: â��tv��ҳ - ͼ���б�����
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->
<div class="m-list-single mt30 mg_module" mg-name="list-single" data-lazyload-fn="0">
<textarea style="display:none;" class="template hide">
	<div class="m-title">
            <p class="til"><a href="/rembzx/cartoon/" target="_blank">����</a></p>
            <p class="more"><a href="/rembzx/cartoon/" target="_blank">����>></a></p>
        <p class="change"><a href="/rembzx/javascript:void(0);">��һ��</a></p>
    </div>

	<!--ͼ��-->
	<div class="v-list-inner">
		<ul class="v-list-unit">
		{{#items}}
			<li class="v-item" data-vid="{{videoid}}" data-jumpkind="{{jumpkind}}" data-jumpid="{{jumpid}}" data-childid="{{childid}}">
				<p class="screenshot">
					<a href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
					{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
					{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
				</p>
				<p class="title"><a href="/rembzx/{{link}}" target="_blank">{{title}}</a></p>
				<p class="des">{{desc}}</p>
			</li>
		{{/items}}
		</ul>
	</div>
</textarea>


</div>
</div>
        <div class="wp-main">
    <!--
 * ģ��: m-list-single.hbs
 * ��ʽ: m-list-single.less
 * ����: â��tv��ҳ - ͼ���б�����
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->
<div class="m-list-single mt30 mg_module" mg-name="list-single" data-lazyload-fn="0">
<textarea style="display:none;" class="template hide">
	<div class="m-title">
            <p class="til"><a href="/rembzx/d/334.html" target="_blank">â������</a></p>
            <p class="more"><a href="/rembzx/d/334.html" target="_blank">����>></a></p>
        
    </div>

	<!--ͼ��-->
	<div class="v-list-inner">
		<ul class="v-list-unit">
		{{#items}}
			<li class="v-item" data-vid="{{videoid}}" data-jumpkind="{{jumpkind}}" data-jumpid="{{jumpid}}" data-childid="{{childid}}">
				<p class="screenshot">
					<a href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
					{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
					{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
				</p>
				<p class="title"><a href="/rembzx/{{link}}" target="_blank">{{title}}</a></p>
				<p class="des">{{desc}}</p>
			</li>
		{{/items}}
		</ul>
	</div>
</textarea>


</div>
</div>
        <div class="wp-main">
    <!--
 * ģ��: m-list-single.hbs
 * ��ʽ: m-list-single.less
 * ����: â��tv��ҳ - ͼ���б�����
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->
<div class="m-list-single mt30 mg_module" mg-name="list-single" data-lazyload-fn="0">
<textarea style="display:none;" class="template hide">
	<div class="m-title">
            <p class="til"><a href="/rembzx/music/" target="_blank">����live</a></p>
            <p class="more"><a href="/rembzx/music/" target="_blank">����>></a></p>
        <p class="change"><a href="/rembzx/javascript:void(0);">��һ��</a></p>
    </div>

	<!--ͼ��-->
	<div class="v-list-inner">
		<ul class="v-list-unit">
		{{#items}}
			<li class="v-item" data-vid="{{videoid}}" data-jumpkind="{{jumpkind}}" data-jumpid="{{jumpid}}" data-childid="{{childid}}">
				<p class="screenshot">
					<a href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
					{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
					{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
				</p>
				<p class="title"><a href="/rembzx/{{link}}" target="_blank">{{title}}</a></p>
				<p class="des">{{desc}}</p>
			</li>
		{{/items}}
		</ul>
	</div>
</textarea>


</div>
</div>
        <div class="wp-main">
    <!--
 * ģ��: m-list-single.hbs
 * ��ʽ: m-list-single.less
 * ����: â��tv��ҳ - ͼ���б�����
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->
<div class="m-list-single mt30 mg_module" mg-name="list-single" data-lazyload-fn="0">
<textarea style="display:none;" class="template hide">
	<div class="m-title">
            <p class="til"><a href="/rembzx/news/" target="_blank">�ȵ�����</a></p>
            <p class="more"><a href="/rembzx/news/" target="_blank">����>></a></p>
        <p class="change"><a href="/rembzx/javascript:void(0);">��һ��</a></p>
    </div>

	<!--ͼ��-->
	<div class="v-list-inner">
		<ul class="v-list-unit">
		{{#items}}
			<li class="v-item" data-vid="{{videoid}}" data-jumpkind="{{jumpkind}}" data-jumpid="{{jumpid}}" data-childid="{{childid}}">
				<p class="screenshot">
					<a href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
					{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
					{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
				</p>
				<p class="title"><a href="/rembzx/{{link}}" target="_blank">{{title}}</a></p>
				<p class="des">{{desc}}</p>
			</li>
		{{/items}}
		</ul>
	</div>
</textarea>


</div>
</div>
        <div class="wp-main">
    <!--
 * ģ��: m-list-single.hbs
 * ��ʽ: m-list-single.less
 * ����: â��tv��ҳ - ͼ���б�����
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->
<div class="m-list-single mt30 mg_module" mg-name="list-single" data-lazyload-fn="0">
<textarea style="display:none;" class="template hide">
	<div class="m-title">
            <p class="til"><a href="/rembzx/ori/" target="_blank">ԭ��</a></p>
            <p class="more"><a href="/rembzx/ori/" target="_blank">����>></a></p>
        
    </div>

	<!--ͼ��-->
	<div class="v-list-inner">
		<ul class="v-list-unit">
		{{#items}}
			<li class="v-item" data-vid="{{videoid}}" data-jumpkind="{{jumpkind}}" data-jumpid="{{jumpid}}" data-childid="{{childid}}">
				<p class="screenshot">
					<a href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
					{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
					{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
				</p>
				<p class="title"><a href="/rembzx/{{link}}" target="_blank">{{title}}</a></p>
				<p class="des">{{desc}}</p>
			</li>
		{{/items}}
		</ul>
	</div>
</textarea>


</div>
</div>
        <!-- ���ҷֲ�����ͼ�ĺϳ�ģ�� -->
<div class="wp-main m-list-single-split">
    <div class="left"><!--
 * ģ��: m-list-single.hbs
 * ��ʽ: m-list-single.less
 * ����: â��tv��ҳ - ͼ���б�����
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->
<div class="m-list-single mt30 mg_module" mg-name="list-single" data-lazyload-fn="0">
<textarea style="display:none;" class="template hide">
	<div class="m-title">
            <p class="til"><a href="/rembzx/doc/" target="_blank">��¼Ƭ</a></p>
            <p class="more"><a href="/rembzx/doc/" target="_blank">����>></a></p>
        <p class="change"><a href="/rembzx/javascript:void(0);">��һ��</a></p>
    </div>

	<!--ͼ��-->
	<div class="v-list-inner">
		<ul class="v-list-unit">
		{{#items}}
			<li class="v-item" data-vid="{{videoid}}" data-jumpkind="{{jumpkind}}" data-jumpid="{{jumpid}}" data-childid="{{childid}}">
				<p class="screenshot">
					<a href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
					{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
					{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
				</p>
				<p class="title"><a href="/rembzx/{{link}}" target="_blank">{{title}}</a></p>
				<p class="des">{{desc}}</p>
			</li>
		{{/items}}
		</ul>
	</div>
</textarea>


</div></div>
    <div class="right"><!--
 * ģ��: m-list-single.hbs
 * ��ʽ: m-list-single.less
 * ����: â��tv��ҳ - ͼ���б�����
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->
<div class="m-list-single mt30 mg_module" mg-name="list-single" data-lazyload-fn="0">
<textarea style="display:none;" class="template hide">
	<div class="m-title">
            <p class="til"><a href="/rembzx/life/" target="_blank">�ֻ�</a></p>
            <p class="more"><a href="/rembzx/life/" target="_blank">����>></a></p>
        <p class="change"><a href="/rembzx/javascript:void(0);">��һ��</a></p>
    </div>

	<!--ͼ��-->
	<div class="v-list-inner">
		<ul class="v-list-unit">
		{{#items}}
			<li class="v-item" data-vid="{{videoid}}" data-jumpkind="{{jumpkind}}" data-jumpid="{{jumpid}}" data-childid="{{childid}}">
				<p class="screenshot">
					<a href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
					{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
					{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
				</p>
				<p class="title"><a href="/rembzx/{{link}}" target="_blank">{{title}}</a></p>
				<p class="des">{{desc}}</p>
			</li>
		{{/items}}
		</ul>
	</div>
</textarea>


</div></div>
</div>
        <!-- ���ҷֲ�����ͼ�ĺϳ�ģ�� -->
<div class="wp-main m-list-single-split">
    <div class="left"><!--
 * ģ��: m-list-single.hbs
 * ��ʽ: m-list-single.less
 * ����: â��tv��ҳ - ͼ���б�����
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->
<div class="m-list-single mt30 mg_module" mg-name="list-single" data-lazyload-fn="0">
<textarea style="display:none;" class="template hide">
	<div class="m-title">
            <p class="til"><a href="/rembzx/edu/" target="_blank">����</a></p>
            <p class="more"><a href="/rembzx/edu/" target="_blank">����>></a></p>
        <p class="change"><a href="/rembzx/javascript:void(0);">��һ��</a></p>
    </div>

	<!--ͼ��-->
	<div class="v-list-inner">
		<ul class="v-list-unit">
		{{#items}}
			<li class="v-item" data-vid="{{videoid}}" data-jumpkind="{{jumpkind}}" data-jumpid="{{jumpid}}" data-childid="{{childid}}">
				<p class="screenshot">
					<a href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
					{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
					{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
				</p>
				<p class="title"><a href="/rembzx/{{link}}" target="_blank">{{title}}</a></p>
				<p class="des">{{desc}}</p>
			</li>
		{{/items}}
		</ul>
	</div>
</textarea>


</div></div>
    <div class="right"><!--
 * ģ��: m-list-single.hbs
 * ��ʽ: m-list-single.less
 * ����: â��tv��ҳ - ͼ���б�����
 * ����: imgotv-channel��
 * ����: dora - 2016.07.18
 * �޸�: dora - 2016.07.18
 -->
<div class="m-list-single mt30 mg_module" mg-name="list-single" data-lazyload-fn="0">
<textarea style="display:none;" class="template hide">
	<div class="m-title">
            <p class="til"><a href="/rembzx/game/" target="_blank">Ȥ��</a></p>
            <p class="more"><a href="/rembzx/game/" target="_blank">����>></a></p>
        <p class="change"><a href="/rembzx/javascript:void(0);">��һ��</a></p>
    </div>

	<!--ͼ��-->
	<div class="v-list-inner">
		<ul class="v-list-unit">
		{{#items}}
			<li class="v-item" data-vid="{{videoid}}" data-jumpkind="{{jumpkind}}" data-jumpid="{{jumpid}}" data-childid="{{childid}}">
				<p class="screenshot">
					<a href="/rembzx/{{link}}" target="_blank"><img alt="{{title}}" class="lazy" data-original="{{image}}" src="{{image}}?20161110"></a>
					{{#series}}<span class="rb duration">{{series}}</span>{{/series}}
					{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}
				</p>
				<p class="title"><a href="/rembzx/{{link}}" target="_blank">{{title}}</a></p>
				<p class="des">{{desc}}</p>
			</li>
		{{/items}}
		</ul>
	</div>
</textarea>


</div></div>
</div>
        <!-- 
 * ģ��: extensbar.hbs
 * ��ʽ: extensbar.less
-->
<div class="m-extensbar">
	<!-- ���ײ����� -->
	<div class="showbar">
		<div class="box">
			<a href="/rembzx/javascript:void(0);" class="close"><i class="s">x</i></a>
			<a rel="nofollow" href="javascript:void(0);" class="picbtn" style="background-image:url(http://0img.mgtv.com/preview/cms_icon/2017/03/20170307151916489.png);"></a>
		</div>
		<div class="bg-box"></div>
	</div>
	
	<!-- =�����ʾ��ť=  -->
	<div class="showbtn">
		<a rel="nofollow" class="smpic" href="javascript:void(0);"><img src="http://0img.mgtv.com/preview/cms_icon/2017/03/20170307151916627.png?20161110" width="55" height="110"></a>
		<a rel="nofollow" class="bigpic" href="javascript:void(0);"><img src="http://3img.mgtv.com/preview/cms_icon/2017/03/20170307151916735.png?20161110" width="110" height="110"></a>
	</div>
</div>



        <!-- ������ ���ר�� -->
<div class="wp-main made-main gg-main">
    <div class="m-theatre-carousel mt30 mg_module" mg-name="theatre-carousel" data-lazyload-fn="0">
        <textarea style="display:none;" class="template hide">
            <div class="m-title">
                <p class="til">
                    <a href="/rembzx/javascript:void(0);">���</a>
                </p>
            </div>
            <div class="theatre-container">
                <div class="theatre-carousel-wrapper">
                    <div class="theatre-carousel-box">
                    {{#data}}
                        <a class="theatre-item" href="/rembzx/{{link}}" target="_blank">
                            <div class="theatre-expand">
                                <div class="theatre-left">
                                    <img class="theatre-poster" src="{{image}}?20161110">
                                    {{^adtag}}{{#rightcorner}}<i class="icon-o" style="background-color:{{cornertype}};">{{rightcorner}}</i>{{/rightcorner}}{{/adtag}}    
                                    {{#adtag}}<i class="ico-gg">���</i>{{/adtag}}
                                </div>
                                <div class="theatre-right">
                                    <img class="theatre-banner" src="{{bigimage}}?20161110">
                                </div>
                            </div>
                        </a>
                     {{/data}}
                    </div>
                </div>
                <div class="theatre-arrow-right theatre-arrow">
                </div>
                <div class="theatre-arrow-left theatre-arrow">
                </div>
            </div>
        </textarea>

        
    </div>
</div>

    <!-- ������ ���� -->
    <div class="wp-main morebg"><p><span>ȥ</span><a rel="nofollow" href="http://list.mgtv.com/1/-------------.html" target="_blank">����</a><span>���ྫ����Ƶ��~</span></p></div>

    <!-- �ײ��� -->
    <!-- 
 * ģ��: c-footer-lv1.hbs
 * ��ʽ: c-footer.less
 * ����: pc��ҳ�ײ�
 * ����: imgotv-pub / component / footer
 * ������dora - 2015.3.30
 * �޸ģ�iruxu - 2015.5.10
-->


<div class="c-footer c-footer-lv1 ">
	<!-- �ײ�ģ��Ԫ�أ��������� -->
<div class="c-footer-links">
	<ul>
		<li><a class="logo iptv" href="/rembzx/javascript:;">����iptv</a></li>
		<li><a rel="nofollow" class="logo hiq" target="_blank" href="http://mangotv.hunantv.com/">â������������</a></li>
		<li><a rel="nofollow" class="logo jy" target="_blank" href="http://news.hunantv.com/">��ӥ��</a></li>
		<li><a rel="nofollow" target="_blank" href="http://www.eemedia.cn/">���鴫ý</a></li>
		<li><a rel="nofollow" target="_blank" href="http://www.vfund.org/html/index.html">â��v����</a></li>
		<li><a target="_blank" href="/rembzx/zq/hnetv/">���Ͼ���</a></li>
		<li><a rel="nofollow" target="_blank" href="http://www.happigo.com/">���ֹ�</a></li>
		<li><a target="_blank" href="/rembzx/gba/">���Ϲ㲥����Э��</a></li>
		<li><a target="_blank" href="/rembzx/v/klcd/">���ִ���</a></li>
		<li><a rel="nofollow" target="_blank" href="http://shangbiao.hunantv.com/">â���̱�</a></li>
		<li><a target="_blank" href="/rembzx/pmb/">�ص㹤��</a></li>
		<li><a rel="nofollow" target="_blank" href="http://www.mgstudios.cn/">â��Ӱ��</a></li>
	</ul>
</div>
	<!-- �ײ�ģ��Ԫ�أ��б����� -->
<div class="c-footer-list">
	<ul>
		<li><a rel="nofollow" target="_blank" href="http://corp.mgtv.com/">��˾����</a></li>
		<li><a rel="nofollow" target="_blank" href="http://corp.mgtv.com/about/">��������</a></li>
		<li><a rel="nofollow" target="_blank" href="http://corp.mgtv.com/news/dynamics/">��˾��̬</a></li>
		<li><a target="_blank" href="/rembzx/market/">������</a></li>
		<li><a rel="nofollow" target="_blank" href="http://corp.mgtv.com/others/join/">��Ƹ��Ϣ</a></li>
		<li><a rel="nofollow" target="_blank" href="http://corp.mgtv.com/news/notice/">��������</a></li>
		<li><a rel="nofollow" target="_blank" href="http://corp.mgtv.com/others/contact/">��ϵ����</a></li>
		<li><a rel="nofollow" target="_blank" href="http://corp.mgtv.com/product/">ҵ�񹹳�</a></li>
	</ul>
</div>

    <!-- �ײ�ģ��Ԫ�أ���Ȩ������Ӣ�ģ� -->
<p class="c-footer-cpen">
	copyright 2006-2017 mgtv.com corporation,all rights reserved
</p>
    <!-- �ײ�ģ��Ԫ�أ���Ȩ���������ģ� -->
<p class="c-footer-cpcn">
	���Ͽ������⻥�����ִ�ý���޹�˾ ��Ȩ����
</p>
    <!-- �ײ�ģ��Ԫ�أ��������� -->
<div class="c-footer-credit">
	<p>
        <a rel="nofollow" href="http://i1.hunantv.com/ui/2016/images/xkz.jpg" target="_blank">������[2015]1490-016��</a> 
        <span>��Ϣ���紫��������Ŀ����֤�ţ�1805107</span> 
        <span>������������Ϣ��������֤�ţ�4312006005</span> 
        <span><a rel="nofollow" target="_blank" href="http://www.miibeian.gov.cn">��b2-20090004-6</a></span>
    </p>
</div>
    <!-- �ײ�ģ��Ԫ�أ���Ϣ��ȫ -->
<div class="c-footer-safety">
    <!-- ��ȫ��Ϣ -->
    <p class="police">
        <a rel="nofollow" target="_blank" href="javascript:;" style="cursor:default;">
            <img src="http://img.hunantv.com/imgotv-channel/imgotv-pub/component/footer/safety/safety.png?20161110" alt="&#x4e3e;&#x62a5;&#x4e13;&#x533a;">
        </a>
    	<a rel="nofollow" target="_blank" href="http://jubao.12377.cn:13225/reportinputcommon.do">
    		<img src="http://img.hunantv.com/imgotv-channel/imgotv-pub/component/footer/safety/report.png?20161110" alt="&#x4e0d;&#x826f;&#x4fe1;&#x606f;&#x4e3e;&#x62a5;&#x4e2d;&#x5fc3;">
    	</a>
    	<a>
    		<img border="0" src="http://img.hunantv.com/imgotv-channel/imgotv-pub/component/footer/safety/hngawj.png?20161110" alt="">
    	</a>
    	<a rel="nofollow" target="_blank" href="http://www.hnains.net.cn/">
    		<img border="0" src="http://img.hunantv.com/imgotv-channel/imgotv-pub/component/footer/safety/hnains.png?20161110" alt="">
    	</a>
        <a rel="nofollow" target="_blank" href="http://wfblxx.rednet.cn/column.aspx?colid=10">
       		<img border="0" src="http://img.hunantv.com/imgotv-channel/imgotv-pub/component/footer/safety/rednet.png?20161110" alt="">
       	</a> 
        <a rel="nofollow" target="_blank" href="http://pypt.rednet.cn/">
        	<img border="0" src="http://img.hunantv.com/imgotv-channel/imgotv-pub/component/footer/safety/wfblxx.png?20161110" alt="">
        </a>
    </p>
    <!-- ��ϵ��ʽ -->
    <p class="contact">
    	<span>�ٱ��绰 : 0731��82871680 </span> 
    	<span>�ٱ����� : web@mgtv.com </span>
    </p>
    <p class="statement">�ž���ٱ��� ��ӭ���ල</p>
</div>
</div>

</div>




 
 


<!-- ����ͳ�� start-->



<!--ͳ�ƴ��� start-->
<!-- start ǰ�˼�� -->

<!-- end ǰ�˼�� -->

<!-- start ����iwt -->

<!-- end ����iwt -->

<!-- start baidu by 20140420 -->

<!-- end baidu by 20140420 -->

<!-- begin comscore tag -->

<noscript>
    <img src="http://b.scorecardresearch.com/p?c1=2&amp;c2=18400293&amp;c3=&amp;c4=&amp;c5=&amp;c6=&amp;c15=&amp;cv=2.0&amp;cj=1&amp;;comscorekw=?20161110">
</noscript>
<!-- end comscore tag -->

<!--ͳ�ƴ��� end-->
<!-- ����ͳ�� end-->
<!-- 09wl.com --><div class="renmentuijian1888">

<li><a href="/html/3.html" class="red">�������</a></li>
<li><a href="/html/2.html" class="red">�Ƽ�����</a></li>
</div></body>
</html>
