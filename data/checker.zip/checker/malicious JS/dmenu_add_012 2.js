<!DOCTYPE html>
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
 	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  
	




<!--
	<script type="text/javascript" src='//static.s-sfr.fr/resources/js/frameworks/jquery/jquery-1.6.4.min.js' charset="UTF-8"></script>
-->

 
    <script type="text/javascript" src='//static.s-sfr.fr/resources/js/frameworks/jquery/sfr.jquery.js' charset="UTF-8"></script>
 
    <script src='//static.s-sfr.fr/resources/ist/param.sfr.min.js' charset="UTF-8"></script>

	<script type="text/javascript" src='//static.s-sfr.fr/resources/js/global.sfr.min.js' charset="UTF-8"></script>
	<script type="text/javascript" src='//static.s-sfr.fr/resources/pontis/pontis.sfr.min.js' charset="UTF-8"></script>
    <script type="text/javascript" src="//static.s-sfr.fr/resources/js/fastforward/deviceRedirect.js"></script>

	<link rel="stylesheet" type="text/css" href="//static.s-sfr.fr/resources/css/global.sfr.min.css" charset="UTF-8"/>

	<link rel="icon" type="image/png" href="//static.s-sfr.fr/media/favicon.png" />
	<!--[if IE]><link rel="shortcut icon" type="image/x-icon" href="//static.s-sfr.fr/media/favicon.ico" /><![endif]-->

<script>



_is_authenticated=false;
_stats_timestamp="1492226082549";
sfrIstConfig=djangoUtils={};





sfrIstConfig.context = 'static.s-sfr.fr';
</script>

	
    <link rel="canonical" href="http://www.sfr.fr/fermeture-des-pages-perso.html" />
	

<!--[if IE]><link rel="stylesheet" type="text/css" href="//static.s-sfr.fr/resources/css/iefixes.css" charset="UTF-8"/></script><![endif]-->
<!--[if IE 8]><link rel="stylesheet" type="text/css" href="//static.s-sfr.fr/resources/css/ie8fixes.css" charset="UTF-8"/><![endif]-->
<!--[if IE 7]><link rel="stylesheet" type="text/css" href="//static.s-sfr.fr/resources/css/ie7fixes.css" charset="UTF-8"/><![endif]-->
<!--[if IE 6]><link rel="stylesheet" type="text/css" href="//static.s-sfr.fr/resources/css/ie6fixes.css" charset="UTF-8"/><![endif]-->
<!--[if IE 9]>
	<meta name="application-name" content="SFR" />
	<meta name="msapplication-tooltip" content="SFR" />
	<meta name="msapplication-starturl" content="/" />
	<meta name="msapplication-navbutton-color" content="#E2001A" />
	<script type='text/javascript' src='//static.s-sfr.fr/resources/js/utils/ie9utility.js'></script>
<![endif]-->






	











































	<link rel="stylesheet" type="text/css" href="//static.s-sfr.fr/resources/css/global.sfr.v2.css" />
	<link rel="stylesheet" type="text/css" href="//static.s-sfr.fr/resources/css/blocs/sfr.adsl.css" />
	<script type='text/javascript' src='//static.s-sfr.fr/resources/js/plugins/jquery/sfr.stickyMenu.js' charset="UTF-8"></script>
	<script type='text/javascript' src='//static.s-sfr.fr/resources/js/plugins/jquery/sfr.stickyStuff.js' charset="UTF-8"></script>
	<script type='text/javascript' src='//static.s-sfr.fr/resources/js/plugins/jquery/sfr.crzl.js' charset="UTF-8"></script>
	<link rel="stylesheet" type="text/css" href="//static.s-sfr.fr/resources/css/plugins/sfr.crzl.css" />
	

<!--END OF SOCIAL-->





<link rel="apple-touch-startup-image" type="image/png" href="http://m.sfr.fr/mist/assets/logos/apple-touch-startup.png"/>
<link rel="apple-touch-icon" type="image/png" href="http://m.sfr.fr/mist/assets/logos/apple-touch-icon.png" />
<link rel="apple-touch-icon" sizes="114x114" href="http://m.sfr.fr/mist/assets/logos/iphone_114x114.png" />

<script type="application/ld+json">
{
   "@context": "http://schema.org",
   "@type": "Organization",
   "url": "http://www.sfr.fr",
   "logo": "http://static.s-sfr.fr/media/sfr_logo2014_exe_rvb.png", 
   "contactPoint" : [{
   "@type" : "ContactPoint",
   "telephone" : "(+33) 1023",
   "contactType" : "customer support", 
   "areaServed" : "FR"
  } , {
    "@type" : "ContactPoint",
    "telephone" : "(+33) 1099",
    "contactType" : "sales",
    "areaServed" : "FR"
  }] , 
"sameAs" : [
    "https://fr-fr.facebook.com/SFR",
    "https://twitter.com/SFR",
    "https://plus.google.com/113745061295301596108/posts"
  ]}
</script>
<script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "WebSite",
  "url": "http://www.sfr.fr/",
  "potentialAction": {
    "@type": "SearchAction",
    "target": "http://www.sfr.fr/recherche?q={search_term_string}",
    "query-input": "required name=search_term_string"
  }
}
</script>



<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

<meta name="mobile-web-app-capable" content="yes">

<link rel="stylesheet" href="//static.s-sfr.fr/resources/css/responsive/responsive.sfr.min.css" />
<!--[if lt IE 9]><link rel="stylesheet" href="//static.s-sfr.fr/resources/css/responsive/ie8-sfrRN.css" /><![endif]-->

<script type="text/javascript" src="//static.s-sfr.fr/resources/js/frameworks/jquery/jquery-1.9.1.min.js"></script>
<!--[if lt IE 9]><script src="//static.s-sfr.fr/resources/js/plugins/jquery/html5shiv.js"></script><![endif]-->
<script>sfrIstConfig.context='static.s-sfr.fr'</script>
<script src="//static.s-sfr.fr/resources/js/responsive/responsive.closure.sfr.min.js"></script>
<script src="//static.s-sfr.fr/stats/header.js" charset="UTF-8"></script>
</head><body class="sfrRN">
<!--Header-->

<!-- header -->
<style>
body{margin:0}
#eTsH *{margin:0;padding:0;border:0;font-size:100%;font:inherit;text-align:left;vertical-align:baseline;box-sizing:border-box;-webkit-font-smoothing:auto;text-rendering:optimizeLegibility}
#eTsH{font:12px Arial;color:#1C1C1C;padding-bottom:0;display:block!important;z-index:40000;position:relative;box-shadow:0 1px 1px #ddd}
#eTsH ul{list-style:none}
#eTsH img{vertical-align:middle}
#eTsH a,#eTsH a:active,#eTsH a:focus,#eTsH a:hover{text-decoration:none}
#eTsH .liI{list-style:none;white-space:nowrap}
#eTsH .liI>li{display:inline-block;padding:4px 9px}
#eTsH .liI a>.R{color:#00e094}
#eTsH .liI a>.S{color:#e2001a}
#eTsH .text-center{text-align:center}
#eTsH strong{font-weight:bold}
#eTsH>.T{height:40px;background:#181818}
#eTsH>.T>ul{overflow:hidden;white-space:normal;height:40px}
#eTsH>.T>.L{float:left;max-width:35%}
#eTsH>.T>.R{float:right;max-width:64%;text-align:right}
#eTsH>.T ul>li{font:12px SFR-Regular;text-transform:uppercase;margin:4px 0}
#eTsH>.T ul>li,#eTsH .T ul>li>a{color:#aaa;line-height:24px}
#eTsH>.T ul>li>a.hi,#eTsH .T ul>li>a:hover{border-bottom:1px solid #666}
#eTsH>.T B{font-family:SFR-Bold}
#eTsH>.M{background:#FFF;height:80px;position:relative}
#eTsH>.M a:hover{text-decoration:none}
#eTsH>.M>*{height:80px}
#eTsH>.M>.L{position:absolute;left:0;width:80px}
#eTsH>.M>.L img{width:100%}
#eTsH>.M:after{content:" ";display:table;clear:both}
#eTsH>.M>.P{padding:9px 0 0 68px}
#eTsH>.M>.P>ul{display:inline-block;border-top:1px solid #ddd;margin:14px 0 0 2%}
#eTsH>.M>.P>ul:before{content:"Nos offres";font:12px SFR-Thin;display:table;clear:both;margin:-7px 0 -9px;padding:0 9px 0 32px;text-transform:uppercase;background:#fff}
#eTsH>.M>.P>ul+ul:before{content:"Nos contenus"}
#eTsH>.M>.P>ul>li{padding:9px 16px;margin:0 -16px 0 16px}
#eTsH>.M>.P>ul>li>a{position:relative;font:18px 'SFR-Regular',Arial;line-height:42px;color:#000}
#eTsH>.M>.P>ul>li>a.hi{font-family:'SFR-Bold',Arial;-webkit-font-smoothing:antialiased}
#eTsH>.M>.P>ul>li>a>p{display:none;width:280%;height:36px;position:absolute;left:-90%;top:18px;
    background:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='25' height='13'%3E%3Cpolygon points='12,0 0,12 24,12' style='fill:%23f2f2f2'/%3E%3C/svg%3E") 50% 13px no-repeat}
#eTsH>.M>.P>ul>li.ok:hover>a>p{display:block}
#eTsH>.M>.P>ul>li.ok:hover .sH{display:block;z-index:59999}
#eTsH .sH{font-size:0;width:100%;display:none;position:absolute;top:80px;left:0;height:448px;box-shadow:0 700px 480px 400px rgba(0,0,0,.8);padding:0}
#eTsH .sH:after{content:" ";height:80px;width:100%;display:block}
#eTsH .sH>div{background:#f2f2f2;display:inline-block;vertical-align:top;height:448px;width:40%;white-space:normal}
#eTsH .sH>div>p{color:#444;font:52px SFR-Thin,Arial;max-width:500px;padding:36px 60px 0 20px;margin:0 0 0 auto}
#eTsH .sH>div>p>a{color:#444;text-decoration:none}
#eTsH .sH>div>p>a:hover{text-decoration:underline}
#eTsH .sH>div>p+p{font:18px 'SFR-Regular',Arial;padding:14px 60px 20px 20px;line-height:156%}
#eTsH .sH>div+div{width:60%;position:relative;overflow-x:hidden}
#eTsH>.M .Z{border-left:1px solid #ddd}
#eTsH>.M .Z>div{border-left:6px solid transparent;margin:12px 0;padding:5px 0 6px 20px}
#eTsH>.M .Z>div:first-child{margin-top:44px}
#eTsH>.M .Z>div p{color:#222;font:18px 'SFR-Bold'}
#eTsH>.M .Z>div p+p{color:#777;font:14px 'SFR-Regular'}
#eTsH>.M .Z>div.act{border-left-color:#e2001a}
#eTsH>.M .Z>div>a>img{display:none;position:absolute;top:44px;left:280px}
#eTsH>.M .Z>div.act>a>img{display:block}
#eTsH>.M>.A{white-space:nowrap;position:absolute;right:0;top:0;padding:24px 9px 0;width:16%}
#eTsH>.M>.A>a{cursor:pointer;font:18px 'SFR-Thin';color:#000}
#eTsH>.M>.A>a>*,#eTsH>.M>.A>img{display:block;float:right}
#eTsH>.M>.A>a>i{margin-top:4px}
#eTsH>.M>.A>a>i.up,#eTsH .EC{display:none}
#eTsH>.M>.A p{padding-right:4px;max-height:25px;max-width:calc(100% - 24px);line-height:26px;overflow:hidden;text-overflow:ellipsis;text-align:right}
#eTsH>.M>.A>a+a>p{max-width:calc(100% - 36px)}
#eTsH .EC{display:none;top:56px;position:absolute;right:8px;z-index:59999;padding:0;min-width:168px;background:#FFF;border:1px solid #4a4a53;text-align:center}
#eTsH .EC h4{text-align:center;font:17px 'SFR-Regular',Arial;font-style:italic;line-height:40px}
#eTsH .EC h4 i{color:#707177}
#eTsH .EC p{text-align:center;font-size:13px;line-height:18px;padding-bottom:20px}
#eTsH .EC ul>li{padding:0;overflow:hidden}
#eTsH .EC ul>li a{padding-left:13px;padding-right:13px;display:block;height:40px;font:14px Arial;line-height:40px;color:#1a171b}
#eTsH .EC ul>li a:hover{color:#FFF;background:#e2001a}
#eTsH>.M>.S{position:absolute;top:20px;right:18%;width:calc(78% - 720px);height:40px}
#eTsH>.M>.S input{height:40px;border:1px solid #bbb;position:absolute;top:0;right:0}
#eTsH [name=q]{width:100%;max-width:480px;background:url(//static.s-sfr.fr/media/rgoo.png) #fff no-repeat 0 6px;padding:9px 40px 9px 5px}
#eTsH [name=q]:focus,#eTsH [name=q].q{background:#fff}
#eTsH>.M>.S [type=submit]{width:35px;background:#bbb url(//static.s-sfr.fr/media/picto-loupe.png) center no-repeat;background-size:50%;cursor:pointer}
#eTsH i{font:14px "sfr-icons";-webkit-font-smoothing:antialiased}
#eTsH i.dc{font-size:18px;color:#b7b7b7}
#eTsH .liI>li.1st{padding-left:0;display:none}
#eTsH .pi{height:25px;margin-top:-3px;display:inline-block;width:auto}
#eTsH .pi.U{margin-right:3px;filter:invert(1)}
#eTsH .S .pi{height:18px;margin-top:-3px;position:absolute;display:inline-block;top:9px;left:7px}
#eTsH i.mel{display:none;background:#e2001a;color:#ddd;border-radius:9px;padding:3px 5px;margin:-3px -3px 0 3px;font:11px Arial;text-transform:none}
#eTsH>.B{display:none}
@media only screen and (max-width:1199px){
    #eTsH>.M>.P>ul>li{padding:9px 9px;margin:0 -9px 0 9px}
    #eTsH>.M>.P>ul:before{padding-left:18px}
    #eTsH>.M .Z>div>a>img{left:260px}
    #eTsH>.M>.S{right:16.2%;width:calc(78% - 610px)}}
@media only screen and (max-width:1024px){
    #eTsH>.M .Z>div>a>img{left:240px;width:calc(99% - 240px)}
    #eTsH>.M>.S{width:calc(78% - 480px)}
    #eTsH>.M>.P>ul{margin-left:1%}
    #eTsH>.M>.P>ul:before{padding-left:12px}
    #eTsH>.M>.P>ul>li{padding:9px 6px;margin:0 -6px 0 6px}
    #eTsH>.M>.P>ul>li>a,#eTsH>.M>.A>a{font-size:16px}}
@media only screen and (max-width:879px){#eTsH [name=q]{background-position-x:-76px}}
@media only screen and (max-width:767px){
    #eTsH>.T>.L,#eTsH>.M>*{display:none}
    #eTsH .sH{display:none!important}
    #eTsH>.M{height:auto}
    #eTsH>.M>.L{display:block;top:-40px;width:40px}
    #eTsH>.M>.P{height:auto;padding:4px;text-align:center}
    #eTsH>.M>.P>ul{margin:20px auto -8px}
    #eTsH>.T{padding:0 40px}
    #eTsH .liI>li{padding:4px 6px}
    #eTsH>.M>.A{min-width:0}
    #eTsH .UN p{display:none!important}
    #eTsH>.B{display:block;position:absolute;top:0;right:0;width:40px;height:40px;padding:5px 3px;cursor:pointer}
    #eTsH>.B>p{height:4px;width:26px;border-radius:2px;background:#bbb;margin:4px}}
</style>

<header id="eTsH"><div class="T" data-stat="Top">
<ul class="liI R"><li><a href="https://webmail.sfr.fr/">Mails<i class=mel></i></a></li><li><a href="https://boutique.sfr.fr/">Boutiques</a></li><li><a href="https://www.sfr.fr/sfr-et-moi.html">Espace Client</a></li><li><a href="https://assistance.sfr.fr/">Assistance</a></li><li><a href="https://www.sfr.fr/suivi-commande/"> Suivi de commande</a></li><li><a href="https://www.sfr.fr/portail.html">Portail SFR</a></li></ul>
<ul class="liI L"><li><a href="https://www.sfr.fr/offres/">Offres <span class=S>SFR</span></a></li><li><a href="https://www.red-by-sfr.fr/">Offres <span class=R>RED</span></a></li><li><a href="https://www.sfrbusiness.fr/">Offres <span style='color:white'>ENTREPRISES</span></a></li></ul>
</div><div class="B">
    <p></p><p></p><p></p>
</div><div class="M">
    <div class="L"><a href="https://www.sfr.fr/#sfrintid=HH_Logo"><img src="//static.s-sfr.fr/media/logo-3.jpg" alt=""/></a></div>
    <div class="P"><ul class="liI"><li data-stat="Box"><a data-hi="@/(box|offre)-internet" href="https://www.sfr.fr/box-internet/">Box<p></p></a><div class="sH"><div><p>Box</p><p>Testez votre <a href='https://www.sfr.fr/box-internet/test-eligibilite-adsl-vdsl-fibre.html'>éligibilité</a> et votre <a href='https://mire.sfr.fr/'>débit</a> à la <a href='https://www.sfr.fr/offre-internet/box-fibre'>fibre optique</a> ou à l'<a href='https://www.sfr.fr/offre-internet/box-adsl/'>ADSL</a> et choisissez l'offre internet adaptée à vos besoins.<BR>Découvrez également nos offres de maison connectée avec  <a href='https://boutique.home.sfr.fr/'>Home by SFR</a> : <a href='https://boutique.home.sfr.fr/usage-securite'>sécurité</a>, <a href='https://boutique.home.sfr.fr/usage-domotique'>domotique</a> et <a href='https://boutique.home.sfr.fr/usage-chauffage'>pilotage du chauffage</a></p></div><div><div class="Z"><div class="act"><a data-img="-box-thd-v2-" data-hi="@/(box|offre)-internet" href="https://www.sfr.fr/offre-internet/box-thd/""><p>Offres box THD</p><p>Internet Très Haut Débit</p></a></p></div><div><a data-img="-box-adsl-v2-" data-hi="@/(box|offre)-internet" href="https://www.sfr.fr/offre-internet/box-adsl/""><p>Offres box ADSL</p><p>Internet Haut Débit</p></a></p></div><div><a data-img="-box-thd4k-v2-" data-hi="@/(box|offre)-internet" href="https://www.sfr.fr/la-box-tres-haut-debit/""><p>La Box 4K</p><p>La Box en détail</p></a></p></div><div><a data-img="-box-chainestv-" data-hi="@/(box|offre)-internet" href="https://www.sfr.fr/box-internet/television-box-tv-fibre-sfr/television-box-sfr.html""><p>Chaînes TV</p><p>Toutes les chaînes sont là</p></a></p></div><div><a data-img="-box-accessoires-v2-" data-hi="@/(box|offre)-internet" href="https://accessoires.sfr.fr/""><p>Accessoires</p><p>Box, ordinateurs, TV</p></a></p></div><div><a data-img="-box-toutes-" data-hi="@/(box|offre)-internet" href="https://www.sfr.fr/box-internet/""><p>Toutes nos offres</p><p>Votre équipement connecté</p></a></p></div></div></div></div></li><li data-stat="Mobile"><a data-hi="@/(telephonie|forfait)-mobile" href="https://www.sfr.fr/telephonie-mobile/">Mobile<p></p></a><div class="sH"><div><p>Mobile</p><p>Découvrez les meilleurs <a href='https://www.sfr.fr/forfait-mobile/telephones/smartphone'>Smartphones</a> (<a href='https://www.sfr.fr/forfait-mobile/telephone/APPLE-iPhone-7'>iPhone 7</a>, <a href='https://www.sfr.fr/forfait-mobile/telephones/apple'>iPhone</a> <a href='https://www.sfr.fr/forfait-mobile/telephone/APPLE-iPhone-6S'>6S</a>, <a href='https://www.sfr.fr/forfait-mobile/telephones/samsung'>Samsung</a> <a href='https://www.sfr.fr/forfait-mobile/telephone/SAMSUNG-Galaxy-S8'>Galaxy S8</a> et <a href='https://www.sfr.fr/forfait-mobile/telephone/SAMSUNG-Galaxy-S7'>Galaxy S7</a>, <a href='https://www.sfr.fr/forfait-mobile/telephones/wiko'>Wiko</a>, <a href='https://www.sfr.fr/forfait-mobile/telephones/huawei'>Huawei</a>) à l'achat ou en <a href='https://www.sfr.fr/telephonie-mobile/location-smartphone-forever/'>location</a> et choisissez le <a href='https://www.sfr.fr/forfait-mobile/offres/forfait-mobile'>Forfait Mobile</a> <a href='https://www.sfr.fr/decouvrir-offres-sfr/reseau-sfr/4g/couverture.html'>4G</a> adapté à vos besoins.</p></div><div><div class="Z"><div class="act"><a data-img="-mobile-telephone-forfait-v2-" data-hi="@/(telephonie|forfait)-mobile" href="https://www.sfr.fr/forfait-mobile/telephones/forfait-mobile""><p>Téléphones avec forfait</p><p>Les meilleurs smartphones avec forfait</p></a></p></div><div><a data-img="-mobile-telephone-v2-" data-hi="@/(telephonie|forfait)-mobile" href="https://www.sfr.fr/forfait-mobile/telephones/forfait-mobile?billingModeSel=SANS_FORFAIT""><p>Téléphones sans forfait</p><p>Votre smartphone au meilleur prix</p></a></p></div><div><a data-img="-mobile-4g-v2-" data-hi="@/(telephonie|forfait)-mobile" href="https://www.sfr.fr/forfait-mobile/offres/forfait-mobile""><p>Forfaits 4G</p><p>Vos usages puissance 4G</p></a></p></div><div><a data-img="-mobile-alacarte-v2-" data-hi="@/(telephonie|forfait)-mobile" href="https://www.sfr.fr/telephonie-mobile/sfr-la-carte.html""><p>Cartes prépayées</p><p>Kit prépayé avec ou sans mobile</p></a></p></div><div><a data-img="-mobile-accessoires-v2-" data-hi="@/(telephonie|forfait)-mobile" href="https://accessoires.sfr.fr/""><p>Accessoires</p><p>Coques, chargeurs, casques…</p></a></p></div></div></div></div></li><li data-stat="4P"><a data-hi="@/(box-mobile|avantages-sfr-family)" href="https://www.sfr.fr/box-mobile/">Box + Mobile<p></p></a><div class="sH"><div><p>Box + Mobile</p><p>Le Très Haut Débit partout, tout le temps et pour toute la famille ! Testez votre <a href='https://www.sfr.fr/box-internet/test-eligibilite-adsl-vdsl-fibre.html'>éligibilité à la fibre</a> ou votre <a href='http://mire.sfr.fr/'>débit internet</a> et profitez de la <a href='https://www.sfr.fr/offre-internet/box-thd/box-tres-haut-debit-power-de-sfr.html'>Box THD 4K</a> sur tous vos écrans.</p></div><div><div class="Z"><div class="act"><a data-img="-boxmobile-offres-v2-" data-hi="@/(box-mobile|avantages-sfr-family)" href="https://www.sfr.fr/box-mobile/""><p>Offres Box + Mobile</p><p>Très Haut Débit + 4G</p></a></p></div><div><a data-img="-boxmobile-sfrfamily-v2-" data-hi="@/(box-mobile|avantages-sfr-family)" href="https://www.sfr.fr/avantages-sfr-family.html""><p>SFR FAMiLY !</p><p>Partagez, économisez !</p></a></p></div></div></div></div></li></ul><ul class="liI"><li data-stat="Sport"><a data-hi="@/newsfr/sfr-sport" href="https://www.sfr.fr/newsfr/sfr-sport/">Sport<p></p></a><div class="sH"><div><p>SFR Sport</p><p>Retrouvez tous vos sports préférés dont le rugby anglais, le basket français, la <a href='https://www.sfr.fr/newsfr/sfr-sport/premier-league.html'>Premier League</a> anglaise et la Liga portugaise de football.</p></div><div><div class="Z"><div class="act"><a data-img="-newsfr-sport-v2-" data-hi="@/newsfr/sfr-sport" href="https://www.sfr.fr/newsfr/sfr-sport/""><p>Découvrir SFR Sport</p><p>5 chaines exclusives pour vibrer sport</p></a></p></div><div><a data-img="-sport-box-" data-hi="@/newsfr/sfr-sport" href="https://www.sfr.fr/offre-internet/box-thd/""><p>Avec nos offres box</p><p>Disponible dès l’offre Power</p></a></p></div><div><a data-img="-sport-mobile-" data-hi="@/newsfr/sfr-sport" href="https://www.sfr.fr/forfait-mobile/offres/forfait-mobile/""><p>Avec nos offres mobile</p><p>Disponible partout avec vous</p></a></p></div><div><a data-img="-sport-digital-" data-hi="@/newsfr/sfr-sport" href="https://www.sfr.fr/newsfr/sfr-sport/digital.html""><p>SFR Sport 100% digital</p><p>Sans engagement</p></a></p></div><div><a data-img="-sport-actu-" data-hi="@/newsfr/sfr-sport" href="https://sport.sfr.fr/""><p>Actualités Sport</p><p>L’info sport et résultats en direct</p></a></p></div></div></div></div></li><li data-stat="Play"><a data-hi="@/newsfr/sfr-play" href="https://www.sfr.fr/newsfr/sfr-play/">Play<p></p></a><div class="sH"><div><p>SFR Play</p><p>Ciné, Séries, jeunesse… Le meilleur de la <a href='https://www.sfr.fr/newsfr/sfr-play/'>TV</a> avec les chaînes <a href='https://www.sfr.fr/newsfr/sfr-play/discovery.html'>Discovery</a>, <a href='https://www.sfr.fr/newsfr/sfr-play/chaines-syfy-et-13emerue.html'>Syfy</a> et <a href='https://www.sfr.fr/newsfr/sfr-play/chaines-syfy-et-13emerue.html'>13ème RUE</a>, de la <a href='https://www.sfr.fr/newsfr/sfr-play/svod.html'>VOD en illimité</a> avec <a href='https://www.sfr.fr/newsfr/sfr-play/serie-taken.html'>la série Taken</a> et du <a href='https://play.sfr.fr/'>streaming HD</a></p></div><div><div class="Z"><div class="act"><a data-img="-newsfr-play-v2-" data-hi="@/newsfr/sfr-play" href="https://www.sfr.fr/newsfr/sfr-play/""><p>Découvrir SFR Play</p><p>Le meilleur du divertissement</p></a></p></div><div><a data-img="-play-box-" data-hi="@/newsfr/sfr-play" href="https://www.sfr.fr/offre-internet/box-thd/""><p>Avec nos offres box</p><p>Disponible dès l’offre Power</p></a></p></div><div><a data-img="-play-mobile-" data-hi="@/newsfr/sfr-play" href="https://www.sfr.fr/forfait-mobile/offres/forfait-mobile/""><p>Avec nos offres mobile</p><p>Disponible partout avec vous</p></a></p></div><div><a data-img="-play-vod-" data-hi="@/newsfr/sfr-play" href="https://www.sfr.fr/newsfr/sfr-play/svod.html""><p>VOD Illimitée</p><p>Pour toute la famille et en 4k</p></a></p></div><div><a data-img="-play-guide-" data-hi="@/newsfr/sfr-play" href="http://tv.sfr.fr/""><p>Guide TV</p><p>Faites votre programme</p></a></p></div></div></div></div></li><li data-stat="Presse"><a data-hi="@/newsfr/sfr-presse" href="https://www.sfr.fr/newsfr/sfr-presse/">Presse<p></p></a><div class="sH"><div><p>SFR Presse</p><p>Du <a href='http://magazine-presse.sfr.fr/catalog/le-figaro'>Figaro</a> à <a href='http://magazine-presse.sfr.fr/catalog/liberation'>Libération</a> en passant par <a href='http://magazine-presse.sfr.fr/catalog/elle'>Elle</a> et <a href='http://magazine-presse.sfr.fr/catalog/paris-match'>Paris Match</a>, retrouvez tous les grands titres de la presse journal et magazine en illimité</p></div><div><div class="Z"><div class="act"><a data-img="-newsfr-presse-v2-" data-hi="@/newsfr/sfr-presse" href="https://www.sfr.fr/newsfr/sfr-presse/""><p>Découvrir SFR Presse</p><p>Vos titres préférés en illimité</p></a></p></div><div><a data-img="-presse-box-" data-hi="@/newsfr/sfr-presse" href="https://www.sfr.fr/offre-internet/box-thd/""><p>Avec nos offres box</p><p>Disponible dès l’offre Starter</p></a></p></div><div><a data-img="-presse-mobile-" data-hi="@/newsfr/sfr-presse" href="https://www.sfr.fr/forfait-mobile/offres/forfait-mobile/""><p>Avec nos offres mobile</p><p>Disponible partout avec vous</p></a></p></div><div><a data-img="-presse-digital-" data-hi="@/newsfr/sfr-presse" href="https://www.sfr.fr/newsfr/sfr-presse/digital.html""><p>Sans engagement</p><p>Abonnez-vous dès maintenant</p></a></p></div><div><a data-img="-presse-liseuse-" data-hi="@/newsfr/sfr-presse" href="http://magazine-presse.sfr.fr""><p>Lisez vos magazines</p><p>Vos magazines sur tous vos écrans</p></a></p></div></div></div></div></li><li data-stat="News"><a data-hi="@/newsfr/sfr-news" href="https://www.sfr.fr/newsfr/sfr-news/">News<p></p></a><div class="sH"><div><p>SFR News</p><p>Profitez d'un nouvel éclairage sur le monde en suivant en direct et en continu toute l'info sportive, économique, locale et les <a href='https://news.sfr.fr/actualites/politique/'>élections présidentielles 2017</a></p></div><div><div class="Z"><div class="act"><a data-img="-newsfr-news-v2-" data-hi="@/newsfr/sfr-news" href="https://www.sfr.fr/newsfr/sfr-news/""><p>Découvrir SFR News</p><p>5 chaines TV</p></a></p></div><div><a data-img="-news-portail-" data-hi="@/newsfr/sfr-news" href="https://www.sfr.fr/portail.html""><p>Portail actualités</p><p>Votre site d’actualités en continu</p></a></p></div><div><a data-img="-sport-actu-" data-hi="@/newsfr/sfr-news" href="https://sport.sfr.fr/""><p>Actualités sports</p><p>L’info sport et résultats en direct</p></a></p></div><div><a data-img="-news-info-" data-hi="@/newsfr/sfr-news" href="https://news.sfr.fr/""><p>Dernières infos</p><p>Actus, cinéma, high-tech, people…</p></a></p></div></div></div></div></li></ul></div>
    <div class="A">
        <a href="https://www.sfr.fr/sfr-et-moi.html"><p>Connexion</p></a>
        <a class="UN"><i class="dn">&#xe806;</i><i class="up">&#xe805;</i><p></p></a>
        <img class="pi U" src="//static.s-sfr.fr/media/HSFR_ec2.png"/>
        <div class="EC" data-stat="EC"><ul><li><a href="https://www.sfr.fr/mon-espace-client/">Mon Espace Client</a></li><li><a href="https://www.sfrcloud.sfr.fr/">Mon Cloud</a></li><li><a href="https://forum.sfr.fr/">Mon Forum</a></li><li><a href="https://www.sfr.fr/portail.html">Mon Portail Actualités</a></li><li><a href="http://tv.sfr.fr/">Ma TV & VOD</a></li><li><a href="https://www.sfr.fr/cas/logout?url=https://www.sfr.fr/"><i class=dc>&#xe809;</i> Déconnexion</a></li></ul></div>
    </div>
    <form class="S" action="https://www.sfr.fr/recherche/mixte" method="get"><input type="text" name="q" maxlength="400"/><input type="submit" value=""/></form>
</div></header>
<script>!function(W,$){if($=W.$sfr||W.$){
var _,f,m=0,o=0,q,fq,$H=$('#eTsH'),EC,swEC,U='',N=0,
    H=function(s){return $H.find(s)},M=H('i.mel'),
    Q=function(s){return s.replace(/~/g,'"')},
    S=function(o,s,i){o.find(s).each(function(s){s=$(this).attr('href')||'';s=s.replace(/[?#&]sfrintid=[^#&]*/,'')+'#sfrintid='+i;$(this).attr('href',s)})};
q=H('[name=q]');q.blur(fq=function(){q[q.val()?'addClass':'removeClass']('q')});
H('.UN').click(swEC=function(){EC=H('i.dn:visible').length;H('i.dn')[EC?'hide':'show']();H('i.up,.EC')[EC?'show':'hide']()});
H('.UN').hover(function(b){if(!EC)swEC()});
H('.EC').mouseleave(function(){if(EC)swEC()});
H('.B').click(function(h){H('.M>.P').toggle()});
$(W).on('load',function(){$H.find('a[data-img]').each(function(i,o){o=$(o);o.append('<img src="//static.s-sfr.fr/media/'+o.data('img').replace(/^-/,'sub-menu-').replace(/-$/,'.jpg')+'"/>')})});
if(f=W.sfrIstConfig)f.isRED=0;
if(_=W._eT){
    _.ckD('ISTRED');
    _.font('SFR-Thin,SFR-Bold,SFR-Regular,sfr-icons:sfr-icons');
    H('.Z>div').hover(function(o){o=$(this);o.parent().find('div').removeClass('act');o.addClass('act')});
    H('.sH').click(function(){$(this).parent().removeClass('ok')});
    H('.P>ul>li').hover(
        function(o){
            if(H('i.up:visible').length){H('i.up,.EC').hide();H('i.dn').show();EC=!1}

            $(o=this).addClass('ok');setTimeout(function(){o.go=1},50)},            
        function(){this.go=0}).click(
        function(e){if(!this.go)e.preventDefault()});
    H('a[data-hi]').each(function(v){if(v=_.M($(this).data('hi'),_.par('U'))){v=v[0].length;if(v>=m){m=v;o=this}}});
    if(o)$(o).addClass('hi').parents('li').find('>a').addClass('hi');
    H('[data-stat]').each(function(o,s){
        o=$(this);s='HH_'+o.data('stat');
        if(o.prop("tagName")=='LI'){S(o,'a:eq(0)',s);S(o,'div>div:eq(0) a',s+'_G');S(o,'div>div:eq(1) a',s+'_D')}
        else S(o,'a',s)});
    setInterval(f=function(i){
        fq();
        if(i=_.ckR('sfrUserInfos')){
            if(H('.A>a:eq(0)>p:visible').length){
                H('.A>a:eq(0),i.up,.EC').hide();
                H('i.dn,.UN').show()}
            if(U!=i)H('.UN>p').html(unescape(U=i));
            i=_.ckR('sfrUserUnreadMessages');
            if(N!=i)M.html(N=i>999?(i/1e3|0)+'k':i)[i>0?'show':'hide']()}
        else{
            H('.A>a:eq(0)').show();
            H('.UN,.EC').hide();
            M.hide()}},333);f()}
}}(window)</script>



<!--MainContent-->


<style type="text/css">
#sfrMentions p {margin-top:10px; font-size:13px;}
#sfrMentions h3 {font-size:15px; margin-top:25px; font-weight:bold;}
#sfrMentions h4 {font-size:14px; margin-top:15px; text-decoration:underline;}
#sfrMentions b {font-weight:bold;}
@media only screen and (max-width: 1024px) {
    #sfrMentions{
        width:100%;
        padding:15px;
    }
}

/* min-width 1025px, large screens */
@media only screen and (min-width: 1025px) {
    #sfrMentions{
        width:984px;
        margin:0 auto;
    }
}
</style>      
 
<div id="sfrMentions">
<br /><br />
<h2 class="mainTitle">Pages Perso - Fermeture</h2>
<br /><br />
<p>Le service de Pages Perso SFR est fermé depuis le 21/11/2016<br /><br />
Les utilisateurs de ce service ont été prévenus par mail de cette fermeture et via des encarts d'information sur les pages de ce service, depuis le mois de mars 2016.<br />
Des fiches d'aide ont été mises à leur disposition pour récupérer le contenu de leurs Pages Perso SFR afin de le recréer sur un autre service de Pages Perso de leur choix.
<br / ><br />
Depuis le 21/11/2016, date de fermeture du service, il n'est plus possible d'accéder aux Pages Perso SFR créées, ni aux interfaces de gestion et de publication de ce service.
</p>
<br/><br/>
<br/><br/>
</div>

<!--Footer-->

<!-- footer -->
<style>
#eTsF,#eTsF *{text-align:center;vertical-align:top;margin:0;padding:0;box-sizing:border-box;background:transparent;color:inherit;font-family:inherit;font-size:inherit}
#eTsF{clear:both;background:#3d3f3f;color:#fff;font:16px "SFR-Light",Arial;position:relative}
#eTsF h3{margin:30px 0 15px;text-transform:uppercase;font-weight:normal;font:18px "SFR-Regular",Arial}
#eTsF a{text-decoration:none;cursor:pointer;transition:color 200ms ease-out}
#eTsFd a:hover{border-bottom: 1px dotted #fff}
#eTsFs,#eTsFd{width:96%;max-width:968px;margin:0 auto}
#eTsFs{border-bottom:1px solid #c7c8ca}
#eTsFs *{display:inline-block}
#eTsFs img{height:45px}
#eTsFs>a{margin:20px;font-size:12px}
#eTsFs>a span{padding:15px 8px;font:12px "SFR-Bold",Arial}
#eTsFs>h3{line-height:30px;font-size:20px;float:left}
#eTsFd{text-align:justify}
#eTsFd>div{display:inline-block}
#eTsFd>div *{text-align:left}
#eTsFd>div.F{width:100%;color:#cfcfd7;font-size:12px;text-align:justify;margin-top:20px;border-top:1px solid #c7c8ca;padding:9px 0}
#eTsFd>div.F>p{display:inline-block;font:12px "SFR-Bold",Arial;height:27px;line-height:27px}
#eTsFd>div.F>p:first-child{padding-left:37px;background:url(//static.s-sfr.fr/media/logo_h_2x.png) top left no-repeat;background-size:27px 27px;font-family:'SFR-Regular',Arial}
#eTsFd>div.F>p:last-child{height:0;width:99%}
#eTsFd ul{list-style-type:none}
#eTsFd li{margin:5px 0}
#eTsFd li a{font:12px "SFR-Regular",Arial}
#eTsFm{display:none;margin:20px auto 0;max-width:560px;text-align:justify}
#eTsFm>div{display:inline-block;max-width:49%}
#eTsFm h3{display:block;margin:0;padding:9px;text-align:left;color:#fff}
#eTsFm>p{display:inline-block;width:99%;text-align:center;color:#fff;font-size:13px;padding:20px 9px}
@media only screen and (max-width:1024px){#eTsFd{display:none}#eTsFm{display:block}#eTsFs h3{display:none}}
@media only screen and (max-width:767px){#eTsFs>a{margin:16px 0;width:22%}#eTsFs>a span{display:none}#eTsFs img{height:30px}#eTsFm h3{font-size:14px}}
</style>
<footer id="eTsF"><div id="eTsFs">
    <h3>REJOIGNEZ-NOUS</h3>
    <a href="https://fr-fr.facebook.com/SFR" target="_blank"><img src="//static.s-sfr.fr/media/facebook_h.png" class="social-icon" alt="Facebook"/><span>Facebook</span></a>
    <a href="https://twitter.com/SFR" target="_blank"><img src="//static.s-sfr.fr/media/twitter_h.png" class="social-icon" alt="Twitter"/><span>Twitter</span></a>
    <a href="https://www.youtube.com/channel/UCmOWXd_I8xsFRViDcQBNolA" target="_blank"><img src="//static.s-sfr.fr/media/youtube_h.png" class="social-icon" alt="YouTube"/><span>Youtube</span></a>

    <a href="https://forum.sfr.fr/#sfrintid=V_footer_contact-forum" target="_blank"><img src="//static.s-sfr.fr/media/forum_h.png" class="social-icon" alt="Forum SFR"/><span>Forum SFR</span></a>
</div><div id="eTsFd">
    <div>
        <a href="https://www.sfr.fr/#sfrintid=V_footer_bol"><h3>BOUTIQUE</h3></a>
        <ul>
            <li><a href="https://www.sfr.fr/offre-internet/box-thd/#sfrintid=V_footer_bol_offres-box">Offres Box Internet et Fibre</a></li>
            <li><a href="https://www.sfr.fr/forfait-mobile/offres/forfait-mobile#sfrintid=V_footer_bol_forfaits-mob">Forfaits mobile</a> | <a href="https://www.sfr.fr/telephonie-mobile/sfr-la-carte.html#sfrintid=V_footer_bol_cartes-prepayees">Cartes prépayées</a></li>
            <li><a href="http://odr.sfr.fr/offres-remboursement/#sfrintid=V_footer_bol_odr">Offres de remboursement</a></li>
            <li><a href="https://www.sfr.fr/bons-plans/#sfrintid=V_footer_bol_bons-plans">Bons plans</a> | <a href="https://accessoires.sfr.fr/#sfrintid=V_footer_bol_acc">Accessoires</a></li>
            <li><a href="https://www.sfr.fr/telephonie-mobile/tarifs-conditions.html#sfrintid=V_footer_bol_tarifs">Tarifs</a> | <a href="https://www.sfr.fr/sfr-et-moi/vos-services-sfr/international/#sfrintid=V_footer_bol_inter">International </a></li>
            <li><a href="https://www.sfr.fr/telephonie-mobile/reprise-occasion.html#sfrintid=V_footer_bol_reprise-mob">Reprise mobile</a> | <a href="https://www.sfr.fr/telephonie-mobile/assurance-mobile.html#sfrintid=V_footer_bol_assurances">Assurances</a></li>
        </ul>
    </div>
    <div>
        <a href="https://www.sfr.fr/sfr-et-moi.html#sfrintid=V_footer_ec"><h3>ESPACE CLIENT</h3></a>
        <ul>
            <li><a href="https://www.sfr.fr/suivi-commande/#sfrintid=V_footer_ec_suivi-commande">Suivre ma commande</a></li>
            <li><a href="https://www.sfr.fr/mobile/ma-commande/suivre-ma-commande/login#sfrintid=_footer_ec_activer-ligne">Activer ma ligne</a></li>
            <li><a href="https://www.sfr.fr/reseau-tres-haut-debit/4g-mobile.html#sfrintid=V_footer_ec_reseau-mobile">Couverture réseau mobile</a></li>
            <li><a href="https://www.sfr.fr/reseau-tres-haut-debit/fibre.html#sfrintid=V_footer_ec_reseau-fibre-thd">Couverture réseau Fibre et THD</a></li>
            <li><a href="https://www.sfr.fr/sfr-et-moi/vos-services-sfr.html#sfrintid=V_footer_ec_vos-services-quotidien">Services au quotidien</a></li>
            <li><a href="https://www.sfr.fr/portail.html#sfrintid=V_footer_ec_portail">Portail SFR</a> | <a href="http://tv.sfr.fr/epg/maintenant/#sfrintid=P_nav_tvepg">Guide TV</a></li>
        </ul>
    </div>
    <div>
        <a href="https://assistance.sfr.fr/#sfrintid=V_footer_ass"><h3>ASSISTANCE</h3></a>
        <ul>
            <li><a href="https://www.sfr.fr/procedures-urgence/actes-urgences.html#sfrintid=V_footer_ec_urgence-depannage">Urgences et dépannage</a></li>
            <li><a href="https://assistance.sfr.fr/mobile-et-tablette/offres-mobile/vol-perte-mobile.html#sfrintid=V_footer_ass_mob-perdu-vole">Mobile perdu ou volé ?</a></li>
            <li><a href="https://www.sfr.fr/parcours-securite/password/oubliMotDePasse/identifiant.action#sfrintid=V_footer_ass_oubli-mot-de-passe">Mot de passe oublié</a></li>
            <li><a href="https://www.sfr.fr/box-internet/internet/informations-technologie-acces-internet-fixe.html#sfrintid=V_footer_ass_comprendre-fibre">Comprendre la fibre</a></li>
            <li><a href="https://assistance.sfr.fr/form/incidents/reseau/fixe/get.html#sfrintid=V_footer_ass_etat-reseau-fixe">L’état du réseau fixe</a></li>
            <li><a href="https://assistance.sfr.fr/form/incidents/reseau/mobile/get.html#sfrintid=V_footer_ass_etat-reseau&sfrclicid=V_footer_ass_etat-reseau">L'état du réseau mobile</a></li>
        </ul>
    </div>
    <div>
        <a href="https://assistance.sfr.fr/contacter/accueil/contact-accueil/fc-3269-72681#sfrintid=V_footer_contact"><h3>CONTACTS</h3></a>
        <ul>
            <li><a href="https://boutique.sfr.fr/#sfrintid=V_footer_contact_magasins">Trouver une boutique</a></li>
            <li><a href="https://www.sfr.fr/service-client-1099.html#sfrintid=V_footer_contact_1099">Commander au 1099</a></li>
            <li><a href="https://assistance.sfr.fr/contacter/#sfrintid=V_footer_contact_nous-contacter">Service client</a> | <a href="https://www.sfr.fr/handicap/#sfrintid=V_footer_contact_handicap">Handicap</a></li>
            <li><a href="https://forum.sfr.fr/#sfrintid=V_footer_contact_commu-sfr">Communauté SFR</a></li>
            <li><a href="https://www.sfr.fr/faq.html#sfrintid=V_footer_questions-frequentes">Questions fréquentes</a></li>
            <li><a href="https://www.sfr.fr/sfr-et-moi/vos-applis-sfr.html#sfrintid=V_footer_contact_applis-sfr">Applications mobile SFR</a></li>
        </ul>
    </div>
    <div class="F">
        <p><a href="https://www.sfr.fr/#sfrintid=V_footer_logo-sfr">© 2017 SFR</a></p>
        <p><a href="https://www.sfr.fr/mentions-legales.html#sfrintid=V_footer_info-legale">Informations légales</a></p>
        <p><a href="https://www.sfr.fr/plan-du-site.html#sfrintid=V_footer_plan-site">Plan du site</a></p>
        <p><a href="https://assistance.sfr.fr/internet-et-box/securite/se-proteger-du-phishing.html#sfrintid=V_footer_phishing">Phishing</a></p>
        <p><a onclick="window._eT&&_eT.CkML&&_eT.CkML()">Cookies</a></p>
        <p><a href="http://signalement.fftelecoms.org/" target="_blank">Signaler un contenu illicite</a></p>
        <p><a href="http://www.sfr.com/#sfrintid=V_footer_groupe_nc-sfr" target="_blank">Groupe SFR</a></p>
        <p></p>
    </div>
</div>
<div id="eTsFm">
    <div>
        <h3><a href="https://www.sfr.fr/forfait-mobile/offres/forfait-mobile#sfrintid=V_footer_mob_forfaits">FORFAITS MOBILE</a></h3>
        <h3><a href="https://www.sfr.fr/offre-internet/box-thd/#sfrintid=V_footer_box_accueil-box">INTERNET ET FiBRE</a></h3>
        <h3><a href="https://www.sfr.fr/bons-plans/#sfrintid=V_footer_bol_bons-plans">BONS PLANS</a></h3>
    </div>
    <div>
        <h3><a href="https://www.sfr.fr/portail.html#sfrintid=V_footer_portail">Portail SFR</a></h3>
        <h3><a href="https://assistance.sfr.fr/#sfrintid=V_footer_assistance">ASSISTANCE</a></h3>
        <h3><a href="https://assistance.sfr.fr/contacter/#sfrintid=V_footer_contact_nous-contacter">NOUS CONTACTER</a></h3>
    </div>
    <p>© 2017 SFR - Tous droits réservés</p>
</div></footer>
<script>!function(_){if(_)with(_){_.font('SFR-Regular,SFR-Light,SFR-Bold');$(window).scroll(function(){$('#eTsF').css('left',$(this).scrollLeft())})}}(window._eT)</script>



<!--Scripts-->

<script>$RN('document').ready(function(){$RN.fn.initMainView()})</script>
<script src="//static.s-sfr.fr/stats/footer.js" charset="UTF-8"></script>
</body></html>
