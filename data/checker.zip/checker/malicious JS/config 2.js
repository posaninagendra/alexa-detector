var fan_page_url='https://www.facebook.com/rao247com';
var opacity=0;var time=60000;