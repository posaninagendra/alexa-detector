<!DOCTYPE HTML >
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:vtex="http://www.vtex.com.br/2009/vtex-common" xmlns:vtex.cmc="http://www.vtex.com.br/2009/vtex-commerce">
  <head><meta name="language" content="pt-BR" />
<meta name="country" content="BRA" />
<meta name="currency" content="R$" />
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<meta name="description" content="Moda feminina online é na Aquamar. Sempre com tendências e novidades para diversos gostos. Você não pode perder, confira!" />
<meta name="Abstract" content="Moda Feminina Online 2016 | Aquamar" />
<meta name="author" content="Aquamar" />
<meta name="copyright" content="Aquamar" />
<meta name="vtex-version" content="1.4.710.1275" />
<meta http-equiv="pragma" content="no-cache" />
<meta name="google-site-verification" content="TCXGM6Ci16B0yww-UIN9qTR7Sk1pgCyrPIMkdDxj_pI" /><meta name="google-site-verification" content="3AdKVR9hfKZAZ7skSZkZuOzdYLGI0iO0DaUC-16xW9o" /><meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" /><link rel="apple-touch-icon" sizes="57x57" href="//aquamar.vteximg.com.br/arquivos/apple-icon-57x57.png" /><link rel="apple-touch-icon" sizes="60x60" href="//aquamar.vteximg.com.br/arquivos/apple-icon-60x60.png" /><link rel="apple-touch-icon" sizes="72x72" href="//aquamar.vteximg.com.br/arquivos/apple-icon-72x72.png" /><link rel="apple-touch-icon" sizes="76x76" href="//aquamar.vteximg.com.br/arquivos/apple-icon-76x76.png" /><link rel="apple-touch-icon" sizes="114x114" href="//aquamar.vteximg.com.br/arquivos/apple-icon-114x114.png" /><link rel="apple-touch-icon" sizes="120x120" href="//aquamar.vteximg.com.br/arquivos/apple-icon-120x120.png" /><link rel="apple-touch-icon" sizes="144x144" href="//aquamar.vteximg.com.br/arquivos/apple-icon-144x144.png" /><link rel="apple-touch-icon" sizes="152x152" href="//aquamar.vteximg.com.br/arquivos/apple-icon-152x152.png" /><link rel="apple-touch-icon" sizes="180x180" href="//aquamar.vteximg.com.br/arquivos/apple-icon-180x180.png" /><link rel="icon" type="image/png" sizes="192x192" href="//aquamar.vteximg.com.br/arquivos/android-icon-192x192.png" /><link rel="icon" type="image/png" sizes="32x32" href="//aquamar.vteximg.com.br/arquivos/favicon-32x32.png" /><link rel="icon" type="image/png" sizes="96x96" href="//aquamar.vteximg.com.br/arquivos/favicon-96x96.png" /><link rel="icon" type="image/png" sizes="16x16" href="//aquamar.vteximg.com.br/arquivos/favicon-16x16.png" /><link rel="manifest" href="//aquamar.vteximg.com.br/arquivos/manifest.js" /><meta name="msapplication-TileColor" content="#ffffff" /><meta name="msapplication-TileImage" content="//aquamar.vteximg.com.br/arquivos/ms-icon-144x144.png" /><meta name="theme-color" content="#ffffff" /><title>Moda Feminina Online | Aquamar</title><script type="text/javascript" language="javascript">var jscheckoutUrl = 'https://www.eaquamar.com.br/checkout/#/cart';var jscheckoutAddUrl = 'https://www.eaquamar.com.br/checkout/cart/add';var jscheckoutGiftListId = '';var jsnomeSite = 'aquamar';var jsnomeLoja = 'aquamar';var jssalesChannel = '1';var defaultStoreCurrency = 'R$';var localeInfo = {"CountryCode":"BRA","CultureCode":"pt-BR","CurrencyLocale":{"RegionDisplayName":"Brazil","RegionName":"BR","RegionNativeName":"Brasil","TwoLetterIsoRegionName":"BR","CurrencyEnglishName":"Real","CurrencyNativeName":"Real","CurrencySymbol":"R$","ISOCurrencySymbol":"BRL","Locale":1046,"Format":{"CurrencyDecimalDigits":2,"CurrencyDecimalSeparator":",","CurrencyGroupSeparator":".","CurrencyGroupSize":3,"StartsWithCurrencySymbol":true},"FlagUrl":"http://www.geonames.org/flags/x/br.gif"}};</script> 
<script type="text/javascript" language="javascript">vtxctx = {searchTerm:"",isOrder:"0",isCheck:"0",isCart:"0",actionType:"",actionValue:"",login:"",url:"www.eaquamar.com.br",transurl:"www.eaquamar.com.br"};</script> 
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/mobile/mdetect.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/mobile/mdetect2.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://io.vtex.com.br/front-libs/jquery/1.8.3/jquery-1.8.3.min.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://ajax.googleapis.com/ajax/libs/swfobject/2.2/swfobject.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/vtex.ajax.wait.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/vtex.common.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://io.vtex.com.br/front-libs/front-i18n/0.4.1/vtex-i18n.min.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://io.vtex.com.br/front-libs/front-utils/1.0.1/vtex-utils.min.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://io.vtex.com.br/front-libs/dustjs-linkedin/2.3.5/dust-core-2.3.5.min.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://dmx56ht1p4edz.cloudfront.net/rc.js?an=aquamar?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/vtex.tagmanager.helper.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://io.vtex.com.br/portal-ui/1.7.2/scripts/vtex-events-all.min.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://io.vtex.com.br/portal-ui/1.7.2/scripts/vtex-analytics.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://io.vtex.com.br/vtex.js/2.7.0/vtex.min.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://io.vtex.com.br/portal-plugins/2.9.13/js/portal-template-as-modal.min.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://io.vtex.com.br/portal-plugins/2.9.13/js/portal-sku-selector-with-template.min.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/vtex.cookie.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/jquery.pager.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/vtex.viewPart.newsletter.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/jquery.ui.core.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/autocomplete/jquery.ui.widget.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/autocomplete/jquery.ui.position.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/autocomplete/jquery.ui.autocomplete.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/vtex.commerce.search.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/vtex.viewPart.fullTextSearchBox.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://io.vtex.com.br/portal-plugins/2.9.13/js/portal-minicart-with-template.min.js?v=1.4.710.1275"  type="text/javascript"></script>
<link href="//aquamar.vteximg.com.br/arquivos/2016-aquamar.css" rel="stylesheet" type="text/css" media="all" /><script language="javascript">var ___scriptPathTransac = '';</script><script language="javascript">var ___scriptPath = '';</script><link rel="canonical" href="http://www.eaquamar.com.br/" /></head>
  <body class="home">
<!-- Start - WebAnalyticsViewPart -->
<script> var defaultUtmFromFolder = '';</script>
<!-- CommerceContext.Current.VirtualFolder.Name: / -->

<script>
vtex.events.addData({"pageCategory":"Home","pageDepartment":null,"pageUrl":"http://www.eaquamar.com.br/","pageTitle":"Moda Feminina Online | Aquamar","skuStockOutFromShelf":["2025691","2025694","2025688","2025674","2025643","2025626","2025631","2025614","2025532","2025537","2025540","533504","535437","535439","532995","532996","532997","533001","534254","534256","534259","532791","533031","532133","532134","532135","532136","532138","530608","530609","530610","530611","530613","531364","531119","531120","531121","531122","531123","531124","531126","531128","531129","531130","531131","531132","531133","531134","531135","531136","523210","523211","523212","523213","523215","533162","529037","533004","533006","529390","529391","529393","529395","528286","528287","528288","528289","528290","528291","528292","528294","531194","531195","531196","531197","531200","531201","532277","532278","532279","2025325","2025328","533187","532890","532891","532895","2024343","2024346","2024349","2024352","535476","535479","535482","535483","535484","534167","534170","534171","534172","534173","534175","533530","533533","535055","535058","534583","534586","532399","532400","532403","534580"],"skuStockOutFromProductDetail":[],"shelfProductIds":["2000149","2000148","2000147","2000146","2000145","2000143","2000142","2000141","2000140","2000139","2000138","2000132","2000130","2000127","2000120","2000119","513519","513326","513607","513509","513240","513425","513207","513246","513279","513614","513120","2000074","513272","513559","513412","513603","512926","513016","511952","512479","512996","511247","513219","513270","512556","512441","513241","512677","512301","513215","513003","2000095","513623","2000044","513277","513226","2000048","513615","513413","2000121","513330","513541","2000085","513482","513153","2000036","513481"],"accountName":"aquamar","pageFacets":[]});
</script>

<script>
(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
                            new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
                            j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
                            '//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
                            })(window,document,'script','dataLayer','GTM-K5QW9C');
</script>

<script>
var helper = new vtexTagManagerHelper('homeView'); helper.init();
</script>

<!-- End - WebAnalyticsViewPart -->
<div class="ajax-content-loader" rel="/no-cache/callcenter/disclaimer"></div><!-- topo --><div class="page-face"><div id="fb-root"></div><script src="//aquamar.vteximg.com.br/arquivos/2016-facebook.js" type="text/javascript"></script></div><div class="spacerHeader"></div><!-- topo --><!-- Carrossel --><nav class="linha cycle-slideshow" data-cycle-slides="a" data-cycle-fx="scrollHorz" data-cycle-timeout="6000" data-cycle-speed="2000"><div class="cycle-pager"></div><div class="box-banner"><a href="/new-collection-inverno-2017"><img width="1980" height="622" id="ihttp://aquamar.vteximg.com.br/arquivos/ids/203424/banner_TV_preview_inerno__2017___1.jpg" alt="New Collection Inverno 2017" src="http://aquamar.vteximg.com.br/arquivos/ids/203424/banner_TV_preview_inerno__2017___1.jpg" complete="complete"/></a></div></nav><!-- /Carrossel --><!-- Linha banner 1 --><nav class="linha banner-produto"><div class="box-banner"><a href="/new-collection-inverno-2017"><img width="563" height="499" id="ihttp://aquamar.vteximg.com.br/arquivos/ids/203434/banner_triplo_1.jpg" alt="Banner pequeno 1" src="http://aquamar.vteximg.com.br/arquivos/ids/203434/banner_triplo_1.jpg" complete="complete"/></a></div><div class="box-banner"><a href="/new-collection-inverno-2017"><img width="563" height="499" id="ihttp://aquamar.vteximg.com.br/arquivos/ids/203463/banner_triplo_2Marc.jpg" alt="Banner pequeno 2" src="http://aquamar.vteximg.com.br/arquivos/ids/203463/banner_triplo_2Marc.jpg" complete="complete"/></a></div><div class="box-banner"><a href="/nowlink"><img width="831" height="496" id="ihttp://aquamar.vteximg.com.br/arquivos/ids/203176/BANNER_TRIPLO_3.jpg" alt="Banner pequeno 3" src="http://aquamar.vteximg.com.br/arquivos/ids/203176/BANNER_TRIPLO_3.jpg" complete="complete"/></a></div></nav><!-- /Linha banner 1 --><!-- Vitrines --><div class="cycle-pager-vitrine linha pad center"></div><div class="linha pad cycle-slideshow" data-cycle-slides="article.ofertas" data-cycle-fx="fade" data-cycle-timeout="0" data-cycle-speed="2000" data-cycle-pager=".cycle-pager-vitrine"><article class="ofertas"><div class="vitrine n4colunas"><h2>Novidades</h2>
<ul><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="sapatos-femininos-|-aquamar">
<article class="2000149" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Sapatos / Salto Alto"> Sapatos / Salto Alto</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content="Sandália Verniz"></span>
        </div>
        <a class="productImage" title="Sand&#225;lia Verniz" href="http://www.eaquamar.com.br/sandalia-verniz-13-04-0402/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/207775-320-480/13.04.0402_0002_1.jpg" width="320" height="480" alt="13.04.0402_0002_1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-inverno">roupas-moda-inverno</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Sand&#225;lia Verniz" href="http://www.eaquamar.com.br/sandalia-verniz-13-04-0402/p">
                <span itemprop="name"> Sandália Verniz</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Sand&#225;lia Verniz" href="http://www.eaquamar.com.br/sandalia-verniz-13-04-0402/p">
                    <span itemprop="itemOffered"> Sandália Verniz</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Sapatos / Salto Alto"> Sapatos / Salto Alto</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content="Sandália Verniz"></span>
                <span itemprop="sku" >2000149</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 49,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.2000149');
        console.log('id do produto atual = ' + id);
        var altV = "Sand&#225;lia Verniz";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_2000149" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="sapatos-femininos-|-aquamar">
<article class="2000148" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Sapatos / Oxford"> Sapatos / Oxford</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content="Oxford Laminado"></span>
        </div>
        <a class="productImage" title="Oxford Laminado" href="http://www.eaquamar.com.br/oxford-laminado-13-05-0029/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/207852-320-480/13.05.0029_0012_1.jpg" width="320" height="480" alt="13.05.0029_0012_1" id="" />
            <div class="bandeirolas">
                
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Oxford Laminado" href="http://www.eaquamar.com.br/oxford-laminado-13-05-0029/p">
                <span itemprop="name"> Oxford Laminado</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Oxford Laminado" href="http://www.eaquamar.com.br/oxford-laminado-13-05-0029/p">
                    <span itemprop="itemOffered"> Oxford Laminado</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Sapatos / Oxford"> Sapatos / Oxford</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content="Oxford Laminado"></span>
                <span itemprop="sku" >2000148</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 89,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.2000148');
        console.log('id do produto atual = ' + id);
        var altV = "Oxford Laminado";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_2000148" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="sapatos-femininos-|-aquamar">
<article class="2000147" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Sapatos / Bota"> Sapatos / Bota</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content="Coturno Couro"></span>
        </div>
        <a class="productImage" title="Coturno Couro" href="http://www.eaquamar.com.br/coturno-couro-13-07-0159/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/208060-320-480/13.07.0159_0008_1.jpg" width="320" height="480" alt="13.07.0159_0008_1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-inverno">roupas-moda-inverno</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Coturno Couro" href="http://www.eaquamar.com.br/coturno-couro-13-07-0159/p">
                <span itemprop="name"> Coturno Couro</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Coturno Couro" href="http://www.eaquamar.com.br/coturno-couro-13-07-0159/p">
                    <span itemprop="itemOffered"> Coturno Couro</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Sapatos / Bota"> Sapatos / Bota</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content="Coturno Couro"></span>
                <span itemprop="sku" >2000147</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 99,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.2000147');
        console.log('id do produto atual = ' + id);
        var altV = "Coturno Couro";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_2000147" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="sapatos-femininos-|-aquamar last">
<article class="2000146" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Sapatos / Sapatilha"> Sapatos / Sapatilha</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content="Sapatilha Metalizado Prata"></span>
        </div>
        <a class="productImage" title="Sapatilha Metalizado Prata" href="http://www.eaquamar.com.br/sapatilha-metalizado-prata-13-06-0453/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/207978-320-480/13.06.0453_0012_1.jpg" width="320" height="480" alt="13.06.0453_0012_1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-inverno">roupas-moda-inverno</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Sapatilha Metalizado Prata" href="http://www.eaquamar.com.br/sapatilha-metalizado-prata-13-06-0453/p">
                <span itemprop="name"> Sapatilha Metalizado Prata</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Sapatilha Metalizado Prata" href="http://www.eaquamar.com.br/sapatilha-metalizado-prata-13-06-0453/p">
                    <span itemprop="itemOffered"> Sapatilha Metalizado Prata</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Sapatos / Sapatilha"> Sapatos / Sapatilha</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content="Sapatilha Metalizado Prata"></span>
                <span itemprop="sku" >2000146</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 79,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.2000146');
        console.log('id do produto atual = ' + id);
        var altV = "Sapatilha Metalizado Prata";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_2000146" style="display:none" class="helperComplement"></li></ul><ul><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="sapatos-femininos-|-aquamar">
<article class="2000145" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Sapatos / Tênis"> Sapatos / Tênis</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content="Sapatênis Verniz Flat"></span>
        </div>
        <a class="productImage" title="Sapat&#234;nis Verniz Flat" href="http://www.eaquamar.com.br/sapatenis-verniz-flat-13-05-0066/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/207954-320-480/13.05.0066_0002_1.jpg" width="320" height="480" alt="13.05.0066_0002_1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-inverno">roupas-moda-inverno</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Sapat&#234;nis Verniz Flat" href="http://www.eaquamar.com.br/sapatenis-verniz-flat-13-05-0066/p">
                <span itemprop="name"> Sapatênis Verniz Flat</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Sapat&#234;nis Verniz Flat" href="http://www.eaquamar.com.br/sapatenis-verniz-flat-13-05-0066/p">
                    <span itemprop="itemOffered"> Sapatênis Verniz Flat</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Sapatos / Tênis"> Sapatos / Tênis</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content="Sapatênis Verniz Flat"></span>
                <span itemprop="sku" >2000145</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 109,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.2000145');
        console.log('id do produto atual = ' + id);
        var altV = "Sapat&#234;nis Verniz Flat";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_2000145" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="sapatos-femininos-|-aquamar">
<article class="2000143" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Sapatos / Oxford"> Sapatos / Oxford</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content="Oxford Black"></span>
        </div>
        <a class="productImage" title="Oxford Black" href="http://www.eaquamar.com.br/oxford-black-13-05-0032/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/207900-320-480/13.05.0032_0002_1.jpg" width="320" height="480" alt="13.05.0032_0002_1" id="" />
            <div class="bandeirolas">
                
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Oxford Black" href="http://www.eaquamar.com.br/oxford-black-13-05-0032/p">
                <span itemprop="name"> Oxford Black</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Oxford Black" href="http://www.eaquamar.com.br/oxford-black-13-05-0032/p">
                    <span itemprop="itemOffered"> Oxford Black</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Sapatos / Oxford"> Sapatos / Oxford</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content="Oxford Black"></span>
                <span itemprop="sku" >2000143</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 89,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.2000143');
        console.log('id do produto atual = ' + id);
        var altV = "Oxford Black";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_2000143" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="sapatos-femininos-|-aquamar">
<article class="2000142" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Sapatos / Salto Médio"> Sapatos / Salto Médio</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content="Salto Médio Velvet"></span>
        </div>
        <a class="productImage" title="Salto M&#233;dio Velvet" href="http://www.eaquamar.com.br/salto-medio-velvet-13-04-0422/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/207804-320-480/13.04.0422_0002_1.jpg" width="320" height="480" alt="13.04.0422_0002_1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-inverno">roupas-moda-inverno</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Salto M&#233;dio Velvet" href="http://www.eaquamar.com.br/salto-medio-velvet-13-04-0422/p">
                <span itemprop="name"> Salto Médio Velvet</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Salto M&#233;dio Velvet" href="http://www.eaquamar.com.br/salto-medio-velvet-13-04-0422/p">
                    <span itemprop="itemOffered"> Salto Médio Velvet</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Sapatos / Salto Médio"> Sapatos / Salto Médio</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content="Salto Médio Velvet"></span>
                <span itemprop="sku" >2000142</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 99,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.2000142');
        console.log('id do produto atual = ' + id);
        var altV = "Salto M&#233;dio Velvet";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_2000142" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="sapatos-femininos-|-aquamar last">
<article class="2000141" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Sapatos / Salto Alto"> Sapatos / Salto Alto</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content="Salto Alto Velvet"></span>
        </div>
        <a class="productImage" title="Salto Alto Velvet" href="http://www.eaquamar.com.br/salto-alto-velvet-13-04-0421/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/207757-320-480/13.04.0421_0003_1.jpg" width="320" height="480" alt="13.04.0421_0003_1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-inverno">roupas-moda-inverno</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Salto Alto Velvet" href="http://www.eaquamar.com.br/salto-alto-velvet-13-04-0421/p">
                <span itemprop="name"> Salto Alto Velvet</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Salto Alto Velvet" href="http://www.eaquamar.com.br/salto-alto-velvet-13-04-0421/p">
                    <span itemprop="itemOffered"> Salto Alto Velvet</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Sapatos / Salto Alto"> Sapatos / Salto Alto</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content="Salto Alto Velvet"></span>
                <span itemprop="sku" >2000141</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 99,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.2000141');
        console.log('id do produto atual = ' + id);
        var altV = "Salto Alto Velvet";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_2000141" style="display:none" class="helperComplement"></li></ul><ul><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="sapatos-femininos-|-aquamar">
<article class="2000140" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Sapatos / Salto Alto"> Sapatos / Salto Alto</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content="Scarpin Salto Grosso"></span>
        </div>
        <a class="productImage" title="Scarpin Salto Grosso" href="http://www.eaquamar.com.br/scarpin-salto-grosso-13-04-0417/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/207709-320-480/13.04.0417_0026_1.jpg" width="320" height="480" alt="13.04.0417_0026_1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-inverno">roupas-moda-inverno</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Scarpin Salto Grosso" href="http://www.eaquamar.com.br/scarpin-salto-grosso-13-04-0417/p">
                <span itemprop="name"> Scarpin Salto Grosso</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Scarpin Salto Grosso" href="http://www.eaquamar.com.br/scarpin-salto-grosso-13-04-0417/p">
                    <span itemprop="itemOffered"> Scarpin Salto Grosso</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Sapatos / Salto Alto"> Sapatos / Salto Alto</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content="Scarpin Salto Grosso"></span>
                <span itemprop="sku" >2000140</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 59,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.2000140');
        console.log('id do produto atual = ' + id);
        var altV = "Scarpin Salto Grosso";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_2000140" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="sapatos-femininos-|-aquamar">
<article class="2000139" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Sapatos / Rasteira"> Sapatos / Rasteira</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content="Rasteira Slide"></span>
        </div>
        <a class="productImage" title="Rasteira Slide" href="http://www.eaquamar.com.br/rasteira-slide-13-03-0365/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/207660-320-480/13.03.0365_0012_1.jpg" width="320" height="480" alt="13.03.0365_0012_1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Rasteira Slide" href="http://www.eaquamar.com.br/rasteira-slide-13-03-0365/p">
                <span itemprop="name"> Rasteira Slide</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Rasteira Slide" href="http://www.eaquamar.com.br/rasteira-slide-13-03-0365/p">
                    <span itemprop="itemOffered"> Rasteira Slide</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Sapatos / Rasteira"> Sapatos / Rasteira</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content="Rasteira Slide"></span>
                <span itemprop="sku" >2000139</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 79,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.2000139');
        console.log('id do produto atual = ' + id);
        var altV = "Rasteira Slide";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_2000139" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="macacao-feminino-|-aquamar">
<article class="2000138" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Macacão / Longo"> Macacão / Longo</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content="Macacão Pantacourt Lis"></span>
        </div>
        <a class="productImage" title="Macac&#227;o Pantacourt Lis" href="http://www.eaquamar.com.br/macacao-pantacourt-lis-07-06-0006/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/207485-320-480/07.06.0006_0034_1.jpg" width="320" height="480" alt="07.06.0006_0034_1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Macac&#227;o Pantacourt Lis" href="http://www.eaquamar.com.br/macacao-pantacourt-lis-07-06-0006/p">
                <span itemprop="name"> Macacão Pantacourt Lis</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Macac&#227;o Pantacourt Lis" href="http://www.eaquamar.com.br/macacao-pantacourt-lis-07-06-0006/p">
                    <span itemprop="itemOffered"> Macacão Pantacourt Lis</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Macacão / Longo"> Macacão / Longo</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content="Macacão Pantacourt Lis"></span>
                <span itemprop="sku" >2000138</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 119,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.2000138');
        console.log('id do produto atual = ' + id);
        var altV = "Macac&#227;o Pantacourt Lis";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_2000138" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="casacos-femininos-|-aquamar last">
<article class="2000132" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Casaco / Blazer"> Casaco / Blazer</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content="Blazer"></span>
        </div>
        <a class="productImage" title="Blazer" href="http://www.eaquamar.com.br/blazer-08-06-0157/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/207582-320-480/08.06.0157_0002_1.jpg" width="320" height="480" alt="08.06.0157_0002_1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-inverno">roupas-moda-inverno</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Blazer" href="http://www.eaquamar.com.br/blazer-08-06-0157/p">
                <span itemprop="name"> Blazer</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Blazer" href="http://www.eaquamar.com.br/blazer-08-06-0157/p">
                    <span itemprop="itemOffered"> Blazer</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Casaco / Blazer"> Casaco / Blazer</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content="Blazer"></span>
                <span itemprop="sku" >2000132</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 129,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.2000132');
        console.log('id do produto atual = ' + id);
        var altV = "Blazer";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_2000132" style="display:none" class="helperComplement"></li></ul><ul><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="casacos-femininos-|-aquamar">
<article class="2000130" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Casaco / Jaqueta"> Casaco / Jaqueta</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content="Jaqueta Couro Zíper"></span>
        </div>
        <a class="productImage" title="Jaqueta Couro Z&#237;per" href="http://www.eaquamar.com.br/jaqueta-couro-ziper-08-01-0271/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/207303-320-480/08.01.0271_0008_1.jpg" width="320" height="480" alt="08.01.0271_0008_1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-inverno">roupas-moda-inverno</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Jaqueta Couro Z&#237;per" href="http://www.eaquamar.com.br/jaqueta-couro-ziper-08-01-0271/p">
                <span itemprop="name"> Jaqueta Couro Zíper</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Jaqueta Couro Z&#237;per" href="http://www.eaquamar.com.br/jaqueta-couro-ziper-08-01-0271/p">
                    <span itemprop="itemOffered"> Jaqueta Couro Zíper</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Casaco / Jaqueta"> Casaco / Jaqueta</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content="Jaqueta Couro Zíper"></span>
                <span itemprop="sku" >2000130</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 239,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.2000130');
        console.log('id do produto atual = ' + id);
        var altV = "Jaqueta Couro Z&#237;per";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_2000130" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="casacos-femininos-|-aquamar">
<article class="2000127" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Casaco / Blazer"> Casaco / Blazer</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content="Blazer Clássico"></span>
        </div>
        <a class="productImage" title="Blazer Cl&#225;ssico" href="http://www.eaquamar.com.br/blazer-classico-08-06-0159/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/207513-320-480/08.06.0159_0001_1.jpg" width="320" height="480" alt="08.06.0159_0001_1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-inverno">roupas-moda-inverno</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Blazer Cl&#225;ssico" href="http://www.eaquamar.com.br/blazer-classico-08-06-0159/p">
                <span itemprop="name"> Blazer Clássico</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Blazer Cl&#225;ssico" href="http://www.eaquamar.com.br/blazer-classico-08-06-0159/p">
                    <span itemprop="itemOffered"> Blazer Clássico</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Casaco / Blazer"> Casaco / Blazer</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content="Blazer Clássico"></span>
                <span itemprop="sku" >2000127</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 129,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.2000127');
        console.log('id do produto atual = ' + id);
        var altV = "Blazer Cl&#225;ssico";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_2000127" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="casacos-femininos-|-aquamar">
<article class="2000120" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Casaco / Casaco"> Casaco / Casaco</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content="Casaco Long Tricot"></span>
        </div>
        <a class="productImage" title="Casaco Long Tricot" href="http://www.eaquamar.com.br/casaco-long-tricot-02-08-0351/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/207354-320-480/02.08.0351_0004_1.jpg" width="320" height="480" alt="02.08.0351_0004_1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-inverno">roupas-moda-inverno</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Casaco Long Tricot" href="http://www.eaquamar.com.br/casaco-long-tricot-02-08-0351/p">
                <span itemprop="name"> Casaco Long Tricot</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Casaco Long Tricot" href="http://www.eaquamar.com.br/casaco-long-tricot-02-08-0351/p">
                    <span itemprop="itemOffered"> Casaco Long Tricot</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Casaco / Casaco"> Casaco / Casaco</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content="Casaco Long Tricot"></span>
                <span itemprop="sku" >2000120</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 89,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.2000120');
        console.log('id do produto atual = ' + id);
        var altV = "Casaco Long Tricot";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_2000120" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="casacos-femininos-|-aquamar last">
<article class="2000119" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Casaco / Casaco"> Casaco / Casaco</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content="Casaco Renda Rebite"></span>
        </div>
        <a class="productImage" title="Casaco Renda Rebite" href="http://www.eaquamar.com.br/casaco-renda-rebite-02-08-0353/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/207431-320-480/02.08.0353_0002_1.jpg" width="320" height="480" alt="02.08.0353_0002_1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-inverno">roupas-moda-inverno</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Casaco Renda Rebite" href="http://www.eaquamar.com.br/casaco-renda-rebite-02-08-0353/p">
                <span itemprop="name"> Casaco Renda Rebite</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Casaco Renda Rebite" href="http://www.eaquamar.com.br/casaco-renda-rebite-02-08-0353/p">
                    <span itemprop="itemOffered"> Casaco Renda Rebite</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Casaco / Casaco"> Casaco / Casaco</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content="Casaco Renda Rebite"></span>
                <span itemprop="sku" >2000119</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 179,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.2000119');
        console.log('id do produto atual = ' + id);
        var altV = "Casaco Renda Rebite";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_2000119" style="display:none" class="helperComplement"></li></ul></div></article><article class="ofertas"><div class="vitrine n4colunas"><h2>Blusas</h2>
<ul><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="blusas-femininas-|-aquamar">
<article class="2000048" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Blusa / Manga Longa"> Blusa / Manga Longa</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content="Blusa Tricot Leve"></span>
        </div>
        <a class="productImage" title="Blusa Tricot Leve" href="http://www.eaquamar.com.br/blusa-tricot-leve-02-11-0018/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/206980-320-480/02.11.0018_0009_1.jpg" width="320" height="480" alt="02.11.0018_0009_1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-inverno">roupas-moda-inverno</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Blusa Tricot Leve" href="http://www.eaquamar.com.br/blusa-tricot-leve-02-11-0018/p">
                <span itemprop="name"> Blusa Tricot Leve</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Blusa Tricot Leve" href="http://www.eaquamar.com.br/blusa-tricot-leve-02-11-0018/p">
                    <span itemprop="itemOffered"> Blusa Tricot Leve</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Blusa / Manga Longa"> Blusa / Manga Longa</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content="Blusa Tricot Leve"></span>
                <span itemprop="sku" >2000048</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 59,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.2000048');
        console.log('id do produto atual = ' + id);
        var altV = "Blusa Tricot Leve";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_2000048" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="teste-1">
<article class="513413" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="teste 1 / Manga Longa"> teste 1 / Manga Longa</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Blusa Bicolor Z&#237;per" href="http://www.eaquamar.com.br/blusa-bicolor-ziper-02-03-2397/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/203791-320-480/02.03.2397-preto-1.jpg" width="320" height="480" alt="02.03.2397-preto-1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-inverno">roupas-moda-inverno</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Blusa Bicolor Z&#237;per" href="http://www.eaquamar.com.br/blusa-bicolor-ziper-02-03-2397/p">
                <span itemprop="name"> Blusa Bicolor Zíper</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Blusa Bicolor Z&#237;per" href="http://www.eaquamar.com.br/blusa-bicolor-ziper-02-03-2397/p">
                    <span itemprop="itemOffered"> Blusa Bicolor Zíper</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="teste 1 / Manga Longa"> teste 1 / Manga Longa</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513413</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 79,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513413');
        console.log('id do produto atual = ' + id);
        var altV = "Blusa Bicolor Z&#237;per";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513413" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="blusas-femininas-|-aquamar">
<article class="513153" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Blusa / Manga Curta"> Blusa / Manga Curta</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Blusa Long Barrado Renda" href="http://www.eaquamar.com.br/blusa-long-barrado-renda-02-04-1991/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/202312-320-480/02.04.1991-preto-1.jpg" width="320" height="480" alt="02.04.1991-preto-1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag blusas-sale">Blusas Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p><p class="flag roupas-email-mkt">roupas-email-mkt</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Blusa Long Barrado Renda" href="http://www.eaquamar.com.br/blusa-long-barrado-renda-02-04-1991/p">
                <span itemprop="name"> Blusa Long Barrado Renda</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Blusa Long Barrado Renda" href="http://www.eaquamar.com.br/blusa-long-barrado-renda-02-04-1991/p">
                    <span itemprop="itemOffered"> Blusa Long Barrado Renda</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Blusa / Manga Curta"> Blusa / Manga Curta</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513153</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                    <span class="preco-de"> 
                    <span class="uHPrices">   R$ 59,90</span>
                </span>
                        <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 29,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513153');
        console.log('id do produto atual = ' + id);
        var altV = "Blusa Long Barrado Renda";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513153" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="blusas-femininas-|-aquamar last">
<article class="2000121" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Blusa / Cropped"> Blusa / Cropped</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content="Cropped Manga Listrada"></span>
        </div>
        <a class="productImage" title="Cropped Manga Listrada" href="http://www.eaquamar.com.br/cropped-manga-listrada-02-02-1930/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/206815-320-480/02.02.1930_0002_1.jpg" width="320" height="480" alt="02.02.1930_0002_1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Cropped Manga Listrada" href="http://www.eaquamar.com.br/cropped-manga-listrada-02-02-1930/p">
                <span itemprop="name"> Cropped Manga Listrada</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Cropped Manga Listrada" href="http://www.eaquamar.com.br/cropped-manga-listrada-02-02-1930/p">
                    <span itemprop="itemOffered"> Cropped Manga Listrada</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Blusa / Cropped"> Blusa / Cropped</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content="Cropped Manga Listrada"></span>
                <span itemprop="sku" >2000121</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 49,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.2000121');
        console.log('id do produto atual = ' + id);
        var altV = "Cropped Manga Listrada";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_2000121" style="display:none" class="helperComplement"></li></ul><ul><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="teste-1">
<article class="513277" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="teste 1 / Cropped"> teste 1 / Cropped</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Cropped Estampa Marinho Floral" href="http://www.eaquamar.com.br/cropped-estampa-marinho-floral-02-04-2014/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/202848-320-480/02.04.2014-est1-1.jpg" width="320" height="480" alt="02.04.2014-est1-1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag blusas-sale">Blusas Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p><p class="flag roupas-email-mkt">roupas-email-mkt</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Cropped Estampa Marinho Floral" href="http://www.eaquamar.com.br/cropped-estampa-marinho-floral-02-04-2014/p">
                <span itemprop="name"> Cropped Estampa Marinho Floral</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Cropped Estampa Marinho Floral" href="http://www.eaquamar.com.br/cropped-estampa-marinho-floral-02-04-2014/p">
                    <span itemprop="itemOffered"> Cropped Estampa Marinho Floral</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="teste 1 / Cropped"> teste 1 / Cropped</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513277</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                    <span class="preco-de"> 
                    <span class="uHPrices">   R$ 49,90</span>
                </span>
                        <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 29,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513277');
        console.log('id do produto atual = ' + id);
        var altV = "Cropped Estampa Marinho Floral";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513277" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="teste-1">
<article class="513623" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="teste 1 / Cropped"> teste 1 / Cropped</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Cropped Visco Estampado" href="http://www.eaquamar.com.br/cropped-visco-estampado-02-01-1391/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/204736-320-480/02.01.1391-est1-1.jpg" width="320" height="480" alt="02.01.1391-est1-1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Cropped Visco Estampado" href="http://www.eaquamar.com.br/cropped-visco-estampado-02-01-1391/p">
                <span itemprop="name"> Cropped Visco Estampado</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Cropped Visco Estampado" href="http://www.eaquamar.com.br/cropped-visco-estampado-02-01-1391/p">
                    <span itemprop="itemOffered"> Cropped Visco Estampado</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="teste 1 / Cropped"> teste 1 / Cropped</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513623</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 49,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513623');
        console.log('id do produto atual = ' + id);
        var altV = "Cropped Visco Estampado";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513623" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="blusas-femininas-|-aquamar">
<article class="513226" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Blusa / Regata"> Blusa / Regata</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Regata Flower" href="http://www.eaquamar.com.br/regata-flower-02-02-1859/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/202529-320-480/02.02.1859-azul-1.jpg" width="320" height="480" alt="02.02.1859-azul-1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag roupas-email-mkt">roupas-email-mkt</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Regata Flower" href="http://www.eaquamar.com.br/regata-flower-02-02-1859/p">
                <span itemprop="name"> Regata Flower</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Regata Flower" href="http://www.eaquamar.com.br/regata-flower-02-02-1859/p">
                    <span itemprop="itemOffered"> Regata Flower</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Blusa / Regata"> Blusa / Regata</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513226</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 39,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513226');
        console.log('id do produto atual = ' + id);
        var altV = "Regata Flower";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513226" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="teste-1 last">
<article class="513330" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="teste 1 / Manga Longa"> teste 1 / Manga Longa</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Blusa Tricot Listrado Duplo" href="http://www.eaquamar.com.br/blusa-tricot-listrado-duplo-02-06-0571/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/203464-320-480/02.06.0571-est1-1.jpg" width="320" height="480" alt="02.06.0571-est1-1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-inverno">roupas-moda-inverno</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Blusa Tricot Listrado Duplo" href="http://www.eaquamar.com.br/blusa-tricot-listrado-duplo-02-06-0571/p">
                <span itemprop="name"> Blusa Tricot Listrado Duplo</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Blusa Tricot Listrado Duplo" href="http://www.eaquamar.com.br/blusa-tricot-listrado-duplo-02-06-0571/p">
                    <span itemprop="itemOffered"> Blusa Tricot Listrado Duplo</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="teste 1 / Manga Longa"> teste 1 / Manga Longa</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513330</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 79,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513330');
        console.log('id do produto atual = ' + id);
        var altV = "Blusa Tricot Listrado Duplo";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513330" style="display:none" class="helperComplement"></li></ul><ul><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="blusas-femininas-|-aquamar">
<article class="2000036" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Blusa / Manga Curta"> Blusa / Manga Curta</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content="Blusa Time Is Now"></span>
        </div>
        <a class="productImage" title="Blusa Time Is Now" href="http://www.eaquamar.com.br/blusa-time-is-now-02-02-1924/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/205161-320-480/02.02.1924_0002_1.jpg" width="320" height="480" alt="02.02.1924_0002_1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag roupas-email-mkt">roupas-email-mkt</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Blusa Time Is Now" href="http://www.eaquamar.com.br/blusa-time-is-now-02-02-1924/p">
                <span itemprop="name"> Blusa Time Is Now</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Blusa Time Is Now" href="http://www.eaquamar.com.br/blusa-time-is-now-02-02-1924/p">
                    <span itemprop="itemOffered"> Blusa Time Is Now</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Blusa / Manga Curta"> Blusa / Manga Curta</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content="Blusa Time Is Now"></span>
                <span itemprop="sku" >2000036</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 49,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.2000036');
        console.log('id do produto atual = ' + id);
        var altV = "Blusa Time Is Now";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_2000036" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="blusas-femininas-|-aquamar">
<article class="2000095" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Blusa / Manga Longa"> Blusa / Manga Longa</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content="Blusa Listrada Transpassada"></span>
        </div>
        <a class="productImage" title="Blusa Listrada Transpassada" href="http://www.eaquamar.com.br/blusa-listrada-transpassada-02-11-0014/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/206547-320-480/02.11.0014_0034_1.jpg" width="320" height="480" alt="02.11.0014_0034_1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-inverno">roupas-moda-inverno</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Blusa Listrada Transpassada" href="http://www.eaquamar.com.br/blusa-listrada-transpassada-02-11-0014/p">
                <span itemprop="name"> Blusa Listrada Transpassada</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Blusa Listrada Transpassada" href="http://www.eaquamar.com.br/blusa-listrada-transpassada-02-11-0014/p">
                    <span itemprop="itemOffered"> Blusa Listrada Transpassada</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Blusa / Manga Longa"> Blusa / Manga Longa</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content="Blusa Listrada Transpassada"></span>
                <span itemprop="sku" >2000095</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 89,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.2000095');
        console.log('id do produto atual = ' + id);
        var altV = "Blusa Listrada Transpassada";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_2000095" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="blusas-femininas-|-aquamar">
<article class="2000085" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Blusa / Manga Longa"> Blusa / Manga Longa</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content="Blusa Manga Longa Visco"></span>
        </div>
        <a class="productImage" title="Blusa Manga Longa Visco" href="http://www.eaquamar.com.br/blusa-manga-longa-visco-02-11-0016/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/206704-320-480/02.11.0016_0006_1.jpg" width="320" height="480" alt="02.11.0016_0006_1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-inverno">roupas-moda-inverno</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Blusa Manga Longa Visco" href="http://www.eaquamar.com.br/blusa-manga-longa-visco-02-11-0016/p">
                <span itemprop="name"> Blusa Manga Longa Visco</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Blusa Manga Longa Visco" href="http://www.eaquamar.com.br/blusa-manga-longa-visco-02-11-0016/p">
                    <span itemprop="itemOffered"> Blusa Manga Longa Visco</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Blusa / Manga Longa"> Blusa / Manga Longa</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content="Blusa Manga Longa Visco"></span>
                <span itemprop="sku" >2000085</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 79,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.2000085');
        console.log('id do produto atual = ' + id);
        var altV = "Blusa Manga Longa Visco";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_2000085" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="blusas-femininas-|-aquamar last">
<article class="2000044" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Blusa / Cropped"> Blusa / Cropped</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content="Cropped Flores Antique Amarrado"></span>
        </div>
        <a class="productImage" title="Cropped Flores Antique Amarrado" href="http://www.eaquamar.com.br/cropped-flores-antique-amarrado-02-04-2064/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/205674-320-480/02.04.2064_0034_1.jpg" width="320" height="480" alt="02.04.2064_0034_1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag roupas-email-mkt">roupas-email-mkt</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Cropped Flores Antique Amarrado" href="http://www.eaquamar.com.br/cropped-flores-antique-amarrado-02-04-2064/p">
                <span itemprop="name"> Cropped Flores Antique Amarrado</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Cropped Flores Antique Amarrado" href="http://www.eaquamar.com.br/cropped-flores-antique-amarrado-02-04-2064/p">
                    <span itemprop="itemOffered"> Cropped Flores Antique Amarrado</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Blusa / Cropped"> Blusa / Cropped</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content="Cropped Flores Antique Amarrado"></span>
                <span itemprop="sku" >2000044</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 59,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.2000044');
        console.log('id do produto atual = ' + id);
        var altV = "Cropped Flores Antique Amarrado";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_2000044" style="display:none" class="helperComplement"></li></ul><ul><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="teste-1">
<article class="513481" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="teste 1 / Manga Curta"> teste 1 / Manga Curta</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Blusa Moletom Flor" href="http://www.eaquamar.com.br/blusa-moletom-flor-02-02-1935/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/204113-320-480/02.02.1935-cinza-1.jpg" width="320" height="480" alt="02.02.1935-cinza-1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Blusa Moletom Flor" href="http://www.eaquamar.com.br/blusa-moletom-flor-02-02-1935/p">
                <span itemprop="name"> Blusa Moletom Flor</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Blusa Moletom Flor" href="http://www.eaquamar.com.br/blusa-moletom-flor-02-02-1935/p">
                    <span itemprop="itemOffered"> Blusa Moletom Flor</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="teste 1 / Manga Curta"> teste 1 / Manga Curta</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513481</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 79,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513481');
        console.log('id do produto atual = ' + id);
        var altV = "Blusa Moletom Flor";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513481" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="teste-1">
<article class="513615" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="teste 1 / Manga Longa"> teste 1 / Manga Longa</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Blusa Assim&#233;trica" href="http://www.eaquamar.com.br/blusa-assimetrica-02-01-1341/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/204745-320-480/02.01.1341-vermelho-1.jpg" width="320" height="480" alt="02.01.1341-vermelho-1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-inverno">roupas-moda-inverno</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Blusa Assim&#233;trica" href="http://www.eaquamar.com.br/blusa-assimetrica-02-01-1341/p">
                <span itemprop="name"> Blusa Assimétrica</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Blusa Assim&#233;trica" href="http://www.eaquamar.com.br/blusa-assimetrica-02-01-1341/p">
                    <span itemprop="itemOffered"> Blusa Assimétrica</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="teste 1 / Manga Longa"> teste 1 / Manga Longa</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513615</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 59,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513615');
        console.log('id do produto atual = ' + id);
        var altV = "Blusa Assim&#233;trica";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513615" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="teste-1">
<article class="513541" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="teste 1 / Manga Longa"> teste 1 / Manga Longa</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Blusa Decote Listrada" href="http://www.eaquamar.com.br/blusa-decote-listrada-02-11-0005/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/204614-320-480/02.11.0005-est1-1.jpg" width="320" height="480" alt="02.11.0005-est1-1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-inverno">roupas-moda-inverno</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Blusa Decote Listrada" href="http://www.eaquamar.com.br/blusa-decote-listrada-02-11-0005/p">
                <span itemprop="name"> Blusa Decote Listrada</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Blusa Decote Listrada" href="http://www.eaquamar.com.br/blusa-decote-listrada-02-11-0005/p">
                    <span itemprop="itemOffered"> Blusa Decote Listrada</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="teste 1 / Manga Longa"> teste 1 / Manga Longa</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513541</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 79,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513541');
        console.log('id do produto atual = ' + id);
        var altV = "Blusa Decote Listrada";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513541" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="teste-1 last">
<article class="513482" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="teste 1 / Cropped"> teste 1 / Cropped</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Cropped Tricot Rasgado" href="http://www.eaquamar.com.br/cropped-tricot-rasgado-02-06-0569/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/204085-320-480/02.06.0569-rosa-1.jpg" width="320" height="480" alt="02.06.0569-rosa-1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Cropped Tricot Rasgado" href="http://www.eaquamar.com.br/cropped-tricot-rasgado-02-06-0569/p">
                <span itemprop="name"> Cropped Tricot Rasgado</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Cropped Tricot Rasgado" href="http://www.eaquamar.com.br/cropped-tricot-rasgado-02-06-0569/p">
                    <span itemprop="itemOffered"> Cropped Tricot Rasgado</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="teste 1 / Cropped"> teste 1 / Cropped</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513482</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 79,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513482');
        console.log('id do produto atual = ' + id);
        var altV = "Cropped Tricot Rasgado";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513482" style="display:none" class="helperComplement"></li></ul></div></article><article class="ofertas"><div class="vitrine n4colunas"><h2>Vestidos</h2>
<ul><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="teste-1">
<article class="513279" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="teste 1 / Curto"> teste 1 / Curto</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Vestido Estampa Marinho Floral" href="http://www.eaquamar.com.br/vestido-estampa-marinho-floral-01-04-2779/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/202869-320-480/01.04.2779-est1-1.jpg" width="320" height="480" alt="01.04.2779-est1-1" id="" />
            <div class="bandeirolas">
                <p class="flag vestidos-de-renda">Vestidos de Renda</p><p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag vestidos-manga-longa">Vestidos Manga Longa</p><p class="flag vestidos-sale">Vestidos Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p><p class="flag roupas-email-mkt">roupas-email-mkt</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Vestido Estampa Marinho Floral" href="http://www.eaquamar.com.br/vestido-estampa-marinho-floral-01-04-2779/p">
                <span itemprop="name"> Vestido Estampa Marinho Floral</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Vestido Estampa Marinho Floral" href="http://www.eaquamar.com.br/vestido-estampa-marinho-floral-01-04-2779/p">
                    <span itemprop="itemOffered"> Vestido Estampa Marinho Floral</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="teste 1 / Curto"> teste 1 / Curto</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513279</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                    <span class="preco-de"> 
                    <span class="uHPrices">   R$ 79,90</span>
                </span>
                        <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 59,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513279');
        console.log('id do produto atual = ' + id);
        var altV = "Vestido Estampa Marinho Floral";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513279" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="teste-1">
<article class="513614" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="teste 1 / Curto"> teste 1 / Curto</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Vestido Jasmine" href="http://www.eaquamar.com.br/vestido-jasmine-01-02-1017/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/204714-320-480/01.02.1017-preto-1.jpg" width="320" height="480" alt="01.02.1017-preto-1" id="" />
            <div class="bandeirolas">
                <p class="flag vestidos-de-renda">Vestidos de Renda</p><p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag vestidos-manga-longa">Vestidos Manga Longa</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Vestido Jasmine" href="http://www.eaquamar.com.br/vestido-jasmine-01-02-1017/p">
                <span itemprop="name"> Vestido Jasmine</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Vestido Jasmine" href="http://www.eaquamar.com.br/vestido-jasmine-01-02-1017/p">
                    <span itemprop="itemOffered"> Vestido Jasmine</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="teste 1 / Curto"> teste 1 / Curto</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513614</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 89,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513614');
        console.log('id do produto atual = ' + id);
        var altV = "Vestido Jasmine";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513614" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="vestidos-femininos-|-aquamar">
<article class="513207" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Vestido / Curto"> Vestido / Curto</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Vestido Estampa Paisley Chin&#234;s" href="http://www.eaquamar.com.br/vestido-estampa-paisley-chines-01-04-2777/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/202547-320-480/01.04.2777-est1-1.jpg" width="320" height="480" alt="01.04.2777-est1-1" id="" />
            <div class="bandeirolas">
                <p class="flag vestidos-de-renda">Vestidos de Renda</p><p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag vestidos-manga-longa">Vestidos Manga Longa</p><p class="flag vestidos-sale">Vestidos Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p><p class="flag roupas-email-mkt">roupas-email-mkt</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Vestido Estampa Paisley Chin&#234;s" href="http://www.eaquamar.com.br/vestido-estampa-paisley-chines-01-04-2777/p">
                <span itemprop="name"> Vestido Estampa Paisley Chinês</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Vestido Estampa Paisley Chin&#234;s" href="http://www.eaquamar.com.br/vestido-estampa-paisley-chines-01-04-2777/p">
                    <span itemprop="itemOffered"> Vestido Estampa Paisley Chinês</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Vestido / Curto"> Vestido / Curto</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513207</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                    <span class="preco-de"> 
                    <span class="uHPrices">   R$ 89,90</span>
                </span>
                        <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 59,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513207');
        console.log('id do produto atual = ' + id);
        var altV = "Vestido Estampa Paisley Chin&#234;s";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513207" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="vestidos-femininos-|-aquamar last">
<article class="513326" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Vestido / Curto"> Vestido / Curto</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Vestido Midi Canelado Lis" href="http://www.eaquamar.com.br/vestido-midi-canelado-lis-01-03-0609/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/203221-320-480/01.03.0609-est1-1.jpg" width="320" height="480" alt="01.03.0609-est1-1" id="" />
            <div class="bandeirolas">
                <p class="flag vestidos-de-renda">Vestidos de Renda</p><p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag vestidos-manga-longa">Vestidos Manga Longa</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Vestido Midi Canelado Lis" href="http://www.eaquamar.com.br/vestido-midi-canelado-lis-01-03-0609/p">
                <span itemprop="name"> Vestido Midi Canelado Lis</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Vestido Midi Canelado Lis" href="http://www.eaquamar.com.br/vestido-midi-canelado-lis-01-03-0609/p">
                    <span itemprop="itemOffered"> Vestido Midi Canelado Lis</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Vestido / Curto"> Vestido / Curto</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513326</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 79,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513326');
        console.log('id do produto atual = ' + id);
        var altV = "Vestido Midi Canelado Lis";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513326" style="display:none" class="helperComplement"></li></ul><ul><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="vestidos-femininos-|-aquamar">
<article class="513240" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Vestido / Longo"> Vestido / Longo</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Vestido Longo Recorte" href="http://www.eaquamar.com.br/vestido-longo-recorte-01-04-2766/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/202604-320-480/01.04.2766-amarelo-1.jpg" width="320" height="480" alt="01.04.2766-amarelo-1" id="" />
            <div class="bandeirolas">
                <p class="flag vestidos-de-renda">Vestidos de Renda</p><p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag vestidos-manga-longa">Vestidos Manga Longa</p><p class="flag vestidos-sale">Vestidos Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p><p class="flag roupas-email-mkt">roupas-email-mkt</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Vestido Longo Recorte" href="http://www.eaquamar.com.br/vestido-longo-recorte-01-04-2766/p">
                <span itemprop="name"> Vestido Longo Recorte</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Vestido Longo Recorte" href="http://www.eaquamar.com.br/vestido-longo-recorte-01-04-2766/p">
                    <span itemprop="itemOffered"> Vestido Longo Recorte</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Vestido / Longo"> Vestido / Longo</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513240</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                    <span class="preco-de"> 
                    <span class="uHPrices">   R$ 89,90</span>
                </span>
                        <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 69,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513240');
        console.log('id do produto atual = ' + id);
        var altV = "Vestido Longo Recorte";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513240" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="teste-1">
<article class="513509" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="teste 1 / Curto"> teste 1 / Curto</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Vestido Rendado" href="http://www.eaquamar.com.br/vestido-rendado-01-04-2746/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/204323-320-480/01.04.2746-preto-1.jpg" width="320" height="480" alt="01.04.2746-preto-1" id="" />
            <div class="bandeirolas">
                <p class="flag vestidos-de-renda">Vestidos de Renda</p><p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag vestidos-manga-longa">Vestidos Manga Longa</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Vestido Rendado" href="http://www.eaquamar.com.br/vestido-rendado-01-04-2746/p">
                <span itemprop="name"> Vestido Rendado</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Vestido Rendado" href="http://www.eaquamar.com.br/vestido-rendado-01-04-2746/p">
                    <span itemprop="itemOffered"> Vestido Rendado</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="teste 1 / Curto"> teste 1 / Curto</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513509</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 89,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513509');
        console.log('id do produto atual = ' + id);
        var altV = "Vestido Rendado";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513509" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="teste-1">
<article class="513607" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="teste 1 / Curto"> teste 1 / Curto</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Vestido Renda Floren&#231;a" href="http://www.eaquamar.com.br/vestido-renda-florenca-01-04-2813/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/204760-320-480/01.04.2813-marrom-1.jpg" width="320" height="480" alt="01.04.2813-marrom-1" id="" />
            <div class="bandeirolas">
                <p class="flag vestidos-de-renda">Vestidos de Renda</p><p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag vestidos-manga-longa">Vestidos Manga Longa</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Vestido Renda Floren&#231;a" href="http://www.eaquamar.com.br/vestido-renda-florenca-01-04-2813/p">
                <span itemprop="name"> Vestido Renda Florença</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Vestido Renda Floren&#231;a" href="http://www.eaquamar.com.br/vestido-renda-florenca-01-04-2813/p">
                    <span itemprop="itemOffered"> Vestido Renda Florença</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="teste 1 / Curto"> teste 1 / Curto</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513607</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 99,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513607');
        console.log('id do produto atual = ' + id);
        var altV = "Vestido Renda Floren&#231;a";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513607" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="teste-1 last">
<article class="513603" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="teste 1 / Curto"> teste 1 / Curto</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Vestido Black Veludo Molhado" href="http://www.eaquamar.com.br/vestido-black-veludo-molhado-01-04-2807/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/204811-320-480/01.04.2807-preto-1.jpg" width="320" height="480" alt="01.04.2807-preto-1" id="" />
            <div class="bandeirolas">
                <p class="flag vestidos-de-renda">Vestidos de Renda</p><p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag vestidos-manga-longa">Vestidos Manga Longa</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Vestido Black Veludo Molhado" href="http://www.eaquamar.com.br/vestido-black-veludo-molhado-01-04-2807/p">
                <span itemprop="name"> Vestido Black Veludo Molhado</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Vestido Black Veludo Molhado" href="http://www.eaquamar.com.br/vestido-black-veludo-molhado-01-04-2807/p">
                    <span itemprop="itemOffered"> Vestido Black Veludo Molhado</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="teste 1 / Curto"> teste 1 / Curto</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513603</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 99,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513603');
        console.log('id do produto atual = ' + id);
        var altV = "Vestido Black Veludo Molhado";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513603" style="display:none" class="helperComplement"></li></ul><ul><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="teste-1">
<article class="513272" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="teste 1 / Curto"> teste 1 / Curto</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Vestido Manga Bossa Tropical" href="http://www.eaquamar.com.br/vestido-manga-bossa-tropical-01-04-2781/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/202875-320-480/01.04.2781-est1-1.jpg" width="320" height="480" alt="01.04.2781-est1-1" id="" />
            <div class="bandeirolas">
                <p class="flag vestidos-de-renda">Vestidos de Renda</p><p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag vestidos-manga-longa">Vestidos Manga Longa</p><p class="flag vestidos-sale">Vestidos Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p><p class="flag roupas-email-mkt">roupas-email-mkt</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Vestido Manga Bossa Tropical" href="http://www.eaquamar.com.br/vestido-manga-bossa-tropical-01-04-2781/p">
                <span itemprop="name"> Vestido Manga Bossa Tropical</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Vestido Manga Bossa Tropical" href="http://www.eaquamar.com.br/vestido-manga-bossa-tropical-01-04-2781/p">
                    <span itemprop="itemOffered"> Vestido Manga Bossa Tropical</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="teste 1 / Curto"> teste 1 / Curto</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513272</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                    <span class="preco-de"> 
                    <span class="uHPrices">   R$ 79,90</span>
                </span>
                        <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 49,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513272');
        console.log('id do produto atual = ' + id);
        var altV = "Vestido Manga Bossa Tropical";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513272" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="vestidos-femininos-|-aquamar">
<article class="513120" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Vestido / Longo"> Vestido / Longo</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Vestido Longo Estampa Floresta" href="http://www.eaquamar.com.br/vestido-longo-estampa-floresta-01-03-0577/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/202014-320-480/01.03.0577-est2-1.jpg" width="320" height="480" alt="01.03.0577-est2-1" id="" />
            <div class="bandeirolas">
                <p class="flag vestidos-de-renda">Vestidos de Renda</p><p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag vestidos-manga-longa">Vestidos Manga Longa</p><p class="flag vestidos-sale">Vestidos Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p><p class="flag roupas-email-mkt">roupas-email-mkt</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Vestido Longo Estampa Floresta" href="http://www.eaquamar.com.br/vestido-longo-estampa-floresta-01-03-0577/p">
                <span itemprop="name"> Vestido Longo Estampa Floresta</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Vestido Longo Estampa Floresta" href="http://www.eaquamar.com.br/vestido-longo-estampa-floresta-01-03-0577/p">
                    <span itemprop="itemOffered"> Vestido Longo Estampa Floresta</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Vestido / Longo"> Vestido / Longo</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513120</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                    <span class="preco-de"> 
                    <span class="uHPrices">   R$ 79,90</span>
                </span>
                        <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 69,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513120');
        console.log('id do produto atual = ' + id);
        var altV = "Vestido Longo Estampa Floresta";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513120" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="vestidos-femininos-|-aquamar">
<article class="513246" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Vestido / Curto"> Vestido / Curto</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Vestido Estampa Len&#231;o Mandala" href="http://www.eaquamar.com.br/vestido-estampa-lenco-mandala-01-04-2718/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/202592-320-480/01.04.2718-est1-1.jpg" width="320" height="480" alt="01.04.2718-est1-1" id="" />
            <div class="bandeirolas">
                <p class="flag vestidos-de-renda">Vestidos de Renda</p><p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag vestidos-manga-longa">Vestidos Manga Longa</p><p class="flag vestidos-sale">Vestidos Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p><p class="flag roupas-email-mkt">roupas-email-mkt</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Vestido Estampa Len&#231;o Mandala" href="http://www.eaquamar.com.br/vestido-estampa-lenco-mandala-01-04-2718/p">
                <span itemprop="name"> Vestido Estampa Lenço Mandala</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Vestido Estampa Len&#231;o Mandala" href="http://www.eaquamar.com.br/vestido-estampa-lenco-mandala-01-04-2718/p">
                    <span itemprop="itemOffered"> Vestido Estampa Lenço Mandala</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Vestido / Curto"> Vestido / Curto</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513246</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                    <span class="preco-de"> 
                    <span class="uHPrices">   R$ 69,90</span>
                </span>
                        <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 59,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513246');
        console.log('id do produto atual = ' + id);
        var altV = "Vestido Estampa Len&#231;o Mandala";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513246" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="teste-1 last">
<article class="513425" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="teste 1 / Longo"> teste 1 / Longo</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Vestido Longo Floral Barrado" href="http://www.eaquamar.com.br/vestido-longo-floral-barrado-01-03-0584/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/203836-320-480/01.03.0584-est1-1.jpg" width="320" height="480" alt="01.03.0584-est1-1" id="" />
            <div class="bandeirolas">
                <p class="flag vestidos-de-renda">Vestidos de Renda</p><p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag vestidos-manga-longa">Vestidos Manga Longa</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Vestido Longo Floral Barrado" href="http://www.eaquamar.com.br/vestido-longo-floral-barrado-01-03-0584/p">
                <span itemprop="name"> Vestido Longo Floral Barrado</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Vestido Longo Floral Barrado" href="http://www.eaquamar.com.br/vestido-longo-floral-barrado-01-03-0584/p">
                    <span itemprop="itemOffered"> Vestido Longo Floral Barrado</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="teste 1 / Longo"> teste 1 / Longo</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513425</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 159,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513425');
        console.log('id do produto atual = ' + id);
        var altV = "Vestido Longo Floral Barrado";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513425" style="display:none" class="helperComplement"></li></ul><ul><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="teste-1">
<article class="513519" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="teste 1 / Curto"> teste 1 / Curto</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Vestido Recorte B&amp;W" href="http://www.eaquamar.com.br/vestido-recorte-b-w-01-02-0998/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/204390-320-480/01.02.0998-preto-1.jpg" width="320" height="480" alt="01.02.0998-preto-1" id="" />
            <div class="bandeirolas">
                <p class="flag vestidos-de-renda">Vestidos de Renda</p><p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag vestidos-manga-longa">Vestidos Manga Longa</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Vestido Recorte B&amp;W" href="http://www.eaquamar.com.br/vestido-recorte-b-w-01-02-0998/p">
                <span itemprop="name"> Vestido Recorte B&W</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Vestido Recorte B&amp;W" href="http://www.eaquamar.com.br/vestido-recorte-b-w-01-02-0998/p">
                    <span itemprop="itemOffered"> Vestido Recorte B&W</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="teste 1 / Curto"> teste 1 / Curto</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513519</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 129,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513519');
        console.log('id do produto atual = ' + id);
        var altV = "Vestido Recorte B&amp;W";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513519" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="teste-1">
<article class="513559" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="teste 1 / Curto"> teste 1 / Curto</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Vestido B&amp;W" href="http://www.eaquamar.com.br/vestido-b-w-01-02-1020/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/204493-320-480/01.02.1020-preto-1.jpg" width="320" height="480" alt="01.02.1020-preto-1" id="" />
            <div class="bandeirolas">
                <p class="flag vestidos-de-renda">Vestidos de Renda</p><p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag vestidos-manga-longa">Vestidos Manga Longa</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Vestido B&amp;W" href="http://www.eaquamar.com.br/vestido-b-w-01-02-1020/p">
                <span itemprop="name"> Vestido B&W</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Vestido B&amp;W" href="http://www.eaquamar.com.br/vestido-b-w-01-02-1020/p">
                    <span itemprop="itemOffered"> Vestido B&W</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="teste 1 / Curto"> teste 1 / Curto</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513559</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 119,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513559');
        console.log('id do produto atual = ' + id);
        var altV = "Vestido B&amp;W";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513559" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="teste-1">
<article class="513412" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="teste 1 / Curto"> teste 1 / Curto</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Vestido Detalhe Metalizado" href="http://www.eaquamar.com.br/vestido-detalhe-metalizado-01-04-2802/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/204326-320-480/01.04.2802-preto-1.jpg" width="320" height="480" alt="01.04.2802-preto-1" id="" />
            <div class="bandeirolas">
                <p class="flag vestidos-de-renda">Vestidos de Renda</p><p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag vestidos-manga-longa">Vestidos Manga Longa</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Vestido Detalhe Metalizado" href="http://www.eaquamar.com.br/vestido-detalhe-metalizado-01-04-2802/p">
                <span itemprop="name"> Vestido Detalhe Metalizado</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Vestido Detalhe Metalizado" href="http://www.eaquamar.com.br/vestido-detalhe-metalizado-01-04-2802/p">
                    <span itemprop="itemOffered"> Vestido Detalhe Metalizado</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="teste 1 / Curto"> teste 1 / Curto</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513412</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 119,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513412');
        console.log('id do produto atual = ' + id);
        var altV = "Vestido Detalhe Metalizado";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513412" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="vestidos-femininos-|-aquamar last">
<article class="2000074" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Vestido / Curto"> Vestido / Curto</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content="Vestido Elle Ombro A Ombro"></span>
        </div>
        <a class="productImage" title="Vestido Elle Ombro A Ombro" href="http://www.eaquamar.com.br/vestido-elle-ombro-a-ombro-01-01-0186/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/205457-320-480/01.01.0186_0002_1.jpg" width="320" height="480" alt="01.01.0186_0002_1" id="" />
            <div class="bandeirolas">
                <p class="flag vestidos-de-renda">Vestidos de Renda</p><p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag vestidos-manga-longa">Vestidos Manga Longa</p><p class="flag roupas-email-mkt">roupas-email-mkt</p><p class="flag new-collection---inverno-2017">New Collection - Inverno 2017</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Vestido Elle Ombro A Ombro" href="http://www.eaquamar.com.br/vestido-elle-ombro-a-ombro-01-01-0186/p">
                <span itemprop="name"> Vestido Elle Ombro A Ombro</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Vestido Elle Ombro A Ombro" href="http://www.eaquamar.com.br/vestido-elle-ombro-a-ombro-01-01-0186/p">
                    <span itemprop="itemOffered"> Vestido Elle Ombro A Ombro</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Vestido / Curto"> Vestido / Curto</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content="Vestido Elle Ombro A Ombro"></span>
                <span itemprop="sku" >2000074</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 119,99</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.2000074');
        console.log('id do produto atual = ' + id);
        var altV = "Vestido Elle Ombro A Ombro";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_2000074" style="display:none" class="helperComplement"></li></ul></div></article><article class="ofertas"><div class="vitrine n4colunas"><h2>Sale</h2>
<ul><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="shorts-e-bermudas-femininos--|-aquamar">
<article class="512677" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Short/Bermuda / Short"> Short/Bermuda / Short</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Short Jeans Dobrado" href="http://www.eaquamar.com.br/ref--8325-short-jeans-04-08-0032/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/199625-320-480/04.08.0032-jeans-1.jpg" width="320" height="480" alt="04.08.0032-jeans-1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag shorts-sale">Shorts Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p><p class="flag roupas-email-mkt">roupas-email-mkt</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Short Jeans Dobrado" href="http://www.eaquamar.com.br/ref--8325-short-jeans-04-08-0032/p">
                <span itemprop="name"> Short Jeans Dobrado</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Short Jeans Dobrado" href="http://www.eaquamar.com.br/ref--8325-short-jeans-04-08-0032/p">
                    <span itemprop="itemOffered"> Short Jeans Dobrado</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Short/Bermuda / Short"> Short/Bermuda / Short</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >512677</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                    <span class="preco-de"> 
                    <span class="uHPrices">   R$ 69,90</span>
                </span>
                        <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 39,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.512677');
        console.log('id do produto atual = ' + id);
        var altV = "Short Jeans Dobrado";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_512677" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="acessorios-femininos-|-aquamar">
<article class="512441" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Acessórios / Anel"> Acessórios / Anel</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Anel Pedra Preta" href="http://www.eaquamar.com.br/anel-pedra-preta-06-12-0728/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/198137-320-480/06.12.0728-prata-1.jpg" width="320" height="480" alt="06.12.0728-prata-1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-inverno">roupas-moda-inverno</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag acessorios-sale">Acessorios Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Anel Pedra Preta" href="http://www.eaquamar.com.br/anel-pedra-preta-06-12-0728/p">
                <span itemprop="name"> Anel Pedra Preta</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Anel Pedra Preta" href="http://www.eaquamar.com.br/anel-pedra-preta-06-12-0728/p">
                    <span itemprop="itemOffered"> Anel Pedra Preta</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Acessórios / Anel"> Acessórios / Anel</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >512441</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                    <span class="preco-de"> 
                    <span class="uHPrices">   R$ 17,90</span>
                </span>
                        <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 6,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.512441');
        console.log('id do produto atual = ' + id);
        var altV = "Anel Pedra Preta";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_512441" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="calcas-femininas-|-aquamar">
<article class="513016" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Calça / Calça Jeans"> Calça / Calça Jeans</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Cal&#231;a Jeans Skinny" href="http://www.eaquamar.com.br/calca-jeans-skinny-03-03-0564/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/201244-320-480/03.03.0564-jeans-1.jpg" width="320" height="480" alt="03.03.0564-jeans-1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-inverno">roupas-moda-inverno</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag calcas-sale">Calcas Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p><p class="flag roupas-email-mkt">roupas-email-mkt</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Cal&#231;a Jeans Skinny" href="http://www.eaquamar.com.br/calca-jeans-skinny-03-03-0564/p">
                <span itemprop="name"> Calça Jeans Skinny</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Cal&#231;a Jeans Skinny" href="http://www.eaquamar.com.br/calca-jeans-skinny-03-03-0564/p">
                    <span itemprop="itemOffered"> Calça Jeans Skinny</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Calça / Calça Jeans"> Calça / Calça Jeans</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513016</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 69,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513016');
        console.log('id do produto atual = ' + id);
        var altV = "Cal&#231;a Jeans Skinny";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513016" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="moda-praia-e-fitness---compre-roupas-de-praia-e-fitness-feminina-|-aquamar last">
<article class="512301" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Moda Praia / Biquini"> Moda Praia / Biquini</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Biquini Franja" href="http://www.eaquamar.com.br/ref--1-biquini-12-01-0063/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/198241-320-480/12.01.0063-coral-1.jpg" width="320" height="480" alt="12.01.0063-coral-1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag primavera-verao-2017-remarcados">primavera-verao-2017-remarcados</p><p class="flag biquinis-sale">Biquinis Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Biquini Franja" href="http://www.eaquamar.com.br/ref--1-biquini-12-01-0063/p">
                <span itemprop="name"> Biquini Franja</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Biquini Franja" href="http://www.eaquamar.com.br/ref--1-biquini-12-01-0063/p">
                    <span itemprop="itemOffered"> Biquini Franja</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Moda Praia / Biquini"> Moda Praia / Biquini</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >512301</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 39,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.512301');
        console.log('id do produto atual = ' + id);
        var altV = "Biquini Franja";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_512301" style="display:none" class="helperComplement"></li></ul><ul><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="sapatos-femininos-|-aquamar">
<article class="512996" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Sapatos / Rasteira"> Sapatos / Rasteira</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Rasteirinha Flat" href="http://www.eaquamar.com.br/rasteirinha-flat-13-03-0352/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/201180-320-480/13.03.0352-preto-006.jpg" width="320" height="480" alt="13.03.0352-preto-006" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag sapatos-sale">Sapatos Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Rasteirinha Flat" href="http://www.eaquamar.com.br/rasteirinha-flat-13-03-0352/p">
                <span itemprop="name"> Rasteirinha Flat</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Rasteirinha Flat" href="http://www.eaquamar.com.br/rasteirinha-flat-13-03-0352/p">
                    <span itemprop="itemOffered"> Rasteirinha Flat</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Sapatos / Rasteira"> Sapatos / Rasteira</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >512996</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                    <span class="preco-de"> 
                    <span class="uHPrices">   R$ 49,90</span>
                </span>
                        <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 39,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.512996');
        console.log('id do produto atual = ' + id);
        var altV = "Rasteirinha Flat";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_512996" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="calcas-femininas-|-aquamar">
<article class="511247" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Calça / Calça Jeans"> Calça / Calça Jeans</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Cal&#231;a Jeans Joelho Rasgado" href="http://www.eaquamar.com.br/ref--7996-calca-cos-alto-03-03-0509/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/192497-320-480/03.03.0509-jeans-1.jpg" width="320" height="480" alt="03.03.0509-jeans-1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-inverno">roupas-moda-inverno</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag primavera-verao-2017-remarcados">primavera-verao-2017-remarcados</p><p class="flag calcas-sale">Calcas Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p><p class="flag roupas-email-mkt">roupas-email-mkt</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Cal&#231;a Jeans Joelho Rasgado" href="http://www.eaquamar.com.br/ref--7996-calca-cos-alto-03-03-0509/p">
                <span itemprop="name"> Calça Jeans Joelho Rasgado</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Cal&#231;a Jeans Joelho Rasgado" href="http://www.eaquamar.com.br/ref--7996-calca-cos-alto-03-03-0509/p">
                    <span itemprop="itemOffered"> Calça Jeans Joelho Rasgado</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Calça / Calça Jeans"> Calça / Calça Jeans</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >511247</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                    <span class="preco-de"> 
                    <span class="uHPrices">   R$ 89,90</span>
                </span>
                        <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 69,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.511247');
        console.log('id do produto atual = ' + id);
        var altV = "Cal&#231;a Jeans Joelho Rasgado";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_511247" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="blusas-femininas-|-aquamar">
<article class="512926" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Blusa / Manga Curta"> Blusa / Manga Curta</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Blusa Freedom" href="http://www.eaquamar.com.br/ref-01074823-bl-visco-c--mg-02-01-1308/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/200645-320-480/02.01.1308-off-1.jpg" width="320" height="480" alt="02.01.1308-off-1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag blusas-sale">Blusas Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p><p class="flag roupas-email-mkt">roupas-email-mkt</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Blusa Freedom" href="http://www.eaquamar.com.br/ref-01074823-bl-visco-c--mg-02-01-1308/p">
                <span itemprop="name"> Blusa Freedom</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Blusa Freedom" href="http://www.eaquamar.com.br/ref-01074823-bl-visco-c--mg-02-01-1308/p">
                    <span itemprop="itemOffered"> Blusa Freedom</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Blusa / Manga Curta"> Blusa / Manga Curta</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >512926</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                    <span class="preco-de"> 
                    <span class="uHPrices">   R$ 59,90</span>
                </span>
                        <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 29,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.512926');
        console.log('id do produto atual = ' + id);
        var altV = "Blusa Freedom";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_512926" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="acessorios-femininos-|-aquamar last">
<article class="512556" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Acessórios / Cinto"> Acessórios / Cinto</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Cinto Fecho" href="http://www.eaquamar.com.br/ref--yw-4968-cinto-06-04-1160/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/199103-320-480/06.04.1160-off-1.jpg" width="320" height="480" alt="06.04.1160-off-1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-inverno">roupas-moda-inverno</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag acessorios-sale">Acessorios Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Cinto Fecho" href="http://www.eaquamar.com.br/ref--yw-4968-cinto-06-04-1160/p">
                <span itemprop="name"> Cinto Fecho</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Cinto Fecho" href="http://www.eaquamar.com.br/ref--yw-4968-cinto-06-04-1160/p">
                    <span itemprop="itemOffered"> Cinto Fecho</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Acessórios / Cinto"> Acessórios / Cinto</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >512556</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                    <span class="preco-de"> 
                    <span class="uHPrices">   R$ 15,90</span>
                </span>
                        <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 9,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.512556');
        console.log('id do produto atual = ' + id);
        var altV = "Cinto Fecho";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_512556" style="display:none" class="helperComplement"></li></ul><ul><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="teste-1">
<article class="513270" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="teste 1 / Curto"> teste 1 / Curto</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Vestido Curto Jardim Mandala" href="http://www.eaquamar.com.br/vestido-curto-jardim-mandala-01-04-2716/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/202860-320-480/01.04.2716-est1-1.jpg" width="320" height="480" alt="01.04.2716-est1-1" id="" />
            <div class="bandeirolas">
                <p class="flag vestidos-de-renda">Vestidos de Renda</p><p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag vestidos-manga-longa">Vestidos Manga Longa</p><p class="flag vestidos-sale">Vestidos Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p><p class="flag roupas-email-mkt">roupas-email-mkt</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Vestido Curto Jardim Mandala" href="http://www.eaquamar.com.br/vestido-curto-jardim-mandala-01-04-2716/p">
                <span itemprop="name"> Vestido Curto Jardim Mandala</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Vestido Curto Jardim Mandala" href="http://www.eaquamar.com.br/vestido-curto-jardim-mandala-01-04-2716/p">
                    <span itemprop="itemOffered"> Vestido Curto Jardim Mandala</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="teste 1 / Curto"> teste 1 / Curto</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513270</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                    <span class="preco-de"> 
                    <span class="uHPrices">   R$ 89,90</span>
                </span>
                        <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 69,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513270');
        console.log('id do produto atual = ' + id);
        var altV = "Vestido Curto Jardim Mandala";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513270" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="saias-femininas-|-aquamar">
<article class="513141" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Saia / Curta"> Saia / Curta</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Saia Curta Jeans" href="http://www.eaquamar.com.br/saia-curta-jeans-05-06-0477/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/202161-320-480/05.06.0477-jeans-1.jpg" width="320" height="480" alt="05.06.0477-jeans-1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag saias-sale">Saias Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p><p class="flag roupas-email-mkt">roupas-email-mkt</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Saia Curta Jeans" href="http://www.eaquamar.com.br/saia-curta-jeans-05-06-0477/p">
                <span itemprop="name"> Saia Curta Jeans</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Saia Curta Jeans" href="http://www.eaquamar.com.br/saia-curta-jeans-05-06-0477/p">
                    <span itemprop="itemOffered"> Saia Curta Jeans</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Saia / Curta"> Saia / Curta</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513141</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                    <div class="preco"><strong>ESGOTADO</strong></div>
            <span class="uLPrices" itemprop="price" style="display:none">R$ 0,00
            </span>
            <span itemprop="availability" href="http://schema.org/outOfStock" style="display: none">
                outOfStock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513141');
        console.log('id do produto atual = ' + id);
        var altV = "Saia Curta Jeans";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513141" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="acessorios-femininos-|-aquamar">
<article class="512479" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Acessórios / Anel"> Acessórios / Anel</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Anel Prateado Solare" href="http://www.eaquamar.com.br/anel-prateado-solare-06-12-0712/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/198731-320-480/06.12.0712-prata-1.jpg" width="320" height="480" alt="06.12.0712-prata-1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-inverno">roupas-moda-inverno</p><p class="flag roupas-moda-outono">roupas-moda-outono</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag acessorios-sale">Acessorios Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Anel Prateado Solare" href="http://www.eaquamar.com.br/anel-prateado-solare-06-12-0712/p">
                <span itemprop="name"> Anel Prateado Solare</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Anel Prateado Solare" href="http://www.eaquamar.com.br/anel-prateado-solare-06-12-0712/p">
                    <span itemprop="itemOffered"> Anel Prateado Solare</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Acessórios / Anel"> Acessórios / Anel</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >512479</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                    <span class="preco-de"> 
                    <span class="uHPrices">   R$ 17,90</span>
                </span>
                        <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 6,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.512479');
        console.log('id do produto atual = ' + id);
        var altV = "Anel Prateado Solare";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_512479" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="teste-1 last">
<article class="513241" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="teste 1 / Curto"> teste 1 / Curto</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Vestido Decote Costas" href="http://www.eaquamar.com.br/vestido-decote-costas-01-04-2772/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/202619-320-480/01.04.2772-coral-1.jpg" width="320" height="480" alt="01.04.2772-coral-1" id="" />
            <div class="bandeirolas">
                <p class="flag vestidos-de-renda">Vestidos de Renda</p><p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag vestidos-manga-longa">Vestidos Manga Longa</p><p class="flag vestidos-sale">Vestidos Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p><p class="flag roupas-email-mkt">roupas-email-mkt</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Vestido Decote Costas" href="http://www.eaquamar.com.br/vestido-decote-costas-01-04-2772/p">
                <span itemprop="name"> Vestido Decote Costas</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Vestido Decote Costas" href="http://www.eaquamar.com.br/vestido-decote-costas-01-04-2772/p">
                    <span itemprop="itemOffered"> Vestido Decote Costas</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="teste 1 / Curto"> teste 1 / Curto</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513241</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 49,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513241');
        console.log('id do produto atual = ' + id);
        var altV = "Vestido Decote Costas";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513241" style="display:none" class="helperComplement"></li></ul><ul><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="teste-1">
<article class="513219" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="teste 1 / Cropped"> teste 1 / Cropped</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Cropped Estampa Havaiana" href="http://www.eaquamar.com.br/cropped-estampa-havaiana-02-03-2429/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/202706-320-480/02.03.2429-est1-1.jpg" width="320" height="480" alt="02.03.2429-est1-1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag blusas-sale">Blusas Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p><p class="flag roupas-email-mkt">roupas-email-mkt</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Cropped Estampa Havaiana" href="http://www.eaquamar.com.br/cropped-estampa-havaiana-02-03-2429/p">
                <span itemprop="name"> Cropped Estampa Havaiana</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Cropped Estampa Havaiana" href="http://www.eaquamar.com.br/cropped-estampa-havaiana-02-03-2429/p">
                    <span itemprop="itemOffered"> Cropped Estampa Havaiana</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="teste 1 / Cropped"> teste 1 / Cropped</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513219</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                    <span class="preco-de"> 
                    <span class="uHPrices">   R$ 39,90</span>
                </span>
                        <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 29,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513219');
        console.log('id do produto atual = ' + id);
        var altV = "Cropped Estampa Havaiana";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513219" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="teste-1">
<article class="513215" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="teste 1 / Short"> teste 1 / Short</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Short Estampa Floral Am&#233;rica" href="http://www.eaquamar.com.br/short-estampa-floral-america-04-09-0058/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/202755-320-480/04.09.0058-est1-1.jpg" width="320" height="480" alt="04.09.0058-est1-1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag shorts-sale">Shorts Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p><p class="flag roupas-email-mkt">roupas-email-mkt</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Short Estampa Floral Am&#233;rica" href="http://www.eaquamar.com.br/short-estampa-floral-america-04-09-0058/p">
                <span itemprop="name"> Short Estampa Floral América</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Short Estampa Floral Am&#233;rica" href="http://www.eaquamar.com.br/short-estampa-floral-america-04-09-0058/p">
                    <span itemprop="itemOffered"> Short Estampa Floral América</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="teste 1 / Short"> teste 1 / Short</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513215</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                    <span class="preco-de"> 
                    <span class="uHPrices">   R$ 59,90</span>
                </span>
                        <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 39,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513215');
        console.log('id do produto atual = ' + id);
        var altV = "Short Estampa Floral Am&#233;rica";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513215" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="moda-praia-e-fitness---compre-roupas-de-praia-e-fitness-feminina-|-aquamar">
<article class="511952" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Moda Praia / Top Biquínis"> Moda Praia / Top Biquínis</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Top Tomara-que-caia Listrado" href="http://www.eaquamar.com.br/top-tomara-que-caia-listrado-12-07-0015/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/195491-320-480/tqcLIST01.jpg" width="320" height="480" alt="tqcLIST01" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag primavera-verao-2017-remarcados">primavera-verao-2017-remarcados</p><p class="flag biquinis-sale">Biquinis Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Top Tomara-que-caia Listrado" href="http://www.eaquamar.com.br/top-tomara-que-caia-listrado-12-07-0015/p">
                <span itemprop="name"> Top Tomara-que-caia Listrado</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Top Tomara-que-caia Listrado" href="http://www.eaquamar.com.br/top-tomara-que-caia-listrado-12-07-0015/p">
                    <span itemprop="itemOffered"> Top Tomara-que-caia Listrado</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Moda Praia / Top Biquínis"> Moda Praia / Top Biquínis</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >511952</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                    <span class="preco-de"> 
                    <span class="uHPrices">   R$ 39,90</span>
                </span>
                        <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 29,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.511952');
        console.log('id do produto atual = ' + id);
        var altV = "Top Tomara-que-caia Listrado";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_511952" style="display:none" class="helperComplement"></li><li layout="2bdf84f0-6c92-4b0c-8b23-de083ded76bf" class="blusas-femininas-|-aquamar last">
<article class="513003" itemprop="itemListElement" itemscope itemtype="http://schema.org/Offer">
    <div itemprop="itemOffered" itemscope itemtype="http://schema.org/Product">
        <meta id="metaBrand" itemprop="brand" content='' />
        <div class="infoEscondida" style="display:none">
            <span class="descriCurta" >$product.Description</span>
            <span class="prodBrand" ><p class="texto brand aquamar">aquamar</p></span>
            <span class="nomeCategoria" itemprop="category" content="Blusa / Regata"> Blusa / Regata</span>
            <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
            <span class="descricaoProduto" itemprop="description" content=""></span>
        </div>
        <a class="productImage" title="Regata Estampa Pinterest" href="http://www.eaquamar.com.br/regata-estampa-pinterest-02-02-1899/p">
            <img src="http://aquamar.vteximg.com.br/arquivos/ids/201220-320-480/02.02.1899-off-1.jpg" width="320" height="480" alt="02.02.1899-off-1" id="" />
            <div class="bandeirolas">
                <p class="flag roupas-moda-verao">roupas-moda-verao</p><p class="flag roupas-moda-primavera">roupas-moda-primavera</p><p class="flag blusas-sale">Blusas Sale</p><p class="flag liquidacao-sale">Liquidacao-sale</p><p class="flag roupas-email-mkt">roupas-email-mkt</p>
                
            </div>
        </a>
        <h3 class="nome">
            <a itemprop="url" title="Regata Estampa Pinterest" href="http://www.eaquamar.com.br/regata-estampa-pinterest-02-02-1899/p">
                <span itemprop="name"> Regata Estampa Pinterest</span>
            </a>
        </h3>
        <div class="preco" itemprop="offers" itemscope itemtype="http://schema.org/Offer">
            <div class="infoEscondida" style="display:none">
                <span class="entidadeVendedora" itemprop="seller" content="Aquamar"></span>
                <span class="entidadeVendedora" itemprop="businessFunction" content="http://purl.org/goodrelations/v1#Sell"></span>
                <a itemprop="url" title="Regata Estampa Pinterest" href="http://www.eaquamar.com.br/regata-estampa-pinterest-02-02-1899/p">
                    <span itemprop="itemOffered"> Regata Estampa Pinterest</span>
                </a>
                <span class="nomeCategoria" itemprop="category" content="Blusa / Regata"> Blusa / Regata</span>
                <span class="condicaoProduto" itemprop="itemCondition" content="novo"></span>
                <span class="descricaoProduto" itemprop="description" content=""></span>
                <span itemprop="sku" >513003</span>
                <meta itemprop="priceCurrency" content="BRL" />
            </div>
                                    <span class="preco-de"> 
                    <span class="uHPrices">   R$ 39,90</span>
                </span>
                        <span class="preco-por">
                <strong>
                    <span class="uLPrices" itemprop="price">R$ 29,90</span>
                </strong>
            </span>
            <span itemprop="availability" href="http://schema.org/InStock" style="display: none">
                In stock
            </span>
        </div>
            </div>
    <script>
        var id = $('.513003');
        console.log('id do produto atual = ' + id);
        var altV = "Regata Estampa Pinterest";
        var brand= id.find('.prodBrand:eq(0) p').text();
        id.find('.metaBrand').attr('content',brand);
        id.find('img').attr('itemprop', 'image').attr('alt', altV);
        var idLowPrice = id.find('.uLPrices');
        var LowPrice = idLowPrice.html().replace('R$', '').replace('.', '').replace(',', '.');
        idLowPrice.attr('content', LowPrice);
    </script>
</article>
</li><li id="helperComplement_513003" style="display:none" class="helperComplement"></li></ul></div></article></div><!-- Vitrines --><!-- Linha news 1 --><div class="linha pad news-line"><article><a href="/liquidacao?&O=OrderByBestDiscountDESC" title="Liquidacao" >
          <article>
               <span class="imgNews">
                    <img src="//aquamar.vteximg.com.br/arquivos/NossaLiqui.jpg" title="Liquidacao" alt="Liquidacao" />
               </span>
               <h3></h3>
               <p></p>
     </article>
</a><!-- ATENÇÃO, esse erro prejudica a performance do seu site, o conteudo de nome Largura 60% não foi renderizado por nao ser um XDocument válido, erro: - '=' is an unexpected token. The expected token is ';'. Line 1, position 30.--></article><article><a href="/vestido?PS=32&O=OrderByPriceASC" title="Vestidos" >
          <article>
               <span class="imgNews">
                    <img src="//aquamar.vteximg.com.br/arquivos/banner_medio_2Marc.jpg" title="Vestidos" alt="Vestidos" />
               </span>
               <h3></h3>
               <p></p>
     </article>
</a><!-- ATENÇÃO, esse erro prejudica a performance do seu site, o conteudo de nome Largura 40% não foi renderizado por nao ser um XDocument válido, erro: - '=' is an unexpected token. The expected token is ';'. Line 1, position 32.--></article></div><!-- /Linha news 1 --><!-- Linha news 2 --><div class="linha pad news-line2"><h2>AQUAMAR NAS MÍDIAS</h2>
  <article>
    <span class="imgNews">
      <img src="//aquamar.vteximg.com.br/arquivos/thumb_ana_paula3.jpg" title="Editorial especial de natal da Revista Flu com um longo vermelho" alt="Editorial especial de natal da Revista Flu com um longo vermelho" />
    </span>
    <h2>Ensaio do portal Ego.</h2>
    <h3> Ana Paula Renault linda com body Aquamar no ensaio do Ego, clique aqui e veja a matéria. </h3>
    <a href="/midia/3" title="Ana Paula Renault linda com body Aquamar no ensaio do Ego, clique aqui e veja a matéria">  &gt;Veja mais...</a>
  </article>

  <article>
    <span class="imgNews">
      <img src="//aquamar.vteximg.com.br/arquivos/thumb-aquamar-na-midia-3.jpg" title="Ensaio do Jornal O Fluminense inspirado na cantora Grace Jones. " alt="Ensaio do Jornal O Fluminense inspirado na cantora Grace Jones. " />
    </span>
    <h2>Ensaio do Jornal O Fluminense inspirado na cantora Grace Jones. </h2>
    <h3>Acessórios e macacão branco Aquamar.</h3>
    <a href="/midia/2" title="Ensaio do Jornal O Fluminense inspirado na cantora Grace Jones. ">  &gt;Veja mais...</a>
  </article>

  <article>
    <span class="imgNews">
      <img src="//aquamar.vteximg.com.br/arquivos/thumb-aquamar-na-midia-1.jpg" title="Pauta de renda da Revista O Globo, do Jornal O Globo, com essa blusa maravilhosa!" alt="Pauta de renda da Revista O Globo, do Jornal O Globo, com essa blusa maravilhosa!" />
    </span>
    <h2>Pauta da Revista O Globo, do Jornal O Globo!</h2>
    <h3>Rendas: com essa blusa maravilhosa vendida pela Aquamar! </h3>
    <a href="/midia/1" title="Pauta de renda da Revista O Globo, do Jornal O Globo, com essa blusa maravilhosa!">  &gt;Veja mais...</a>
  </article>
</div><!-- /Linha news 2 --><!-- texto para SEO--><div class="linha pad2 border"><h1 class="TituloSEO">Moda Feminina - Aquamar</h1><p class="textoSEO"><div class="textoSEO">
A Aquamar é uma marca contemporânea focada no universo feminino. A cada temporada, fazemos pesquisas, analisamos mudanças de mercado e de comportamento que influenciam diretamente nossas coleções. Buscamos sempre trazer inovações para leitura da moda feminina que apresentamos em nossas criações.  
</p>
<p>
Este é um setor que vem crescendo e se superando a cada estação. Hoje, a Aquamar oferece produtos de qualidade com preços acessíveis para nossas clientes estarem sempre por dentro das tendências mundiais. Nosso objetivo é apresentar um mix completo e diversificado para que todas as mulheres encontrem peças lindas e versáteis.  Além das mais de 20 lojas físicas, no estado do Rio de Janeiro, também levamos nossas coleções para o Brasil através da loja virtual. 
</p>
<p>
Aqui na Aquamar estamos sempre antenados as novidades para assim desenvolvermos peças desejo com o que há de mais atual na moda feminina. Temos opções perfeitas para todos os estilos, gostos e looks. Seja qual for sua rotina, temos itens perfeitos, desde os mais casuais até os mais poderosos para festas. Dessa forma, estamos sempre juntos com nossas clientes e presentes nos momentos importantes de suas vidas. 
</p>
<p>
Não perca tempo, navegue agora mesmo em nosso e-commerce e se deixe encantar pela nossa coleção. Aproveite para adquirir várias peças e renovar seu guarda roupas. Você vai encontrar vestidos curtos, longos, estampados, lisos, decotados, saias de todos os tipos, calças desde jeans a tecidos variados, blusas, croppeds, camisas, blazers, casacos, jaquetas, coletes, macacões, macaquinhos, shorts, bermudas, conjuntos, moda praia, linha fitness, sapatos, sandálias, botas, bolsas e é claro muitos acessórios, tudo isso em um só lugar, afinal a Aquamar é 100% moda feminina.
</p>
<p>
Proporcionamos uma experiência de compra única, dando liberdade para as mulheres montarem looks completos para todas as ocasiões e experimentarem vários estilos diferentes, sempre destacando a beleza e a personalidade de cada uma. 
</p>
</div><!-- ATENÇÃO, esse erro prejudica a performance do seu site, o conteudo de nome p seo não foi renderizado por nao ser um XDocument válido, erro: - The 'div' start tag on line 1 position 8 does not match the end tag of 'p'. Line 3, position 3.--></p></div><!-- /texto para SEO--><!-- footer --><footer><!-- newsletter --><div id="gnewsletter" class="linha centralizar linhaUm"><div class="newsRodape"><div class="newsletter" id="NewsLetter_5355172c_fe25_4161_aadc_b3ee69a865e3"><h3 class="newsletter-title">promoções</h3><fieldset><p>Ao se inscrever ganhe 10% DE DESCONTO na primeira compra!</p><input id="newsletterClientName" onfocus="newsSelect(this,'Digite seu nome');" onblur="newsLeave(this,'Digite seu nome');" class="newsletter-client-name" value="Digite seu nome" size="20" type="text" name="newsClientName" /><input id="newsletterClientEmail" onfocus="newsSelect(this,'Digite seu e-mail');" onblur="newsLeave(this,'Digite seu e-mail');" class="newsletter-client-email" value="Digite seu e-mail" size="20" type="text" name="newsletterClientEmail" /><input id="newsletterButtonOK" class="btn-ok newsletter-button-ok" value="ok" type="button" name="newsletterButtonOK" value="" onclick="newsButtonClick('NewsLetter_5355172c_fe25_4161_aadc_b3ee69a865e3')" /><input id="newsletterLoading" type="hidden" class="newsletter-loading" value="Processando..." /><input id="newsletterSuccess" type="hidden" class="newsletter-success" value="Obrigado por se cadastrar na Aquamar!" /><input id="newsletterSuccess2" type="hidden" class="newsletter-success2" value="Seu código para Cupom de Desconto é: IKRYGEVOAT. Anote este código e utilize no carrinho para  ganhar seu desconto." /><input id="newsletterError" type="hidden" class="newsletter-error" value="
    Encontramos um erro no cadastro de suas informações.<br />Por favor, tente novamente!
  " /><input id="newsInternalPage" type="hidden" value="_" /><input id="newsInternalPart" type="hidden"  value="newsletter" /><input id="newsInternalCampaign" type="hidden" value="newsletter:opt-in" /></fieldset><span class="rt"></span><span class="rb"></span><span class="lb"></span><span class="lt"></span></div></div></div><!-- newsletter --><div id="rodape" class="linha tab"><nav class="menuUsuarioRodape linha linhaDois"><!-- Sua Loja --><div class="col suaLoja"><h3>SUA LOJA</h3><ul class="rnav"><li><a href="/account" title="Informações sobre sua conta">Meu Cadastro</a></li><li><a href="/account/orders" title="Informações sobre seus pedidos">Meus pedidos</a></li><li><a href="/encontre-sua-revendedora" title="Encontre uma de nossas revendedoras próximas de você">Encontre sua revendedora</a></li><li><a href="/encontre-sua-loja" title="Encontre uma de nossas lojas próxima de você">Encontre sua Loja</a></li></ul></div><!-- /Sua Loja --><!-- Ajuda --><div class="col ajuda"><h3>AJUDA</h3><ul class="rnav"><li><a href="/como-utilizar-seu-cupom-de-desconto" title="Informações sobre a utilização de cupom na Aquamar">Cupom</a></li><li><a href="/como-utilizar-seu-vale-presente" title="Informações sobre a utilização dos vale presente na Aquamar">Vale Presente</a></li><li><a href="/account/orders" title="Texto de ajuda para entender e encontrar as informações sobre seus pedidos">Seus Pedidos</a></li><li><a href="/institucional/como-recuperar-senha" title="Informações sobre como recuperar suas senhas">Recuperar Senha</a></li><li><a href="/institucional/sac" title="Serviço de Atendimento ao Cliente">SAC Lojas Físicas</a></li></ul></div><!-- /ajuda --><!-- politica --><div class="col politica"><h3>POLÍTICAS</h3><ul class="rnav"><li><a href="/Institucional/Politica-de-privacidade" title="Politicas da Aquamar quanto à Privacidade">De privacidade</a></li><li><a href="/Institucional/Politica-de-troca" title="Politicas da Aquamar quanto às Trocas de Produtos">De troca</a></li><li><a href="/Institucional/Formas-de-pagamento" title="Politicas da Aquamar quanto às Compras">De compra</a></li><li><a href="/Institucional/entrega" title="Politicas da Aquamar quanto à Privacidade">De entrega</a></li><li><a href="/Institucional/Politica-de-retirada-em-loja" title="Politicas da Aquamar quanto à Retirada em Loja">De retirada em loja</a></li></ul></div><!-- politica --><!-- Sua Loja --><div class="col suaLoja"><h3>INSTITUCIONAL</h3><ul class="rnav"><li><a href="/institucional/empresa" title="Sobre a Empresa Aquamar">A empresa</a></li><li><a href="/institucional/a-marca" title="Sobre a Marca Aquamar">A marca</a></li><li><a href="/institucional/release" title="Release para imprensa">Release</a></li><li><a href="/trabalhe-conosco" title="Envie seu currículo para a Aquamar">Trabalhe Conosco</a></li><li><a href="/institucional/contato" title="Entre em contato com a Aquamar">Contato</a></li><!-- li><a href="/colecao-2017" title="Saiba mais sobre nossa Coleção Primavera Verão 2017">Coleção Primavera Verão 2017</a></li--></ul></div><!-- /Sua Loja --><!-- Central de Atendimento --><div class="col central-atendimento"><span class="telRodape"></span><a class="mailRodape" href="mailto:atendimento@eaquamar.com.br"></a><span class="horarioRodape">. Seg. à Sex. das 9:00 às 18:00 <br />
                      . Whatsapp exclusivo para clientes da loja online
                </span><div class="midiasSociaisRodape"><a class="twitterRodape" title="Siga-nos no Twitter" href="https://twitter.com/aquamarrio" target="_blank"></a><a class="faceRodape" title="Siga-nos no Facebook" href="https://www.facebook.com/AquamarRio" target="_blank"></a><a class="blogRodape" title="Siga o nosso Blog" href="http://blog.aquamar-rio.com.br/" target="_blank"></a><a class="isntagramRodape" title="Siga-nos no Instagram" href="http://instagram.com/aquamarrio" target="_blank"></a></div></div><!-- Central de Atendimento --></nav><div class="linha pad2 linha3"><!-- selos --><div class="col selosRodape"><h3>Segurança</h3><a href="https://selo.clearsale.com.br/Loja/ExibirDetalhesLoja/806273AE-5948-4930-8675-D404058BAB9B" target="_blank"><img src="https://selo.clearsale.com.br/Imagem/806273AE-5948-4930-8675-D404058BAB9B" alt="Selo                 Clearsale" /></a><!-- Begin DigiCert site seal HTML and JavaScript --><div id="DigiCertClickID_rDYbygEk" data-language="en_US"><a href="https://www.digicert.com/unified-communications-ssl-tls.htm">DigiCert.com</a></div><script type="text/javascript">
                var __dcid = __dcid || [];
                __dcid.push(["DigiCertClickID_rDYbygEk", "7", "s", "black", "rDYbygEk"]);
                (function() {
                    var cid = document.createElement("script");
                    cid.async = true;
                    cid.src = "//seal.digicert.com/seals/cascade/seal.min.js";
                    var s = document.getElementsByTagName("script");
                    var ls = s[(s.length - 1)];
                    ls.parentNode.insertBefore(cid, ls.nextSibling);
                }());
                </script><!-- End DigiCert site seal HTML and JavaScript --><a id="seloEbit" href="http://www.ebit.com.br/#aquamar" target="_blank" onclick="redir(this.href);"></a><script type="text/javascript" id="getSelo" src="https://imgs.ebit.com.br/ebitBR/selo-ebit/js/getSelo.js?79569"></script></div><!-- /selos --><!-- pagamento --><div class="col pagamentoRodape"><h3>Meios de Pagamento</h3><div class="meiosPagamentoRodape"></div></div><!-- /pagamento --><!-- facebook --><div class="col faceboxRodape"><div class="col-face"><iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2FAquamarRio&amp;width=260&amp;height=230&amp;colorscheme=light&amp;show_faces=true&amp;header=false&amp;stream=false&amp;show_border=false" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:260px; height:230px;" allowTransparency="true"></iframe></div></div><!-- /facebook --></div></div><!-- Menu Aberto Rodape --><menu id="menuPrincipalFooter" class="linha pad2"><h2>Todos os Nossos Produtos</h2><nav><div class="menu-departamento" itemscope itemtype="http://schema.org/BreadcrumbList">
    <div class="rt"></div>
    <h3 class="destaque">
        <span></span>
        <a class="menu-item-texto" href="/new-collection-inverno-2017" title="New Collection"itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="1" />New Collection</a>
    </h3>
    <ul></ul>
    <h3 class="vestido even has-sub">
        <span></span>
        <a class="menu-item-texto" href="/vestido?O=OrderByReleaseDateDESC" title="Vestidos" itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="2" />Vestidos</a>
    </h3>
    <ul class="vestido even">
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="3" />
            <a href="/vestido/longo?O=OrderByReleaseDateDESCO=OrderByReleaseDateDESC" title="Vestidos Longos">Longos</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="4" />
            <a href="/vestido/curto?O=OrderByReleaseDateDESC" title="Vestidos Curtos">Curtos</a>
        </li>
    </ul>
    <h3 class="blusa has-sub">
        <span></span>
        <a class="menu-item-texto" href="/blusa?O=OrderByReleaseDateDESC" title="Blusas" itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="4" />Blusas</a>
    </h3>
    <ul class="blusa">
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="5" />
            <a href="/blusa/manga-longa?O=OrderByReleaseDateDESC" title="Blusas de Manga Longa">Manga Longa</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="6" />
            <a href="/blusa/manga-curta?O=OrderByReleaseDateDESC" title="Blusas de Manga Curta">Manga Curta</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="7" />
            <a href="/blusa/regata?O=OrderByReleaseDateDESC" title="Blusas Regatas">Regatas</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="8" />
            <a href="/blusa/colete?O=OrderByReleaseDateDESC" title="Blusas Coletes">Coletes</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="9" />
            <a href="/busca?fq=H:185&O=OrderByReleaseDateDESC" title="Bodys">Bodys</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="10" />
            <a href="/blusa/cropped?O=OrderByReleaseDateDESC" title="Blusas Croppeds">Croppeds</a>
        </li>
    </ul>
    <h3 class="short-bermuda has-sub">
        <span></span>
        <a class="menu-item-texto" href="/short-bermuda?O=OrderByReleaseDateDESC" title="Shorts e Bermudas" itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="11" />Shorts</a>
    </h3>
    <ul class="short-bermuda">
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="12" />
            <a href="/short-bermuda/short-saia?" tiles="Short Saia">Shorts Saia</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="13" />
            <a href="/short-bermuda/short?O=OrderByReleaseDateDESC" title="Shorts">Shorts</a>
        </li>
    </ul>
    <h3 class="saia has-sub">
        <span></span>
        <a class="pai" href="/saia?O=OrderByReleaseDateDESC" title="Saias" itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="14" />Saias</a>
    </h3>
    <ul class="saia has-sub">
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="15" />
            <a href="/saia/curta?O=OrderByReleaseDateDESC" title="Saias Curtas">Curtas</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="16" />
            <a href="/saia/longa?O=OrderByReleaseDateDESC" title="Saias Longas">Longas</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="17" />
            <a href="/saia/midi?O=OrderByReleaseDateDESC" title="Saias Midis">Midis</a>
        </li>
    </ul>
    <h3 class="calca has-sub">
        <span></span>
        <a class="pai" href="/calca?O=OrderByReleaseDateDESC" title="Calças" itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="18" />Calças</a>
    </h3>
    <ul class="calca">
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="19" />
            <a href="/calca/legging?O=OrderByReleaseDateDESC" title="Calças Legging">Leggings</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="20" />
            <a href="/calca/calca-jeans?O=OrderByReleaseDateDESC" title="Calças Jeans">Calças Jeans</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="21" />
            <a href="/calca/calca-tecido?O=OrderByReleaseDateDESC" title="Calças Tecido">Calças Tecido</a>
        </li>
    </ul>
    <h3 class="casaco has-sub">
        <span></span>
        <a class="menu-item-texto" href="/casaco?O=OrderByReleaseDateDESC" title="Casacos" itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="22" />Casacos</a>
    </h3>
    <ul class="casaco">
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="23" />
            <a href="/casaco/jaqueta?O=OrderByReleaseDateDESC" title="Jaquetas">Jaquetas</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="24" />
            <a href="/casaco/blazer?O=OrderByReleaseDateDESC" titles="Blazeres">Blazers</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="25" />
            <a href="/casaco/kimono?O=OrderByReleaseDateDESC" titles="Kimonos">Kimonos</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="26" />
            <a href="/casaco/trench-coat?O=OrderByReleaseDateDESC" title="Trench Coats">Trench Coats</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="27" />
            <a href="/casaco/casaco?O=OrderByReleaseDateDESC" title="Casacos">Casacos</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="28" />
            <a href="/casaco/colete?O=OrderByReleaseDateDESC" title="Coletes">Coletes</a>
        </li>
    </ul>
    <h3 class="macacao has-sub">
        <span></span>
        <a class="pai" href="/macacao?O=OrderByReleaseDateDESC" title="Macacão" itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="29" />Macacões</a>
    </h3>
    <ul class="macacao">
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="30" />
            <a href="/macacao/curto?O=OrderByReleaseDateDESC" title="Macacão Curto">Curtos</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="31" />
            <a href="/macacao/longo?O=OrderByReleaseDateDESC" title="Macacão Longo">Longos</a>
        </li>
    </ul>
    <h3 class="sapatos has-sub">
        <span></span>
        <a class="menu-item-texto" href="/sapatos?O=OrderByReleaseDateDESC" title="Sapatos" itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="32" />Sapatos</a>
    </h3>
    <ul class="sapatos">
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="33" />
            <a href="/sapatos/salto-alto?O=OrderByReleaseDateDESC" title="Sapatos de Salto Alto">Salto Alto</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="34" />
            <a href="/sapatos/anabela?O=OrderByReleaseDateDESC" title="Anabelas">Anabelas</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="35" />
            <a href="/sapatos/sapatilha?O=OrderByReleaseDateDESC" title="Sapatilhas">Sapatilhas</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="36" />
            <a href="/sapatos/rasteira?O=OrderByReleaseDateDESC" title="Rasteiras">Rasteiras</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="37" />
            <a href="/sapatos/bota?O=OrderByReleaseDateDESC" title="Botas">Botas</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="38" />
            <a href="/sapatos/tenis?O=OrderByReleaseDateDESC" title="Botas">Tênis</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="39" />
            <a href="/sapatos/oxford?O=OrderByReleaseDateDESC" title="Botas">Oxford</a>
        </li>
    </ul>
    <h3 class="acessorios even has-sub">
        <span></span>
        <a class="menu-item-texto" href="/acessorios?O=OrderByReleaseDateDESC" title="Acessórios" itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="40" />Acessórios</a>
    </h3>
    <ul class="acessorios even ">
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="65" />
            <a href="/bolsa?O=OrderByReleaseDateDESC" title="Bolsas">Bolsas</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="41" />
            <a href="/acessorios/lenco?O=OrderByReleaseDateDESC" title="Lenços">Lenços</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="42" />
            <a href="/acessorios/cinto?O=OrderByReleaseDateDESC" title="Cintos">Cintos</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="43" />
            <a href="/acessorios/aromatizante?O=OrderByReleaseDateDESC" title="Aromatizantes">Aromatizantes</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="44" />
            <a href="/acessorios/agendas?O=OrderByReleaseDateDESC" title="Agendas">Agendas</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="45" />
            <a href="/acessorios/anel?O=OrderByReleaseDateDESC" title="Anéis">Anéis</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="46" />
            <a href="/acessorios/brinco?O=OrderByReleaseDateDESC" title="Brinco">Brincos</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="47" />
            <a href="/acessorios/colar?O=OrderByReleaseDateDESC" title="Colares">Colares</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="48" />
            <a href="/acessorios/pulseira?O=OrderByReleaseDateDESC" title="Pulseiras">Pulseiras</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="49" />
            <a href="/acessorios/perfume?O=OrderByReleaseDateDESC" title="Perfumes">Perfumes</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="50" />
            <a href="/acessorios/chaveiro?O=OrderByReleaseDateDESC" title="Chaveiros">Chaveiros</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="51" />
            <a href="/acessorios/prendedor-de-cabelo?O=OrderByReleaseDateDESC" title="Prendedores de Cabelo">Prendedores de Cabelo</a>
        </li>
    </ul>
    <h3 class="praia has-sub">
        <span></span>
        <a class="menu-item-texto" href="/moda-praia/?O=OrderByReleaseDateDESC" title="Praia"itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="52" />Praia</a>
    </h3>
     <ul class="praia"> 
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="2" />
            <a href="/moda-praia/biquini?O=OrderByReleaseDateDESC" title="Biquini">Biquinis</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="65" />
            <a href="/moda-praia/maio?O=OrderByReleaseDateDESC" title="Maiô">Maiôs</a>
         </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="66" />
            <a href="/moda-praia/top-biquinis?O=OrderByReleaseDateDESC" title="Top Biquinis">Biquinis Tops </a>
         </li>
         <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="67" />
            <a href="/moda-praia/biquinis-bottom?O=OrderByReleaseDateDESC" title="Maiô">Biquinis Bottom</a>
         </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="68" />
            <a href="/moda-praia/body-alaiah?O=OrderByReleaseDateDESC" title="Body">Body</a>
        </li>
    </ul>
    <!-- ul class="bolsa even"></ul-->
    <h3 class="sale has-sub">
        <span></span>
        <a class="pai" href="/liquidacao?&amp;O=OrderByBestDiscountDESC" title="Sale" itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="53" />Liquidação</a>
    </h3>
    <ul class="sale">
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="54" />
            <a href="/acessorios-sale?&amp;O=OrderByBestDiscountDESC" title="Sale Acessórios">Acessórios</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="55" />
            <a href="/biquinis-sale?&amp;O=OrderByBestDiscountDESC" title="Sale Biquiniss">Biquinis</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="56" />
            <a href="/blusas-sale?&amp;O=OrderByBestDiscountDESC" title="Sale Blusas">Blusas</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="57" />
            <a href="/bolsas-sale?&amp;O=OrderByBestDiscountDESC title="Sale Bolsas">Bolsas</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="58" />
            <a href="/calcas-sale?&amp;O=OrderByBestDiscountDESC" title="Sale Calças">Calças</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="59" />
            <a href="/casacos-sale?&amp;O=OrderByBestDiscountDESC" title="Sale Casacos">Casacos</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="60" />
            <a href="/macacoes-sale?&amp;O=O=OrderByBestDiscountDESC" title="Sale Blusas">Macacões</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="61" />
            <a href="/saias-sale?&amp;O=OrderByBestDiscountDESC title="Sale Saias">Saias</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="62" />
            <a href="/sapatos-sale?&amp;O=OrderByBestDiscountDESC" title="Sale Sapatos">Sapatos</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="63" />
            <a href="/shorts-sale?&amp;O=OrderByBestDiscountDESC" title="Sale Shorts-Bermudas">Shorts</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="64" />
            <a href="/vestidos-sale?&amp;O=OrderByReleaseDateDESC" title="Sale Vestidos">Vestidos</a>
        </li>
    </ul>
</div><!-- ATENÇÃO, esse erro prejudica a performance do seu site, o conteudo de nome Novo Menu não foi renderizado por nao ser um XDocument válido, erro: - 'itemtype' is an unexpected token. The expected token is '='. Line 1, position 48.--><h3 class="pai"><a class="pai" href="/roupas-moda-outono"><img src="//aquamar.vteximg.com.br/arquivos/icon-star.gif" />Moda Outono</a></h3><h3 class="pai"><a class="pai" href="/roupas-moda-inverno"><img src="//aquamar.vteximg.com.br/arquivos/icon-star.gif" />Moda Inverno</a></h3><h3 class="pai"><a class="pai" href="/roupas-moda-primavera"><img src="//aquamar.vteximg.com.br/arquivos/icon-star.gif" />Moda Primavera</a></h3><h3 class="pai last"><a class="pai" href="/roupas-moda-verao"><img src="//aquamar.vteximg.com.br/arquivos/icon-star.gif" />Moda Verão</a></h3><h3 class="pai last"><a class="pai" href="/vestidos-manga-longa"><img src="//aquamar.vteximg.com.br/arquivos/icon-star.gif" />Vestidos Manga Longa</a></h3><h3 class="pai last"><a class="pai" href="/vestido-de-renda"><img src="//aquamar.vteximg.com.br/arquivos/icon-star.gif" />Vestido de Renda</a></h3></nav></menu><!-- /Menu Aberto Rodape --><!-- Banner Rodape --><div class="linha pad2 bannerRodape"><div class="box-banner"><a href="/seja-uma-revendedora"><img width="1641" height="71" id="ihttp://aquamar.vteximg.com.br/arquivos/ids/194923/2016-bannerSejaRevendedorRodape.jpg" alt="bannerRodape" src="http://aquamar.vteximg.com.br/arquivos/ids/194923/2016-bannerSejaRevendedorRodape.jpg" complete="complete"/></a></div></div><!-- /Banner Rodape --><!-- Copyright --><div id="endFooter" class="linha pad2"><div class="copyright"><p>Aquamar - Todos os direitos reservados - VIRTUAL 2043 CONFECÇÕES LTDA. - CNPJ: 17.465.257/0001-11 R. Francisco de Souza e Melo, 1590 - Galpão 04 - 167/168 | Cep.:21.010-410 | Cordovil - Rio de Janeiro - RJ</p></div><!-- copyright --><!-- by --><div class="col-by"><a href="http://www.vtex.com/" title="nova janela: Vtex" target="_blank"><strong>Powered by</strong><br /><img src="//aquamar.vteximg.com.br/arquivos/logo-vtex.gif" alt="Vtex" /><span>Vtex</span></a><a href="http://www.agenciainnovar8.com.br/" title="nova janela: Innovar8" target="_blank"><strong>Desenvolvimento</strong><br /><img src="//aquamar.vteximg.com.br/arquivos/logo-innovar.gif" alt="innovar8" /><span>Innovar8</span></a></div><!-- by --></div><!-- /Copyright --></footer><a id="voltartopo">Voltar para o topo</a><header><div class="topbar linha pad"><a class="telefonesHeader" title="Telefone(21) 3034-1075 / Whatsapp(21)97644-0137 - seg. à sex. das 9:00 às 18:00 - Atendimento somente via mensagens digitadas"></a><!-- search --><div class="busca"><script type="text/javascript" language="javascript"> /*<![CDATA[*/ $(document).ready(function(){currentDept = '0'; enableFullTextSearchBox('ftBoxebcf30f6f833450fa1a793a1e6e1b8be', 'ftDeptebcf30f6f833450fa1a793a1e6e1b8be', 'ftIdxebcf30f6f833450fa1a793a1e6e1b8be', 'ftBtnebcf30f6f833450fa1a793a1e6e1b8be', '/SEARCHTERM','Digite aqui o que procura...' );}); /*]]>*/ </script><fieldset class="busca"><legend>Buscar no site</legend><label>Buscar</label><select id="ftDeptebcf30f6f833450fa1a793a1e6e1b8be"><option value="">Todo o site</option><option value="1000003">Sapatos</option><option value="1000004">Acessórios</option><option value="1000011">Blusa</option><option value="1000013">Vestido</option><option value="1000016">Macacão</option><option value="1000010">Calça</option><option value="1000014">Saia</option><option value="1000012">Casaco</option><option value="1000017">Bolsa</option><option value="1000015">Short/Bermuda</option><option value="1000037">Bermuda</option><option value="1000062">Moda Praia</option><option value="1000088">Preview</option></select><input type="hidden" id=ftIdxebcf30f6f833450fa1a793a1e6e1b8be value="" /><input id="ftBoxebcf30f6f833450fa1a793a1e6e1b8be" class="fulltext-search-box" type="text" size="20" accesskey="b" /><input id="ftBtnebcf30f6f833450fa1a793a1e6e1b8be" type="button" value="Buscar" class="btn-buscar" /></fieldset></div><!-- search --><a href="/account/" class="minhaConta" title="Clique para acessar as suas informações de cadastro">MEU CADASTRO</a><a href="/account/order" class="meusPedidos" title="Clique para acessar as informações dos seus pedidos">MEUS PEDIDOS</a><!-- top cart --><div class="top-cart"><a href="/checkout/#/cart" title="Meu Carrinho" class="gt-carrinho-link"><div class="portal-totalizers-ref"></div><script>$('.portal-totalizers-ref').minicart({ showMinicart: false, showTotalizers: true, showShippingOptions: false });</script></a><span class="parcelamentoHeader"></span></div><!-- top cart --></div><!-- topbar --><!-- header --><div class="header linha pad center"><!-- logo --><h2 class="logo"><span>Aquamar</span><a href="/" title="home"><img src="//aquamar.vteximg.com.br/arquivos/2016-logoNovoLayout.jpg" alt="Aquamar" /></a></h2><!-- logo --><!-- nav --><menu id="menuPrincipal" class="linha center"><nav class="linha center"><div class="menu-departamento" itemscope itemtype="http://schema.org/BreadcrumbList">
    <div class="rt"></div>
    <h3 class="destaque">
        <span></span>
        <a class="menu-item-texto" href="/new-collection-inverno-2017" title="New Collection"itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="1" />New Collection</a>
    </h3>
    <ul></ul>
    <h3 class="vestido even has-sub">
        <span></span>
        <a class="menu-item-texto" href="/vestido?O=OrderByReleaseDateDESC" title="Vestidos" itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="2" />Vestidos</a>
    </h3>
    <ul class="vestido even">
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="3" />
            <a href="/vestido/longo?O=OrderByReleaseDateDESCO=OrderByReleaseDateDESC" title="Vestidos Longos">Longos</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="4" />
            <a href="/vestido/curto?O=OrderByReleaseDateDESC" title="Vestidos Curtos">Curtos</a>
        </li>
    </ul>
    <h3 class="blusa has-sub">
        <span></span>
        <a class="menu-item-texto" href="/blusa?O=OrderByReleaseDateDESC" title="Blusas" itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="4" />Blusas</a>
    </h3>
    <ul class="blusa">
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="5" />
            <a href="/blusa/manga-longa?O=OrderByReleaseDateDESC" title="Blusas de Manga Longa">Manga Longa</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="6" />
            <a href="/blusa/manga-curta?O=OrderByReleaseDateDESC" title="Blusas de Manga Curta">Manga Curta</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="7" />
            <a href="/blusa/regata?O=OrderByReleaseDateDESC" title="Blusas Regatas">Regatas</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="8" />
            <a href="/blusa/colete?O=OrderByReleaseDateDESC" title="Blusas Coletes">Coletes</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="9" />
            <a href="/busca?fq=H:185&O=OrderByReleaseDateDESC" title="Bodys">Bodys</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="10" />
            <a href="/blusa/cropped?O=OrderByReleaseDateDESC" title="Blusas Croppeds">Croppeds</a>
        </li>
    </ul>
    <h3 class="short-bermuda has-sub">
        <span></span>
        <a class="menu-item-texto" href="/short-bermuda?O=OrderByReleaseDateDESC" title="Shorts e Bermudas" itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="11" />Shorts</a>
    </h3>
    <ul class="short-bermuda">
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="12" />
            <a href="/short-bermuda/short-saia?" tiles="Short Saia">Shorts Saia</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="13" />
            <a href="/short-bermuda/short?O=OrderByReleaseDateDESC" title="Shorts">Shorts</a>
        </li>
    </ul>
    <h3 class="saia has-sub">
        <span></span>
        <a class="pai" href="/saia?O=OrderByReleaseDateDESC" title="Saias" itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="14" />Saias</a>
    </h3>
    <ul class="saia has-sub">
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="15" />
            <a href="/saia/curta?O=OrderByReleaseDateDESC" title="Saias Curtas">Curtas</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="16" />
            <a href="/saia/longa?O=OrderByReleaseDateDESC" title="Saias Longas">Longas</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="17" />
            <a href="/saia/midi?O=OrderByReleaseDateDESC" title="Saias Midis">Midis</a>
        </li>
    </ul>
    <h3 class="calca has-sub">
        <span></span>
        <a class="pai" href="/calca?O=OrderByReleaseDateDESC" title="Calças" itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="18" />Calças</a>
    </h3>
    <ul class="calca">
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="19" />
            <a href="/calca/legging?O=OrderByReleaseDateDESC" title="Calças Legging">Leggings</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="20" />
            <a href="/calca/calca-jeans?O=OrderByReleaseDateDESC" title="Calças Jeans">Calças Jeans</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="21" />
            <a href="/calca/calca-tecido?O=OrderByReleaseDateDESC" title="Calças Tecido">Calças Tecido</a>
        </li>
    </ul>
    <h3 class="casaco has-sub">
        <span></span>
        <a class="menu-item-texto" href="/casaco?O=OrderByReleaseDateDESC" title="Casacos" itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="22" />Casacos</a>
    </h3>
    <ul class="casaco">
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="23" />
            <a href="/casaco/jaqueta?O=OrderByReleaseDateDESC" title="Jaquetas">Jaquetas</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="24" />
            <a href="/casaco/blazer?O=OrderByReleaseDateDESC" titles="Blazeres">Blazers</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="25" />
            <a href="/casaco/kimono?O=OrderByReleaseDateDESC" titles="Kimonos">Kimonos</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="26" />
            <a href="/casaco/trench-coat?O=OrderByReleaseDateDESC" title="Trench Coats">Trench Coats</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="27" />
            <a href="/casaco/casaco?O=OrderByReleaseDateDESC" title="Casacos">Casacos</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="28" />
            <a href="/casaco/colete?O=OrderByReleaseDateDESC" title="Coletes">Coletes</a>
        </li>
    </ul>
    <h3 class="macacao has-sub">
        <span></span>
        <a class="pai" href="/macacao?O=OrderByReleaseDateDESC" title="Macacão" itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="29" />Macacões</a>
    </h3>
    <ul class="macacao">
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="30" />
            <a href="/macacao/curto?O=OrderByReleaseDateDESC" title="Macacão Curto">Curtos</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="31" />
            <a href="/macacao/longo?O=OrderByReleaseDateDESC" title="Macacão Longo">Longos</a>
        </li>
    </ul>
    <h3 class="sapatos has-sub">
        <span></span>
        <a class="menu-item-texto" href="/sapatos?O=OrderByReleaseDateDESC" title="Sapatos" itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="32" />Sapatos</a>
    </h3>
    <ul class="sapatos">
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="33" />
            <a href="/sapatos/salto-alto?O=OrderByReleaseDateDESC" title="Sapatos de Salto Alto">Salto Alto</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="34" />
            <a href="/sapatos/anabela?O=OrderByReleaseDateDESC" title="Anabelas">Anabelas</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="35" />
            <a href="/sapatos/sapatilha?O=OrderByReleaseDateDESC" title="Sapatilhas">Sapatilhas</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="36" />
            <a href="/sapatos/rasteira?O=OrderByReleaseDateDESC" title="Rasteiras">Rasteiras</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="37" />
            <a href="/sapatos/bota?O=OrderByReleaseDateDESC" title="Botas">Botas</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="38" />
            <a href="/sapatos/tenis?O=OrderByReleaseDateDESC" title="Botas">Tênis</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="39" />
            <a href="/sapatos/oxford?O=OrderByReleaseDateDESC" title="Botas">Oxford</a>
        </li>
    </ul>
    <h3 class="acessorios even has-sub">
        <span></span>
        <a class="menu-item-texto" href="/acessorios?O=OrderByReleaseDateDESC" title="Acessórios" itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="40" />Acessórios</a>
    </h3>
    <ul class="acessorios even ">
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="65" />
            <a href="/bolsa?O=OrderByReleaseDateDESC" title="Bolsas">Bolsas</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="41" />
            <a href="/acessorios/lenco?O=OrderByReleaseDateDESC" title="Lenços">Lenços</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="42" />
            <a href="/acessorios/cinto?O=OrderByReleaseDateDESC" title="Cintos">Cintos</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="43" />
            <a href="/acessorios/aromatizante?O=OrderByReleaseDateDESC" title="Aromatizantes">Aromatizantes</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="44" />
            <a href="/acessorios/agendas?O=OrderByReleaseDateDESC" title="Agendas">Agendas</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="45" />
            <a href="/acessorios/anel?O=OrderByReleaseDateDESC" title="Anéis">Anéis</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="46" />
            <a href="/acessorios/brinco?O=OrderByReleaseDateDESC" title="Brinco">Brincos</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="47" />
            <a href="/acessorios/colar?O=OrderByReleaseDateDESC" title="Colares">Colares</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="48" />
            <a href="/acessorios/pulseira?O=OrderByReleaseDateDESC" title="Pulseiras">Pulseiras</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="49" />
            <a href="/acessorios/perfume?O=OrderByReleaseDateDESC" title="Perfumes">Perfumes</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="50" />
            <a href="/acessorios/chaveiro?O=OrderByReleaseDateDESC" title="Chaveiros">Chaveiros</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="51" />
            <a href="/acessorios/prendedor-de-cabelo?O=OrderByReleaseDateDESC" title="Prendedores de Cabelo">Prendedores de Cabelo</a>
        </li>
    </ul>
    <h3 class="praia has-sub">
        <span></span>
        <a class="menu-item-texto" href="/moda-praia/?O=OrderByReleaseDateDESC" title="Praia"itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="52" />Praia</a>
    </h3>
     <ul class="praia"> 
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="2" />
            <a href="/moda-praia/biquini?O=OrderByReleaseDateDESC" title="Biquini">Biquinis</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="65" />
            <a href="/moda-praia/maio?O=OrderByReleaseDateDESC" title="Maiô">Maiôs</a>
         </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="66" />
            <a href="/moda-praia/top-biquinis?O=OrderByReleaseDateDESC" title="Top Biquinis">Biquinis Tops </a>
         </li>
         <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="67" />
            <a href="/moda-praia/biquinis-bottom?O=OrderByReleaseDateDESC" title="Maiô">Biquinis Bottom</a>
         </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="68" />
            <a href="/moda-praia/body-alaiah?O=OrderByReleaseDateDESC" title="Body">Body</a>
        </li>
    </ul>
    <!-- ul class="bolsa even"></ul-->
    <h3 class="sale has-sub">
        <span></span>
        <a class="pai" href="/liquidacao?&amp;O=OrderByBestDiscountDESC" title="Sale" itemscope itemtype="http://schema.org/ListItem"><meta itemprop="position" content="53" />Liquidação</a>
    </h3>
    <ul class="sale">
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="54" />
            <a href="/acessorios-sale?&amp;O=OrderByBestDiscountDESC" title="Sale Acessórios">Acessórios</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="55" />
            <a href="/biquinis-sale?&amp;O=OrderByBestDiscountDESC" title="Sale Biquiniss">Biquinis</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="56" />
            <a href="/blusas-sale?&amp;O=OrderByBestDiscountDESC" title="Sale Blusas">Blusas</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="57" />
            <a href="/bolsas-sale?&amp;O=OrderByBestDiscountDESC title="Sale Bolsas">Bolsas</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="58" />
            <a href="/calcas-sale?&amp;O=OrderByBestDiscountDESC" title="Sale Calças">Calças</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="59" />
            <a href="/casacos-sale?&amp;O=OrderByBestDiscountDESC" title="Sale Casacos">Casacos</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="60" />
            <a href="/macacoes-sale?&amp;O=O=OrderByBestDiscountDESC" title="Sale Blusas">Macacões</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="61" />
            <a href="/saias-sale?&amp;O=OrderByBestDiscountDESC title="Sale Saias">Saias</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="62" />
            <a href="/sapatos-sale?&amp;O=OrderByBestDiscountDESC" title="Sale Sapatos">Sapatos</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="63" />
            <a href="/shorts-sale?&amp;O=OrderByBestDiscountDESC" title="Sale Shorts-Bermudas">Shorts</a>
        </li>
        <li itemscope itemtype="http://schema.org/ListItem">
            <meta itemprop="position" content="64" />
            <a href="/vestidos-sale?&amp;O=OrderByReleaseDateDESC" title="Sale Vestidos">Vestidos</a>
        </li>
    </ul>
</div><!-- ATENÇÃO, esse erro prejudica a performance do seu site, o conteudo de nome Novo Menu não foi renderizado por nao ser um XDocument válido, erro: - 'itemtype' is an unexpected token. The expected token is '='. Line 1, position 48.--></nav></menu><!-- nav --></div><div class="pitBar linha pad center"><div class="box-banner"><a href="/Institucional/Politica-de-retirada-em-loja"><img width="684" height="30" id="ihttp://aquamar.vteximg.com.br/arquivos/ids/199374/2016-bannerRetiradaLoja2.jpg" alt="pitBarEsquerda" src="http://aquamar.vteximg.com.br/arquivos/ids/199374/2016-bannerRetiradaLoja2.jpg" complete="complete"/></a></div><div class="box-banner"><a href="#"><img width="962" height="30" id="ihttp://aquamar.vteximg.com.br/arquivos/ids/199373/2016-bannerPit4.jpg" alt="pitBarDireita" src="http://aquamar.vteximg.com.br/arquivos/ids/199373/2016-bannerPit4.jpg" complete="complete"/></a></div></div></header><!-- /footer --><script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/Track.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/thickbox.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/json2.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/vtex.viewPart.CallCenterDisclaimer.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/vtex.viewPart.ajaxLoader_V2.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/vtex.commerce.batchbuy.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/vtex.jsevents.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/vtex.skuEvents.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/vtex.skuEvents.skuDataFetcher.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/jquery.livequery.min.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/prettyPhoto/js/jquery.prettyPhoto.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/prettyPhoto/js/lean-prettyPhoto.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/vtex.commerce.Compare.js?v=1.4.710.1275"  type="text/javascript"></script>
<script language="javascript" src="http://aquamar.vteximg.com.br/Scripts/mobile/vtex.make.mobile.pager.js?v=1.4.710.1275"  type="text/javascript"></script>
</body>
  <!-- js -->
  <script type="text/javascript">
$(document).ready(function() { 
    var browser = jQuery.browser.msie?'ie':/(chrome)/.test(navigator.userAgent.toLowerCase())?'chrome':jQuery.browser.mozilla?'fx':'other';
    var version = jQuery.browser.version.split('.').shift();
    $("html").addClass(browser+" "+browser+version);
});
</script>
  <script type="text/javascript" src="//aquamar.vteximg.com.br/arquivos/jquery.cookie.js"></script>
  <script src="//aquamar.vteximg.com.br/arquivos/cycle2.js" type="text/javascript"></script>
  <script src="//aquamar.vteximg.com.br/arquivos/jquery.feedBackBox2.js" type="text/javascript"></script>
  <script src="//aquamar.vteximg.com.br/arquivos/jquery.elevateZoom-3.0.8.min.js"></script>
  <script src="//aquamar.vteximg.com.br/arquivos/2016-aquamar.js" type="text/javascript"></script>
  <script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
  <script type="text/javascript">stLight.options({publisher: "f37f522c-e968-40e2-93e8-eac6d4bacc70", doNotHash: false, doNotCopy: false, hashAddressBar: false});</script>
  <script type="application/ld+json">
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "url": "http://www.eaquamar.com.br",
  "logo": "http://aquamar.vteximg.com.br/arquivos/gt-logo.gif",
  "contactPoint": [{
    "@type": "ContactPoint",
    "telephone": "+55 21 3034-1075",
    "contactType": "customer service",
    "availableLanguage" : ["English","Portuguese"]
  },{
    "@type" : "ContactPoint",
    "telephone" : "+55 21 97644-0137",
    "contactType" : "Whatsapp",
    "contactOption" : "TollFree",
    "availableLanguage" : ["English","Portuguese"]
  }]
},
{
  "@context": "http://schema.org",
  "@type": "Organization",
  "url": "http://www.eaquamar.com.br",
  "logo": "http://aquamar.vteximg.com.br/arquivos/gt-logo.gif"
}
</script>
  <script type="text/javascript">
window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
_.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute("charset","utf-8");
$.src="//v2.zopim.com/?42eA2ACJY5K1PKgdrt5TpeHNXu5LsVNt";z.t=+new Date;$.
type="text/javascript";e.parentNode.insertBefore($,e)})(document,"script");
</script>
  <!-- /js -->
</html>